6+6

var number = 7

number+4
number==6
 var word="hello"
word="anvesh"
var pi=3.1444
let p=1.5

word+" "+"world"

pi=42