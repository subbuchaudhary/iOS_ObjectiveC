//
//  MyfriendsSegmentViewController.m
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "MyfriendsSegmentViewController.h"
#import "MyFriendsTableViewCell.h"

@interface MyfriendsSegmentViewController ()
{
    NSArray *profilePics, *names, *details, *socialIcons;
}

@end

@implementation MyfriendsSegmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.myFriendsTableView.rowHeight = UITableViewAutomaticDimension;
    self.myFriendsTableView.estimatedRowHeight= 101;
    profilePics = @[@"facebookIcon", @"linkedInIcon", @"googleIcon", @"facebookIcon", @"linkedInIcon", @"googleIcon"];
    names = @[@"Alfred Pennyworth", @"Gary Robertson", @"Gotham General", @"Alfred Pennyworth", @"Gary Robertson", @"Gotham General"];
    details = @[@"23 mutual friends", @"Sr.UX/UI Designer", @"UI Developer at Wipro", @"23 mutual friends", @"Sr.UX/UI Designer", @"UI Developer at Wipro"];
    socialIcons = @[@"facebookIcon", @"linkedInIcon", @"googleIcon", @"facebookIcon", @"linkedInIcon", @"googleIcon"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return names.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyFriendsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyFriendsTableViewCell"];
    if(cell == nil)
    {
        cell = [[MyFriendsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyFriendsTableViewCell"];
    }
    cell.profilePic.image = [UIImage imageNamed:[profilePics objectAtIndex:indexPath.row]];
    cell.nameLabel.text = [names objectAtIndex:indexPath.row];
    cell.DetailsLabel.text = [details objectAtIndex:indexPath.row];
    cell.socialIcon.image = [UIImage imageNamed:[socialIcons objectAtIndex:indexPath.row]];
    return cell;
}


@end
