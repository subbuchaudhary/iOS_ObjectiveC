//
//  SignUpViewController.m
//  HopeWit_iOS
//
//  Created by Nelakudhiti, Subba on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "SignUpViewController.h"
#import "SignUpTableViewCell.h"
#import "SocialNetworkIntegrationCell.h"

@interface SignUpViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.signUpTableView.estimatedRowHeight = 80;
    //the estimatedRowHeight but if is more this autoincremented with autolayout
    self.signUpTableView.rowHeight = UITableViewAutomaticDimension;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==1) {
        
        SignUpTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"SignUpTableViewCell"];
        if (cell==nil) {
            cell=[[SignUpTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SignUpTableViewCell"];
        }
        cell=contentcell;
    }else
    {
        SocialNetworkIntegrationCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"SocialNetworkIntegrationCell"];
        if (cell==nil) {
            cell=[[SocialNetworkIntegrationCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SocialNetworkIntegrationCell"];
        }
        cell=contentcell;
    }
    
    return cell;
}

//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    SignUpTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellIds"];
//    if(cell == nil)
//    {
//        cell = [[SignUpTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellIds"];
//    }
//    [cell.profilePicBtn addTarget:self action:@selector(profilePicActions) forControlEvents:UIControlEventAllTouchEvents];
//    return cell;
//}

-(void )profilePicActions
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"select Option" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *takePhoto = [UIAlertAction actionWithTitle:@"Take Photo" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
     UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
        //  [self presentViewController:picker animated:YES completion:nil];
        // [picker release];
        
    }];
    UIAlertAction *choosePhoto = [UIAlertAction actionWithTitle:@"Choose Photo" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
      UIImagePickerController  *picker2 = [[UIImagePickerController alloc] init];
        picker2.delegate = self;
        [picker2 setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
        //  [self presentViewController:picker2 animated:YES completion:nil];
        // [picker2 release];
        
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    //UIActionSheet
    [alert addAction:takePhoto];
    [alert addAction:choosePhoto];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    image = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
