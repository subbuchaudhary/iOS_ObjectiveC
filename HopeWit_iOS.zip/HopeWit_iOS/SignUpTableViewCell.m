//
//  SignUpTableViewCell.m
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "SignUpTableViewCell.h"

@implementation SignUpTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

//- (IBAction)picUploadClkd:(id)sender {
//    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"select Option" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
//    UIAlertAction *takePhoto = [UIAlertAction actionWithTitle:@"Take Photo" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
//        picker = [[UIImagePickerController alloc] init];
//        picker.delegate = self;
//        [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
//      //  [self presentViewController:picker animated:YES completion:nil];
//       // [picker release];
//        
//    }];
//    UIAlertAction *choosePhoto = [UIAlertAction actionWithTitle:@"Choose Photo" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
//        picker2 = [[UIImagePickerController alloc] init];
//        picker2.delegate = self;
//        [picker2 setSourceType:UIImagePickerControllerSourceTypeCamera];
//        //  [self presentViewController:picker2 animated:YES completion:nil];
//        // [picker2 release];
//        
//    }];
//    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
//    }];
//    //UIActionSheet
//    [alert addAction:takePhoto];
//    [alert addAction:choosePhoto];
//    [alert addAction:cancel];
//    [self.inputViewController presentViewController:alert animated:YES completion:nil];
//}
@end
