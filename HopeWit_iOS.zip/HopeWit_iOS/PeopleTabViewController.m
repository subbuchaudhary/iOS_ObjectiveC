//
//  PeopleTabViewController.m
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "PeopleTabViewController.h"
#import "MyfriendsSegmentViewController.h"
#import "DiscoverSegmentViewController.h"

@interface PeopleTabViewController ()

@end

@implementation PeopleTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabBarItem.selectedImage = [[UIImage imageNamed:@"People_active"]
                                     imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    self.tabBarItem.image = [[UIImage imageNamed:@"People"]
                             imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    MyfriendsSegmentViewController *myFriendsScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"MyfriendsSegmentViewController"];
    [self addChildViewController:myFriendsScreen];
    [myFriendsScreen didMoveToParentViewController:self];
    myFriendsScreen.view.frame = CGRectMake(0, 90, self.view.frame.size.width, self.view.frame.size.height-90);
    [self.view addSubview:myFriendsScreen.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)indexChanged:(id)sender {
    switch (self.segmentedControl.selectedSegmentIndex) {
        case 0:
        {
            MyfriendsSegmentViewController *myFriendsScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"MyfriendsSegmentViewController"];
            [self addChildViewController:myFriendsScreen];
            [myFriendsScreen didMoveToParentViewController:self];
            myFriendsScreen.view.frame = CGRectMake(0, 90, self.view.frame.size.width, self.view.frame.size.height-90);
            [self.view addSubview:myFriendsScreen.view];
        }
            break;
        case 1:
        {
            DiscoverSegmentViewController *discoverFriendsScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"DiscoverSegmentViewController"];
            [self addChildViewController:discoverFriendsScreen];
            [discoverFriendsScreen didMoveToParentViewController:self];
            discoverFriendsScreen.view.frame = CGRectMake(0, 90, self.view.frame.size.width, self.view.frame.size.height-90);
            [self.view addSubview:discoverFriendsScreen.view];
        }
            break;
            
        default:
            break;
    }
}
@end
