//
//  DiscoverTabViewController.m
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "DiscoverTabViewController.h"
#import "DiscoverTableViewCell.h"

@interface DiscoverTabViewController ()
{
    NSArray *profilePics, *names, *timePeriod, *distance, *icons;
}

@end

@implementation DiscoverTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.discoverTableView.rowHeight = UITableViewAutomaticDimension;
    self.discoverTableView.estimatedRowHeight= 101;
    profilePics = @[@"facebookIcon", @"linkedInIcon", @"googleIcon"];
    names = @[@"Alfred Pennyworth", @"Gary Robertson", @"Gotham General"];
    timePeriod = @[@"1 min ago", @"2 min ago", @"5 min ago"];
    distance = @[@"1 km", @"1 km", @"2 km"];
    icons = @[@"facebookIcon", @"linkedInIcon", @"googleIcon"];
    self.tabBarItem.selectedImage = [[UIImage imageNamed:@"Discover_active"]
                                     imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    self.tabBarItem.image = [[UIImage imageNamed:@"Discover"]
                             imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return distance.count;
    return profilePics.count;
    return names.count;
    return timePeriod.count;
    return icons.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DiscoverTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DiscoverTableViewCell"];
    if(cell == nil)
    {
        cell = [[DiscoverTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DiscoverTableViewCell"];
    }
    cell.profilePic.image = [UIImage imageNamed:[profilePics objectAtIndex:indexPath.row]];
    cell.nameLabel.text = [names objectAtIndex:indexPath.row];
    cell.timeLabel.text = [timePeriod objectAtIndex:indexPath.row];
    cell.distanceLabel.text = [distance objectAtIndex:indexPath.row];
    cell.iconPic.image = [UIImage imageNamed:[icons objectAtIndex:indexPath.row]];
    return cell;
}

@end
