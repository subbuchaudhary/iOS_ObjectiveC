//
//  SocialNetworkIntegrationCell.m
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "SocialNetworkIntegrationCell.h"

@implementation SocialNetworkIntegrationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)linkedInIntegrate:(id)sender {
}
- (IBAction)facebookIntegrate:(id)sender {
}
- (IBAction)googleIntegrate:(id)sender {
}
@end
