//
//  SocialNetworkIntegrationCell.h
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SocialNetworkIntegrationCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *linkedInBtn;
- (IBAction)linkedInIntegrate:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *facebookBtn;
- (IBAction)facebookIntegrate:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *googlePlusBtn;
- (IBAction)googleIntegrate:(id)sender;

@end
