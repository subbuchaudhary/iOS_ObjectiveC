//
//  PageContentViewController.h
//  HopeWit_iOS
//
//  Created by Nelakudhiti, Subba on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageContentViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *pageViewImage;
@property (weak, nonatomic) IBOutlet UILabel *pageViewImageTitle;
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;

@property NSUInteger pageIndex;
@property NSString *imgFile;
@property NSString *txtTitle;
@property NSString *descText;
@end
