//
//  SignUpTableViewCell.h
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpTableViewCell : UITableViewCell<UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    UIImagePickerController *picker;
    UIImagePickerController *picker2;
    UIImage *image;
    IBOutlet UIImageView *imageView;
}
@property (weak, nonatomic) IBOutlet UILabel *photoUploadTitle;
@property (weak, nonatomic) IBOutlet UIButton *profilePicBtn;
- (IBAction)picUploadClkd:(id)sender;

@end
