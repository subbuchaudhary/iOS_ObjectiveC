//
//  DiscoverSegmentViewController.m
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "DiscoverSegmentViewController.h"
#import "DiscoverSegTableViewCell.h"

@interface DiscoverSegmentViewController ()
{
    NSArray *profilePics, *names, *details, *invite;
}

@end

@implementation DiscoverSegmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.discoverFriendsTableView.rowHeight = UITableViewAutomaticDimension;
    self.discoverFriendsTableView.estimatedRowHeight= 101;
    profilePics = @[@"facebookIcon", @"linkedInIcon", @"googleIcon", @"facebookIcon", @"linkedInIcon", @"googleIcon"];
    names = @[@"Alfred Pennyworth", @"Gary Robertson", @"Gotham General", @"Alfred Pennyworth", @"Gary Robertson", @"Gotham General"];
    details = @[@"23 mutual friends", @"Sr.UX/UI Designer", @"UI Developer at Wipro", @"23 mutual friends", @"Sr.UX/UI Designer", @"UI Developer at Wipro"];
    invite = @[@"facebookIcon", @"linkedInIcon", @"googleIcon", @"facebookIcon", @"linkedInIcon", @"googleIcon"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return names.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DiscoverSegTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DiscoverSegTableViewCell"];
    if(cell == nil)
    {
        cell = [[DiscoverSegTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DiscoverSegTableViewCell"];
    }
    cell.profilePic.image = [UIImage imageNamed:[profilePics objectAtIndex:indexPath.row]];
    cell.nameLabel.text = [names objectAtIndex:indexPath.row];
    cell.detailsLabel.text = [details objectAtIndex:indexPath.row];
    cell.invitePic.image = [UIImage imageNamed:[invite objectAtIndex:indexPath.row]];
    return cell;
}

@end
