//
//  OTPViewController.h
//  HopeWit_iOS
//
//  Created by Nelakudhiti, Subba on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTPViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *mobileNumberField;
- (IBAction)sendOtpClkd:(id)sender;

@end
