//
//  MyFriendsTableViewCell.h
//  HopeWit_iOS
//
//  Created by Subbu Chaudhary on 5/13/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFriendsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profilePic;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *DetailsLabel;
@property (weak, nonatomic) IBOutlet UIImageView *socialIcon;

@end
