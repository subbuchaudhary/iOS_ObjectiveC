//
//  GELoginModalViewController_iPhone.m
//  MobileDS
//
//  Created  on 5/16/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import "GELoginModalViewController_iPhone.h"
#define TOOLBAR_HEIGHT 44
#define TOOLBAR_BUTTON_PADDING 10
#define TITLEBAR_FONT_SIZE 12
#define HERO_BG_HEIGHT 35
#define TEXTVIEWPADDING 22
#define FORM_ELEMENT_HERO_OVERLAP 27
#define FORM_ELEMENT_WIDTH 276
#define FORM_ELEMENT_HEIGHT 46
#define BUTTON_TOP_MARGIN 10
#define SMALL_BUTTON_MARGIN 14

@interface GELoginModalViewController_iPhone ()

@end

@implementation GELoginModalViewController_iPhone

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [self setupLogin];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    [self.acctTextField becomeFirstResponder];

}

-(void)setupLogin
{
    self.view.backgroundColor = GE_COLOR_GROUND_ACCENT;
    UIView *toolBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, TOOLBAR_HEIGHT)];
    toolBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    toolBar.backgroundColor = GE_COLOR_CHROME;
    
    GEBarButton *closeButton = [[GEBarButton alloc]initWithFrame:CGRectMake(TOOLBAR_BUTTON_PADDING, 0, 44, 48) andText:@"CANCEL"];
    [closeButton addTarget:self action:@selector(dismissModal) forControlEvent:UIControlEventTouchUpInside];
    [toolBar addSubview:closeButton];
    
    GELabel *modalTitleView = [[GELabel alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 48) Font:GE_Inspira_Medium Size:TITLEBAR_FONT_SIZE andColor:GE_COLOR_WHITE];
    modalTitleView.textAlignment = NSTextAlignmentCenter;
    modalTitleView.text = @"SIGN IN";
    [toolBar addSubview:modalTitleView];
    
    [self.view addSubview:toolBar];
    
    UIView *heroBG = [[UIView alloc]initWithFrame:CGRectMake(0, TOOLBAR_HEIGHT, self.view.frame.size.width, HERO_BG_HEIGHT)];
    heroBG.backgroundColor = GE_COLOR_GROUND;
    
    [self.view addSubview:heroBG];
    

    UIButton *dismissKeyboardButton = [UIButton buttonWithType:UIButtonTypeCustom];
    CGRect dismissKeyboardFrame = self.view.frame;
    dismissKeyboardFrame.origin.y += TOOLBAR_HEIGHT;
    dismissKeyboardButton.frame = dismissKeyboardFrame;
    [dismissKeyboardButton addTarget:self action:@selector(dismissKeyboardAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:dismissKeyboardButton];
    self.acctTextField = [[GETextField alloc]initWithFrame:CGRectMake(TEXTVIEWPADDING, HERO_BG_HEIGHT  + TOOLBAR_HEIGHT - FORM_ELEMENT_HERO_OVERLAP, FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT) Font:GE_Inspira_Bold Size:12 andColor:self.accentColor andPlaceholder:@"USER ID (REQUIRED)" ];
    

    self.acctTextField.backgroundColor = GE_COLOR_WHITE;
    
    self.acctTextField.layer.cornerRadius = 5.0;
    self.acctTextField.delegate = self;
    
    
    [self.view addSubview:self.acctTextField];
    
    self.passTextField = [[GETextField alloc]initWithFrame:CGRectMake(TEXTVIEWPADDING, self.acctTextField.frame.origin.y + self.acctTextField.frame.size.height + 2, FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT) Font:GE_Inspira_Bold Size:12 andColor:self.accentColor andPlaceholder:@"PASSWORD (REQUIRED)" ];
    self.passTextField.backgroundColor = GE_COLOR_WHITE;
    self.passTextField.layer.cornerRadius = 5.0;
    self.passTextField.secureTextEntry = YES;
    self.passTextField.delegate = self;
    
    [self.view addSubview:self.passTextField];
    
    
    self.signInButton = [[GEButton alloc]initWithStyle:GEButtonStyleLarge andColor:self.accentColor];
    self.signInButton.frame = CGRectMake(TEXTVIEWPADDING, self.passTextField.frame.origin.y + self.passTextField.frame.size.height + BUTTON_TOP_MARGIN, FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT);
    //self.signInButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    //self.signInButton.buttonSize = CGSizeMake(FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT);
    self.signInButton.buttonColor = self.accentColor;
    
    self.signInButton.buttonText = @"Sign In";
    
    [self.signInButton.button addTarget:self action:@selector(signInButtonAction:) forControlEvents:UIControlEventTouchUpInside ];
    [self.view addSubview:self.signInButton];
    
    UIView *smallButtonBox = [[UIView alloc]initWithFrame:CGRectMake(TEXTVIEWPADDING, self.signInButton.frame.origin.y + self.signInButton.frame.size.height + SMALL_BUTTON_MARGIN, FORM_ELEMENT_WIDTH, 44)];
    // smallButtonBox.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    
    
    UIEdgeInsets smallButtonInsets = UIEdgeInsetsMake(-16, 0, 16, 0);
    
    self.createAcctButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.createAcctButton.frame = CGRectMake(0, 0, self.signInButton.frame.size.width/2, 44);
    [self.createAcctButton setTitle:@"Create Account" forState:UIControlStateNormal];
    self.createAcctButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-Bold" size:12];
    self.createAcctButton.contentHorizontalAlignment= UIControlContentHorizontalAlignmentLeft;
    [self.createAcctButton setTitleColor:GE_COLOR_GRAY forState:UIControlStateNormal];
    [self.createAcctButton setTitleColor:GE_COLOR_CHROME forState:UIControlStateHighlighted];
    
    
    self.createAcctButton.titleEdgeInsets = smallButtonInsets;
    
    [smallButtonBox addSubview:self.createAcctButton];
    
    
    self.forgotPassButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.forgotPassButton.frame = CGRectMake(smallButtonBox.frame.size.width/2, 0, self.signInButton.frame.size.width/2, 44);
    [self.forgotPassButton setTitle:@"Forgot Password?" forState:UIControlStateNormal];
    self.forgotPassButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-Bold" size:12];
    [self.forgotPassButton setTitleColor:GE_COLOR_GRAY forState:UIControlStateNormal];
    [self.forgotPassButton setTitleColor:GE_COLOR_CHROME forState:UIControlStateHighlighted];
    self.forgotPassButton.contentHorizontalAlignment= UIControlContentHorizontalAlignmentRight;
    self.forgotPassButton.titleEdgeInsets = smallButtonInsets;
    
    
    [smallButtonBox addSubview:self.forgotPassButton];
    
    [self.view addSubview:smallButtonBox];
    
    [self.acctTextField becomeFirstResponder];

    
    
    
}

#pragma mark Actions


-(void)dismissKeyboardAction:(id)sender{
    [self.acctTextField resignFirstResponder];
    [self.passTextField resignFirstResponder];

}
-(void)dismissModal
{


    
    [self dismissViewControllerAnimated:YES completion:nil];

}

-(void)signInButtonAction:(id)sender
{
    //Here is where Authentication Happens
    
    UIAlertView *badLogin = [[UIAlertView alloc]initWithTitle:nil message:@"The user ID or password you entered is incorrect." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    
    [badLogin show];
    
}

#pragma mark TextView Delgates

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (range.location == 0 && string.length > 0) {
        textField.font = [UIFont fontWithName:@"LucidaGrande" size:textField.font.pointSize];
    }
    else if (range.location <=0 && string.length <= 0) {
        textField.font = [UIFont fontWithName:@"GEInspira-Bold" size:textField.font.pointSize];
    }
    return YES;
}



#pragma mark AlertViewDelegates
-(void)alertViewCancel:(UIAlertView *)alertView
{
    
    
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //go to create account
    
}

-(void)setAccentColor:(UIColor *)accentColor
{
    _accentColor = accentColor;
    self.signInButton.buttonColor = _accentColor;
    self.acctTextField.textColor = _accentColor;
    self.passTextField.textColor = _accentColor;

}

-(BOOL)shouldAutorotate
{
    return YES;
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}



@end
