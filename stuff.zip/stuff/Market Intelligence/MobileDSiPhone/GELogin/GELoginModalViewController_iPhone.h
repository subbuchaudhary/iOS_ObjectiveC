//
//  GELoginModalViewController_iPhone.h
//  MobileDS
//
//  Created  on 5/16/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import "GEViewController.h"
#import "GETextField.h"

@interface GELoginModalViewController_iPhone : GEViewController <UITextFieldDelegate>

@property (nonatomic, strong) GEButton *signInButton;
@property (nonatomic, strong) UIButton *createAcctButton;
@property (nonatomic, strong) UIButton *forgotPassButton;
@property (nonatomic, strong) GETextField *acctTextField;
@property (nonatomic, strong) GETextField *passTextField;
@property (nonatomic, strong) UIColor *accentColor;


@end
