//
//  SurveyUtil.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/4/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "SurveyUtil.h"

#import "Survey+SurveyCustom.h"
#import "SurveyType.h"
#import "SuperCategory.h"
#import "SurveyCategory.h"
#import "SubCategory.h"
#import "Topic.h"
#import "Dealer+DealerCustom.h"
#import "DealerSummaryEntity+DealerSummaryCustom.h"
#import "FSR+FSRCustom.h"
#import "MIDBHelper.h"
#import "FSGMICustomerData.h"


@implementation SurveyUtil
@synthesize superCategoryList;
@synthesize customerRetention;
@synthesize creditLineIncrease;
@synthesize flooringOpportunity;

@synthesize customerExperience;
@synthesize dealerList;

const NSString* ENCRYPTION_KEY= @"MI-MarketIntelligence";

- (id) init
{
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    //Load Category Hierarchy from data store. If first time, create
    SurveyType* sales = (SurveyType*)    [self loadEntityOfType:@"SurveyType" withName:@"Sales Opportunity"];
    SurveyType* custExp = (SurveyType*)    [self loadEntityOfType:@"SurveyType" withName:@"Customer Experience"];
    
    if ((sales == Nil) || (custExp == Nil))
    {
    
        sales = (SurveyType*)[self newEntityForName:@"SurveyType"];
        sales.name =@"Sales Opportunity";
        [sales addSuperCategoryListObject:[self createCustomerRetention]];
        [sales addSuperCategoryListObject:[self createFlooringOpportunity]];
        [sales addSuperCategoryListObject:[self createCreditLineIncrease]];
 
        custExp = (SurveyType*)[self newEntityForName:@"SurveyType"];
        custExp.name = @"Customer Experience";
        [custExp addSuperCategoryListObject:[self createCustomerExperience]];
        
        [self saveCurrentSurvey];
    }
    else
    {
        customerRetention = [sales.superCategoryList objectAtIndex:0];
        flooringOpportunity = [sales.superCategoryList objectAtIndex:1];
        creditLineIncrease = [sales.superCategoryList objectAtIndex:2];
        
        customerExperience = [custExp.superCategoryList objectAtIndex:0];
        
    }
    
    // If there is a survey load it otherwise create a new one

    [self loadSurvey];
    [self loadDealerList];
    return self;
}

- (void) loadCategoryHierarchy
{
    [self loadEntityOfType:@"SurveyType" withName:@"Sales Opportunity"];
    [self loadEntityOfType:@"SurveyType" withName:@"Customer Experience"];
}

- (void) loadSurvey
{
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Survey" inManagedObjectContext:appDelegate.moc];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setReturnsObjectsAsFaults:NO];
    [request setEntity:entity];
    NSError *error;
    NSArray *array = [appDelegate.moc executeFetchRequest:request error:&error];
    if (array.count == 0)
    {
        appDelegate.currentSurvey = (Survey*)[self newEntityForName:@"Survey"];
        appDelegate.currentSurvey.surveyID = @"100";
    }
    else
    {
        appDelegate.currentSurvey = [array objectAtIndex:0];
        [appDelegate.currentSurvey decryptWithKey:ENCRYPTION_KEY];
        NSLog(@" Loaded survey %@", appDelegate.currentSurvey.commentList);
    }
}

- (void) loadDealerList
{
    @synchronized(self)
    {
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Dealer" inManagedObjectContext:appDelegate.moc];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setReturnsObjectsAsFaults:NO];
    [request setEntity:entity];
    NSError *error;
    NSArray *array = [appDelegate.moc executeFetchRequest:request error:&error];
    if (array.count == 0)
    {
        [self initDealerList];
    }
    else
    {
        self.dealerList = [[NSMutableArray alloc] initWithArray:array];
        for (int i=0; i< dealerList.count;i++)
        {
            Dealer* dealer = [dealerList objectAtIndex:i];
           [dealer decryptWithKey:ENCRYPTION_KEY];
            
        }
    }
    // Now load all Dealer Summaries
    NSEntityDescription *dealer = [NSEntityDescription entityForName:@"DealerSummaryEntity" inManagedObjectContext:appDelegate.moc];
    NSFetchRequest *dealerSummaryrequest = [[NSFetchRequest alloc] init];
    [dealerSummaryrequest setEntity:dealer];
    NSArray *dealerSummaryArray = [appDelegate.moc executeFetchRequest:dealerSummaryrequest error:&error];
        
    NSLog(@"Dealer list loaded %d dealers and %d dealer summaries", array.count, dealerSummaryArray.count);
    }
}


/**
 * Creating hierarchies from spreadsheet for now
*/

- (SuperCategory*) createCustomerRetention
{
    NSLog(@" MOC : %@", appDelegate.moc);
     
    SuperCategory *cr = (SuperCategory*)[self newEntityForName:@"SuperCategory"];
    cr.keyId = [[NSNumber alloc] initWithInt:1];
    cr.name = @"Customer Retention";

    

    SurveyCategory *pricing =(SurveyCategory*)[self newEntityForName:@"SurveyCategory"];
    pricing.name = @"Pricing (Rates/Structure)" ;
    pricing.keyId = [[NSNumber alloc] initWithInt:2];
    
    // Sub Categories
    SubCategory* t1 = [self newSubCategoryEntityWithName:@"FFP/Credit Line Utilization" key:1];
    t1.parent = pricing;
    [pricing addCategoryListObject:t1];
    
    SubCategory* t2 = [self newSubCategoryEntityWithName:@"Interest Rate" key:2];
    [pricing addCategoryListObject:t2];

    SubCategory* t3 =  [self newSubCategoryEntityWithName:@"OEM Agreement" key:3];
    [pricing addCategoryListObject:t3];
    
    SubCategory* t4 = [self newSubCategoryEntityWithName:@"Due in Full" key:4];
    [pricing addCategoryListObject:t4];
    
    SubCategory* t5 = [self newSubCategoryEntityWithName:@"Curtailments" key:5];
    [pricing addCategoryListObject:t5];
    
    SubCategory* t6 = [self newSubCategoryEntityWithName:@"Other" key:6];
    [pricing addCategoryListObject:t6];

    SurveyCategory* ownershipChange = [self newSurveyCategoryEntityWithName:@"Change Of Ownership" key:2];
    
    SurveyCategory* competitiveThreat = [self newSurveyCategoryEntityWithName:@"Competitive Threat" key:3];
    
    SubCategory* ct1 = [self newSubCategoryEntityWithName:@"Customer Satisfaction" key:8];
    Topic* st1 = [self newTopicEntityWithName:@"Miscommunication (Non GE)" key:9];
    Topic* st2 = [self newTopicEntityWithName:@"Policies And Procedures" key:10];
    Topic* st3 = [self newTopicEntityWithName:@"Ease Of Doing Business" key:11];
    [ct1 addTopicListObject:st1];
    [ct1 addTopicListObject:st2];
    [ct1 addTopicListObject:st3];
    [competitiveThreat addCategoryListObject:ct1];

    SubCategory* ct2 = [self newSubCategoryEntityWithName:@"Technology/Amenities" key:11];
    [competitiveThreat addCategoryListObject:ct2];
    
    SubCategory* ct3 = [self newSubCategoryEntityWithName:@"Adverse Media" key:12];
    [competitiveThreat addCategoryListObject:ct3];
    
    SubCategory* ct4 = [self newSubCategoryEntityWithName:@"Local Bank/Finance Company" key:13];
    [competitiveThreat addCategoryListObject:ct4];
    
    SubCategory* ct5 = [self newSubCategoryEntityWithName:@"Other" key:14];
    [competitiveThreat addCategoryListObject:ct5];
    

    [cr addCategoryListObject:pricing];
    [cr addCategoryListObject:ownershipChange];
    [cr addCategoryListObject:competitiveThreat];

    customerRetention = cr;
    return cr;
}

- (SuperCategory*) createFlooringOpportunity
{
    SuperCategory* fo = [self newSuperCategoryEntityWithName:@"Flooring Opportunity" key:2];

    SurveyCategory* newProductLine = [self newSurveyCategoryEntityWithName:@"New Product Line" key:15];
    SurveyCategory* openAccount = [self newSurveyCategoryEntityWithName:@"Open Account" key:16];
    SurveyCategory* buyoutOpportunity = [self newSurveyCategoryEntityWithName:@"Buyout Opportunity" key:17];
    SurveyCategory* preOwned = [self newSurveyCategoryEntityWithName:@"Pre-Owned" key:18];
    SurveyCategory* rentalProgram = [self newSurveyCategoryEntityWithName:@"Rental Program" key:19];
    
    SurveyCategory* newMarket = [self newSurveyCategoryEntityWithName:@"NRD - New Market Growth" key:20];
    SurveyCategory* newProduct = [self newSurveyCategoryEntityWithName:@"NRD - New Products" key:21];
    SurveyCategory* existingMarketGrowth = [self newSurveyCategoryEntityWithName:@"NRD - Existing Market Growth" key:21];
    
    [fo addCategoryListObject:newProductLine];
    [fo addCategoryListObject:openAccount];
    [fo addCategoryListObject:buyoutOpportunity];
    [fo addCategoryListObject:preOwned];
    [fo addCategoryListObject:rentalProgram];
    [fo addCategoryListObject:newMarket];
    [fo addCategoryListObject:newProduct];
    [fo addCategoryListObject:existingMarketGrowth];

    flooringOpportunity = fo;
    return fo;
}

- (SuperCategory*) createCreditLineIncrease
{
    SuperCategory* ci = [self newSuperCategoryEntityWithName:@"Credit Line Increase" key:3];
  
    SurveyCategory* redistCreditLine = [self newSurveyCategoryEntityWithName:@"Redistribution Of Credit Line" key:23];
    SurveyCategory* increaseSpecificOEM = [self newSurveyCategoryEntityWithName:@"Increase Of Specific OEM" key:24];
    
    SurveyCategory* tempIncrease = [self newSurveyCategoryEntityWithName:@"Temporary Increase" key:25];
    SubCategory* specialCirumstance = [self newSubCategoryEntityWithName:@"Special Circumstance" key:25];
    SubCategory* seasonal = [self newSubCategoryEntityWithName:@"Seasonal" key:26];
    SubCategory* other = [self newSubCategoryEntityWithName:@"Other" key:27];
    
    [tempIncrease addCategoryListObject:specialCirumstance];
    [tempIncrease addCategoryListObject:seasonal];
    [tempIncrease addCategoryListObject:other];

    
    SurveyCategory* assetLending = [self newSurveyCategoryEntityWithName:@"Asset Backed Lending" key:28];
    SurveyCategory* shortTermAR = [self newSurveyCategoryEntityWithName:@"Short Term A/R" key:29];
    
    [ci addCategoryListObject:redistCreditLine];
    [ci addCategoryListObject:increaseSpecificOEM];
    [ci addCategoryListObject:tempIncrease];
    [ci addCategoryListObject:assetLending];
    [ci addCategoryListObject:shortTermAR];
    
    creditLineIncrease = ci;
    return ci;
}


- (SuperCategory*) createCustomerExperience
{
    SuperCategory* cx = [self newSuperCategoryEntityWithName:@"CX" key:5];

    SurveyCategory* timelyResponse = [self newSurveyCategoryEntityWithName:@"Timely Response" key:33];
    SubCategory* returnedCalls = [self newSubCategoryEntityWithName:@"Returned Calls" key:33];
    SubCategory* issueResolution = [self newSubCategoryEntityWithName:@"Issue Resolution" key:34];
    SubCategory* other = [self newSubCategoryEntityWithName:@"Other" key:35];
    [timelyResponse addCategoryListObject:returnedCalls];
    [timelyResponse addCategoryListObject:issueResolution];
    [timelyResponse addCategoryListObject:other];
    
    SurveyCategory* generalCustomerSvc = [self newSurveyCategoryEntityWithName:@"General Customer Service" key:36];
    SubCategory* accountMgr = [self newSubCategoryEntityWithName:@"Account Manager" key:36];
    SubCategory* fieldSvcs = [self newSubCategoryEntityWithName:@"Field Services" key:37];
    SubCategory* commercial = [self newSubCategoryEntityWithName:@"Commercial" key:38];
    SubCategory* oem = [self newSubCategoryEntityWithName:@"OEM" key:39];
    SubCategory* otherTopic = [self newSubCategoryEntityWithName:@"Other" key:40];
    [generalCustomerSvc addCategoryListObject:accountMgr];
    [generalCustomerSvc addCategoryListObject:fieldSvcs];
    [generalCustomerSvc addCategoryListObject:commercial];
    [generalCustomerSvc addCategoryListObject:oem];
    [generalCustomerSvc addCategoryListObject:otherTopic];
    
    
    SurveyCategory* coms = [self newSurveyCategoryEntityWithName:@"COMS" key:41];
    SubCategory* issue = [self newSubCategoryEntityWithName:@"Issue" key:41];
    SubCategory* enhancement = [self newSubCategoryEntityWithName:@"Enhancement" key:42];
    SubCategory* otherComs = [self newSubCategoryEntityWithName:@"Other" key:43];
    [coms addCategoryListObject:issue];
    [coms addCategoryListObject:enhancement];
    [coms addCategoryListObject:otherComs];


    SurveyCategory* easeOfDoingBusiness = [self newSurveyCategoryEntityWithName:@"Ease Of Doing Business" key:44];
    SubCategory* documentation = [self newSubCategoryEntityWithName:@"Documentation" key:44];
    SubCategory* structure = [self newSubCategoryEntityWithName:@"Structure" key:45];
    Topic* multipleTouchs = [self newTopicEntityWithName:@"Multiple Touches" key:45];
    Topic* oemPrograms = [self newTopicEntityWithName:@"OEM Programs" key:46];
    [structure addTopicListObject:multipleTouchs];
    [structure addTopicListObject:oemPrograms];
    SubCategory* otherEaseOfBusiness = [self newSubCategoryEntityWithName:@"Other" key:47];
    
    [easeOfDoingBusiness addCategoryListObject:documentation];
    [easeOfDoingBusiness addCategoryListObject:structure];
    [easeOfDoingBusiness addCategoryListObject:otherEaseOfBusiness];

    SurveyCategory* purchasingInvoice = [self newSurveyCategoryEntityWithName:@"Purchasing/Invoicing" key:48];
    SubCategory* preApprovedCoding = [self newSubCategoryEntityWithName:@"Pre-Approved Coding (Demo Etc.)" key:48];
    SubCategory* modelSerialNos = [self newSubCategoryEntityWithName:@"Model/Serial Numbers" key:49];
    SubCategory* billingCorrections = [self newSubCategoryEntityWithName:@"Billing Corrections" key:50];
    SubCategory* otherPurchsing = [self newSubCategoryEntityWithName:@"Other" key:51];
    
    [purchasingInvoice addCategoryListObject:preApprovedCoding];
    [purchasingInvoice addCategoryListObject:modelSerialNos];
    [purchasingInvoice addCategoryListObject:billingCorrections];
    [purchasingInvoice addCategoryListObject:otherPurchsing];
    
    
    SurveyCategory* cashApplication = [self newSurveyCategoryEntityWithName:@"Cash Application" key:52];
    SubCategory* tradeIns = [self newSubCategoryEntityWithName:@"Trade Ins" key:52];
    SubCategory* refunds = [self newSubCategoryEntityWithName:@"Refunds" key:53];
    SubCategory* creditMemoDelays = [self newSubCategoryEntityWithName:@"Credit Memo Delays" key:54];
    SubCategory* otherCash = [self newSubCategoryEntityWithName:@"Other" key:55];
    
    [cashApplication addCategoryListObject:tradeIns];
    [cashApplication addCategoryListObject:refunds];
    [cashApplication addCategoryListObject:creditMemoDelays];
    [cashApplication addCategoryListObject:otherCash];
    
    SurveyCategory* manufacturingEscalations = [self newSurveyCategoryEntityWithName:@"Manufacturing Escalations" key:56];
    SubCategory* shipmentDelays = [self newSubCategoryEntityWithName:@"Shipment Delays" key:56];
    SubCategory* unidentifiableInventory = [self newSubCategoryEntityWithName:@"Unidentifiable Inventory" key:56];
    [unidentifiableInventory addTopicListObject:[self newTopicEntityWithName:@"Inventory Label Issues" key:58]];
    [unidentifiableInventory addTopicListObject:[self newTopicEntityWithName:@"Serial Number Location Visibility" key:59]];
    [unidentifiableInventory addTopicListObject:[self newTopicEntityWithName:@"Unverifiable Line Items" key:60]];
    SubCategory* otherManufacturing = [self newSubCategoryEntityWithName:@"Other" key:61];

    [manufacturingEscalations addCategoryListObject:shipmentDelays];
    [manufacturingEscalations addCategoryListObject:unidentifiableInventory];
    [manufacturingEscalations addCategoryListObject:otherManufacturing];
    
    [cx addCategoryListObject:easeOfDoingBusiness];
    [cx addCategoryListObject:timelyResponse];
    [cx addCategoryListObject:generalCustomerSvc];
    [cx addCategoryListObject:coms];
    [cx addCategoryListObject:purchasingInvoice];
    [cx addCategoryListObject:cashApplication];
    [cx addCategoryListObject: manufacturingEscalations];
    
    customerExperience = cx;
    return cx;
}


- (NSManagedObject*) newEntityForName: (NSString*) entityName
{
    NSManagedObject* entity = [NSEntityDescription insertNewObjectForEntityForName:entityName
                                                            inManagedObjectContext:appDelegate.moc];
    
    return entity;
    
}

- (SubCategory*) newSubCategoryEntityWithName:(NSString*) name key:(int) key
{
    SubCategory* newEntity = (SubCategory*)[self newEntityForName:@"SubCategory"];
    
    newEntity.name = name;
    newEntity.keyId = [[NSNumber alloc] initWithInt:key];
    
    return newEntity;
}

- (SurveyCategory*) newSurveyCategoryEntityWithName:(NSString*) name key:(int) key
{
    SurveyCategory* newEntity = (SurveyCategory*)[self newEntityForName:@"SurveyCategory"];
    
    newEntity.name = name;
    newEntity.keyId = [[NSNumber alloc] initWithInt:key];
    
    return newEntity;
}

- (Topic*) newTopicEntityWithName:(NSString*) name key:(int) key
{
    Topic* newEntity = (Topic*)[self newEntityForName:@"Topic"];
    
    newEntity.name = name;
    newEntity.keyId = [[NSNumber alloc] initWithInt:key];
    
    return newEntity;
}

- (SuperCategory*) newSuperCategoryEntityWithName:(NSString*) name key:(int) key
{
    SuperCategory* newEntity = (SuperCategory*)[self newEntityForName:@"SuperCategory"];
    
    newEntity.name = name;
    newEntity.keyId = [[NSNumber alloc] initWithInt:key];
    
    return newEntity;
}

- (void) initDealerList
{
    dealerList = [[NSMutableArray alloc] initWithCapacity:10];
    
}

/*
 ** Utility function to create Managed Dealer object from SOAP Response
 */
- (Dealer*) dealerFromSOAPCustomerData : (FSGMICustomerData*) customerData
{
    Dealer* aDealer = (Dealer*) [self newEntityForName:@"Dealer"];
    
    aDealer.customerName = customerData.CustomerName;
    aDealer.customerNo = customerData.CustomerNumber;
    aDealer.vbu = customerData.VBUName;
    aDealer.branchNo = customerData.BranchRegion;
    
    // Also add a Dealer Summary to Coredata
    DealerSummaryEntity* dealerSummary = [appDelegate.surveyUtil newDealerSummaryForDealer:aDealer];
    
    return aDealer;
}

/*
 ** Utility function to get Dealer object for transmission to SFDC
 */


- (void) saveCurrentSurvey
{
    
    // Encrypt items for save
    
    if (appDelegate.currentSurvey != Nil)
    {
        [appDelegate.currentSurvey encryptWithKey:ENCRYPTION_KEY];
    }
    for (int i=0; i< dealerList.count; i++)
    {
        Dealer* dealer = [dealerList objectAtIndex:i];
        [dealer encryptWithKey:ENCRYPTION_KEY];
    }
    if (appDelegate.fsr != nil)
    {
        [appDelegate.fsr encryptWithKey:ENCRYPTION_KEY];
    }
    
    NSError* error;
    
    [appDelegate.moc save:&error];

    // Decrypt for use in memory
    if (appDelegate.currentSurvey != Nil)
    {
        [appDelegate.currentSurvey decryptWithKey:ENCRYPTION_KEY];
    }
    for (int i=0; i< dealerList.count; i++)
    {
        Dealer* dealer = [dealerList objectAtIndex:i];
        [dealer decryptWithKey:ENCRYPTION_KEY];
    }
    if (appDelegate.fsr != nil)
    {
        [appDelegate.fsr decryptWithKey:ENCRYPTION_KEY];
    }
    
    NSLog(@"Error while saving survey %@", error.userInfo);
}

- (void) removeEntity:(NSManagedObject*) entity
{
    
    [appDelegate.moc deleteObject:entity];
    
}
- (NSArray*) loadEntitiyOfType: (NSString*) entityType
{
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityType inManagedObjectContext:appDelegate.moc];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setReturnsObjectsAsFaults:NO];
    [request setEntity:entity];
    NSError *error;
    NSArray *array = [appDelegate.moc executeFetchRequest:request error:&error];
    
    return array;
}

- (NSManagedObject*) loadEntityOfType: (NSString*) entityType withName:(NSString*) name
{
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityType inManagedObjectContext:appDelegate.moc];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setReturnsObjectsAsFaults:NO];
    [request setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name = %@",name];
    [request setPredicate:predicate];
    NSError *error;
    NSArray *array = [appDelegate.moc executeFetchRequest:request error:&error];

    if (array.count > 0)
        return [array objectAtIndex:0];
    else
        return Nil;
}

- (void) clearCurrentDealers
{
    for (int i=0; i<self.dealerList.count;i++)
    {
        [self removeEntity:[dealerList objectAtIndex:i]];
    }
    [dealerList removeAllObjects];
    [self saveCurrentSurvey];
}


/*
 ** After a Survey is sent clean all dealer Summary entities created
 */
- (void) clearDealerSummaryEntities
{
    NSArray* dealerSummaryList = [self loadEntitiyOfType:@"DealerSummaryEntity"];
    if (dealerSummaryList != nil)
    {

        for (int i=0;i<dealerSummaryList.count;i++)
        {
            [self removeEntity:[dealerSummaryList objectAtIndex:i]];
        }
    }
    [self saveCurrentSurvey];
}

- (void) clearFSR
{
    [[MIDBHelper getSharedInstance]deleteDataFromFSR];
    //Need to fetch and remove from sqlite
    NSArray* fsrArrary = [self loadEntitiyOfType:@"FSR"];
    if (fsrArrary != nil)
    {
        
        for (int i=0;i<fsrArrary.count;i++)
        {
            [self removeEntity:[fsrArrary objectAtIndex:i]];
        }
    }
    appDelegate.fsr = nil;
    [self saveCurrentSurvey];
}

- (FSR*) currentFSRWithSSO:(NSString *)sso
{
    FSR* fsr = nil;
    NSArray* fsrList = [self loadEntitiyOfType:@"FSR" ];
    
    if (fsrList != nil)
    {
        for (int i=0; i<fsrList.count;i++)
        {
            FSR* aFSR = [fsrList objectAtIndex:i];
            [aFSR decryptWithKey:ENCRYPTION_KEY];
            
            if ([aFSR.sso isEqualToString:sso])
            {
                fsr = aFSR;
                break;
            }
        }
    }
    

    return fsr;
}

- (DealerSummaryEntity*) newDealerSummaryForDealer:(Dealer*) dealer
{
    DealerSummaryEntity* aDealer = Nil;
    // Check first if a Dealer with given dealer summary already exists
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"DealerSummaryEntity" inManagedObjectContext:appDelegate.moc];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setReturnsObjectsAsFaults:NO];
    
    // Check with predicates
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"customerNumber == %@ AND branchNo == %@", dealer.customerNo, dealer.branchNo];
    [request setEntity:entity];
    [request setPredicate:predicate];
    NSError *error;
    NSArray *array = [appDelegate.moc executeFetchRequest:request error:&error];
    
    if (array.count == 0)
    {
        // Not found create a new one
       aDealer = (DealerSummaryEntity*)[self newEntityForName:@"DealerSummaryEntity"];
       [aDealer copyFromDealer:dealer];
    }
    else
    {
        aDealer = (DealerSummaryEntity*) [array objectAtIndex:0];
    }
    return aDealer;
    
}

- (DealerSummaryEntity*) newDealerSummary
{
    DealerSummaryEntity* aDealer = (DealerSummaryEntity*)[self newEntityForName:@"DealerSummaryEntity"];
    [appDelegate.moc insertObject:aDealer];
    
    return aDealer;
}
@end
