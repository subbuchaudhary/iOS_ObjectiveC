//
//  DealerSummary.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu Manuru on 1/13/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MIDealerSummary.h"
//#import "NSString+AESCrypt.h"

@implementation MIDealerSummary

@synthesize customerNumber;
@synthesize customerName;
@synthesize branchNo;
@synthesize vbu;
@synthesize isValidated;


-(id) initWithDealer:(MIDealerList*) dealer
{
    self.customerName = dealer.customerName;
    self.customerNumber = dealer.customerNo;
    self.branchNo = dealer.branchNo;
    self.vbu = dealer.vbu;
    isValidated = YES;
    
    return self;
}

- (id) initWithDealerNumber: (NSString*) dealerNo
{
    self.customerNumber = dealerNo;
    isValidated = NO;
    return self;
}
- (BOOL) isEqual:(id)object
{
    BOOL result = NO;
    if ([object class] == [self class])
    {
        MIDealerSummary* aDealer = (MIDealerSummary*) object;
        
        if (([aDealer.customerNumber isEqualToString:self.customerNumber])
             && ([aDealer.branchNo isEqualToString:self.branchNo]))
            result = YES;

    }
    return result;
}

- (id) initWithCoder:(NSCoder *)aDecoder
{
    self.customerName = [aDecoder decodeObjectForKey:@"CustomerName"];
    self.customerNumber = [aDecoder decodeObjectForKey:@"CustomerNo"];
    self.branchNo = [aDecoder decodeObjectForKey:@"BranchNo"];
    self.vbu = [aDecoder decodeObjectForKey:@"VBU"];
    self.isValidated = [aDecoder decodeBoolForKey:@"isValidated"];
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:customerName forKey:@"CustomerName"];
    [aCoder encodeObject:customerNumber forKey:@"CustomerNo"];
    [aCoder encodeObject:branchNo forKey:@"BranchNo"];
    [aCoder encodeObject:vbu forKey:@"VBU"];
    [aCoder encodeBool:isValidated forKey:@"isValidated"];
}

-(NSDictionary*) asDictionary
{
    NSMutableDictionary* asDict = [[NSMutableDictionary alloc] init];
    
    [asDict setObject:self.customerNumber forKey:@"CustomerNumber"];
    [asDict setObject:self.branchNo forKey:@"BranchNumber"];
    [asDict setObject:self.vbu forKey:@"VBU"];
    
    return  asDict;
}

- (void) encryptWithKey:(NSString*) key
{
    /*self.customerName = [self.customerName AES256EncryptWithKey:key];
    self.customerNumber = [self.customerNumber AES256EncryptWithKey:key];
    self.branchNo = [self.branchNo AES256EncryptWithKey:key];
    self.vbu = [self.vbu AES256EncryptWithKey:key];*/
}

-(void) decryptWithKey:(NSString*) key
{
    /*self.customerName = [self.customerName AES256DecryptWithKey:key];
    self.customerNumber = [self.customerNumber AES256DecryptWithKey:key];
    self.branchNo = [self.branchNo AES256DecryptWithKey:key];
    self.vbu = [self.vbu AES256DecryptWithKey:key];*/
    
}

- (void) copyFromDealer: (MIDealerList*) dealer
{
    self.customerName = dealer.customerName;
    self.customerNumber = dealer.customerNo;
    self.branchNo = dealer.branchNo;
    self.vbu = dealer.vbu;
    self.isValidated = @YES ;
    self.addedManually = @NO;
}

- (BOOL) isEqualToDealer:(MIDealerList *)aDealer
{
    BOOL result = NO;
    if (([aDealer.customerNo isEqualToString:self.customerNumber])
        && ([aDealer.branchNo isEqualToString:self.branchNo]))
        result = YES;
    
    return result;
}



@end
