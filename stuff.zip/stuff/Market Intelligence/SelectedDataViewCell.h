//
//  SelectedDataViewCell.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/6/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DealerSummaryEntity+DealerSummaryCustom.h"
#import "BaseCategory.h"

typedef enum {
    DEALER_DATA_CELL,
    OPPORTUNITY_DATA_CELL,
} DataCellType;

@interface SelectedDataViewCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *dataLabel;
@property  BaseCategory* opportunityType;
@property  DealerSummaryEntity* dealer;


@property DataCellType type;
- (IBAction)deletePressed:(id)sender;


- (void) configureWithOpportunityType: (BaseCategory*) type;
- (void) configureWithDealer:(DealerSummaryEntity*) dealer;

@end
