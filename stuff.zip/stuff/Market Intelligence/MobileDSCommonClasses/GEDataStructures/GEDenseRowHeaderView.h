//
//  GEDenseRowHeaderView.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//


#import <UIKit/UIKit.h>
#import "GEDenseCell.h"
#import "GELabel.h"


@interface GEDenseRowHeaderView : UIView


@property (nonatomic, strong) UIButton *selectionButton;
@property (nonatomic)NSInteger row;
@property (nonatomic)NSInteger column;
@property (nonatomic)BOOL isSelected;


-(id)initWithframe:(CGRect)frame DataRowTitle:(GEDenseCell*)rowHeaderCell;


@end