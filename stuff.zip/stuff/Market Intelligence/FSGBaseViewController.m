//
//  FSGBaseViewController.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 12/2/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

// Parent view controller for all custom view controllers in the application, does common tasks like setting font to Inspira, etc

#import "FSGBaseViewController.h"
#import "UIView+FSGViewSetFont.h"

@interface FSGBaseViewController ()

@end

@implementation FSGBaseViewController
@synthesize titleText;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setFontForViewAndSubviews:[UIFont fontWithName:@"GE Inspira" size:12]];
    self.view.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"bg"]];
	// Do any additional setup after loading the view.
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"GEInspira-Bold" size:15.0], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [_cancelBarButton setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [_doneBarButton setTitleTextAttributes:attributes forState:UIControlStateNormal];

 }

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)cancelPressed:(UIBarButtonItem *)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
@end
