//
//  MISurveyManager.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MIConstant.h"
#import "MISurveyType.h"
#import "MIDealerSummary.h"
#import "FSGMICustomerData.h"
@class AppDelegate;
@class MIFSR;
@interface MISurveyManager : NSObject
{
    AppDelegate* appDelegate;
}
@property(nonatomic,strong)NSMutableArray *superCategoryList;
@property (strong, retain) NSMutableArray *dealerList;
-(void)saveCurrentSurvey;
//Survey
@property(nonatomic,strong)MISurveyType *sales ;
@property(nonatomic,strong)MISurveyType *custExp ;;

//Dealerlist
- (void) clearCurrentDealers;
- (MIDealerList*) dealerFromSOAPCustomerData : (FSGMICustomerData*) customerData;
- (MIDealerSummary*) newDealerSummaryForDealer:(MIDealerList*) dealer;
//FSR
- (MIFSR*) currentFSRWithSSO:(NSString *)sso;
- (void) clearFSR;
@end
