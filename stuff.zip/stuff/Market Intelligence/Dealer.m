//
//  Dealer.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "Dealer.h"


@implementation Dealer

@dynamic branchNo;
@dynamic customerName;
@dynamic customerNo;
@dynamic masterNumber;
@dynamic vbu;

@end
