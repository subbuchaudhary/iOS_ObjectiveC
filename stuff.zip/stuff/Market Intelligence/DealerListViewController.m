//
//  dealerTableViewController.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/17/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "DealerListViewController.h"

#import "Dealer.h"
#import "SurveyUtil.h"
#import "AppDelegate.h"
#import "DealerSummary.h"
#import "DealerSummaryEntity+DealerSummaryCustom.h"

#import "DealerViewCell.h"


@interface DealerListViewController ()

@end

@implementation DealerListViewController
@synthesize dealerDataList;
@synthesize delegate;
@synthesize comment;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        AppDelegate* appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
        
        dealerDataList = appDelegate.miSurveyUtil.dealerList;
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.dealerTable.tableFooterView = [[UIView alloc] init];
    UINib* cellNib = [UINib nibWithNibName:@"DealerViewCell" bundle:nil];
    [self.dealerTable registerNib:cellNib forCellReuseIdentifier:@"DealerCell"];
    
    // Set title of controller
    UILabel *label = [[UILabel alloc] init ];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:@"GEInspira-Bold" size:17.0];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor]; // change this color
    label.text = @"Dealer No";
    self.navigationItem.titleView = label;
    [label sizeToFit];
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"GE Inspira Medium" size:14], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
    selectedDealerList = [[NSMutableArray alloc] initWithArray:comment.dealerList.allObjects];
    
    [self.dealerTable setContentInset:UIEdgeInsetsMake(0, 0, 80, 0)];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dealerDataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DealerViewCell* dealerCell =  [self.dealerTable dequeueReusableCellWithIdentifier:@"DealerCell" forIndexPath:indexPath];
    
    if (dealerCell == nil)
    {
        dealerCell = [[DealerViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DealerCell"];
    }
    
    MIDealerList* dealer = [dealerDataList objectAtIndex:indexPath.row];
    [dealerCell configureWithDealer:dealer];
    dealerCell.delegate = self;
    
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    MIDealerSummary* dealerSummary = [appDelegate.miSurveyUtil newDealerSummaryForDealer:dealer];
    if ([selectedDealerList containsObject:dealerSummary])
    {
        [dealerCell markSelected];
    }
    
    dealerCell.dealerName.font = [UIFont fontWithName:@"GEInspira-Bold" size:15.0];
    dealerCell.branchNoAndVBU.font = [UIFont fontWithName:@"GEInspira" size:15.0];
    dealerCell.selectionStyle = UITableViewCellSelectionStyleNone;
    return dealerCell;
    
}


- (IBAction)doneClicked:(id)sender {

    if (selectedDealerList.count == 0)
    {
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"None Selected." message:@"You need to select at least one Dealer." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    // Now add selection to Comment
    [comment addDealersFromList:selectedDealerList];
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSError* error;
    [comment.managedObjectContext save:&error];
    [delegate dealerDataSelected];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) selectDealer:(MIDealerList *)dealer
{
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    MIDealerSummary* dealerSummary = [appDelegate.miSurveyUtil newDealerSummaryForDealer:dealer];
    
    [selectedDealerList addObject:dealerSummary];
    [self.dealerTable reloadData];
}

- (void) unselectDealer:(MIDealerList *)dealer
{
    AppDelegate *appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    MIDealerSummary* dealerSummary = [appDelegate.miSurveyUtil newDealerSummaryForDealer:dealer];
    
    [selectedDealerList removeObject:dealerSummary];
    [self.dealerTable reloadData];

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DealerViewCell* cell = (DealerViewCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    if (cell.checkboxOff.hidden)
        [cell checkboxClicked:cell.checkboxOn];
    else
        [cell checkboxClicked:cell.checkboxOff];
}
@end
