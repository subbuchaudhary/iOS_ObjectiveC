//
//  SurveyUtil.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/4/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import "SuperCategory.h"
#import "Dealer.h"
#import "FSGMICustomerData.h"
#import "Survey.h"
#import "FSR.h"
#import "DealerSummaryEntity+DealerSummaryCustom.h"

@class AppDelegate;
@interface SurveyUtil : NSObject
{
    AppDelegate* appDelegate;
}

@property (strong, retain) NSMutableArray *superCategoryList;
@property (strong, retain) NSMutableArray *dealerList;

@property (readonly) SuperCategory* customerRetention;
@property (readonly) SuperCategory* creditLineIncrease;
@property (readonly) SuperCategory* customerExperience;
@property (readonly) SuperCategory* flooringOpportunity;



- (id) init;
- (Dealer*) dealerFromSOAPCustomerData: (FSGMICustomerData*) customerData;
- (NSManagedObject*) newEntityForName : (NSString*) name;

- (void) removeEntity:(NSManagedObject*) entity;

- (void) clearDealerSummaryEntities;
- (void) clearFSR;
- (void) clearCurrentDealers;
- (void) saveCurrentSurvey;
- (FSR*) currentFSRWithSSO:(NSString*) sso;

- (DealerSummaryEntity*) newDealerSummaryForDealer:(Dealer*) dealer;
- (DealerSummaryEntity*) newDealerSummary;
@end
