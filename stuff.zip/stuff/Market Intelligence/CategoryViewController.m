//
//  CategoryViewController.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/14/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CategoryViewController.h"
#import "CategoryCell.h"
#import "SubCategoryViewCell.h"
#import "TopicViewCell.h"
#import "SurveyCategory.h"
#import "SubCategory.h"
#import "Topic.h"
#import "BaseCategory+BaseCategoryCustom.h"

@interface CategoryViewController ()

@end

@implementation CategoryViewController
@synthesize superCategory;
@synthesize title;
@synthesize delegate;
@synthesize comment;

static NSString* TOPIC_CELL = @"TopicViewCell";
static NSString* CATEGORY_CELL = @"CategoryViewCell";
static NSString* SUB_CATEGORY_CELL = @"SubCategoryViewCell";


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (displayedHierarchyObjects == nil)
    {
        displayedHierarchyObjects = [[NSMutableArray alloc] initWithArray:superCategory.categorylist.allObjects];
    }
    
    self.categoryTable.tableFooterView = [[UIView alloc] init];
    UINib* cellNib = [UINib nibWithNibName:CATEGORY_CELL bundle:nil];
    [self.categoryTable registerNib:cellNib forCellReuseIdentifier:CATEGORY_CELL];
    
    UINib* subCategoryCellNib = [UINib nibWithNibName:SUB_CATEGORY_CELL bundle:nil];
    [self.categoryTable registerNib:subCategoryCellNib forCellReuseIdentifier:SUB_CATEGORY_CELL];
    
    UINib* topicNib = [UINib nibWithNibName:TOPIC_CELL bundle:nil];
    [self.categoryTable registerNib:topicNib forCellReuseIdentifier:TOPIC_CELL];
    
    
    // Set title of controller
    UILabel *label = [[UILabel alloc] init ];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:@"GEInspira-Bold" size:17.0];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor]; // change this color
    self.navigationItem.titleView = label;
    label.text = superCategory.superCatName;
    [label sizeToFit];
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"GE Inspira Medium" size:14], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
}

- (void) viewWillAppear:(BOOL)animated
{
    // Check if we are displyaing same SuperCategory as already selected
    if ((comment.superCategory != nil) && ([self.superCategory.superCatName isEqualToString:comment.superCategory.name]))
    {
        if ((comment.subCategoryList != Nil) && (comment.subCategoryList.count > 0))
        {
            subCategoryList = [[NSMutableArray alloc] initWithArray:comment.subCategoryList.allObjects];
            expandedCategory = ((SubCategory*)[subCategoryList objectAtIndex:0]).parent;
        }
        else
        {
            subCategoryList = [[NSMutableArray alloc] init];
        }
        
        if ((comment.topicList != nil) && (comment.topicList.count > 0))
        {
            topicList = [[NSMutableArray alloc] initWithArray:comment.topicList.allObjects];
            Topic* topic = [topicList objectAtIndex:0];
            expandedCategory = topic.parent.parent;
            expandedSubCategory = topic.parent;
            
        }
        else
        {
            topicList = [[NSMutableArray alloc] init];
        }
        if (comment.category != Nil)
            selectedCategory = comment.category;
        [self setDisplayHierarchy];
    }


    if (subCategoryList == nil)
        subCategoryList = [[NSMutableArray alloc] init];
    if (topicList == nil)
        topicList = [[NSMutableArray alloc] init];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [displayedHierarchyObjects count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoryHierarchyCell* cell = nil;
    BaseCategory* category = [displayedHierarchyObjects objectAtIndex:indexPath.row];
    
    Boolean selectCell = NO;
    if (
        (selectedCategory == category) ||
        ([subCategoryList containsObject:category]) ||
        ([topicList containsObject:category]))
        selectCell = YES;
    
    if ([category isKindOfClass:[SurveyCategory class]])
    {
        cell = [_categoryTable dequeueReusableCellWithIdentifier:CATEGORY_CELL forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[CategoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CATEGORY_CELL];
        }
        if (selectedCategory == category)
            selectCell = YES;

    }
    if ([category isKindOfClass:[SubCategory class]] )
    {
        cell = [_categoryTable dequeueReusableCellWithIdentifier:SUB_CATEGORY_CELL forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[SubCategoryViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SUB_CATEGORY_CELL];
        }
        if ([subCategoryList containsObject:category])
        {
            selectCell = YES;
        }
        
    }
    if ([category isKindOfClass:[Topic class]] )
    {
        cell = [_categoryTable dequeueReusableCellWithIdentifier:TOPIC_CELL forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[TopicViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TOPIC_CELL];
        }
        if ([topicList containsObject:category])
            selectCell = YES;
    }
    
    cell.parentController = self;
    [cell configureWithHierarchy: category];
    
    if (selectCell)
        [cell selectCategory];
    
    if ((category == expandedCategory) || (category == expandedSubCategory))
    {
        [cell hideExpand];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


-(IBAction) cancel:(UIBarButtonItem*) sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)doneClicked:(id)sender {

    SurveyCategory* category ;
    if (selectedCategory != nil)
        category = selectedCategory;
    else
    {
        if ((subCategoryList.count == 0) && (topicList.count == 0))
        {
            UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"None selected." message:@"You must select at least one category to proceed." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            [alert show];
            return;
        }
    }
    [delegate categoryDataSelected:category subCategoryList:subCategoryList topicList:topicList];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) selectObject: (BaseCategory*) category
{
    BOOL reset = NO;
    if ([category isKindOfClass:[SurveyCategory class]])
    {
        selectedCategory = (SurveyCategory*) category;
        if ((subCategoryList.count != 0 ) &&
            ([[subCategoryList objectAtIndex:0] parent] != selectedCategory))
        {
            [subCategoryList removeAllObjects];
            [topicList removeAllObjects];
        }
        
        if (topicList.count != 0)
        {
            Topic* topic = [topicList objectAtIndex:0];
            SurveyCategory* currentSelectedParent = [[topic parent] parent];
            
            if (currentSelectedParent != selectedCategory)
            {
                [subCategoryList removeAllObjects];
                [topicList removeAllObjects];
            }
        
        }
            
    }
    if ([category isKindOfClass:[SubCategory class]])
    {
        SubCategory* subCategory = (SubCategory*) category;

        
        if ((subCategoryList.count != 0 ) &&
            ([[subCategoryList objectAtIndex:0] parent] != [subCategory parent]))
        {
            [subCategoryList removeAllObjects];
            [topicList removeAllObjects];
            selectedCategory = nil;
        }
        if (topicList.count != 0)
        {
            Topic* topic = [topicList objectAtIndex:0];
            SurveyCategory* currentSelectedParent = [[topic parent] parent];
            
            if (currentSelectedParent != [subCategory parent])
            {
                [subCategoryList removeAllObjects];
                [topicList removeAllObjects];
            }
            
        }

        
        if ([subCategory parent] != selectedCategory)
             selectedCategory = nil;
        selectedCategory = subCategory.parent;
        [subCategoryList addObject:category];
    }
    if ([category isKindOfClass:[Topic class]])
    {
        Topic* topic = (Topic*) category;
        if ((subCategoryList.count != 0 ) &&
            ([[subCategoryList objectAtIndex:0] parent] != [[topic parent] parent]))
        {
            [subCategoryList removeAllObjects];
            [topicList removeAllObjects];
            selectedCategory = nil;
        }
        
        if ([[topic parent] parent] != selectedCategory)
            selectedCategory = nil;
        
        if (![subCategoryList containsObject:topic.parent])
        {
            [subCategoryList addObject:topic.parent];
        }
        selectedCategory = topic.parent.parent;
        [topicList addObject:category];
    }
    [self.categoryTable reloadData];
}

- (void) unselectObject: (BaseCategory*) category
{
    if ([category isKindOfClass:[SurveyCategory class]])
    {
        selectedCategory = nil;
    }
    if ([category isKindOfClass:[SubCategory class]])
    {
        SubCategory* subCategory = (SubCategory*) category;
        [subCategoryList removeObject:category];
        SurveyCategory* surveyCategory = subCategory.parent;
        
        if (![self shouldCategoryBeSelected:surveyCategory])
        {
            selectedCategory = Nil;
        }
    }
    if ([category isKindOfClass:[Topic class]])
    {
        Topic* topic = (Topic*) category;
        
        // Check if parents in hierarchy are to be unselected
        SubCategory *subCategory = topic.parent;
        SurveyCategory* surveyCategory = subCategory.parent;
        
        [topicList removeObject:category];
        if (![self shouldSubCategoryBeSelected:subCategory])
        {
            [subCategoryList removeObject:subCategory];
        }
        if (![self shouldCategoryBeSelected:surveyCategory])
        {
            selectedCategory = Nil;
        }

    }
    [self.categoryTable reloadData];
}

/*
 ** Checks if a given subcategory has any children topic selected or not
 */
- (BOOL) shouldSubCategoryBeSelected: (SubCategory*) subCategory
{
    BOOL shouldBeSelected = NO;
    
    if (subCategory.topicList.count == 0)
    {
        shouldBeSelected = YES;
    }
    
    for (int i=0; i < subCategory.topicList.count; i++)
    {
        Topic* topic = [subCategory.topicList objectAtIndex:i];
        
        if ([topicList containsObject:topic])
        {
            shouldBeSelected = YES;
            break;
        }
    }
    
    return shouldBeSelected;
}

/*
 ** Checks if a given Category has any children sub topics selected or not
 */
- (BOOL) shouldCategoryBeSelected: (SurveyCategory*) category
{
    BOOL shouldBeSelected = NO;
    
    if (category.categoryList.count == 0)
    {
        shouldBeSelected = YES;
    }
    
    for (int i=0;i < category.categoryList.count; i++)
    {
        SubCategory* subCategory = [category.categoryList objectAtIndex:i];
        
        if ([subCategoryList containsObject:subCategory])
        {
            shouldBeSelected = YES;
            break;
        }
    }
    
    return shouldBeSelected;
    
}


- (void) expandClickedOnCell:(CategoryHierarchyCell *)cell
{
    
    // Check what is being expanded
    BaseCategory* cellType = cell.dataObject;
    NSIndexPath* index = [_categoryTable indexPathForCell:cell];
    
    if ([cellType isKindOfClass:[SurveyCategory class]])
    {
        // Display all SubCategories
        expandedCategory = (SurveyCategory*) cell.dataObject;
        expandedSubCategory = nil;

    }
    else
    {
        // Display all topics under this Sub Category
        expandedSubCategory = (SubCategory*) cell.dataObject;
    }
    [self setDisplayHierarchy];
    [self.categoryTable reloadData];
}

- (int) indexForSurveyCategory:(SurveyCategory*) category
{
    int index = NSNotFound;
    index = [superCategory.categorylist.allObjects indexOfObject:category];
    
    
    return index;
}

- (void) collapseClickedOnCell:(CategoryHierarchyCell*) cell
{
    BaseCategory* category = cell.dataObject;
    
    if ([category isKindOfClass:[SurveyCategory class]] )
    {
        expandedCategory = nil;
        expandedSubCategory = nil;
    }
    
    if ([category isKindOfClass:[SubCategory class]] )
    {
        expandedSubCategory = nil;
    }

    [self setDisplayHierarchy];
    [self.categoryTable reloadData];
}

- (void) setDisplayHierarchy
{
    [displayedHierarchyObjects removeAllObjects];
    
    for (int i = 0; i < [superCategory.categorylist.allObjects count]; i++)
    {
        SurveyCategory* category = [superCategory.categorylist.allObjects objectAtIndex:i];
        [displayedHierarchyObjects addObject:category];
        if (expandedCategory != nil)
        {
            if ([expandedCategory isEqual:category])
            {
                for (int j = 0; j < expandedCategory.categoryList.count; j++)
                {
                    SubCategory* subCategory = [expandedCategory.categoryList objectAtIndex:j];
                    [displayedHierarchyObjects addObject:[expandedCategory.categoryList objectAtIndex:j]];
                
                    if (expandedSubCategory != nil)
                    {
                        if ([expandedSubCategory isEqual:subCategory])
                        {
                            for (int k=0; k < subCategory.topicList.count; k++)
                            {
                                [displayedHierarchyObjects addObject:[subCategory.topicList objectAtIndex:k]];
                            }
                        }
                    }
                }
            }
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoryHierarchyCell* cell =  (CategoryHierarchyCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    if ([cell.dataObject class] == [SurveyCategory class])
    {
        CategoryCell* categoryCell = (CategoryCell*) cell;
        SurveyCategory* category = (SurveyCategory*) categoryCell.dataObject;
        
        if (category.categoryList.count == 0)
        {
            if (categoryCell.checkboxOff.hidden == NO)
            {
                [categoryCell checkboxSelected:categoryCell.checkboxOff];
            }
            else
            {
                [categoryCell checkboxSelected:categoryCell.checkboxOn];
            }
        }
        else
        {
            if (categoryCell.isExpanded)
                [categoryCell collapseClicked:categoryCell.collapse];
            else
                [categoryCell expandClicked:categoryCell.expand];
        }
    }
    if ([cell.dataObject class] == [SubCategory class])
    {
        SubCategoryViewCell* subCategoryCell = (SubCategoryViewCell*) cell;
        SubCategory* subCat = (SubCategory*) subCategoryCell.dataObject;
        
        if (subCat.topicList.count ==0)
        {
            if (subCategoryCell.checkboxOff.hidden == NO)
            {
                [subCategoryCell checkboxSelected:subCategoryCell.checkboxOff];
            }
            else
            {
                [subCategoryCell checkboxSelected:subCategoryCell.checkboxOn];
            }
        }
        else
        {
            if (subCategoryCell.isExpanded)
                [subCategoryCell collaspseClicked:subCategoryCell.collapse];
            else
                [subCategoryCell expandClicked:subCategoryCell.expand];
        }
    }
    if ([cell.dataObject class] == [Topic class])
    {
        TopicViewCell* topicCell = (TopicViewCell*) cell;
        
        if (topicCell.checkboxOff.hidden == NO)
        {
            [topicCell checkboxSelected:topicCell.checkboxOff];
        }
        else
        {
            [topicCell checkboxSelected:topicCell.checkboxOn];
        }
    }
}


@end
