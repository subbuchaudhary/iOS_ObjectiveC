//
//  MIDBHelper.m
//  Market Intelligence
//
//  Created by Subbu Chaudhary on 1/27/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import "MIDBHelper.h"

//#import <GD/GDFileManager.h>

@implementation MIDBHelper

static MIDBHelper *sharedInstance = nil;
static sqlite3 *database = nil;
//static sqlite3_stmt *statement = nil;


+(MIDBHelper*)getSharedInstance{
    if (!sharedInstance) {
        sharedInstance = [[MIDBHelper alloc]init];
        [sharedInstance createDatabase];
    }
    return sharedInstance;
}

- (id)init{
    self = [super init];
    return self;
}

- (void)createDatabase{
    NSArray *dirpaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = dirpaths[0];
    dbPath = [[NSString alloc]initWithString:[path stringByAppendingString:@"MIAPP.db"]];
    //GDFileManager *fileManager = [GDFileManager defaultManager];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:dbPath] == NO) {
        
        if ((sqlite3_open( [dbPath UTF8String], &database)) == SQLITE_OK){
            const char *createTable = "create table if not exists FSR (firstname text, lastname text, managersso text, sso text)";
            //char *createTable = "create table if not exists Employee(empid text, name text, age text)";
            char *error;
            if (sqlite3_exec(database, createTable, NULL, NULL, &error) == SQLITE_OK) {
                NSLog(@"database created");
            }
            else{
                NSLog(@"db not created");
            }
            sqlite3_close(database);
        }
    }
}

- (void)saveData:(NSString *)firstName lastNname:(NSString *)lastName managerSSO:(NSString *)managerSSO sso:(NSString *)sso{
    sqlite3_stmt *statement;
    const char *dbpath = [dbPath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO FSR (firstname, lastname, managersso, sso) VALUES (\"%@\", \"%@\", \"%@\", \"%@\") ", firstName, lastName, managerSSO, sso];
        
        const char *insert_stmt = [insertSql UTF8String];
        sqlite3_prepare_v2(database, insert_stmt, -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE) {
            NSLog(@"added");
        }else{
            NSLog(@"Error while creating database. '%s'", sqlite3_errmsg(database));
        }
        sqlite3_finalize(statement);
        sqlite3_close(database);
    }
}

- (void)deleteDataFromFSR{
    sqlite3_stmt *statement;
    const char *dbpath = [dbPath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *deleteSql =[NSString stringWithFormat:@"DELETE FROM FSR"];
        
        const char *delete_stmt = [deleteSql UTF8String];
        sqlite3_prepare_v2(database, delete_stmt, -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE) {
            NSLog(@"deleted");
        }else{
            NSLog(@"Error while creating database. '%s'", sqlite3_errmsg(database));
        }
        sqlite3_finalize(statement);
        sqlite3_close(database);
    }
}

@end
