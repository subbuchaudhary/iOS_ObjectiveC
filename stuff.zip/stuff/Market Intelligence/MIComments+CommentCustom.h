//
//  Comment+CommentCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/9/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "Comment.h"
#import "Dealer.h"

@interface Comment (CommentCustom)


- (void) clearSubCategoryList;
- (void) clearTopicList;

- (void) encryptWithKey:(NSString*) key;
- (void) decryptWithKey:(NSString*) key;

- (BOOL) isTextEntered;
- (BOOL) isOpportunityTypeSelected;
- (BOOL) isDealerSelected;
- (BOOL) isContactNameSelected;

-(BOOL) containsDealer:(Dealer*) aDealer;
- (void) addDealersFromList:(NSArray*) selectedDealerList;

@end
