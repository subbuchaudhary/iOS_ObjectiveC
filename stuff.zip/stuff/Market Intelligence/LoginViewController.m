//
//  LoginViewController.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/12/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "LoginViewController.h"
#import "ViewController.h"
#import "AppDelegate.h"
#import "DealerListService.h"
#import "KeychainItemWrapper.h"

//MI_V_1.0
#import "MIConstant.h"
@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil callback:(SEL) callback
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        loginCallback = callback;
        
        //Add activity view

        CGRect activityViewFrame = CGRectMake(145.0, 275.0, 10.0, 10.0);
        activityView = [[UIActivityIndicatorView alloc] initWithFrame:activityViewFrame];
        activityView.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
        [activityView setColor:[UIColor grayColor]];
        [self.view addSubview:activityView];
        [self.view bringSubviewToFront:activityView];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.heroImage = [UIImage imageNamed:@"logo_login@2x.png"];
    self.appName   = @"FSG Market Intelligence";
    self.accentColor = GE_COLOR_BLUE;
    [activityView setHidden:YES];
    
    // Check local login
    KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
    [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];

    // Remember SSO
    NSString* localSSO = [keychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
    
    if (localSSO != nil)
    {
        self.acctTextField.text = localSSO;
    }
    
    UIColor *textColor = [UIColor colorWithRed:80/255.0 green:80/255.0 blue:80/255.0 alpha:1];
    self.acctTextField.textColor = textColor;
    self.passTextField.textColor = textColor;
    
    self.acctTextField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    
    // For displaying status bar
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)signInButtonAction:(id)sender
{
    //Here is where Authentication Happens
    
    loginService = [[LoginService alloc] initWithDelegate:self];
    if ([self.acctTextField.text isEqualToString:@""] || [self.passTextField.text isEqualToString:@""])
    {
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Required Fields" message:@"You did not enter required fields." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
        return;
        
    }
    activityView.hidden = NO;
    [activityView startAnimating];
    [loginService loginWithUserId:self.acctTextField.text password:self.passTextField.text];


}

- (void) receiveLoginStatus:(LoginStatus)status FSR:(MIFSR *)fsr
{
    if (status == REMOTE_LOGIN_FAILED)
    {
        [self showAlertMessage:@"Login credentials not valid" title:@"Login failed"];
        self.passTextField.text = @"";
        
    }
    if (status == REMOTE_SYSTEM_FAILURE)
    {
        [self showAlertMessage:@"FSRO System Timed out. Please try again." title:@"FSRO Time out"];
        
    }
    if (status == LOCAL_LOGIN_FAILED)
    {
        [self showAlertMessage:@"You cannot be locally logged in to application. If you have changed your password recently, it may not have been reflected on the device yet." title:@"Login Failed"];
        self.passTextField.text = @"";
    }
    if (status == NO_LOCAL_CREDENTIALS)
    {
        [self showAlertMessage:@"No connectivity. You need to login for the first time when there is connectivity " title:@"First time login"];
    }
    if (status == REMOTE_ACCOUNT_LOCKED)
    {
        [self showAlertMessage:@"Your account is locked. Please contact FSRO Administrator to reset account. " title:@"FSRO Account Locked"];
        self.passTextField.text = @"";
    }
    [activityView stopAnimating];
    activityView.hidden = YES;

    if ((status == REMOTE_LOGIN_SUCCESSFUL) || (status == LOCAL_LOGIN_SUCCESSFUL))
    {
        /*
         ** User is succesfully logged in Now load the Dealer list
         */
        [activityView startAnimating];
        activityView.hidden = NO;
        
        if (fsr != nil)
        {
            AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            appDelegate.miFsr = fsr;
            
        }
        DealerListService *dealerService = [[DealerListService alloc] initWithDelegate:self];
        [dealerService dealerDataForSSO:fsr.sso];

    }
    


}

- (void) showAlertMessage:(NSString*) message title:(NSString*) title
{

    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
    [alert show];
}

- (void) receiveDealerData:(NSMutableArray *)dealerData
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    appDelegate.miSurveyUtil.dealerList = dealerData;
    [activityView stopAnimating];
    activityView.hidden = YES;
    [appDelegate loginSuccessful];
}


-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


@end
