//
//  SubCategory.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "SubCategory.h"
#import "Comment.h"
#import "SurveyCategory.h"
#import "Topic.h"


@implementation SubCategory

@dynamic parent;
@dynamic topicList;
@dynamic commentList;

@end
