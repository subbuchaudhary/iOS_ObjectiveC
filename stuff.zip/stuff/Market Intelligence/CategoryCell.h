//
//  CategoryCell.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CategoryHierarchyCell.h"

@interface CategoryCell : CategoryHierarchyCell

@property (weak, nonatomic) IBOutlet UIButton *checkboxOff;
@property (weak, nonatomic) IBOutlet UIButton *checkboxOn;
@property (weak, nonatomic) IBOutlet UILabel *objectName;
@property (weak, nonatomic) IBOutlet UIButton *expand;
@property (weak, nonatomic) IBOutlet UIButton *collapse;

- (IBAction) expandClicked:(UIButton*) expandClicked;
- (IBAction)checkboxSelected:(UIButton *)sender;
- (IBAction)collapseClicked:(UIButton *)sender;

- (void) configureWithHierarchy:(BaseCategory *)category;


@end
