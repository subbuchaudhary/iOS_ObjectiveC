//
//  CategoryCell.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CategoryCell.h"

@implementation CategoryCell

- (void) configureWithHierarchy:(BaseCategory *)category
{
    [super configureWithHierarchy:category];
    _objectName.text = category.name;
    _objectName.font = [UIFont fontWithName:@"GEInspira" size:17];
    SurveyCategory* surveyCategory = (SurveyCategory*) category;
    super.isExpanded = false;
    if ([surveyCategory.categoryList count] == 0)
    {
        _expand.hidden = YES;
        _collapse.hidden = YES;
    }
    else
    {
        _checkboxOff.hidden = NO;
        _checkboxOff.enabled = NO;
        _checkboxOn.enabled = NO;
        _checkboxOn.hidden = YES;
        _expand.hidden = NO;
        _collapse.hidden = YES;
    }
    self.contentView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    UIEdgeInsets insets;
    insets.left = 5;
    self.separatorInset = insets;

}
- (void) prepareForReuse
{
    _collapse.hidden = YES;
    _expand.hidden = NO;
    
    _checkboxOn.hidden = YES;
    _checkboxOff.hidden = NO;
    _checkboxOn.enabled = YES;
    _checkboxOff.enabled = YES;
    super.isExpanded = false;
    
}

- (void) selectCategory
{
    SurveyCategory* surveyCategory = (SurveyCategory*) self.dataObject;
    if ([surveyCategory.categoryList count] == 0)
    {
        _expand.hidden = YES;
        _collapse.hidden = YES;
    }
    _checkboxOn.hidden = NO;
    _checkboxOff.hidden = YES;
}

- (IBAction) expandClicked:(UIButton *)sender
{
    super.isExpanded = true;
    [self.parentController expandClickedOnCell:self];    
    
}

- (IBAction)checkboxSelected:(UIButton *)sender {
    
    if ([sender isEqual:_checkboxOn])
    {
        _checkboxOn.hidden = YES;
        _checkboxOff.hidden = NO;
        [self.parentController unselectObject:self.dataObject];
    }
    else
    {
        _checkboxOn.hidden = NO;
        _checkboxOff.hidden = YES;
        [self.parentController selectObject:self.dataObject];
    }
}

- (IBAction)collapseClicked:(UIButton *)sender {
    super.isExpanded = false;
    [self.parentController collapseClickedOnCell:self];
}

- (void) hideExpand
{
    _expand.hidden = YES;
    _collapse.hidden = NO;
}

@end
