//
//  CommentRowView.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CommentRowView.h"
#import "DealerSummaryEntity+DealerSummaryCustom.h"
#import "SurveyCategory+SurveyCategoryCustom.h"
#import "SubCategory+SubCategoryCustom.h"
#import "Topic.h"

@implementation CommentRowView

@synthesize type;
@synthesize  dealerList;
@synthesize dataList;
@synthesize comment;

const int COMMENT_ROW_HEIGHT=44;
const int DATA_ROW_HEIGHT=30;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        //Custom Initialization code here
        [[NSBundle mainBundle] loadNibNamed:@"CommentRowView" owner:self options:nil];
        
        
        [self addSubview:self.container];
        

        //Need to set this so the old autoresizing mask doesnt rear its ugly head
        [self.container setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        //Need to set the constraints on the container view as it is not possible to do this in the XIB
        NSArray *horizontalConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[container]|" options:0 metrics:nil views:@{@"container":self.container}];
        NSArray *verticalConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[container]|" options:0 metrics:nil views:@{@"container":self.container}];
        
        NSArray *allConstraints = [horizontalConstraints arrayByAddingObjectsFromArray:verticalConstraints];
        
        [self addConstraints:allConstraints];
        _defaultColor = _title.textColor;
        
        [self.title setFont:[UIFont fontWithName:@"GEInspira" size:17]]; // Added by Easwar
        
        UINib* cellNib = [UINib nibWithNibName:@"SelectedDataViewCell" bundle:nil];
        [self.selectedDataTable registerNib:cellNib forCellReuseIdentifier:@"SelectedDataCell"];
        self.selectedDataTable.hidden = YES;
        self.selectedDataTable.tableHeaderView = nil;
        self.selectedDataTable.tableFooterView = nil;
        
        self.dealerText.font = [UIFont fontWithName:@"GEInspira-Bold" size:14]; // Added by Easwar
    }
    return self;
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    self.container.backgroundColor = [UIColor colorWithRed:0.196 green:0.196 blue:0.196 alpha:1.0];
}

-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    self.container.backgroundColor = [UIColor groupTableViewBackgroundColor];
}

-(void) touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event {
    self.container.backgroundColor = [UIColor groupTableViewBackgroundColor];
}


- (void) displayValidationError: (BOOL) flag
{
    if (flag)
    {
        self.checkbox.hidden = YES;
        if (type == DEALER_DATA_CELL)
        {
            self.dealerText.layer.borderWidth = 1.0f;
            self.dealerText.layer.borderColor = [[UIColor redColor] CGColor];
        }
        else
        {
            self.title.textColor = [UIColor redColor];
        }
    }
    else
    {
        if (type == DEALER_DATA_CELL)
        {
            self.dealerText.layer.borderWidth = 0.0f;
        }
        else
        {
            self.title.textColor = _defaultColor;
        }
        self.checkbox.hidden = NO;
    }
}

- (void) displayData: (BOOL) display
{
    if (display)
    {
        self.selectedDataTable.hidden = NO;
        self.lineView.hidden = NO;
        if (type == DEALER_DATA_CELL)
            [self displayDealerData];
        else
            [self displayOptionData];
    }
    else
    {
        self.selectedDataTable.hidden = YES;
        self.lineView.hidden = YES;
    }
    [self.selectedDataTable setEditing:NO];
}

- (void) displayDealerData
{
    self.tableHeight.constant = DATA_ROW_HEIGHT*comment.dealerList.count;
    [self.selectedDataTable reloadData];
}

- (void) displayOptionData
{
    dataList = [[NSMutableArray alloc] init];
    
    if (comment.category != Nil)
    {
        [dataList addObject:comment.category];
        
        SurveyCategory* category = comment.category;
        for (int subCatIndex=0; subCatIndex < category.categoryList.count;subCatIndex++)
        {
            SubCategory* subCategory = [category.categoryList objectAtIndex:subCatIndex];
            
            if ((comment.subCategoryList != Nil) &&
                ([comment.subCategoryList containsObject:subCategory]))
            {
                [dataList addObject:subCategory];
                
                // Check for Topics under this subcategory
                for (int topicIndex =0; topicIndex< subCategory.topicList.count;topicIndex++)
                {
                    Topic* topic = [subCategory.topicList objectAtIndex:topicIndex];
                    
                    if ((comment.topicList != nil) &&
                        ([comment.topicList containsObject:topic]))
                    {
                        [dataList addObject:topic];
                    }
                }
            }
            
            
        }
    }
    
    self.tableHeight.constant = DATA_ROW_HEIGHT*dataList.count;
    [self.selectedDataTable reloadData];
}

/*
 ** UITableViewDelegate Datasource Delegate methods
 */
-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    int noOfObjects = 0;
    
    if (type == DEALER_DATA_CELL)
    {
        noOfObjects = comment.dealerList.count;
    }
    else
    {
        noOfObjects = dataList.count;
    }
    
    return noOfObjects;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellId = @"SelectedDataCell";
    
    SelectedDataViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[SelectedDataViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId ];
    }
    
    // Configure the cell...
    if (type == DEALER_DATA_CELL)
    {
        DealerSummaryEntity* dealer = [comment.dealerList.allObjects objectAtIndex:indexPath.row];
        [cell configureWithDealer:dealer];
    }
    else
    {
        BaseCategory* opportunityType = [dataList objectAtIndex:indexPath.row];
        cell.type = type;
        [cell configureWithOpportunityType:opportunityType];
    }
    
    cell.dataLabel.font = [UIFont fontWithName:@"GEInspira" size:15];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    bool editable = YES;
    if (type == OPPORTUNITY_DATA_CELL)
        editable = NO;
    return editable;
}


-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        SelectedDataViewCell *currentCell = (SelectedDataViewCell *)[tableView cellForRowAtIndexPath:indexPath];
        if (currentCell.type == DEALER_DATA_CELL) {
            [self.delegate deleteSelectedDealer:currentCell.dealer];
        }else{
            [self.delegate deleteSelectedOpportunityType:currentCell.opportunityType];
        }
    }

}

- (void) tableView:(UITableView *)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    SelectedDataViewCell *currentCell = (SelectedDataViewCell *)[tableView cellForRowAtIndexPath:indexPath];

}


- (int) height
{
    int tableHeight = 0;
    if (type == DEALER_DATA_CELL)
    {
        tableHeight = DATA_ROW_HEIGHT* comment.dealerList.count;
    }
    else
        tableHeight = DATA_ROW_HEIGHT*dataList.count;
    
    return COMMENT_ROW_HEIGHT + tableHeight ;
}



@end
