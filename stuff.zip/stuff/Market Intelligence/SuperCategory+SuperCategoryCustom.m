//
//  SuperCategory+SuperCategoryCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SuperCategory+SuperCategoryCustom.h"

@implementation SuperCategory (SuperCategoryCustom)
- (void)addCategoryListObject:(SurveyCategory *)value
{
    // Create a mutable set with the existing objects, add the new object, and set the relationship equal to this new mutable ordered set
    NSMutableOrderedSet *categoryList = [[NSMutableOrderedSet alloc] initWithOrderedSet:self.categoryList];
    [categoryList addObject:value];
    self.categoryList = categoryList;
    
}
@end
