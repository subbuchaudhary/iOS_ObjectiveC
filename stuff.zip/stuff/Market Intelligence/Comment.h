//
//  Comment.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/11/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class DealerSummaryEntity, SubCategory, SuperCategory, SurveyCategory, Topic;

@interface Comment : NSManagedObject

@property (nonatomic, retain) NSString * contactName;
@property (nonatomic, retain) NSNumber * keyId;
@property (nonatomic, retain) NSString * surveyType;
@property (nonatomic, retain) NSString * text;
@property (nonatomic, retain) NSString * dealerNumber;
@property (nonatomic, retain) SurveyCategory *category;
@property (nonatomic, retain) NSSet *dealerList;
@property (nonatomic, retain) NSSet *subCategoryList;
@property (nonatomic, retain) SuperCategory *superCategory;
@property (nonatomic, retain) NSSet *topicList;
@end

@interface Comment (CoreDataGeneratedAccessors)

- (void)addDealerListObject:(DealerSummaryEntity *)value;
- (void)removeDealerListObject:(DealerSummaryEntity *)value;
- (void)addDealerList:(NSSet *)values;
- (void)removeDealerList:(NSSet *)values;

- (void)addSubCategoryListObject:(SubCategory *)value;
- (void)removeSubCategoryListObject:(SubCategory *)value;
- (void)addSubCategoryList:(NSSet *)values;
- (void)removeSubCategoryList:(NSSet *)values;

- (void)addTopicListObject:(Topic *)value;
- (void)removeTopicListObject:(Topic *)value;
- (void)addTopicList:(NSSet *)values;
- (void)removeTopicList:(NSSet *)values;

@end
