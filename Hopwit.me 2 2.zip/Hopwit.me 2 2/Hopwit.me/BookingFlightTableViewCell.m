//
//  BookingFlightTableViewCell.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/23/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "BookingFlightTableViewCell.h"

@implementation BookingFlightTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
