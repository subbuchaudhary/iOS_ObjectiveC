//
//  SharemylocationTableViewCell.m
//  Hopwit.me
//
//  Created by Anyuta on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "SharemylocationTableViewCell.h"

@implementation SharemylocationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
