//
//  DiscoverViewController.m
//  Hopwit.me
//
//  Created by Anyuta on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "DiscoverViewController.h"
#import "SearchChatsTableViewCell.h"
#import "SharemylocationTableViewCell.h"
#import "DiscoverTableViewCell.h"
@interface DiscoverViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation DiscoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tableView.estimatedRowHeight = 80;//the estimatedRowHeight but if is more this autoincremented with autolayout
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    // Do any additional setup after loading the view.
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 8;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==0) {
        
        SearchChatsTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"SearchChatsTableViewCell"];
        if (cell==nil) {
            cell=[[SearchChatsTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SearchChatsTableViewCell"];
        }
        cell=contentcell;
    }else if(indexPath.row==1)
    {
        SharemylocationTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"SharemylocationTableViewCell"];
        if (cell==nil) {
            cell=[[SharemylocationTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SharemylocationTableViewCell"];
        }
        cell=contentcell;
    }
    else
    {
        DiscoverTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"DiscoverTableViewCell"];
        if (cell==nil) {
            cell=[[DiscoverTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DiscoverTableViewCell"];
        }
        cell=contentcell;
    }
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
