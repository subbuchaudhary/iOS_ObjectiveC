//
//  DetailedViewController.m
//  Hopwit.me
//
//  Created by Anyuta on 5/13/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "DetailedViewController.h"
#import "DetailedContentTableViewCell.h"
@interface DetailedViewController ()

@end

@implementation DetailedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==0) {
        
        DetailedContentTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"DetailedContentTableViewCell"];
        if (cell==nil) {
            cell=[[DetailedContentTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DetailedContentTableViewCell"];
        }
        cell=contentcell;
    }
    
    return cell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
