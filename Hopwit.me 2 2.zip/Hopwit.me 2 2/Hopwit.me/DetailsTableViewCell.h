//
//  DetailsTableViewCell.h
//  Hopwit.me
//
//  Created by Anyuta on 5/13/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsTableViewCell : UITableViewCell

@end
