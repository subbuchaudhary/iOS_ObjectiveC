//
//  DiscoverViewController.h
//  Hopwit.me
//
//  Created by Anyuta on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverViewController : UIViewController

@end
