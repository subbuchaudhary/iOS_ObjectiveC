//
//  SearchTableViewCell.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTableViewCell : UITableViewCell

@end
