//
//  ChatViewController.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "ChatViewController.h"
#import "SearchTableViewCell.h"
#import "InviteFriendsTableViewCell.h"
#import "FriendsTableViewCell.h"
#import "ChatWindowViewController.h"

@interface ChatViewController ()
{
    NSArray *namesArr, *dpImagesArr, *descriptionArr;
}

@end

@implementation ChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.chatTableView.rowHeight = UITableViewAutomaticDimension;
    self.chatTableView.estimatedRowHeight= 101;
    namesArr = @[@"Patrick Jenkins", @"Robert Black", @"Patrick Jenkins", @"Robert Black"];
    dpImagesArr = @[@"facebookIcon", @"linkedInIcon", @"googleIcon", @"facebookIcon"];
    descriptionArr = @[@"facebookIcon", @"linkedInIcon", @"googleIcon", @"facebookIcon"];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==0) {
        
        SearchTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"SearchTableViewCell"];
        if (cell==nil) {
            cell=[[SearchTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SearchTableViewCell"];
        }
        cell=contentcell;
    }else if(indexPath.row==1)
    {
        InviteFriendsTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"InviteFriendsTableViewCell"];
        if (cell==nil) {
            cell=[[InviteFriendsTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"InviteFriendsTableViewCell"];
        }
        cell=contentcell;
    }
    else
    {
        FriendsTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"FriendsTableViewCell"];
        if (cell==nil) {
            cell=[[FriendsTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FriendsTableViewCell"];
        }

        cell=contentcell;
        contentcell.dpImages.image = [UIImage imageNamed:[dpImagesArr objectAtIndex:indexPath.row-2]];
        contentcell.namesLabel.text = [namesArr objectAtIndex:indexPath.row-2];
        contentcell.descriptionLabel.text = [descriptionArr objectAtIndex:indexPath.row-2];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row !=0 && indexPath.row !=1)
    {
    ChatWindowViewController *chatWindow = [self.storyboard instantiateViewControllerWithIdentifier:@"ChatWindowViewController"];
    [self.navigationController pushViewController:chatWindow animated:YES];
    }
}


@end
