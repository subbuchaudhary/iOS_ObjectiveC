//
//  detailViewController.h
//  tableViewCompletePract
//
//  Created by Subbu Chaudhary on 2/22/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *titleDisplay;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
- (IBAction)cancelBtnClkd:(id)sender;

@end
