//
//  MIDBHelper.h
//  Market Intelligence
//
//  Created by Subbu Chaudhary on 1/27/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
//#import <GD/sqlite3enc.h>

@interface MIDBHelper : NSObject
{
    NSString *dbPath;
}

+(MIDBHelper*)getSharedInstance;
-(void)createDatabase;
- (void) saveData:(NSString*)firstName lastNname:(NSString*)lastName managerSSO:(NSString*)managerSSO sso:(NSString*)sso;
- (void)deleteDataFromFSR;
@end
