//
//  DealerSummaryEntity.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "DealerSummaryEntity.h"
#import "Comment.h"


@implementation DealerSummaryEntity

@dynamic addedManually;
@dynamic branchNo;
@dynamic customerName;
@dynamic customerNumber;
@dynamic isValidated;
@dynamic vbu;
@dynamic commentList;

@end
