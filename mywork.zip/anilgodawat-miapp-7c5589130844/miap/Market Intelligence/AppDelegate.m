//
//  AppDelegate.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "AppDelegate.h"

#import "SurveyUtil.h"
#import "LoginViewController.h"
#import "ViewController.h"
#import "Survey+SurveyCustom.h"

@implementation AppDelegate
const int MAX_IDLE_TIME = 30*60;
@synthesize window;
@synthesize  moc;
@synthesize miModel;
@synthesize currentSurvey;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    UIUserNotificationSettings* notificationSettings = [UIUserNotificationSettings settingsForTypes: UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:notificationSettings];
    
    [self initConfiguration];
    
    self.window = [[UIWindow alloc] init];//[[GDiOS sharedInstance] getWindow];
    //self.good = [GDiOS sharedInstance];
    //_good.delegate = self;
    started = NO;
    //[_good authorize];

    
    // Initialize Persistence Store and Object hierarchy
    /*self.moc = [[NSManagedObjectContext alloc ] init];
    
    NSURL *dataModelURL = [[NSBundle mainBundle] URLForResource:@"MI-DataModel" withExtension:@"momd"];
    self.miModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:dataModelURL];
    
    NSPersistentStoreCoordinator* persistence =
    [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:miModel];
    NSString *storePath = [[[self applicationDocumentsDirectory] path] stringByAppendingPathComponent: @"mi.sqlite"];
    
    NSError* error;
    NSURL *storeUrl = [NSURL fileURLWithPath:storePath];
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
    						 [NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption,
    						 [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption, nil];
    [persistence addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeUrl options:options error:&error];
    
    self.moc.persistentStoreCoordinator = persistence;
    [self.moc setMergePolicy:[[NSMergePolicy alloc] initWithMergeType:NSMergeByPropertyObjectTrumpMergePolicyType]];

    self.surveyUtil = [[SurveyUtil alloc] init];*/
    
    
    //MI_V_1.0
    self.miSurveyUtil = [[MISurveyManager alloc] init];
    LoginViewController* loginController =[[LoginViewController alloc] initWithNibName:nil bundle:nil callback:@selector(loginSuccessful)];
    //self.viewController = loginController;
    [self.window setRootViewController:loginController];
        
    
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
    if (idleTimer)
    {
        [idleTimer invalidate];
    }
    backgroundTimeStamp = [NSDate date];
    //MI_V_1.0
    [self.miSurveyUtil saveCurrentSurvey];
    [UIApplication sharedApplication].applicationIconBadgeNumber = [currentSurvey numberOfUnsentMessages];
    
    NSLog(@"App entering inactive state");
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    if (idleTimer)
    {
        [idleTimer invalidate];
    }
    backgroundTimeStamp = [NSDate date];
    //MI_V_1.0
    [self.miSurveyUtil saveCurrentSurvey];
    [UIApplication sharedApplication].applicationIconBadgeNumber = [currentSurvey numberOfUnsentMessages];
   

    NSLog(@"App entering background state");
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    
    // Check if user has been inactive for long time
    NSDate *currentTimeStamp = [NSDate date];
    
    if (backgroundTimeStamp != nil)
    {
        NSTimeInterval idleTime = [currentTimeStamp timeIntervalSinceDate:backgroundTimeStamp];
        if (idleTime >= MAX_IDLE_TIME)
        {
            [self idleTimerExceeded];
        }
    }
    NSLog(@"App entering forground state");
 
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
     
- (NSURL *)applicationDocumentsDirectory
{
    NSArray *searchPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [searchPaths lastObject];
        
    return [NSURL fileURLWithPath:documentPath];
}

- (void) loginSuccessful
{
    ViewController* vc = [[ViewController alloc] initWithNibName:nil bundle:nil];

    //push view manually
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    [self.window setRootViewController:vc];
   UINavigationController* navController = (UINavigationController*) [storyboard instantiateInitialViewController];
    [self.window setRootViewController:navController];
    [[navController navigationController] pushViewController:vc animated:YES];
    
}

/*
 ** Initializes environment specific variables used from Config list dictionary
 */

- (void) initConfiguration
{
    NSString* configuration = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"Configuration"];
    NSBundle* bundle = [NSBundle mainBundle];
    NSString* envsPListPath = [bundle pathForResource:@
                               "AppConfig" ofType:@"plist"];
    
    NSLog(@"Loading Configuration %@",configuration);
    
    NSDictionary* environments = [[NSDictionary alloc] initWithContentsOfFile:envsPListPath];
    _applicationConfig = [environments objectForKey:configuration];
    
}

- (NSString*) configFor:(NSString*) configKey
{
    NSLog(@"Returning value for %@ --> %@",configKey, [_applicationConfig valueForKey:configKey]);
    return [_applicationConfig valueForKey:configKey];
}

/**
 * Hook (for resetting idle timer) for all UI events in the application
 */
- (void) sendEvent:(UIEvent *)event
{
    [super sendEvent:event];
    
    // Only want to reset the timer on a Began touch or an Ended touch, to reduce the number of timer resets.
    NSSet *allTouches = [event allTouches];
    if ([allTouches count] > 0) {
        // allTouches count only ever seems to be 1, so anyObject works here.
        UITouchPhase phase = ((UITouch *)[allTouches anyObject]).phase;
        if (phase == UITouchPhaseBegan || phase == UITouchPhaseEnded)
            [self resetIdleTimer];
    }
}

- (void)resetIdleTimer {
    if (idleTimer) {
        [idleTimer invalidate];
    }
    
    idleTimer = [NSTimer scheduledTimerWithTimeInterval:MAX_IDLE_TIME target:self selector:@selector(idleTimerExceeded) userInfo:nil repeats:NO] ;
}

- (void)idleTimerExceeded {
    NSLog(@"idle time exceeded");
    [self.miSurveyUtil saveCurrentSurvey];
    //MI_V_1.0
    [self.miSurveyUtil saveCurrentSurvey];
	UIAlertView *alert			=	[[UIAlertView alloc] initWithTitle:@"Idle Time Out. Please Login Again" message:@"" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];

}

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    LoginViewController* loginController =[[LoginViewController alloc] initWithNibName:nil bundle:nil callback:@selector(loginSuccessful)];
    //self.viewController = loginController;
    [self.window setRootViewController:loginController];
    
}


@end
