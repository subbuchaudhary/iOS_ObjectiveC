//
//  NSURLConnection+TrustGESignedCertificate.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/28/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURLConnection (TrustGESignedCertificate)
+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host;
@end
