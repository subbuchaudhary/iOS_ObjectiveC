//
//  DealerSummaryEntity+DealerSummaryCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/6/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "MIDealerSummary.h"
#import "MIDealerList.h"

@interface MIDealerSummary (DealerSummaryCustom)


- (BOOL) isEqualToDealer:(MIDealerList*) aDealer;

-(NSDictionary*) asDictionary;

- (void) encryptWithKey:(NSString*) key;
-(void) decryptWithKey:(NSString*) key;
- (void) copyFromDealer: (MIDealerList*) dealer;


@end
