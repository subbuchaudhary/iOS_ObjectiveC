//
//  SurveyCategory.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyCategory.h"
#import "SubCategory.h"
#import "SuperCategory.h"


@implementation SurveyCategory

@dynamic categoryList;
@dynamic parent;

@end
