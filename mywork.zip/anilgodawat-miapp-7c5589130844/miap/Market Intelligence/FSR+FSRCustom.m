//
//  FSR+FSRCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "FSR+FSRCustom.h"
#import "NSString+AESCrypt.h"

@implementation FSR (FSRCustom)

-(NSDictionary*) asDictionary
{
    NSMutableDictionary* fsrAsDictionary = [[NSMutableDictionary alloc] init];
    
    NSString* name = [NSString stringWithFormat:@"%@, %@",self.lastName,self.firstName];
    [fsrAsDictionary setObject:name forKey:@"Name"];
    
    NSString *deviceId = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    [fsrAsDictionary setObject:@"312-401-1111" forKey:@"PhoneNo"];
    [fsrAsDictionary setObject:self.sso forKey:@"SSO"];
    [fsrAsDictionary setObject:self.managerSSO forKey:@"ManagerSSO"];
    
    return fsrAsDictionary;
}
- (void) encryptWithKey:(NSString*) key
{
    self.sso = [self.sso AES256EncryptWithKey:key ];
    self.firstName = [self.firstName AES256EncryptWithKey:key];
    self.lastName = [self.lastName AES256EncryptWithKey:key];
    self.managerSSO = [self.managerSSO AES256EncryptWithKey:key];
    
}

-(void) decryptWithKey:(NSString*) key
{
    self.sso = [self.sso AES256DecryptWithKey:key ];
    self.firstName = [self.firstName AES256DecryptWithKey:key];
    self.lastName = [self.lastName AES256DecryptWithKey:key];
    self.managerSSO = [self.managerSSO AES256DecryptWithKey:key];
}
@end
