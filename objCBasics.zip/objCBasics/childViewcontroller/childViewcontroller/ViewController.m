//
//  ViewController.m
//  childViewcontroller
//
//  Created by Subbu Chaudhary on 2/3/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "signinViewController.h"
#import "SignUpViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *signupbtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     [self.signinbtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    signinViewController* secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signinViewController"];
    [secondChildVC.view setBackgroundColor:[UIColor redColor]];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0,self.view.frame.size.height/2,self.view.frame.size.width,504);
    [self.view addSubview:secondChildVC.view];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)signupclicked:(id)sender {
    
    
      [self.signinbtn setImage:[UIImage imageNamed:@"deselected_circle.png"] forState:UIControlStateNormal];
  [self.signupbtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    SignUpViewController* secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SignUpViewController"];
    [secondChildVC.view setBackgroundColor:[UIColor greenColor]];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0,self.view.frame.size.height/2,self.view.frame.size.width,504); [self.view addSubview:secondChildVC.view];

}


- (IBAction)signinClkd:(id)sender {
    
    
    [self.signinbtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    
      [self.signupbtn setImage:[UIImage imageNamed:@"deselected_circle.png"] forState:UIControlStateNormal];
    signinViewController* secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signinViewController"];
    [secondChildVC.view setBackgroundColor:[UIColor redColor]];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0,self.view.frame.size.height/2,self.view.frame.size.width,504); [self.view addSubview:secondChildVC.view];
}
@end
