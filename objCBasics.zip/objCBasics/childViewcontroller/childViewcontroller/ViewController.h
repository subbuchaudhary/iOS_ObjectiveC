//
//  ViewController.h
//  childViewcontroller
//
//  Created by Subbu Chaudhary on 2/3/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)signinClkd:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *signinbtn;

@end

