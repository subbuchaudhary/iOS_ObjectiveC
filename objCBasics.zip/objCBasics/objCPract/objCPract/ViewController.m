//
//  ViewController.m
//  objCPract
//
//  Created by Subbu Chaudhary on 1/10/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    //to create title
    [super viewDidLoad];
    UILabel *loginLabel = [[UILabel alloc] init];
    loginLabel.frame = CGRectMake(150, 100, 100, 40);
    [self.view addSubview:loginLabel];
    loginLabel.text = @"Login Page";
    
    //to create text label
    UILabel *username = [[UILabel alloc] init];
    username.frame = CGRectMake(75, 150, 100, 40);
    [self.view addSubview:username];
    username.text = @"Username:";
    
    //to create textfield
    UITextField *usernameField = [[UITextField alloc] init];
    usernameField.frame = CGRectMake(175, 150, 100, 40);
    [self.view addSubview:usernameField];
   // usernameField.text = @"enter username";
    usernameField.layer.borderColor=[UIColor blackColor].CGColor;
    usernameField.layer.borderWidth=1;
    //to create text label
    UILabel *password = [[UILabel alloc] init];
    password.frame = CGRectMake(75, 200, 100, 40);
    [self.view addSubview:password];
    password.text = @"Password:";
    
    //to create text field to enter password
    UITextField *passwordField = [[UITextField alloc] initWithFrame:CGRectMake(175, 200, 100, 40)];
    //passwordField.frame = CGRectMake(175, 200, 100, 40);
    [self.view addSubview:passwordField];
    passwordField.layer.borderWidth = 1;
    passwordField.layer.borderColor = [UIColor blackColor].CGColor;
    
    //to create button
    UIButton *signIn = [UIButton buttonWithType:UIButtonTypeCustom];
    signIn.frame=CGRectMake(200, 250, 100, 40);
    [signIn setTitle:@"SignIn" forState:UIControlStateNormal];
    [signIn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.view addSubview:signIn];
    //signIn. = @"Signin";
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
