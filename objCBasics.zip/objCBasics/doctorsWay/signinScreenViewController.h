//
//  signinScreenViewController.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface signinScreenViewController : UIViewController
- (IBAction)findDrClkd:(id)sender;
- (IBAction)ourPartnersClkd:(id)sender;
- (IBAction)topDrsClkd:(id)sender;
- (IBAction)othersClkd:(id)sender;
@property (weak, nonatomic) IBOutlet UISearchBar *searchItemVieew;

@end
