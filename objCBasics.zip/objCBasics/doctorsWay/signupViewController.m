//
//  signupViewController.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/10/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signupViewController.h"
#import "signinScreenViewController.h"
#import "NetworkApi.h"
@interface signupViewController ()

@end

@implementation signupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)signupClkd:(id)sender {
    
    if ([self.passwordField.text isEqualToString:self.reEnterPassField.text]) {
        
        NSDictionary *dict =@{@"email":self.emailTextField.text,@"mobile": self.mobileNumberField.text, @"password": self.passwordField.text, @"c_pass": self.reEnterPassField.text, @"username": @"Subbu Nivas" };
         NSString *stringApi = [NSString stringWithFormat:@"http://indglobaldemo.com/doctorway_api/index.php/User/user_signup"];
        [NetworkApi starxecuteApi:dict andUrl:stringApi withCompletionBlock:^(NSError *error, id response) {
            NSLog(@"response %@",response);
            
        }];
    }
    else
    {
        
    }
    //indglobaldemo.com/doctorway_api/index.php/User/user_signup
//    email
//    mobile
//    password
//    c_pass
//    username
    
//    signinScreenViewController *signupScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"signinScreenViewController"];
//    [self presentViewController:signupScreen animated:YES completion:nil];
}



@end
