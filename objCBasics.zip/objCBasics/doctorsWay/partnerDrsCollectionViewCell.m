//
//  partnerDrsCollectionViewCell.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/13/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "partnerDrsCollectionViewCell.h"

@implementation partnerDrsCollectionViewCell

@end
