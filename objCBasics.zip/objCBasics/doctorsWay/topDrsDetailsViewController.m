//
//  topDrsDetailsViewController.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/12/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "topDrsDetailsViewController.h"

@interface topDrsDetailsViewController ()

@end

@implementation topDrsDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dpDisplayView.layer.cornerRadius=50;
    self.dpDisplayView.layer.masksToBounds=YES;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
