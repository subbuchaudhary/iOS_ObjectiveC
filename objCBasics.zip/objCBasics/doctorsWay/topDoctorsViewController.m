//
//  topDoctorsViewController.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "topDoctorsViewController.h"
#import "doctorsCustomTableViewCell.h"
#import "topDrsDetailsViewController.h"
#import <QuartzCore/QuartzCore.h>
@interface topDoctorsViewController ()
{
    NSArray *imgArray;
    NSArray *drName;
    NSArray *drSpeciality;
}

@end

@implementation topDoctorsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.topdrsView.rowHeight = UITableViewAutomaticDimension;
    self.topdrsView.estimatedRowHeight = 150;
    imgArray = @[@"_DSC7328.JPG", @"_DSC7359.JPG", @"Me suite.jpg", @"_DSC7328.JPG", @"_DSC7359.JPG", @"Me suite.jpg"];
    drName = @[@"Subbu", @"Nivas", @"Subbu Chaudhary", @"Subbu", @"Nivas", @"Subbu Chaudhary"];
    drSpeciality = @[@"Orthopedic", @"Cardiac", @"Dermatologist", @"Orthopedic", @"Cardiac", @"Dermatologist"];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return imgArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    doctorsCustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if(cell == nil)
    {
        cell = [[doctorsCustomTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
    }
    cell.dpView.image = [UIImage imageNamed:[imgArray objectAtIndex:indexPath.row]];
    cell.dpView.layer.cornerRadius = cell.dpView.frame.size.width/3.5;
    cell.dpView.layer.masksToBounds=YES;
    cell.titleView.text = [drName objectAtIndex:indexPath.row];
    cell.specializationView.text = [drSpeciality objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    topDrsDetailsViewController *screen = [self.storyboard instantiateViewControllerWithIdentifier:@"topDrsDetailsViewController"];
    //[self.navigationController pushViewController:screen animated:YES];
    [self presentViewController:screen animated:YES completion:nil];
    screen.dpDisplayView.image = [UIImage imageNamed:[imgArray objectAtIndex:indexPath.row]];
    screen.titleDisplayView.text = [drName objectAtIndex:indexPath.row];
    screen.specialityView.text = [drSpeciality objectAtIndex:indexPath.row];
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 81;
//}

@end
