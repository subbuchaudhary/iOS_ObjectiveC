//
//  doctorsCustomTableViewCell.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface doctorsCustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *dpView;
@property (weak, nonatomic) IBOutlet UILabel *titleView;
@property (weak, nonatomic) IBOutlet UILabel *specializationView;

@end
