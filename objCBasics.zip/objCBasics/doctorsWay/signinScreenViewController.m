//
//  signinScreenViewController.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signinScreenViewController.h"
#import "findDoctorViewController.h"
#import "ourPartnersViewController.h"
#import "topDoctorsViewController.h"
#import "otherOffersViewController.h"

@interface signinScreenViewController ()

@end

@implementation signinScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    findDoctorViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"findDoctorViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 120, self.view.frame.size.width, self.view.frame.size.height-120);
    [self.view addSubview:firstChildVC.view];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)findDrClkd:(id)sender {
    findDoctorViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"findDoctorViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 120, self.view.frame.size.width, self.view.frame.size.height-120);
    [self.view addSubview:firstChildVC.view];
}

- (IBAction)ourPartnersClkd:(id)sender {
    ourPartnersViewController *secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ourPartnersViewController"];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0, 120, self.view.frame.size.width, self.view.frame.size.height-120);
    [self.view addSubview:secondChildVC.view];
}

- (IBAction)topDrsClkd:(id)sender {
    topDoctorsViewController *thirdChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"topDoctorsViewController"];
    [self addChildViewController:thirdChildVC];
    [thirdChildVC didMoveToParentViewController:self];
    thirdChildVC.view.frame = CGRectMake(0, 120, self.view.frame.size.width, self.view.frame.size.height);
    [self.view addSubview:thirdChildVC.view];
}

- (IBAction)othersClkd:(id)sender {
    otherOffersViewController *fourthChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"otherOffersViewController"];
    [self addChildViewController:fourthChildVC];
    [fourthChildVC didMoveToParentViewController:self];
    fourthChildVC.view.frame = CGRectMake(0, 120, self.view.frame.size.width, self.view.frame.size.height-120);
    [self.view addSubview:fourthChildVC.view];
}
@end
