//
//  signinViewController.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/10/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface signinViewController : UIViewController
- (IBAction)forgotPassSlctd:(id)sender;
- (IBAction)signInClkd:(id)sender;

@end
