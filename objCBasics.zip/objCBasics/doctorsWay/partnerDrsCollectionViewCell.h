//
//  partnerDrsCollectionViewCell.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/13/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface partnerDrsCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *logoDisplay;
@property (weak, nonatomic) IBOutlet UILabel *nameDisplay;

@end
