//
//  doctorsCustomTableViewCell.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "doctorsCustomTableViewCell.h"

@implementation doctorsCustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
