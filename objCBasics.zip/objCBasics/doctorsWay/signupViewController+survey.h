//
//  signupViewController+survey.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/27/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signupViewController.h"

@interface signupViewController (survey)

@end
