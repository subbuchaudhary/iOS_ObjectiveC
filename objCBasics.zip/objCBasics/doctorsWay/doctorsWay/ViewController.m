//
//  ViewController.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/10/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "signupViewController.h"
#import "signinViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.signInBtn setImage:[UIImage imageNamed:@"checkbox_on.png"] forState:UIControlStateNormal];
    [self.signUpBtn setImage:[UIImage imageNamed:@"checkbox_off.png"] forState:UIControlStateNormal];
    signinViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signinViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 200, self.view.frame.size.width, self.view.frame.size.height);
    [self.view addSubview:firstChildVC.view];
    // Do any additional setup after loading the view, typically from a nib}
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)signInClkd:(id)sender {
    [self.signInBtn setImage:[UIImage imageNamed:@"checkbox_on.png"] forState:UIControlStateNormal];
    [self.signUpBtn setImage:[UIImage imageNamed:@"checkbox_off.png"] forState:UIControlStateNormal];
    signinViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signinViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 200, self.view.frame.size.width, self.view.frame.size.height-200);
    [self.view addSubview:firstChildVC.view];
    
}

- (IBAction)signUpClkd:(id)sender {
    [self.signUpBtn setImage:[UIImage imageNamed:@"checkbox_on.png"] forState:UIControlStateNormal];
    [self.signInBtn setImage:[UIImage imageNamed:@"checkbox_off.png"] forState:UIControlStateNormal];
    signupViewController *secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signupViewController"];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0, 200, self.view.frame.size.width, self.view.frame.size.height-200);
    [self.view addSubview:secondChildVC.view];
}
@end
