//
//  ViewController.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/10/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)signInClkd:(id)sender;
- (IBAction)signUpClkd:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *signInBtn;
@property (weak, nonatomic) IBOutlet UIButton *signUpBtn;

@end

