//
//  topDrsDetailsViewController.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/12/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface topDrsDetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *dpDisplayView;
@property (weak, nonatomic) IBOutlet UILabel *titleDisplayView;
@property (weak, nonatomic) IBOutlet UILabel *specialityView;

@end
