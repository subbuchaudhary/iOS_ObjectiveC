//
//  partnerHospitalDetailsViewController.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/13/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface partnerHospitalDetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *hopspitalLogoDisplay;
@property (weak, nonatomic) IBOutlet UILabel *hospitalNameDisplay;

@end
