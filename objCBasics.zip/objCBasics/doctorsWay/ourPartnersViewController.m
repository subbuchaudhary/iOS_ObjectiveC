//
//  ourPartnersViewController.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ourPartnersViewController.h"
#import "partnerDrsCollectionViewCell.h"
#import "partnerHospitalDetailsViewController.h"

@interface ourPartnersViewController ()
{
    NSArray *hospitalLogo;
    NSArray *hospitalName;
}

@end

@implementation ourPartnersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    hospitalLogo = @[@"Al-Amal-Maternity-Hospital.jpg", @"Apollohospitals.jpg", @"CapitalHospital.jpg", @"FamilyClinic.gif", @"HeartTrainingCenter.gif", @"Panacea_Clinic.gif", @"Psycaid.jpg", @"redcross.jpg", @"SnakeGroupOfhospitals.jpg", @"TaibaHospital.jpg", @"TheWomansHealingHospital.jpg"];
    hospitalName = @[@"Al-Amal Maternity Hospital", @"Apollo Hospitals", @"Capital Hospital", @"Family Clinic", @"Heart Training Center", @"Panacea Clinic", @"Psycaid", @"American Red Cross", @"Snake Group of Hospitals", @"Taiba Hospital", @"The Womans Healing Hospital"];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return hospitalName.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    partnerDrsCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
//    if(cell == nil)
//    {
//        cell = [[partnerDrsCollectionViewCell alloc] initWithFrame:CGRectMake(0, 0, 163, 100)];
//        
//    }
    cell.logoDisplay.image = [UIImage imageNamed:[hospitalLogo objectAtIndex:indexPath.row]];
    cell.layer.borderWidth=1.0f;
   // cell.layer.borderColor=[UIColor blueColor].CGColor;
   // cell.nameDisplay.text = [hospitalName objectAtIndex:indexPath.row];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    partnerHospitalDetailsViewController *screen = [self.storyboard instantiateViewControllerWithIdentifier:@"partnerHospitalDetailsViewController"];
  //  [self.navigationController pushViewController:screen animated:YES];
    [self presentViewController:screen animated:YES completion:nil];
    screen.hopspitalLogoDisplay.image = [UIImage imageNamed:[hospitalLogo objectAtIndex:indexPath.row]];
    screen.hospitalNameDisplay.text = [hospitalName objectAtIndex:indexPath.row];
}
- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    float cellWidth = screenWidth / 2.0; //Replace the divisor with the column count requirement. Make sure to have it in float.
    CGSize size = CGSizeMake(cellWidth, cellWidth);
    
    return size;
}

@end
