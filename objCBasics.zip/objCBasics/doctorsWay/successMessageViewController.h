//
//  successMessageViewController.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface successMessageViewController : UIViewController
- (IBAction)signInSlctd:(id)sender;

@end
