//
//  ViewController.m
//  mutableArray
//
//  Created by Subbu Chaudhary on 2/14/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray * image;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    image = @[@"Book", @"Pen"];
    
    NSMutableArray *mutarray=[[NSMutableArray alloc]initWithObjects:@"A",@"B",nil];
    
    [mutarray addObject:@"c"];
    mutarray[1]=@"d";
    [mutarray insertObject:@"e" atIndex:0];
    [mutarray removeObject:@"A"];
    [mutarray removeAllObjects];
    
    NSDictionary *dict=@{@"name":@"latha",@"mobile":@"8550003293",@"emailid":@"latha.kadiyala6@gmail.com"};
    
    
    NSLog(@"%@",dict);
//    NSArray *myaaray=[[NSArray alloc]init];
//    NSArray *yourarray=[NSArray new];
//    NSArray *array=[NSArray array];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
