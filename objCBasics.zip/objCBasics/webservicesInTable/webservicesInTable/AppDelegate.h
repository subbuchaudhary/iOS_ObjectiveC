//
//  AppDelegate.h
//  webservicesInTable
//
//  Created by Subbu Chaudhary on 2/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

