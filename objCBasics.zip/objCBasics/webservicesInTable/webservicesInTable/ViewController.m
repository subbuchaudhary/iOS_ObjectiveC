//
//  ViewController.m
//  webservicesInTable
//
//  Created by Subbu Chaudhary on 2/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "customTableViewCell.h"
#import "detailViewController.h"

@interface ViewController ()
{
    NSArray *jsonArray;
    NSDictionary *dict;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *getApi = [NSString stringWithFormat:@"http://data.colorado.gov/resource/4ykn-tg5h.json"];
    NSURL *url = [NSURL URLWithString:getApi];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        jsonArray = [NSJSONSerialization JSONObjectWithData:data options:nil error:nil];
        [self.tableViewDisp reloadData];
    }];
    [task resume];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return jsonArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    customTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if(cell == nil)
    
    {
        cell = [[customTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
    }
    dict = [jsonArray objectAtIndex:indexPath.row];
    cell.agentName.text = dict[@"agentfirstname"];
    cell.entityName.text = dict[@"entityname"];
    cell.adress.text = dict[@"agentprincipaladdress1"];
    [cell.place setText : [NSString stringWithFormat:@"%@, %@, %@", dict[@"agentprincipalcity"], dict[@"agentprincipalstate"], dict[@"agentprincipalcountry"]]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    detailViewController *detailScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"detailViewController"];
    [self.navigationController pushViewController:detailScreen animated:YES];
    //[self presentViewController:detailScreen animated:YES completion:nil];
    //detailScreen.contentDisplay = dict[@"agentfirstname", @"entityname", @"agentprincipaladdress1", @"agentprincipalcity", @"agentprincipalstate", @"agentprincipalcountry"];
}


@end
