//
//  ViewController.m
//  NSDictionary
//
//  Created by Subbu Chaudhary on 2/24/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSDictionary *dictionary=@{@"firstname":@"latha",@"lastname":@"kadiyala",@"mobileno":@"85500q3434",@"email":@"latha@gmail.com",@"state":@"karnataka",@"city":@"bangalore",@"location":@"Btm"};
    
    NSLog(@"%@",[dictionary objectForKey:@"state"]);
    

    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
