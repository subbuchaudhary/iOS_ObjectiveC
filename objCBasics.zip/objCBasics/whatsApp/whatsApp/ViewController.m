//
//  ViewController.m
//  whatsApp
//
//  Created by Subbu Chaudhary on 2/3/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "CustomTableViewCell.h"
@interface ViewController ()

{
    NSArray *array;
    NSArray *array1;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    array = @[@"BMW", @"BENZ"];
    array1 = @[@"mobile_number.png", @"splashscreen.png"];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return array.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if (cell == nil)
    {
        cell = [[CustomTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
    }
    cell.labelOne.text = [array objectAtIndex:indexPath.row];
     cell.descriptionLabel.text = [array objectAtIndex:indexPath.row];
    cell.dpLabel.image=[UIImage imageNamed:[array1 objectAtIndex:indexPath.row]];
    return cell;
}


@end
