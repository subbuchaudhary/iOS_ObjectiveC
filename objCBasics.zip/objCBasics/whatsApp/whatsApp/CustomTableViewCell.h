//
//  CustomTableViewCell.h
//  whatsApp
//
//  Created by Subbu Chaudhary on 2/3/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *labelOne;
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;
@property (weak, nonatomic) IBOutlet UIImageView *dpLabel;

@end
