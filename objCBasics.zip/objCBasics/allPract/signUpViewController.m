//
//  signUpViewController.m
//  allPract
//
//  Created by Subbu Chaudhary on 1/21/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signUpViewController.h"

@interface signUpViewController ()

@end

@implementation signUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // to create title label
    UILabel *signUpTitle = [[UILabel alloc] initWithFrame:CGRectMake(125, 100, 90, 30)];
    [self.view addSubview:signUpTitle];
    signUpTitle.text = @"Sign Up";
    
    // to create icon
    UIImageView *fullNameIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 150, 30, 30)];
    [self.view addSubview:fullNameIcon];
    fullNameIcon.image = [UIImage imageNamed:@"login_user.png"];
    
    // to create name text
    UITextField *fullName = [[UITextField alloc] initWithFrame:CGRectMake(45, 150, 150, 30)];
    [self.view addSubview:fullName];
    
    //to create line
    UITextView *lineFirst = [[UITextView alloc] initWithFrame:CGRectMake(10, 200, 180, 1)];
    [self.view addSubview:lineFirst];
    lineFirst.layer.borderWidth = 1;
    lineFirst.layer.borderColor = [UIColor blackColor].CGColor;
    
    //to create mobile number icon
    UIImageView *mobileNumIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 230, 30, 30)];
    [self.view addSubview:mobileNumIcon];
    mobileNumIcon.image = [UIImage imageNamed:@"mobile_number.png"];
    
    //to create mobile number textfield
    UITextField *mobileNumber = [[UITextField alloc] initWithFrame:CGRectMake(45, 230, 150, 30)];
    [self.view addSubview:mobileNumber];
    
    //to create line
    UITextView *lineNext = [[UITextView alloc] initWithFrame:CGRectMake(10, 280, 180, 1)];
    [self.view addSubview:lineNext];
    lineNext.layer.borderWidth = 1;
    lineNext.layer.borderColor = [UIColor blackColor].CGColor;
    
    // to create email icon
    UIImageView *emailIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 310, 30, 30)];
    [self.view addSubview:emailIcon];
    emailIcon.image = [UIImage imageNamed:@"email.png"];
    
    //to create email textfield
    UITextField *email = [[UITextField alloc] initWithFrame:CGRectMake(45, 310, 150, 30)];
    [self.view addSubview:email];
    
    //to create line
    UITextView *lineNextOne = [[UITextView alloc] initWithFrame:CGRectMake(10, 360, 180, 1)];
    [self.view addSubview:lineNextOne];
    lineNextOne.layer.borderWidth = 1;
    lineNextOne.layer.borderColor = [UIColor blackColor].CGColor;
    
    //to create password icon
    UIImageView *passwordIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 390, 30, 30)];
    [self.view addSubview:passwordIcon];
    passwordIcon.image = [UIImage imageNamed:@"password.png"];
    
    //to create password field
    UITextField *passwordField = [[UITextField alloc] initWithFrame:CGRectMake(45, 390, 150, 30)];
    [self.view addSubview:passwordField];
    
    //to create line
    UITextView *lineNextTwo = [[UITextView alloc] initWithFrame:CGRectMake(10, 440, 180, 1)];
    [self.view addSubview:lineNextTwo];
    lineNextTwo.layer.borderWidth = 1;
    lineNextTwo.layer.borderColor = [UIColor blackColor].CGColor;
    
    //to create button
    UIButton *signUp = [UIButton buttonWithType:UIButtonTypeCustom];
    signUp.frame = CGRectMake(125, 480, 90, 30);
    [self.view addSubview:signUp];
    [signUp setTitle:@"Sign Up" forState:UIControlStateNormal];
    [signUp setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [signUp setBackgroundColor:[UIColor greenColor]];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
