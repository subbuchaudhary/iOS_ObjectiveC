//
//  forgotPasswordViewController.h
//  allPract
//
//  Created by Subbu Chaudhary on 1/21/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface forgotPasswordViewController : UIViewController

@end
