//
//  ViewController.m
//  allPract
//
//  Created by Subbu Chaudhary on 1/21/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "signUpViewController.h"
#import "forgotPasswordViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    
//    UIImageView *screen =[[UIImageView alloc] initWithFrame:CGRectMake(10, 100, 300, 200)];
//    [self.view addSubview:screen];
//    screen.image = [UIImage imageNamed:@"15940552_1844670472484255_13536710997077557_n.jpg"];
    
    
    
    //to create title
    UILabel *login = [[UILabel alloc] initWithFrame:CGRectMake(125, 75, 60, 30)];
    [self.view addSubview:login];
    login.text = @"LOGIN";
    
    //to create login icon
    UIImageView *loginIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 150, 30, 30)];
    [self.view addSubview:loginIcon];
    loginIcon.image = [UIImage imageNamed:@"login_user.png"];
    
    //to create login field
    UITextField *loginField = [[UITextField alloc] initWithFrame:CGRectMake(45, 150, 150, 30)];
    [self.view addSubview:loginField];
    loginField.placeholder=@"enter username";
     //to create line
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(10, 200, 180, 1)];
    [self.view addSubview:line];
    line.layer.borderWidth = 1;
    line.layer.borderColor = [UIColor blackColor].CGColor;
    
    //TO create password icon
    UIImageView *passwordIcon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 230, 30, 30)];
    [self.view addSubview:passwordIcon];
    passwordIcon.image = [UIImage imageNamed:@"password.png"];
    
    //to create password field
    UITextField *passwordField = [[UITextField alloc] initWithFrame:CGRectMake(45, 230, 150, 30)];
    [self.view addSubview:passwordField];
    passwordField.placeholder = @"enter your password";
    
    //to create line
    UIView *lineSec = [[UIView alloc] initWithFrame:CGRectMake(10, 290, 180, 1)];
    [self.view addSubview:lineSec];
    lineSec.layer.borderWidth = 1;
    lineSec.layer.borderColor = [UIColor blackColor].CGColor;
    
    //to create forgot password button
    UIButton *frgtPass = [UIButton buttonWithType:UIButtonTypeCustom];
    frgtPass.frame = CGRectMake(100, 310, 150, 15);
    [self.view addSubview:frgtPass];
    [frgtPass setTitle:@"forgot password?" forState:UIControlStateNormal];
    [frgtPass setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [frgtPass addTarget:self action:@selector(nextScreen) forControlEvents:UIControlEventTouchUpInside];
    
    // to create login button
    UIButton *signIn = [UIButton buttonWithType:UIButtonTypeCustom];
    signIn.frame = CGRectMake(125, 350, 60, 30);
    [self.view addSubview:signIn];
    [signIn setTitle:@"SignIn" forState:UIControlStateNormal];
    [signIn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [signIn setBackgroundColor:[UIColor greenColor]];
    
    // to create label
    UILabel *createAcnt = [[UILabel alloc] initWithFrame:CGRectMake(75, 450, 250, 30)];
    [self.view addSubview:createAcnt];
    createAcnt.text = @"Don't Have Account?";
    
    //to create button
    UIButton *signUp = [UIButton buttonWithType:UIButtonTypeCustom];
    signUp.frame = CGRectMake(125, 480, 75, 30);
    [self.view addSubview:signUp];
    [signUp setTitle:@"Sign Up" forState:UIControlStateNormal];
    [signUp setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [signUp addTarget:self action:@selector(navigateScreen) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void) nextScreen {
    forgotPasswordViewController *frgtPasswordScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"frgtPassScrn"];
    [self.navigationController pushViewController:frgtPasswordScreen animated:YES];
}

-(void) navigateScreen {
    signUpViewController *signUpScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"signUpScrn"];
    [self.navigationController pushViewController:signUpScreen animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
