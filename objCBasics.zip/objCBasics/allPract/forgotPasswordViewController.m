//
//  forgotPasswordViewController.m
//  allPract
//
//  Created by Subbu Chaudhary on 1/21/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "forgotPasswordViewController.h"

@interface forgotPasswordViewController ()

@end

@implementation forgotPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // to create title label
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(75, 100, 200, 30)];
    [self.view addSubview:title];
    title.text = @"FORGOT PASSWORD";
    
    //to create textview
    UITextView *instruct = [[UITextView alloc] initWithFrame:CGRectMake(60, 150, 240, 30)];
    [self.view addSubview:instruct];
    instruct.text = @"Enter your mobile number or email";
    
    //to create mobile number or email field
    UITextField *mobileNumber = [[UITextField alloc] initWithFrame:CGRectMake(45, 230, 150, 30)];
    [self.view addSubview:mobileNumber];
    
    //to create line
    UITextView *lineNext = [[UITextView alloc] initWithFrame:CGRectMake(45, 280, 180, 1)];
    [self.view addSubview:lineNext];
    lineNext.layer.borderWidth = 1;
    lineNext.layer.borderColor = [UIColor blackColor].CGColor;
    
    //to create button
    UIButton *submit = [UIButton buttonWithType:UIButtonTypeCustom];
    submit.frame = CGRectMake(125, 350, 90, 30);
    [self.view addSubview:submit];
    [submit setTitle:@"Submit" forState:UIControlStateNormal];
    [submit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [submit setBackgroundColor:[UIColor greenColor]];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
