//
//  ViewController.m
//  ArrayConcepts
//
//  Created by Subbu Chaudhary on 1/30/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *orgArray=[[NSArray alloc]initWithObjects: [NSNumber numberWithInt:1], [NSNumber numberWithInt:7], [NSNumber numberWithInt:3], [NSNumber numberWithInt:7], [NSNumber numberWithInt:4], [NSNumber numberWithInt:4], nil];
   // NSMutableSet *repeatNum = [NSMutableSet set];
    NSMutableArray *resultArray = [NSMutableArray array];
    for(id object in orgArray)
    {
        if(![resultArray containsObject:object])
        {
            //[repeatNum addObject:[object num]];
            [resultArray addObject:object];
        }
    }
    
    
   // NSArray *myarray=@[@"goa",@"banana"];
    
    NSLog(@"%@",resultArray);
   // NSLog(@"%@",[myarray objectAtIndex:0]);
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
