//
//  ViewController.m
//  postApi
//
//  Created by Subbu Chaudhary on 2/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize userId;
@synthesize password;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *stringApi = [NSString stringWithFormat:@"https://cdfconnect-sit.wellsfargo.com/8443/INFO/Public/identity.rst"];
    
    NSURL *url = [NSURL URLWithString:stringApi];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:userId, @"U480157", password, @"Abcd@123", nil];
   // NSDictionary *dict =@{@"userId": @"U480157",@"password": @"Abcd@123"};
    //to convert into nsdata format
    NSData *postdata=[NSJSONSerialization dataWithJSONObject:dict options:nil error:nil];
    
    [request setHTTPMethod:@"POST"];
   
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setHTTPBody:postdata];
    
    NSURLSession *session=[NSURLSession sharedSession];
    
    NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSError *err;
        NSDictionary *jsonarray=[NSJSONSerialization JSONObjectWithData:data options:nil error:&err];
        NSLog(@"%@",jsonarray);
        
     
        
        
        
    }];
    
    [task resume];

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
/*
 http://13.92.196.40/homitatapi/api/User/Login
 {
 "UserName": "ios@test.com",
 "Password": "Passw0rd"
 }
 http://appserver.constient.com/HomitatServiceUAT/api/Dimension/ViewHistory
 NSDictionary *parameter=@{@"UserInfoId":@"19"};
 
 
 
 */
