//
//  ViewController.h
//  postApi
//
//  Created by Subbu Chaudhary on 2/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
@public
NSString *userId;
NSString *password;
}
@property (nonatomic, retain) NSString *userId;
@property (nonatomic, retain) NSString *password;
@end

