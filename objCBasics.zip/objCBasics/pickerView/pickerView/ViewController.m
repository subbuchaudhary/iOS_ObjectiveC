//
//  ViewController.m
//  pickerView
//
//  Created by Subbu Chaudhary on 2/11/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *dataarray;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    dataarray =@[@"1",@"2",@"3"];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return dataarray.count;
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return dataarray[row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _labelView.text=dataarray[row];
    _pickerView.hidden = YES;
    
    
}
- (BOOL) textField: (UITextField *)theTextField shouldChangeCharactersInRange:(NSRange)range replacementString: (NSString *)string {
    //return yes or no after comparing the characters
    
    // allow backspace
    if (!string.length)
    {
        return YES;
    }
    
    ////for Decimal value start//////This code use use for allowing single decimal value
    //    if ([theTextField.text rangeOfString:@"."].location == NSNotFound)
    //    {
    //        if ([string isEqualToString:@"."]) {
    //            return YES;
    //        }
    //    }
    //    else
    //    {
    //        if ([[theTextField.text substringFromIndex:[theTextField.text rangeOfString:@"."].location] length]>2)   // this allow 2 digit after decimal
    //        {
    //            return NO;
    //        }
    //    }
    ////for Decimal value End//////This code use use for allowing single decimal value
    
    // allow digit 0 to 9
    if ([string intValue])
    {
        return YES;
    }
    
    return NO;
}

@end
