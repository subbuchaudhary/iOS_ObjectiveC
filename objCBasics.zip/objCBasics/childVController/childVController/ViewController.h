//
//  ViewController.h
//  childVC
//
//  Created by Subbu Chaudhary on 2/4/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *signinBtn;
- (IBAction)signinSlctd:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *signupBtn;
- (IBAction)signupSlctd:(id)sender;


@end

