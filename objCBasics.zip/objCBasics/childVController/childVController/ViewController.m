//
//  ViewController.m
//  childVC
//
//  Created by Subbu Chaudhary on 2/4/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "signinViewController.h"
#import "signupViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self.signinBtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    signinViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signinViewController"];
    [firstChildVC.view setBackgroundColor:[UIColor redColor]];
   [self addChildViewController:firstChildVC];
//    
//    firstChildVC.view.frame = CGRectMake(0,100,self.view.frame.size.width,self.view.frame.size.height);
//    [self.view addSubview:firstChildVC.view];
//    [firstChildVC didMoveToParentViewController:self];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)signinSlctd:(id)sender {
    [self.signinBtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    [self.signupBtn setImage:[UIImage imageNamed:@"deselected.png"] forState:UIControlStateNormal];
    signinViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signinViewController"];
    [firstChildVC.view setBackgroundColor:[UIColor blueColor]];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0,100,self.view.frame.size.width,self.view.frame.size.height-100);
    [self.view addSubview:firstChildVC.view];
}
- (IBAction)signupSlctd:(id)sender {
    [self.signupBtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    [self.signinBtn setImage:[UIImage imageNamed:@"deselected.png"] forState:UIControlStateNormal];
    signupViewController *secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signupViewController"];
    [secondChildVC.view setBackgroundColor:[UIColor redColor]];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0,100,self.view.frame.size.width,self.view.frame.size.height);
    [self.view addSubview:secondChildVC.view];
}
@end
