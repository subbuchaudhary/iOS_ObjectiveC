//
//  main.m
//  objectOriented
//
//  Created by Subbu Chaudhary on 1/7/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface House : NSObject
{
    
  //  float length;
   // float breadth;
    
    
}
@property float length;
@property float breadth;
//-(void)setlenghtandbreadth;
//-(void)getdetails;
@end


@implementation House


//-(void)setlenghtandbreadth{
//    
//    length=90.09;
//    breadth=80;
//}
//
//-(void)getdetails
//{
//    
//    NSLog(@"value of length is %f and breadth is %f",length, breadth);
//}
@end
int main(int argc, const char * argv[]) {
    House *place = [[House alloc] init ];
    
    place.length=90.09;
    place.breadth=80;
     NSLog(@"value of length is %f and breadth is %f",place.length, place.breadth);
  //  [place setlenghtandbreadth];place
   // [place getdetails];
    
    return 0;
}
