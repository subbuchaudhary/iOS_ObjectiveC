//
//  ViewController.m
//  uiPickerViewPract
//
//  Created by Subbu Chaudhary on 2/23/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *selectOptions;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    selectOptions = @[@"Dentist", @"Cardiologist", @"Numerologist", @"Orthopedic"];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return selectOptions.count;
}
- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return selectOptions[row];
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.pickingView.hidden = YES;
    _labelDisplay.text = selectOptions[row];
}


@end
