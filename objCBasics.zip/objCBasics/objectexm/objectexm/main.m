//
//  main.m
//  objectexm
//
//  Created by Subbu Chaudhary on 2/27/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Car : NSObject
@property NSString *carname;
-(void)assignname;
+(void)myname;
@end

@implementation Car

+(void)myname
{

}

-(void)assignname
{

}

@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        Car *obj=[[Car alloc]init];
        obj.carname=@"HONDA";
        [obj assignname];
        [Car myname];
    }
    return 0;
}
