//
//  detailViewController.h
//  tablePrac
//
//  Created by Subbu Chaudhary on 2/6/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *labelView;
- (IBAction)cancelClkd:(id)sender;

@end
