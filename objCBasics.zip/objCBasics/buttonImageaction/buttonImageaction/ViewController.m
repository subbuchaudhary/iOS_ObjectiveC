//
//  ViewController.m
//  buttonImageaction
//
//  Created by Subbu Chaudhary on 1/22/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *radiobtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)radiobuttonclicked:(id)sender {
    
    
    [_radiobtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
}


@end
