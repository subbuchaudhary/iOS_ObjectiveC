//
//  ViewController.m
//  whatsappPract
//
//  Created by Subbu Chaudhary on 2/5/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "customTableViewCell.h"

@interface ViewController ()
{
    NSArray *name;
    NSArray *imgArray;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.detailViewTable.rowHeight = UITableViewAutomaticDimension;
    self.detailViewTable.estimatedRowHeight= 101;
    name = @[@"BMW Bayerische Motoren Werke AG (German pronunciation: [ˈbaɪ̯ʁɪʃə mɔˈtʰɔʁn̩ ˈvɛɐ̯kə] ( listen); German for Bavarian Motor Works), usually known under its abbreviation BMW (German pronunciation: [ˈbeːˈʔɛmˈveː] ( listen)), is a German luxury vehicle, motorcycle, and engine manufacturing company founded in 1916. It is one of the best-selling luxury automakers in the world.[3] The company is a component of the Euro Stoxx 50 stock market index.[4] Headquartered in Munich, Bavaria, BMW owns Mini cars and is the parent company of Rolls-Royce Motor Cars. BMW produces motorcars under the BMW Motorsport division and motorcycles under BMW Motorrad, and plug-in electric cars under the BMW i sub-brand and the iPerformance model designation within the regular BMW lineup.", @"Benz"];
    imgArray = @[@"bmw.jpg", @"benz.jpg"];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return name.count;
    return imgArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    customTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if (cell == nil)
    {
        cell = [[customTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
    }
    cell.titleView.text = [name objectAtIndex:indexPath.row];
    cell.dpView.image = [UIImage imageNamed:[imgArray objectAtIndex:indexPath.row]];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

@end
