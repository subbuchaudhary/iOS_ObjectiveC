//
//  main.m
//  objCBasics
//
//  Created by Subbu Chaudhary on 1/6/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <Foundation/Foundation.h>


//returntype methodname(arguments)
//{
    
//}
int add(int a, int b)
{
    
    float z = a + b;
    return z;
}



int main(int argc, const char * argv[]) {
   // @autoreleasepool {
        // insert code here...
    
    
    int x=30 ;float y = 60.0;

 //   int z=x+y;
    
    NSLog(@"value of x is %d and y is %f", x,y);
   
 int value = add(6, 7);
    NSLog(@"value of z is %d",value);
    return 0;
}
