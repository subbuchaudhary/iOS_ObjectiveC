//
//  ViewController.m
//  ImageView
//
//  Created by Subbu Chaudhary on 1/21/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 100, 300, 200)];
    [self.view addSubview:imageView];
    imageView.image=[UIImage imageNamed:@"nature.jpeg"];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
