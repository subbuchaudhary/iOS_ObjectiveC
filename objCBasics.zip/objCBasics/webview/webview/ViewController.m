//
//  ViewController.m
//  webview
//
//  Created by Subbu Chaudhary on 2/24/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *url = [NSString stringWithFormat:@"%s","https://www.facebook.com"];
    
    NSURL *urlstring=[NSURL URLWithString:url];
    
    NSURLRequest *request=[NSURLRequest requestWithURL:urlstring];
    
    [self.webOutlet loadRequest:request];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
