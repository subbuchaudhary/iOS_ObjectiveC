//
//  ViewController.h
//  webview
//
//  Created by Subbu Chaudhary on 2/24/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webOutlet;


@end
//
//{"created":false,"userName":"","identity_id":"","errorMessage":"Invalid phone number format.","errorType":"InvalidParameterException"}
//
//{
//    givenName = latha;
//    lastName = kadiyala;
//    password = "Latha@123";
//    phoneNumber = 918550003293;
//    postalCode = 560027;
//    type = signup;
//}
//
//
//{"created":true,"userName":"14092910501","identity_id":"1vkde054jd2so772uc8d9ktd7a","errorMessage":"","errorType":""}
//https://78ygtszm81.execute-api.us-east-1.amazonaws.com/dev/getdealsbyuser?userId=14092910501
