//
//  ViewController.m
//  tableViewCompletePract
//
//  Created by Subbu Chaudhary on 2/22/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "detailViewController.h"
#import "customTableViewCell.h"

@interface ViewController ()
{
    NSArray *jsonArray;
    NSString *dictonaryName;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *getApi = [NSString stringWithFormat:@"http://data.colorado.gov/resource/4ykn-tg5h.json"];
    NSURL *url = [NSURL URLWithString:getApi];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *task= [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSError *err;
        jsonArray = [NSJSONSerialization JSONObjectWithData:data options:nil error:&err];
//        for(NSDictionary *dictonaryArray in jsonArray)
//        {
//            dictonaryName = dictonaryArray[@"agentfirstname"];
//            NSLog(@"Agent name is %@", dictonaryName);
//        }
        [self.detailTableView reloadData];
    }];
    [task resume];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   return jsonArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    customTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if (cell == nil) {
        cell = [[customTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
    }
    NSDictionary *dict=[jsonArray objectAtIndex:indexPath.row];
    cell.titleDisplay.text = dict[@"agentfirstname"];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    detailViewController *detailScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"detailViewController"];
    [self presentViewController:detailScreen animated:YES completion:nil];
    NSDictionary *dict = [jsonArray objectAtIndex:indexPath.row];
    detailScreen.titleDisplay.text = dict[@"agentfirstname"];
}

@end
