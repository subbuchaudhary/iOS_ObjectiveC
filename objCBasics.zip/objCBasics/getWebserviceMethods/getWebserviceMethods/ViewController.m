//
//  ViewController.m
//  getWebserviceMethods
//
//  Created by Subbu Chaudhary on 2/24/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *stringApi = [NSString stringWithFormat:@"http://data.colorado.gov/resource/4ykn-tg5h.json"];
    
    NSURL *url = [NSURL URLWithString:stringApi];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    NSURLSession *session=[NSURLSession sharedSession];
    
    NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSError *err;
        NSArray *jsonarray=[NSJSONSerialization JSONObjectWithData:data options:nil error:&err];
        NSLog(@"%@",jsonarray);
        
        for ( NSDictionary *dictionary in jsonarray ) {
            
            NSString *agentname=dictionary[@"agentfirstname"];
            NSLog(@"agentname is %@",agentname);
            
        }
        
    }];
    
    
    [task resume];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
