//
//  main.m
//  practice
//
//  Created by Subbu Chaudhary on 1/7/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <Foundation/Foundation.h>

#define PI 3.14 // defining constant values

//method to calculate area of circle
float areaOfCircle (int radius) {
    float Area = PI * radius * radius;
    return Area;
}
/*
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        float a = areaOfCircle(9);
        NSLog(@"The area of circle is %f", a);
    }
    return 0;
}
*/
//if condition
int main (int argc, const char *argv[]){
    @autoreleasepool {
        int r = 9;
        if (r < 0) {
            NSLog(@"invalid radius value");
        }
        else if (r == 0) {
            NSLog(@"The circle is point");
        }
        else {
            //areaOfCircle(r);
            NSLog(@"the area of circle with radius %d is %f", r,areaOfCircle(r));
        }
    }
    return 0;
}
