//
//  ViewController.m
//  tableviewWithNavigation
//
//  Created by Subbu Chaudhary on 2/23/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "customTableViewCell.h"
#import "detailViewController.h"

@interface ViewController ()
{
    NSArray *namesArray;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.navigationController.navigationBar.topItem.title = @"Home";
    namesArray = @[@"Swami Vivekananda", @"APJ AbdulKalam", @"Subhash ChandraBose", @"Gandhi", @"Loyalty", @"Respect", @"Trust", @"Pain", @"Neutral", @"Ethics", @"Learn", @"Morals", @"Principles", @"Rules"];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  namesArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    customTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if(cell == nil)
    {
        cell = [[customTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    cell.labelDisplay.text = [namesArray objectAtIndex:indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    detailViewController *detailsScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"detailViewController"];
   detailsScreen.contentDisplaystring = [namesArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:detailsScreen animated:YES];
    self.navigationController.navigationBar.topItem.title = [namesArray objectAtIndex:indexPath.row];
    
   
}
@end
