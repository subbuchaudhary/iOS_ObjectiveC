//
//  signInViewController.m
//  practDrway
//
//  Created by Subbu Chaudhary on 3/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signInViewController.h"
#import "homeViewController.h"
#import "networkApi.h"

@interface signInViewController ()<UITextFieldDelegate>

@end

@implementation signInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.emailField) {
        [self.passwordField becomeFirstResponder];
    }
    else if(textField == self.passwordField) {
        [self.passwordField resignFirstResponder];
    }    
    
    return true;
}

- (IBAction)forgotPassClkd:(id)sender {
}

- (IBAction)signInClkd:(id)sender {
    if((self.emailField.text.length || self.passwordField.text.length) !=0){
        NSDictionary *dict = @{@"email": self.emailField.text, @"password": self.passwordField.text};
        
        NSString *stringApi = [NSString stringWithFormat:@"http://indglobaldemo.com/doctorway_api/index.php/User/user_signin"];
        [NetworkApi starxecuteApi:dict andUrl:stringApi withCompletionBlock:^(NSError *error, id response) {
            NSLog(@"response is %@", response);
            
            if ([response[@"status"] isEqualToString:@"error"]) {
                
                NSString *errormessage=response[@"data"][@"message"][@"email"];
              
                dispatch_async(dispatch_get_main_queue(), ^{
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Warning!" message:errormessage preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }];
                    [alert addAction:defaultAction];
                    [self presentViewController:alert animated:YES completion:nil];
                });
           
                
            }
            else if([response[@"status"] isEqualToString:@"success"])
            {
                dispatch_async(dispatch_get_main_queue(), ^{

            homeViewController *homeScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"homeViewController"];
            [self presentViewController:homeScreen animated:YES completion:nil];
                    
                   });
            }
        }];
   
    }
    else{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Warning!" message:@"Please enter all required Fields" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:defaultAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}
@end
