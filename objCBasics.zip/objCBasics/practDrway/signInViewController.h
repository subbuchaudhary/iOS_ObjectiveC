//
//  signInViewController.h
//  practDrway
//
//  Created by Subbu Chaudhary on 3/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface signInViewController : ViewController
@property (weak, nonatomic) IBOutlet UITextField *emailField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *forgotPassBtn;
@property (weak, nonatomic) IBOutlet UIButton *signInBtn;
- (IBAction)forgotPassClkd:(id)sender;
- (IBAction)signInClkd:(id)sender;

@end
