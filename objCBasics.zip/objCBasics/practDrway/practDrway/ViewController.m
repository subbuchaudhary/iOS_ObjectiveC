//
//  ViewController.m
//  practDrway
//
//  Created by Subbu Chaudhary on 3/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "signInViewController.h"
#import "signUpViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self.signUpBtn setImage:[UIImage imageNamed:@"grey_circle.png"] forState:UIControlStateNormal];
//    [self.signInBtn setImage:[UIImage imageNamed:@"placed"] forState:UIControlStateNormal];
//    signInViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signInViewController"];
//    [self addChildViewController:firstChildVC];
//    [firstChildVC didMoveToParentViewController:self];
//    firstChildVC.view.frame = CGRectMake(0, 130, self.view.frame.size.width, self.view.frame.size.height-130);
//    [self.view addSubview:firstChildVC.view];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)signInClkd:(id)sender {
    [self.signUpBtn setImage:[UIImage imageNamed:@"grey_circle.png"] forState:UIControlStateNormal];
    [self.signInBtn setImage:[UIImage imageNamed:@"placed"] forState:UIControlStateNormal];
    signInViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signInViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 130, self.view.frame.size.width, self.view.frame.size.height-130);
    [self.view addSubview:firstChildVC.view];
}
- (IBAction)signUpClkd:(id)sender {
    [self.signUpBtn setImage:[UIImage imageNamed:@"placed.png"] forState:UIControlStateNormal];
    [self.signInBtn setImage:[UIImage imageNamed:@"grey_circle.png"] forState:UIControlStateNormal];
    signUpViewController *secondChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signUpViewController"];
    [self addChildViewController:secondChildVC];
    [secondChildVC didMoveToParentViewController:self];
    secondChildVC.view.frame = CGRectMake(0, 130, self.view.frame.size.width, self.view.frame.size.height-130);
    [self.view addSubview:secondChildVC.view];
}
@end
