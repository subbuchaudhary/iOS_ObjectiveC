//
//  signUpViewController.h
//  practDrway
//
//  Created by Subbu Chaudhary on 3/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"

@interface signUpViewController : ViewController
@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *emailField;
@property (weak, nonatomic) IBOutlet UITextField *mobileNumField;
@property (weak, nonatomic) IBOutlet UITextField *passField;
@property (weak, nonatomic) IBOutlet UITextField *reEnterPassField;
@property (weak, nonatomic) IBOutlet UIButton *signupBtn;
- (IBAction)signUpClkd:(id)sender;

@end
