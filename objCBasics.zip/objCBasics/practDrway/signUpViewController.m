//
//  signUpViewController.m
//  practDrway
//
//  Created by Subbu Chaudhary on 3/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signUpViewController.h"
#import "networkApi.h"
#import "homeViewController.h"

@interface signUpViewController ()<UITextFieldDelegate>

@end

@implementation signUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.usernameField) {
         [self.emailField becomeFirstResponder];
    }
    else if(textField == self.emailField) {
        [self.mobileNumField becomeFirstResponder];
    }
    else if (textField == self.mobileNumField) {
        [self.passField becomeFirstResponder];
    }
    else if(textField == self.passField) {
        [self.reEnterPassField becomeFirstResponder];
    }
    else if (textField == self.reEnterPassField) {
        [self.reEnterPassField resignFirstResponder];
    }
   
    
    return true;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)signUpClkd:(id)sender {
    if((self.usernameField.text.length || self.emailField.text.length || self.mobileNumField.text.length || self.passField.text.length || self.reEnterPassField.text.length) != 0)

    {
        if ([self.passField.text isEqualToString:self.reEnterPassField.text]) {
            
            NSDictionary *dict =@{@"email":self.emailField.text,@"mobile": self.mobileNumField.text, @"password": self.passField.text, @"c_pass": self.reEnterPassField.text, @"username": self.usernameField.text };
            NSString *stringApi = [NSString stringWithFormat:@"http://indglobaldemo.com/doctorway_api/index.php/User/user_signup"];
            [NetworkApi starxecuteApi:dict andUrl:stringApi withCompletionBlock:^(NSError *error, id response) {
                NSLog(@"response %@",response);
                if([response[@"status"] isEqualToString:@"error"]){
                    NSString *errormessage=response[@"data"][@"message"][@"email"];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Warning!" message:errormessage preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                            [self dismissViewControllerAnimated:YES completion:nil];
                        }];
                        [alert addAction:defaultAction];
                        [self presentViewController:alert animated:YES completion:nil];
                    });
                    
                }
                else if([response[@"status"] isEqualToString:@"success"]) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                homeViewController *homeScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"homeViewController"];
                [self presentViewController:homeScreen animated:YES completion:nil];
                    });
                }
                else {
                    NSString *errormessage=response[@"data"][@"message"][@"email"];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Warning!" message:errormessage preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                            [self dismissViewControllerAnimated:YES completion:nil];
                        }];
                        [alert addAction:defaultAction];
                        [self presentViewController:alert animated:YES completion:nil];
                    });
                }
                
            }];
            
        }
        else {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Warning!" message:@"Please enter same values in both fields" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                [self dismissViewControllerAnimated:YES completion:nil];
            }];
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
            
        }
    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Warning!" message:@"Please Fill all required fields" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:defaultAction];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
}
@end
