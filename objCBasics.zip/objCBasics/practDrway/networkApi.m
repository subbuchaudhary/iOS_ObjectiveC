//
//  NetworkApi.m
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/26/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "NetworkApi.h"

@implementation NetworkApi
+(void)starxecuteApi:(NSDictionary *)dict andUrl:(NSString *)string withCompletionBlock:(ApiResponse)block

{
    
    //to pass unique boundary
    NSString *boundary = [self generateBoundaryString];
    NSURL *url = [NSURL URLWithString:string];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    //to convert into nsdata format
    //NSData *postdata=[NSJSONSerialization dataWithJSONObject:dict options:nil error:nil];
    
    [request setHTTPMethod:@"POST"];
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    
    
    NSMutableData *body = [NSMutableData data];
    
    [dict enumerateKeysAndObjectsUsingBlock:^(NSString *parameterKey, NSString *parameterValue, BOOL *stop) {
        
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", parameterKey] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", parameterValue] dataUsingEncoding:NSUTF8StringEncoding]];
        
    }];
    
    
    // [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setHTTPBody:body];
    
    NSURLSession *session=[NSURLSession sharedSession];
    
    NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSError *err;
        
        if(error == nil)
        {
        id responseData=[NSJSONSerialization JSONObjectWithData:data options:nil error:&err];
         // id responseData =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
        block(error,responseData);
        }else{
            
        }
        
        
    }];
    
    [task resume];
}

+(NSString *)generateBoundaryString
{
    return [NSString stringWithFormat:@"Boundary-%@", [[NSUUID UUID] UUIDString]];
}
@end
