//
//  detailTableViewController.h
//  loginStoryboardPract
//
//  Created by Subbu Chaudhary on 2/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailTableViewController : UITableViewController<UITableViewDelegate,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *detailView;

@end
