//
//  signupViewController.m
//  loginStoryboardPract
//
//  Created by Subbu Chaudhary on 1/23/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "signupViewController.h"

@interface signupViewController ()
@property (weak, nonatomic) IBOutlet UIButton *btnSlctd;
@property (weak, nonatomic) IBOutlet UIButton *optnSlctd;

@end

@implementation signupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)cancelClkd:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)radioBtnClkd:(id)sender {
    [_btnSlctd setImage:@"placed.png" forState:UIControlStateNormal];
    [_optnSlctd setImage:@"placed.png" forState:UIControlStateNormal];
}


@end
