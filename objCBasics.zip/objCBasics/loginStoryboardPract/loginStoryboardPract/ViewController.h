//
//  ViewController.h
//  loginStoryboardPract
//
//  Created by Subbu Chaudhary on 1/23/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;

- (IBAction)signupBtnClkd:(id)sender;
- (IBAction)frgtPassClkd:(id)sender;
- (IBAction)SigninClicked:(id)sender;

@end

