//
//  ViewController.m
//  loginStoryboardPract
//
//  Created by Subbu Chaudhary on 1/23/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "signupViewController.h"
#import "forgotPasswordViewController.h"
#import "detailTableViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)signupBtnClkd:(id)sender {
    
   
    signupViewController *loginScrn = [self.storyboard instantiateViewControllerWithIdentifier:@"signupScreen"];
    [self.navigationController pushViewController:loginScrn animated:YES];
}

- (IBAction)frgtPassClkd:(id)sender {
    forgotPasswordViewController *loginScrnNxt = [self.storyboard instantiateViewControllerWithIdentifier:@"forgotScreen"];
    [self.navigationController pushViewController:loginScrnNxt animated:YES];
}

- (IBAction)SigninClicked:(id)sender {
    
    if (self.usernameField.text.length==0 || self.passwordField.text.length==0) {
        
        
        self.usernameField.backgroundColor=[UIColor redColor];
        UIAlertController *alertview =[UIAlertController alertControllerWithTitle:@"Error while submitting" message:@"Required fields must be filled before submitting" preferredStyle:UITableViewCellStyleDefault];
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {}];
        
        [alertview addAction:defaultAction];
        [self presentViewController:alertview animated:YES completion:nil];
        
    }else
    {
        detailTableViewController *signInAction = [self.storyboard instantiateViewControllerWithIdentifier:@"detailTableViewController"];
        [self presentViewController:signInAction animated:YES completion:nil];
    }
}
@end
