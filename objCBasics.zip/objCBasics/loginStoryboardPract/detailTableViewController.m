//
//  detailTableViewController.m
//  loginStoryboardPract
//
//  Created by Subbu Chaudhary on 2/1/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "detailTableViewController.h"

@interface detailTableViewController ()
{
    NSArray *array;
    NSArray *imagearray;
}

@end

@implementation detailTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    array = @[@"BMW", @"Benz", @"Audi", @"Porch"];
    
    imagearray = @[@"password.png", @"password.png", @"password.png", @"password.png"];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return array.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellId"];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
    }
    cell.textLabel.text = [array objectAtIndex:indexPath.row];
    cell.imageView.image = [UIImage imageNamed:[imagearray objectAtIndex:indexPath.row]];
    return cell;
}
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 900;
//}

@end
