//
//  FirstViewController.m
//  tabview
//
//  Created by Subbu Chaudhary on 3/6/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.profileImage setImage:[[UIImage imageNamed:@"Profile"]
                                 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
