//
//  main.m
//  loops
//
//  Created by Subbu Chaudhary on 1/7/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.

//program to print even numbwers from 1 to 100
/*
#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        int n = 100;
        
        for(int i = 1; i <=n; i++)
        {
            if(i%2 ==0){
            NSLog(@"the even numbers from 1 to 100 is %d", i);
        }
        }
    }
    return 0;
}
*/
#import <Foundation/Foundation.h>

int main(int argc, const char *argv[]){
    @autoreleasepool {
        const float PI = 3.14;
        int radius;
        
        int i = 0;
        while(i <3){
        NSLog(@"Enter radius of the circle: ");
        scanf("%d", &radius);
       float Area = PI * radius * radius;
        radius >=0 ? NSLog(@"Area of circle is %f", Area) : NSLog(@"circle radius is invalid");
            i++;
        }
    }
    return 0;
}
