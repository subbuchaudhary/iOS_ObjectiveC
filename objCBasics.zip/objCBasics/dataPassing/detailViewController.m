//
//  detailViewController.m
//  dataPassing
//
//  Created by Subbu Chaudhary on 1/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "detailViewController.h"

@interface detailViewController ()

@end

@implementation detailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.labelChngd.text = self.receiveData;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)cancelClkd:(id)sender {
    
    [self.delegate passMyData:self.txtFld.text];
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
