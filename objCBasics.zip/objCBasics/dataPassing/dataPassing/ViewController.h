//
//  ViewController.h
//  dataPassing
//
//  Created by Subbu Chaudhary on 1/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "detailViewController.h"


@interface ViewController : UIViewController<detailViewControllerprotocol>
@property (weak, nonatomic) IBOutlet UITextField *usernameField;

- (IBAction)nxtBtnClkd:(id)sender;

@end

