//
//  ViewController.m
//  dataPassing
//
//  Created by Subbu Chaudhary on 1/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "detailViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)nxtBtnClkd:(id)sender {
   // NSString *data = _usernameField.text;
 // or same as above   NSString *data = self.usernameField.text;
    detailViewController *mainScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"detailViewController"];
    mainScreen.receiveData = _usernameField.text;
    mainScreen.delegate=self;
    [self presentViewController:mainScreen animated:YES completion:nil];
    //mainScreen.labelChngd.text = _usernameField.text;
    
}

-(void) passMyData:(NSString *) myString
{
    _usernameField.text=myString;
    
}
@end
