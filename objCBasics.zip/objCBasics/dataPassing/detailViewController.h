//
//  detailViewController.h
//  dataPassing
//
//  Created by Subbu Chaudhary on 1/25/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol detailViewControllerprotocol <NSObject>

-(void) passMyData:(NSString *) myString;

@end

@interface detailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *labelChngd;
@property (strong, nonatomic) NSString *receiveData;
- (IBAction)cancelClkd:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtFld;
@property(weak,nonatomic)id<detailViewControllerprotocol> delegate;

@end
