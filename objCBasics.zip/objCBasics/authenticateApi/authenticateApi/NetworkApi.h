//
//  NetworkApi.h
//  doctorsWay
//
//  Created by Subbu Chaudhary on 2/26/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <Foundation/Foundation.h>
//create block
typedef void (^ApiResponse) (NSError *,id);
@interface NetworkApi : NSObject

+(void)starxecuteApi:(NSDictionary *)dict andUrl:(NSString *)string withCompletionBlock:(ApiResponse)block;

@end
