//
//  ViewController.m
//  authenticateApi
//
//  Created by Subbu Chaudhary on 2/26/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "NetworkApi.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *stringApi = [NSString stringWithFormat:@"https://cdfconnect-sit.wellsfargo.com:8443/INFO/secure/generic/cma/identity.rst"];
    
   // NSURL *url = [NSURL URLWithString:stringApi];
    
    //NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    NSDictionary *dict =@{@"userId": @"u480157",@"password": @"Abcd@123"};
    
    [NetworkApi starxecuteApi:dict andUrl:stringApi withCompletionBlock:^(NSError *error, id responsejson) {
       
        NSLog(@"%@",responsejson);
    }];
    //to convert into nsdata format
   // NSData *postdata=[NSJSONSerialization dataWithJSONObject:dict options:nil error:nil];
    
   // [request setHTTPMethod:@"POST"];
    
//    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
//    
//    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
//    [request setHTTPBody:postdata];
//    
//    NSURLSession *session=[NSURLSession sharedSession];
//    
//    NSURLSessionDataTask *task=[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//        NSError *err;
//        NSDictionary *jsonarray=[NSJSONSerialization JSONObjectWithData:data options:nil error:&err];
//        NSLog(@"%@",jsonarray);
//        
//        
//    }];
//    
//    [task resume];
    

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
