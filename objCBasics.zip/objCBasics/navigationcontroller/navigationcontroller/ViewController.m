//
//  ViewController.m
//  navigationcontroller
//
//  Created by Subbu Chaudhary on 1/21/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "ViewController.h"
#import "scndViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnClicked:(id)sender {
    
    scndViewController *sViewCntrlr = [self.storyboard instantiateViewControllerWithIdentifier:@"scndScreen"];
    
    [self.navigationController pushViewController:sViewCntrlr animated:YES];
}


@end
