//
//  MISuperCategory.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MISuperCategory.h"
#import "MIConstant.h"
@implementation MISuperCategory
-(NSMutableArray*)getCategoryList
{
    
   [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
   NSString* query = [NSString stringWithFormat:@"select * from %@ where superCatId = %d ",TABLE_CATEGORY,self.superCatId.intValue];
    NSMutableArray *results = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (results.count>0) {
        self.categorylist = [[NSOrderedSet alloc] initWithArray:results];
    }
    return results;
}

-(MISurveyType*)getSurveyType
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:SURVERY_TABLE];
    NSString* query = [NSString stringWithFormat:@"select * from %@ where id = %d ",TABLE_SURVEYTAPE ,self.surveyId.intValue];
    NSMutableArray *results = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    return (results.count>0)?results[0]:[MISurvey new];
}

#pragma mark - New Method implementation
-(void)fetchCategoryStructure
{
    self.parentSurveyType = [self getSurveyType];
    //First fetch category listing for selcted super category
    [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
    NSString* query = [NSString stringWithFormat:@"select * from %@ where superCatId = %d ORDER BY id ASC",TABLE_CATEGORY,self.superCatId.intValue];
    NSMutableArray *results = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (results.count==0) return;
    
    self.categorylist = [[NSOrderedSet alloc] initWithArray:results];
    //Second get Subcategory listing for all fetched categry
    for (MICategory *objCategory in self.categorylist.array) {
        [objCategory getCategoryListObjects];
        objCategory.parentSuperCategory = self;
    }
    
    
}

//---------



@end
