//
//  BaseCategory+BaseCategoryCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/12/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MIBaseCategory.h"

@interface MIBaseCategory (MIBaseCategoryCustom)

- (BOOL) isSameAs:(id)object;
@end
