//
//  SelectOpportunityView.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 12/9/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OpportunitySelectionRowView.h"

@interface SelectOpportunityView : UIView

@property (strong, nonatomic) IBOutlet UIView *container;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *retentionView;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *flooringView;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *creditView;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *experienceView;
@property NSUInteger selectedOpportunityType;

@property (weak, nonatomic) UIViewController *delegate;

- (IBAction)opportunityRowSelected:(UITapGestureRecognizer *)sender;



@end
