//
//  MIDBManager.h
//  SqlLiteDemo
//
//  Created by devness on 17/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "MIConstant.h"
typedef enum playerStateTypes
{
    SURVERY_TABLE,
    SUPERCATEGORY_TABLE,
    CATEGORY_TABLE,
    SUBCATEGORY_TABLE,
    TOPIC_TABLE,
    DEALER_TABLE,
    DEALER_SUMMERY_TABLE,
    FSR_TABLE,
    COMMENTS_TABLE,
    CURRENT_SURVEY_TABLE
} tableState;
@interface MIDBManager : NSObject
{
    sqlite3* database;
}
@property(nonatomic,assign)tableState stateSelectedTable;
@property (readwrite) sqlite3* database;
@property (strong, nonatomic) NSString *databasePath;
+(MIDBManager*)getSharedInstance;
-(void)createDatabase;


//INSERT RECORDS QUERY FOR DIFFERENT TABLE
-(void)insertSurveyType:(NSNumber*)surveyId AndName:(NSString*)surveyName;
-(void)insertRecrodsInSuperCategory:(NSArray*)supercategory;
-(void)insertRecrodsInCategory:(NSArray*)supercategory;
-(void)insertRecrodsInSubCategory:(NSArray*)supercategory;

//FETCH RECORDS QUERY
-(NSMutableArray*)fetchAllRecordsFromTable:(NSString*)query;

-(void)createCategoryStructureInDatabase;
@property(nonatomic,strong)MISurveyType *surveyType;



//New
-(MISurveyType*)getSurveyRecordsFromSurveyId:(int)surveyId;
//Dealer table
-(void)createDealerTable;
-(void)insertDealerRecords:(NSArray*)dealerlist;
-(void)deleteDealerlist;
-(NSMutableArray*)fetchDealerList;
//Dealer Summery
-(void)deleteDealerSummerylist;
-(void)createDealSummeryTable;
-(void)insertDealerSummeryRecords:(NSArray*)dealerlist;
-(NSMutableArray*)fetchDealerSummery;
//FSR
-(NSMutableArray*)fetchFSRDetail;
-(void)deleteFSRDetail;
- (void)insertFSRData:(NSString *)firstName lastNname:(NSString *)lastName managerSSO:(NSString *)managerSSO sso:(NSString *)sso;
-(MIFSR*)handleFSRList:(int)records forStatemet:(sqlite3_stmt*)statement;


//Comments
-(void)insertRecrodsInComments:(NSArray*)supercategory;
-(NSMutableArray*)fetchCommentlist:(NSString*)query;
-(void)deleteComments:(NSArray*)commentlist; //MiComments object will be in array


//Fetch Single records
-(NSMutableArray*)fetchsingleRecords:(NSString*)recordId;
-(void)deleteSingleRecords:(NSString*)recordId;

//Common query
-(void)updateRecrodsQuery:(NSString*)updateSql;
-(void)deleteRecrodsQuery:(NSString*)deleteSql;

//Current Survey MISurvey
-(void)insertCurrentSurveyRecords:(NSArray*)dealerlist;
@end
