
//
//  ViewController.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "ViewController.h"
#import "CommentInputViewController.h"
#import "SelectOpportunityView.h"


#import "CategoryViewController.h"
#import "DealerListViewController.h"
#import "SubmitSurveyViewController.h"


#import "UIView+FSGViewSetFont.h"
#import "OpportunityTypeSelectionViewController.h"

#import "MIConstant.h"
#define SELECTED_OPTIONS_LIST_ROW_SIZE 20 // Added by Easwar


@interface ViewController ()

@end

@implementation ViewController
@synthesize appDelegate;

- (void)viewDidLoad
{
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.comment.delegate = self;
    sendingSurvey = NO;
    
    _commentTable.delegate = self;
    [self.commentTable registerNib:[UINib nibWithNibName:@"CommentBreak" bundle:nil] forCellReuseIdentifier:@"CommentBreak"];
    
    
    self.appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    
    _current = 0;
    _commentArray = [[NSMutableArray alloc] init];
    [self initComments];

    UIEdgeInsets inset = UIEdgeInsetsMake(25, 0, 0, 0);
    self.commentTable.contentInset = inset;
    
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"GEInspira-Bold" size:15.0], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [_sendButton setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [_deleteButton setTitleTextAttributes:attributes forState:UIControlStateNormal];

}

- (void) initComments
{
    [_commentArray removeAllObjects];
    _current = 0;
    
    if ([self.appDelegate.currentSurvey.commentList.allObjects count] == 0)
    {
        _commentCount = 1;
        CommentView *initialCell = [self createCommentCellWithID:0 comment:nil];
        [_commentArray addObject:initialCell];
        
    }
    else
    {
        _commentCount = (int)[self.appDelegate.currentSurvey.commentList.allObjects count];
        for (int i=0; i < _commentCount; i++)
        {
            CommentView *initialCell = [self createCommentCellWithID:i comment:appDelegate.currentSurvey.commentList.allObjects[i]];
            [_commentArray addObject:initialCell];
        }

    }
    if (_commentCount == 1)
    {
        ((CommentView*)[_commentArray objectAtIndex:0]).deleteComment.hidden = YES;
    }
    [self.commentTable reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self hideSelectOpportunityWindowWithDuration:0.0];

}

-(void) willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    CGSize size = [[UIScreen mainScreen] bounds].size;
    
    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {
        self.selectOpportunityViewWidth.constant = size.width-40;
    } else {
        self.selectOpportunityViewWidth.constant = size.height-40;
    }
    
    if (self.selectOpportunityShowing) {
        [self showSelectOpportunityWindowWithDuration:0.0];
    }
    
}

// Modified by Easwar
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"ToCommentInput"]) {
        CommentInputViewController *commentInputVC = segue.destinationViewController;
        CommentView *currentCell = [_commentArray objectAtIndex:_current];
        commentInputVC.commentText = currentCell.commentArea.text;
        commentInputVC.delegate = self;
        self.textFromCommentInput = @"";
    } else if ([segue.identifier isEqualToString:@"OpportunitySelect"]) {
        OpportunityTypeSelectionViewController *opportunitySelectionViewController = segue.destinationViewController;
        CommentView* currentCommentView = [_commentArray objectAtIndex:_current];
        opportunitySelectionViewController.delegate = self;
        opportunitySelectionViewController.comment = currentCommentView.comment;
    }
    else if ([segue.identifier isEqualToString:@"ToDealerList"]) {
        
        DealerListViewController *dealerListVC = segue.destinationViewController;
        dealerListVC.delegate = self;
        dealerListVC.dealerDataList = appDelegate.miSurveyUtil.dealerList;
        CommentView* currentComment = [_commentArray objectAtIndex:_current];
        dealerListVC.comment = currentComment.comment;
    }
    else if ([segue.identifier isEqualToString:@"submitSurvey"]) {
        
        SubmitSurveyViewController *submitSurvey = segue.destinationViewController;
        submitSurvey.commentViewController = self;
        
    }
    
}

/*CommentInputViewControllerDelegate methods*/
-(void) setTextValueFromInput:(NSString *)text {
    text = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    self.textFromCommentInput = text;

    if(_current < [_commentArray count])
    {
        CommentView *currentCell = [_commentArray objectAtIndex:_current];
        currentCell.comment.text = self.textFromCommentInput;
        
        currentCell.commentArea.text = self.textFromCommentInput;
        currentCell.commentArea.font = [UIFont fontWithName:@"GEInspira-Bold" size:14]; // Added by Easwar

        if (![text isEqualToString:@""])
        {
            currentCell.commentArea.textColor = [UIColor blackColor];
            [currentCell displayValidationError:NO forView:currentCell.commentArea];
        }
        else
        {
            currentCell.commentArea.textColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
            currentCell.commentArea.text = @"Enter Comment";
        }
        [currentCell.comment updateCommentText:self.textFromCommentInput];
    }
    [appDelegate.miSurveyUtil saveCurrentSurvey];
}

/*CommentViewRowSelectionDelegate methods*/
-(void) rowSelectedWithTag:(NSInteger)tag forCommentID:(NSNumber *)commentID
{
    _current = [commentID intValue];

    switch (tag) {
        case 10: {

//            [self showSelectOpportunityWindowWithDuration:0.5];
            [self performSegueWithIdentifier:@"OpportunitySelect" sender:self.view];

            break;
        }
        case 20: {
            
            [self performSegueWithIdentifier:@"ToDealerList" sender:self.view];
            break;
        }
    }
}

- (IBAction)closeSelectOpportunityWindow:(UISwipeGestureRecognizer *)sender {
    [self hideSelectOpportunityWindowWithDuration:0.5];
}


-(void) hideSelectOpportunityWindowWithDuration:(CGFloat) duration {
    [UIView animateWithDuration:duration animations:^{
        self.mainViewLeftEdgeAlignment.constant = 0;
        self.mainViewRightEdgeAlignment.constant = 0;
        [self.view layoutIfNeeded];
    }];
    [self.navigationItem setRightBarButtonItem:self.sendButton animated:NO];
    [self.navigationItem setLeftBarButtonItem:self.deleteButton animated:NO];
    self.selectOpportunityShowing = NO;
}

- (IBAction)deleteSurvey:(UIBarButtonItem *)sender {
    
    
    if (allCommentDelete == nil)
    {
        allCommentDelete = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"You are about to delete all comments. Are you sure?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Continue", nil];
    }
    [allCommentDelete show];
    
  
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView == allCommentDelete)
    {
        if (buttonIndex == 1)
        {
            // Clear all survey comments
            
            [appDelegate.currentSurvey clearSurveyTable];
           
            
            for (int i=0; i< _commentArray.count;i++)
            {
                MIComments* comment = ((CommentView*)[_commentArray objectAtIndex:i]).comment;
                [comment deleteComment:comment];
            }
             [_commentArray removeAllObjects];
            // Now initialize with one cell
            _commentCount = 1;
            CommentView *initialCell = [self createCommentCellWithID:0 comment:nil];
            initialCell.deleteComment.hidden = YES;
            [_commentArray addObject:initialCell];
            [self.commentTable reloadData];
            
        }
    }
    else
    {
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _commentCount*2+1;    //count number of row from counting array hear cataGorry is An Array
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row %2 == 0 && indexPath.row != _commentCount*2)
    {
        
        
        CommentView *cell =  [tableView dequeueReusableCellWithIdentifier:@"CommentView"];
        if (cell == nil) {
            if([_commentArray count] >= indexPath.row/2)
            {
                cell = [_commentArray objectAtIndex:indexPath.row/2];
            }
            else
            {
                cell = [[CommentView alloc] init];
                cell.comment = [[MIComments alloc] init];
                cell.delegate = self;
                cell.updateCurrentComment = @selector(setCurrentComment:);
                [_commentArray addObject:cell];
            }
            
        }
        cell.clipsToBounds = YES; 
        return cell;
    }
    else if( indexPath.row == _commentCount*2)
    {
        AddCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AddCommentCell"];
        if (cell == nil) {
            cell = [[AddCommentCell alloc] init];
            cell.delegate = self;
            cell.backgroundColor = [UIColor clearColor];
            cell.addComment = @selector(addCommentToTable);
            
        }
        return cell;
    }
    else
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommentBreak"];
        return cell;
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(indexPath.row == _commentCount*2)
    {
        return 55;
    }
    else if(indexPath.row %2 == 1)
    {
        return 20;
    }
    else
    {
        CommentView *currentCommentView = [_commentArray objectAtIndex:indexPath.row/2];
        return [currentCommentView height];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _current = indexPath.row;
}

-(void)addCommentToTable
{
    CommentView *newCell = [[CommentView alloc] init];
    newCell.comment = [[MIComments alloc] init];
    if (newCell.comment.keyId.length==0) {
        newCell.comment.keyId = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000];
    }
    //newCell.comment = (m*)[appDelegate.surveyUtil newEntityForName:@"Comment"];
    [appDelegate.currentSurvey addCommentListObject:newCell.comment];
    [appDelegate.currentSurvey updateCommentsListObj:newCell.comment];
    newCell.delegate = self;
    
    _commentCount += 1;
    newCell.objectID = [[NSNumber alloc] initWithInt:_commentCount-1];
    newCell.updateCurrentComment = @selector(setCurrentComment:);
    [_commentArray addObject:newCell];
    [_commentTable reloadData];
    int lastComment = _commentCount *2 -1;
    NSIndexPath *ipath = [NSIndexPath indexPathForRow:lastComment inSection:0];
    [_commentTable scrollToRowAtIndexPath:ipath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    
    // Added by Easwar
    CommentView *firstComment = [_commentArray objectAtIndex:0];
    if (firstComment.deleteComment.hidden) {
        firstComment.deleteComment.hidden = NO;
    }
//    CGRect frame = self.commentTable.frame;
//
//    NSLog(@"PHeight %f - CHeight %f", frame.size.height, self.commentTable.contentSize.height);
//    frame.size.height = self.commentTable.contentSize.height;
//    self.commentTable.frame = frame;
}

-(void)setCurrentComment:(NSNumber*)commentNo
{
    _current = [commentNo intValue];

}



- (IBAction)sendSurvey:(UIBarButtonItem *)sender {
    
    BOOL validComments = YES;
    
    for (int i=0; i< _commentArray.count;i++)
    {
        CommentView* commentView = [_commentArray objectAtIndex:i];
        if (![commentView isValid])
        {
            validComments = NO;
        }
    }
    [_commentTable reloadData];
    
    if (!validComments)
    {
        // To Play the sound for validation errors.
        NSError *error;
        NSString *saveNotSendSoundPath = [[NSBundle mainBundle] pathForResource:@"check" ofType:@"aiff"];
        NSURL *saveNotSendSoundURL = [NSURL fileURLWithPath:saveNotSendSoundPath];
        _validationAlertSound = [[AVAudioPlayer alloc] initWithContentsOfURL:saveNotSendSoundURL error:&error];
        [_validationAlertSound play];
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Validation Error" message:@"One or more comments are not complete. These comments need to be completed before they can be submitted." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    // Check if any of the comments have Dealer#s that are not validated
    BOOL commentsRequireDealerValidation = NO;
    for (int i=0; i< _commentArray.count;i++)
    {
        CommentView* commentView = [_commentArray objectAtIndex:i];
        if (![commentView.dealerInfo.dealerText.text isEqualToString:@""] )
        {
            commentsRequireDealerValidation = YES;
            [commentView validateDealerNumber];

        }
        else
            commentView.dealerNumberValidated = YES;
    }
    if (!commentsRequireDealerValidation)
    {
        [self validationComplete:YES];
    }
}

- (void) categoryDataSelected:(MICategory *)category subCategoryList:(NSMutableArray *)subCategoryList topicList:(NSMutableArray *)topicList
{
    CommentView* commentView = [_commentArray objectAtIndex:_current];
    
    [commentView.comment clearSubCategoryList];
    [commentView.comment clearTopicList];
    if (category != nil)
    {
        commentView.comment.superCategory = [category getSuperCategory];
        commentView.comment.category = category;
        commentView.comment.surveyType = [[category getSuperCategory] getSurveyType].surveyName;
    }
    else
    {
        commentView.comment.category = nil;
    }
    if (subCategoryList.count != 0)
    {
        NSString *subCategoryIdsList;
        for (MISubCategory *subCategory in subCategoryList) {
            if (subCategoryIdsList.length==0)
                [subCategoryIdsList stringByAppendingString:[NSString stringWithFormat:@"%@",[subCategory.subCatId stringValue]]];
            else
                [subCategoryIdsList stringByAppendingString:[NSString stringWithFormat:@",%@",[subCategory.subCatId stringValue]]];
        }
        MISubCategory* subCategory = [subCategoryList objectAtIndex:0];
        commentView.comment.superCategory = subCategory.getParentCategory.getSuperCategory;
        commentView.comment.surveyType = subCategory.getParentCategory.getSuperCategory.getSurveyType.surveyName;
    }
    if (topicList.count != 0)
    {
        NSString *subTopicIdsList;
        for (MITopic *subCategory in topicList) {
            if (subTopicIdsList.length==0)
                [subTopicIdsList stringByAppendingString:[NSString stringWithFormat:@"%@",subCategory.topicid]];
            else
                [subTopicIdsList stringByAppendingString:[NSString stringWithFormat:@",%@",subCategory.topicid]];
        }
        MITopic* topic = [topicList objectAtIndex:0];
        commentView.comment.superCategory = topic.getTopicParentCategory.getParentCategory.getSuperCategory;
        commentView.comment.surveyType = topic.getTopicParentCategory.getParentCategory.getSuperCategory.getSurveyType.surveyName;
    }
    if (commentView.comment.surveyType == Nil)
        commentView.comment.surveyType = @"Sales Opportunity";
    
   
    if (commentView.comment.keyId.length==0) {
        commentView.comment.keyId = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000];
    }
    [commentView validateOptionSelections];
    [commentView displayDealersAndOptionsIfPresent];
    [_commentTable reloadData];
    [commentView.comment insertCommentInDatabase:@[commentView.comment]];
    //[appDelegate.miSurveyUtil saveCurrentSurvey];
}

- (void) dealerDataSelected
{
    CommentView* commentView = [_commentArray objectAtIndex:_current];
    
    if ([commentView.comment isDealerSelected])
    {
        commentView.dealerInfo.checkbox.hidden = NO;
        [commentView.dealerInfo displayValidationError:NO];
    }
    if (commentView.comment.keyId.length==0) {
        commentView.comment.keyId = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000];
    }
    [commentView displayDealersAndOptionsIfPresent];
    [_commentTable reloadData];
    //[appDelegate.miSurveyUtil saveCurrentSurvey];
}

- (void) deleteComment:(NSNumber *)objectID
{
    CommentView* commentView = [_commentArray objectAtIndex:[objectID intValue]];
    
    [appDelegate.currentSurvey removeCommentListObject:commentView.comment];
    //[appDelegate.currentSurvey removeCommentListObject:commentView.comment];
    [commentView.comment deleteComment:commentView.comment];
    [_commentArray removeObjectAtIndex:[objectID intValue]];
    _commentCount -= 1;
    
    if (_commentCount == 0)
    {
        _commentCount = 1;
        CommentView *initialCell = [self createCommentCellWithID:0 comment:nil];
        initialCell.deleteComment.hidden = YES;
        [_commentArray addObject:initialCell];
    }
    for (int index=0; index < _commentArray.count;index++)
    {
        CommentView* commentView = [_commentArray objectAtIndex:index];
        commentView.objectID = [[NSNumber alloc] initWithInt:index];
    }
    
    if (_commentCount == 1)
    {
        ((CommentView*)[_commentArray objectAtIndex:0]).deleteComment.hidden = YES;
    }
    
    [appDelegate.miSurveyUtil saveCurrentSurvey];
    [_commentTable reloadData];
}

- (CGPoint) positionOfTextField:(UITextField*) textField
{
    CGPoint textFieldCenter = textField.center;
    CGPoint pointInTableView = [_commentTable convertPoint:textFieldCenter fromView:textField.superview];
    
    return pointInTableView;
}

-(void) enteredContactName:(NSString *)contactName
{
    //[appDelegate.surveyUtil saveCurrentSurvey];
    CommentView* commentView = [_commentArray objectAtIndex:_current];
    if (commentView.comment.keyId.length==0) {
        commentView.comment.keyId = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000];
    }
    commentView.comment.contactName = contactName;
    NSString *updateSQL = [NSString stringWithFormat:@"update %@ SET contactId = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS,contactName,commentView.comment.keyId];
    
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];

    if (![contactName isEqualToString:@""])
        [commentView displayValidationError:NO forView:commentView.contactName];
    [commentView validateContactName];
}


/*
 ** Create a new Comment Cell
 */
-(CommentView*) createCommentCellWithID:(int) index comment:(MIComments*) comment
{
    
    CommentView *initialCell = [[CommentView alloc] init];
    if (comment == Nil)
    {
        initialCell.comment = [[MIComments alloc] init];
        if (initialCell.comment.keyId.length==0) {
            initialCell.comment.keyId = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000];
        }
        [appDelegate.currentSurvey addCommentListObject:initialCell.comment];
        [appDelegate.currentSurvey updateCommentsListObj:initialCell.comment];
        initialCell.commentArea.text = @"Enter Comment";
        initialCell.commentArea.textColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
    }
    else
    {
        initialCell.comment = comment;
        initialCell.commentArea.text = comment.text;
        initialCell.contactName.text = comment.contactName;

        if ((comment.dealerNumber != nil) && (![comment.dealerNumber isEqualToString:@""]) && comment.dealerNumber == (id)[NSNull null] && comment.dealerNumber.length > 0 )
            initialCell.dealerInfo.dealerText.text = comment.dealerNumber;
        
        if ((comment.text == nil) || ([comment.text isEqualToString:@""]))
        {
            initialCell.commentArea.text = @"Enter Comment";
            initialCell.commentArea.textColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
        }
        else
        {
            initialCell.commentArea.textColor = [UIColor blackColor];
        }
        
        if ([comment isOpportunityTypeSelected])
            initialCell.opportunityType.checkbox.hidden = NO;
        if ([comment isDealerSelected])
            initialCell.dealerInfo.checkbox.hidden = NO;
        if ([comment isContactNameSelected])
            initialCell.contactCheckBox.hidden = NO;
            
    }
    initialCell.delegate = self;
    initialCell.objectID = [[NSNumber alloc] initWithInt:index];
    
    initialCell.updateCurrentComment = @selector(setCurrentComment:);
    
    [initialCell displayDealersAndOptionsIfPresent];
    return initialCell;
}

- (void) validationComplete:(BOOL)validationStatus
{
    // Check if all comment views with manually entered Dealer Numbers have completed validating
    @synchronized(self)
    {
        BOOL allCommentsValidated = YES;
        BOOL validationErrors = NO;
        for (int i=0; i<_commentArray.count;i++)
        {
            CommentView* commentView = [_commentArray objectAtIndex:i];
            if (!commentView.dealerNumberValidated)
                allCommentsValidated = NO;
            else
            {
                if (![commentView.dealerInfo.dealerText.text isEqualToString:@""])
                {
                    validationErrors = YES;
                }
            }
        
        }
    
        if (allCommentsValidated)
        {
            // Check if there are any Validation errors
            if (validationErrors)
            {
                // To Play the sound for validation errors.
                NSError *error;
                NSString *saveNotSendSoundPath = [[NSBundle mainBundle] pathForResource:@"check" ofType:@"aiff"];
                NSURL *saveNotSendSoundURL = [NSURL fileURLWithPath:saveNotSendSoundPath];
                _validationAlertSound = [[AVAudioPlayer alloc] initWithContentsOfURL:saveNotSendSoundURL error:&error];
                [_validationAlertSound play];
                UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Validation Error" message:@"One or more comments are not complete. These comments need to be completed before they can be submitted." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                [alert show];
                return;
            }
            else
            {
                [self performSegueWithIdentifier:@"submitSurvey" sender:self.view];
         
            }
        }
    }
}

- (void) refreshView
{
    [self.appDelegate.miSurveyUtil saveCurrentSurvey];
    [self.commentTable reloadData];
}

@end
