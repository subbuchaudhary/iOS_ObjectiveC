//
//  GEDenseRow.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
///

#import <Foundation/Foundation.h>
#import "GEDenseCell.h"

/*
 * GEDenseRow represents an entire Row of Dense
 * Tabular data
 */
@interface GEDenseRow : NSObject

@property (nonatomic, strong) GEDenseCell *header;
@property (nonatomic, strong) NSArray *cellArray;

- (id)initWithTitle:(NSString *)title Cells:(NSArray *)cellArray;

@end
