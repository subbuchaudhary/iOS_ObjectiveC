//
//  GEDenseTabularDataLayout.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseTabularDataLayout.h"


#define ITEM_WIDTH 100
#define ITEM_HEIGHT 50
#define CONTENT_AREA_PADDING 20
#define CONTENT_SCROLLVIEW_PADDING 10

@interface GEDenseTabularDataLayout()

@property (nonatomic, assign) CGSize contentSize;
@property (nonatomic, strong) NSArray *cellCounts;
@property (nonatomic, strong) NSArray *sectionRects;
@property (nonatomic, assign) NSInteger rowCount;
@property (nonatomic, assign) NSInteger numColumns;
@property (nonatomic, strong) NSMutableDictionary *cellLayoutInfo;
@end

@implementation GEDenseTabularDataLayout

-(id)initWithWidthArray:(NSArray*)widths andHeight:(float)height {
    self = [super init];
    if(self){
        self.widthArray = widths;
        self.numColumns = widths.count;
        float x = 0;
        self.xArray = [[NSMutableArray alloc]init];
        
        for(NSInteger i= 0; i < widths. count; i++)
        {
            [self.xArray addObject:[NSNumber numberWithFloat:x]];
            x =  x + [widths[i] floatValue];

        }
        
        
        self.height = height;
    }
    
    return self;

}

-(void)prepareLayout
{
    [super prepareLayout];
    
    self.rowCount = [self.collectionView numberOfSections];
    
    NSMutableArray *counts = [NSMutableArray arrayWithCapacity:self.rowCount];
    NSMutableArray *rects = [NSMutableArray arrayWithCapacity:self.rowCount];
    self.cellLayoutInfo = [[NSMutableDictionary alloc]init];
    
    for (int section = 0; section < self.rowCount; section++)
    {
        //width = [self.widthArray[section%]floatValue]
        [counts addObject:@([self.collectionView numberOfItemsInSection:section])];
        [rects addObject:[NSValue valueWithCGRect:CGRectMake(0, section*self.height, self.height*100, self.height)]];
        
        NSInteger itemCount = [self.collectionView numberOfItemsInSection:section];
        
        for (NSInteger item = 0; item < itemCount; item++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:item inSection:section];
            
            UICollectionViewLayoutAttributes *itemAttributes =
            [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
            itemAttributes.frame = [self frameforCellAtIndexPath:indexPath];
            
            self.cellLayoutInfo[indexPath] = itemAttributes;
        }
        
        
        
        
    }
    self.cellCounts = [NSArray arrayWithArray:counts];
    self.sectionRects = [NSArray arrayWithArray:rects];
    float contentWidth = 0;
    for(NSNumber *width in self.widthArray)
    {
        contentWidth += [width floatValue];
    
    }
    self.contentSize = CGSizeMake(contentWidth, self.rowCount*self.height);
}

-(CGSize)collectionViewContentSize
{
    CGSize newSize = self.contentSize;
    newSize.width += CONTENT_AREA_PADDING;
    newSize.height += CONTENT_AREA_PADDING;
    return newSize;
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return NO;
}

- (int)cellCountForSection:(NSInteger)section
{
    NSNumber *count = self.cellCounts[section];
    return [count intValue];
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return self.cellLayoutInfo[indexPath];
}



- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect
{
    NSMutableArray *allAttributes = [NSMutableArray arrayWithCapacity:self.cellLayoutInfo.count];

                                                      
        [self.cellLayoutInfo enumerateKeysAndObjectsUsingBlock:^(NSIndexPath *indexPath,
                                                          UICollectionViewLayoutAttributes *attributes,
                                                          BOOL *innerStop) {
            if (CGRectIntersectsRect(rect, attributes.frame)) {
                
                [allAttributes addObject:attributes];
            }
        }];
  
    
    return allAttributes;
}



-(CGRect)frameforCellAtIndexPath:(NSIndexPath*)indexPath{

    float contentScrollViewPadding = CONTENT_SCROLLVIEW_PADDING;

    NSInteger row = indexPath.section;
    NSInteger column = indexPath.row % self.numColumns;

    CGFloat originX = [self.xArray[column]floatValue] + contentScrollViewPadding;
    
    CGFloat originY = (self.height * row)+ contentScrollViewPadding;
    return CGRectMake(originX, originY, [self.widthArray[column]floatValue], self.height);

}


@end
