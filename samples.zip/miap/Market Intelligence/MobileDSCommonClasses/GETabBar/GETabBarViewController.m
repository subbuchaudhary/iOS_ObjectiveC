//
//  GETabBarViewController.m
//  MobileDesignSystem
//
//  Created  on 10/26/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import "GETabBarViewController.h"


#define SELECTED_VIEW_CONTROLLER_TAG 98456345

@interface GETabBarViewController (){

    

}

@end

@implementation GETabBarViewController

@synthesize tabBar;
@synthesize tabBarItems;
@synthesize accentColor = _accentColor;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];


    
    [self.view addSubview:tabBar];
    [tabBar selectItemAtIndex:0];
    [self touchDownAtItemAtIndex:0];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Setters

-(void)setAccentColor:(UIColor *)color
{
    _accentColor = color;
    tabBar.backgroundColor = _accentColor;
    
}

#pragma mark TabBar Delegate Methods

- (void) touchDownAtItemAtIndex:(NSUInteger)itemIndex
{
    // Remove the current view controller's view
    UIView* currentView = [self.view viewWithTag:SELECTED_VIEW_CONTROLLER_TAG];
    [currentView removeFromSuperview];
    
    // Get the right view controller
    NSDictionary* data = tabBarItems[itemIndex];
    UIViewController* viewController = data[@"viewController"];
    

    // Set the view controller's frame to account for the tab bar
    viewController.view.frame = CGRectMake(0,0,self.view.bounds.size.width, self.view.bounds.size.height-49);
    
    // Se the tag so we can find it later
    viewController.view.tag = SELECTED_VIEW_CONTROLLER_TAG;
    
    // Add the new view controller's view
    [self.view insertSubview:viewController.view belowSubview:tabBar];
    [tabBar selectItemAtIndex:itemIndex];
    
    
}




//}
@end
