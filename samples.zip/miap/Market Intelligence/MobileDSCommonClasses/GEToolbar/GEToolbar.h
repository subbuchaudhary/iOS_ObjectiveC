//
//  GEToolbar.h
//  MobileDS
//
//  Created  on 5/29/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import <UIKit/UIKit.h>

@interface GEToolbar : UIToolbar

@end
