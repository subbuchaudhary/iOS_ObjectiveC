//
//  GEButton.h
//  MobileDesignSystem
//
//  Created  on 10/5/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import <UIKit/UIKit.h>
#import "GELabel.h"
#import <QuartzCore/QuartzCore.h>
#import "GEColor.h"

#define LARGE_BUTTON_HEIGHT 44.0
#define LARGE_BUTTON_WIDTH 131.0
#define DETAILICON_BUTTON_HEIGHT 44.0
#define DETAILICON_BUTTON_WIDTH 191.0
#define DETAILICON_ICON_SQR 22.0
#define ICON_BUTTON_HEIGHT 44.0
#define ICON_BUTTON_WIDTH 44.0
#define ICON_BUTTON_ICON_SQR 26.0
#define NAVIGATION_BUTTON_HEIGHT 56.0
#define NAVIGATION_BUTTON_WIDTH 139.0
#define NAVIGATION_BUTTON_ICON_SQR  48.0
#define THUMNAILGRID_BUTTON_SIZE_iPhone 92.0
#define THUMNAILGRID_BUTTON_SIZE_iPad 170
#define THUMBNAILGRID_BUTTON_ICON_SQR  84.0
#define CHART_BUTTON_HEIGHT 27.0
#define CHART_BUTTON_WIDTH 77.0

typedef NS_ENUM(NSInteger, GEButtonStyle) {
    GEButtonStyleLarge,
    GEButtonStyleIcon,
    GEButtonStyleNavigationImage,
    GEButtonStyleThumbnailGrid,
    GEButtonStyleDetail,
    GEButtonStyleChartFilter,
    GEButtonStyleDetailIcon,

};





@interface GEButton : UIView {

    
    UIImageView *iconImageView;
    

}



- (id)initWithFrame:(CGRect)frame
              color:(UIColor *)GEColor
andAttributedString:(NSMutableAttributedString *)attributedString;

- (id)initWithStyle:(GEButtonStyle)GEButtonStyle
              andColor:(UIColor *)GEColor;


@property(nonatomic, strong) GELabel *buttonTextLabel;
@property(nonatomic, strong) UIButton *button;
@property(nonatomic, strong) UIView* rule;
@property(nonatomic, strong, setter=setButtonText:) NSString *buttonText;
@property(nonatomic, strong, setter=setAttributedButtonText:) NSAttributedString *attributedbuttonText;

@property(nonatomic, strong, setter=setIconImage:) UIImage *iconImage;
@property(nonatomic, strong, setter=setGridImage:) UIImage *gridImage;
@property(nonatomic, strong) UIColor *buttonColor;


@end
