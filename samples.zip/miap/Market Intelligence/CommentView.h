//
//  CommentView.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentRowView.h"
#import "Comment+CommentCustom.h"
#import "DealerListService.h"

@protocol CommentViewRowSelectionDelegate <NSObject>

-(void)rowSelectedWithTag:(NSInteger) tag forCommentID:(NSNumber*) objectID;

-(void) deleteComment:(NSNumber*) objectID;

- (CGPoint) positionOfTextField:(UITextField*) textField;
-(void) enteredContactName:(NSString*) contactName;
-(void) dealerDataSelected:(NSMutableArray*) selectedDealerList;

-(void) validationComplete:(BOOL) status;
- (void) refreshView;

@end

@interface CommentView : UITableViewCell <UITextFieldDelegate, DealerDataReceiver, UIAlertViewDelegate, CommentRowViewDeleteDelegate>
{
    BOOL editingContactName;
    BOOL editingDealer;
    UIButton *dismissKeyboardButton;
    
    BOOL validatingDealerNumberForSend;

}


@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@property (strong, nonatomic) IBOutlet UIView *container;
@property (strong, nonatomic) IBOutlet UIView *background;
@property (strong, nonatomic) IBOutlet UITextView *commentArea;
@property (strong, nonatomic) IBOutlet CommentRowView *opportunityType;
@property (strong, nonatomic) IBOutlet CommentRowView *dealerInfo;

@property (strong,nonatomic) MIComments* comment;

//Added by Jeff
@property NSNumber *objectID;
@property SEL updateCurrentComment;

@property (weak, nonatomic) UIViewController<CommentViewRowSelectionDelegate> *delegate;

-(IBAction) rowSelected:(id)sender;
-(IBAction) textViewSelected:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *deleteComment;
@property (weak, nonatomic) IBOutlet UITextField *contactName;
- (void) displayValidationError:(BOOL) flag;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *optionViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dealerViewHeight;

- (IBAction)deleteComment:(UIButton *)sender;
- (BOOL) isValid;
- (BOOL) validateText;
- (BOOL) validateOptionSelections;
- (BOOL) validateDealerSelections;
- (BOOL) validateContactName;

@property (weak, nonatomic) IBOutlet UIImageView *contactCheckBox;

-(void) displayValidationError:(BOOL) flag forView:(UIView*) view;



// Property Indicates if a entered Dealer# has been validated for send
@property BOOL dealerNumberValidated;

- (CGFloat) height ;
-(void) displayDealersAndOptionsIfPresent;
-(void) validateDealerNumber;



@end
