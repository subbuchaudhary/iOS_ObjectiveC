//
//  Dealer+DealerCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MIDealerList.h"
#import "MIDealerSummary.h"
@interface MIDealerList (MI_DealerCustom)

- (void) encryptWithKey:(NSString*) key;
-(void) decryptWithKey:(NSString*) key;
-(MIDealerSummary *)getDealerSummeryObject;
@end
