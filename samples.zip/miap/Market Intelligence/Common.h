//
//  Common.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/19/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#ifndef Market_Intelligence_Common_h
#define Market_Intelligence_Common_h


#endif
