//
//  LoginService.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/18/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <Foundation/Foundation.h>
//MI_V_1.0
#import "MIFSR.h"
typedef NS_ENUM(NSInteger, LoginStatus) {
    NO_LOCAL_CREDENTIALS, // Users has not successfully logged in even once and there is no connectivity
    LOCAL_LOGIN_SUCCESSFUL, // No connectivity and logged in against local credentials
    LOCAL_LOGIN_FAILED, // No connectivity and local login failed
    REMOTE_LOGIN_SUCCESSFUL, // Remote login successful
    REMOTE_LOGIN_FAILED, // Remote login failed
    REMOTE_ACCOUNT_LOCKED,
    REMOTE_SYSTEM_FAILURE
};


@protocol LoginStatusReceiver <NSObject>
@required
- (void) receiveLoginStatus: (LoginStatus) status FSR: (MIFSR*) fsr;
- (void) receiveLoginStatusWithMessage:(NSString*)message;

@end


@interface LoginService : NSObject
{
    NSString *sso;
    NSString *ssoPassword;
    
}

@property (weak,nonatomic) id<LoginStatusReceiver> delegate;

-(id) initWithDelegate:(id<LoginStatusReceiver>) delegate;

- (void) loginWithUserId:(NSString*) userId password:(NSString*) password;

@end


