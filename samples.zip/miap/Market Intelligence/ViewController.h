//
//  ViewController.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentView.h"
#import "AddCommentCell.h"
#import "CommentInputViewController.h"
#import "FSGBaseViewController.h"
#import "SelectOpportunityView.h"
#import "CategoryViewController.h"
#import "DealerListViewController.h"
#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController : FSGBaseViewController <CommentInputViewControllerDelegate, CommentViewRowSelectionDelegate, UITableViewDelegate, CategoryViewDelegate, DealerListViewDelegate, UIAlertViewDelegate>
{
    BOOL sendingSurvey;
    UIAlertView* allCommentDelete;
    UIAlertView* singleCommentDelete;
}


@property (strong, nonatomic) IBOutlet UIView *container;
@property (strong, nonatomic) IBOutlet CommentView *comment;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *mainViewLeftEdgeAlignment;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *mainViewRightEdgeAlignment;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *selectOpportunityViewWidth;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *sendButton;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *deleteButton;
@property (strong, nonatomic) AVAudioPlayer *validationAlertSound;

- (IBAction)sendSurvey:(UIBarButtonItem *)sender;

//Added By Jeff
@property (strong, nonatomic) IBOutlet UITableView *commentTable;
@property int commentCount;
@property int current;

@property (strong, nonatomic) NSMutableArray *commentArray;

@property (weak) AppDelegate* appDelegate;

@property (strong, nonatomic) NSString *textFromCommentInput;

@property BOOL selectOpportunityShowing;

- (IBAction)closeSelectOpportunityWindow:(UISwipeGestureRecognizer *)sender;

-(void) showSelectOpportunityWindowWithDuration:(CGFloat) duration;
-(void) hideSelectOpportunityWindowWithDuration:(CGFloat) duration;
- (IBAction)deleteSurvey:(UIBarButtonItem *)sender;

-(void) initComments;
-(void)setCurrentComment:(NSNumber*)currentComment;


@end
