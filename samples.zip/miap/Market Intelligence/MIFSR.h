//
//  MIFSR.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 19/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MIFSR : NSObject
@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * lastName;
@property (nonatomic, retain) NSString * managerSSO;
@property (nonatomic, retain) NSString * sso;
@end
