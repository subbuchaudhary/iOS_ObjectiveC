/*
	SoapHandler.m
	Implementation of a blank SOAP handler.
	Author:	Jason Kichline, Mechanicsburg, Pennsylvania USA
*/

#import "SoapHandler.h"

@implementation SoapHandler

- (void) onload: (id) value
{
}

- (void) onerror: (NSError*) error
{
}

- (void) onfault: (SoapFault*) fault
{
}

@end
