//
//  MISurvey.m
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import "MISurvey.h"
#import "MIDBManager.h"
#import "AppDelegate.h"
@implementation MISurvey

-(void)getSurveyComments
{
    self.commentList = [[NSMutableOrderedSet alloc] init];
    NSArray *subCatIds = [self.commentIds componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:COMMENTS_TABLE];
    NSMutableArray *objComments = [[NSMutableArray alloc] init];
    for (NSString *subCatId in subCatIds) {
        NSArray*arrComment =  [[MIDBManager getSharedInstance] fetchCommentlist:[NSString stringWithFormat:@"select*from %@ where keyId = '%@'",TABLE_COMMENTS,subCatId]];
        if (arrComment.count>0)
            [objComments addObject:arrComment[0]];
    }
    
    if (objComments.count>0) {
        self.commentList = [NSMutableOrderedSet orderedSetWithArray:objComments];
    }
}

-(void)clearSurveyTable
{
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSString* query = [NSString stringWithFormat:@"delete from %@ ",TABLE_CURRENT_SURVEY];
    [[MIDBManager getSharedInstance] deleteRecrodsQuery:query];
    [self.commentList removeAllObjects ];
    appDelegate.currentSurvey = [[MISurvey alloc] init];
    appDelegate.currentSurvey.surveyID = @"100";
    //appDelegate.currentSurvey.commentIds = @"";
    [[MIDBManager getSharedInstance] insertCurrentSurveyRecords:@[appDelegate.currentSurvey]];
}

-(void)getCurrentSurveyComments
{
    NSArray *arrCommentsIds = [self.commentIds componentsSeparatedByString:@","];
    //Now call comments sectio fucntion to create new commet object
    NSMutableArray *arrCommentsList = [[NSMutableArray alloc] init];
    for (NSString *strCommentId in arrCommentsIds) {
        NSString *selectQuery = [NSString stringWithFormat:@"select * from %@ where keyId = '%@'",TABLE_COMMENTS,strCommentId];
        [[MIDBManager getSharedInstance] setStateSelectedTable:COMMENTS_TABLE];
        NSArray *arrayComment = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:selectQuery];
        if (arrayComment.count>0) {
            MIComments *comment = arrayComment[0];
            [comment getCommentCategoryStructureForComment:comment];
            [arrCommentsList addObject:comment];
        }
        
    }
    self.commentList = [NSMutableOrderedSet orderedSetWithArray:arrCommentsList];
}
@end
