//
//  SubCategoryViewCell.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "SubCategoryViewCell.h"


@implementation SubCategoryViewCell

- (IBAction)expand:(id)sender {
}

- (void)configureWithHierarchy:(MIBaseCategory *)category
{
    [super configureWithHierarchy:category];
    super.isExpanded = false;
     MISubCategory* subCategory = (MISubCategory*) category;
    _objectName.text = subCategory.subCatName;
   
    [_objectName setFont:[UIFont fontWithName:@"GEInspira" size:15]];
   // [subCategory getTopicList:subCategory];
    if ([subCategory.topiclist.array count] == 0)
    {
        _expand.hidden = YES;
        _collapse.hidden = YES;
    }
    else
    {
        _checkboxOff.hidden = NO;
        _checkboxOn.hidden = YES;
        _checkboxOff.enabled = NO;
        _checkboxOn.enabled = NO;
        _expand.hidden = NO;
        _collapse.hidden = YES;
    }
    
    UIEdgeInsets insets;
    insets.left = 30;
    self.separatorInset = insets;
    self.contentView.backgroundColor = [UIColor clearColor];
}

- (void) prepareForReuse
{
    _collapse.hidden = YES;
    _expand.hidden = NO;
    
    _checkboxOn.hidden = YES;
    _checkboxOff.hidden = NO;
    _checkboxOn.enabled = YES;
    _checkboxOff.enabled = YES;
    super.isExpanded = false;
    
}

- (void) selectCategory
{
    MISubCategory* subCat = (MISubCategory*) self.dataObject;
    //[subCat getTopicList:subCat];
    if ([subCat.topiclist.array count] == 0)
    {
        _expand.hidden = YES;
        _collapse.hidden = YES;
    }
    _checkboxOn.hidden = NO;
    _checkboxOff.hidden = YES;
}

- (IBAction)collaspseClicked:(id)sender {
    super.isExpanded = false;
    [self.parentController collapseClickedOnCell:self];
    
}

- (IBAction) expandClicked:(UIButton *)sender
{
    super.isExpanded = true;
    [self.parentController expandClickedOnCell:self];
    
}

- (IBAction)checkboxSelected:(UIButton *)sender {
    
    if ([sender isEqual:_checkboxOn])
    {
        _checkboxOn.hidden = YES;
        _checkboxOff.hidden = NO;
        [self.parentController unselectObject:self.dataObject];
    }
    else
    {
        _checkboxOn.hidden = NO;
        _checkboxOff.hidden = YES;
        [self.parentController selectObject:self.dataObject];
        
    }
}

- (void) hideExpand
{
    _expand.hidden = YES;
    _collapse.hidden = NO;
}

@end
