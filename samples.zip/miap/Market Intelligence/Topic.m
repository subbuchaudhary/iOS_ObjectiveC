//
//  Topic.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "Topic.h"
#import "Comment.h"
#import "SubCategory.h"


@implementation Topic

@dynamic parent;
@dynamic commentList;

@end
