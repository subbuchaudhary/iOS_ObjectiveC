//
//  MISubCategoryType.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MIBaseCategory.h"
#import "MICategory.h"
@interface MISubCategory : MIBaseCategory
@property(nonatomic,strong)NSNumber *surveyId;
@property(nonatomic,strong)NSNumber *superCatId;
@property(nonatomic,strong)NSNumber *catId;
@property(nonatomic,strong)NSNumber *subCatId;
@property(nonatomic,strong)NSString *subCatName;
@property(nonatomic,strong)NSSet *topiclist;
@property(nonatomic,strong)MICategory *parent;
-(MICategory*)getParentCategory;
-(NSMutableArray*)getTopicList:(MISubCategory*)category;

@end
