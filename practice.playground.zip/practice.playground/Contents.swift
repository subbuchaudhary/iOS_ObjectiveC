import UIKit
var greeting = "hi there"
var someInt = ""
var x = 6.0

//hasPrefix checks the string for a prefix
greeting.hasPrefix("hi")

//isEmpty is used to check the give string is empty or not
greeting.isEmpty
someInt.isEmpty

//.advanced(by: some number) does adding
x.advanced(by: 9) // same as (x+9)

x+3

func don() {
    x = x + 9
}
don()
don()
don()
don()
don()
don()
x

sqrt(x)

func nivas(cash: Double, ratio: Double) -> Double{
    return cash*ratio
}
var subbu = nivas(cash: 9, ratio: 9)
print("Give \(subbu) to the actual")



