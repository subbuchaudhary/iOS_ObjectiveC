//
//  DealerViewCell.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/17/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "DealerViewCell.h"
#import "MIConstant.h"
@implementation DealerViewCell
@synthesize dealer;
@synthesize delegate;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        inspiraFont = [UIFont fontWithName:@"GE Inspira" size:8.0];
        inspiraBold = [UIFont fontWithName:@"GE Inspira Bold" size:10.0];

    }
    return self;
}

- (void) prepareForReuse
{
    _checkboxOff.hidden = NO;
    _checkboxOn.hidden = YES;
    _dealerName.text = @"";
    _branchNoAndVBU.text = @"";
}

- (void) configureWithDealer: (MIDealerList*) aDealer
{
    self.dealer = aDealer;
    _dealerName.text = aDealer.customerName;
    _branchNoAndVBU.text = [NSString stringWithFormat:@"%@-%@-%@",aDealer.customerNo,aDealer.branchNo,aDealer.vbu];
    
}

- (IBAction)checkboxClicked:(UIButton *)sender {
    
    if (sender == _checkboxOn)
    {
        _checkboxOn.hidden = YES;
        _checkboxOff.hidden = NO;
       [self.delegate unselectDealer:dealer];
    }
    else
    {
        _checkboxOn.hidden = NO;
        _checkboxOff.hidden = YES;
       [self.delegate selectDealer:dealer];
    }
}

- (void) markSelected
{
    _checkboxOff.hidden = YES;
    _checkboxOn.hidden = NO;
}

- (BOOL) isSelected
{
    return (_checkboxOff.isHidden);
    
}

@end
