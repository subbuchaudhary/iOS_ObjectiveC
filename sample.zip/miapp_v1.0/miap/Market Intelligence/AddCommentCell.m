//
//  AddCommentCell.m
//  Market Intelligence
//
//  Created by Jeff on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "AddCommentCell.h"

@implementation AddCommentCell


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"AddCommentCell" owner:self options:nil];
         [self addSubview:self.container];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        //Custom Initialization code here
        [[NSBundle mainBundle] loadNibNamed:@"AddCommentCell" owner:self options:nil];
        [self addSubview:self.container];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(IBAction)addCommentClicked:(id)sender
{
    [_delegate performSelector:_addComment];
}

@end
