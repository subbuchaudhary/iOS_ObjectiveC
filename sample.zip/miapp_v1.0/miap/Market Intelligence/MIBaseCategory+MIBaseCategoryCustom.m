//
//  BaseCategory+BaseCategoryCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/12/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MIBaseCategory+MIBaseCategoryCustom.h"

@implementation MIBaseCategory (MIBaseCategoryCustom)

-(BOOL)isSameAs:(id)object
{
    BOOL result = false;
    if ([[object class] isSubclassOfClass:[MIBaseCategory class]])
    {
        MIBaseCategory* otherObject = (MIBaseCategory*) object;
        if ([otherObject.name isEqualToString:self.name])
            result = true;
    }
    return result;
}

@end
