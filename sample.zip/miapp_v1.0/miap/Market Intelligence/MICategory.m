//
//  MICategoryType.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MICategory.h"
#import "MIDBManager.h"
@implementation MICategory
-(NSMutableArray*)getSubCategoryList:(MICategory*)category
{
    NSMutableArray *arrSubCategory = [[NSMutableArray alloc] init];
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    NSMutableArray *objSubCategory = [[MIDBManager getSharedInstance] fetchsingleRecords:category.catId.stringValue];
    [arrSubCategory addObjectsFromArray:objSubCategory];
    return arrSubCategory;
}

-(MISuperCategory *)getSuperCategory
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUPERCATEGORY_TABLE];
    NSMutableArray *objSubCategory = [[MIDBManager getSharedInstance] fetchsingleRecords:self.superCatId.stringValue];
    if (objSubCategory.count>0) {
        return self.parentSuperCategory = objSubCategory[0];
    }
    return [MISuperCategory new];
}
-(void)getCategoryListObjects
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    NSString *query = [NSString stringWithFormat:@"select * from %@ where catId = '%@'",TABLE_SUBCATEGORY,self.catId];
    NSArray *objCategory = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (objCategory.count>0) {
        self.subCategorylist =  [NSSet setWithArray:objCategory];
        for (MISubCategory *objSubCategory in self.subCategorylist.allObjects) {
            [objSubCategory getTopicList:objSubCategory];
            [objSubCategory setParentCategory:self];
            
        }
    }
    
}
@end
