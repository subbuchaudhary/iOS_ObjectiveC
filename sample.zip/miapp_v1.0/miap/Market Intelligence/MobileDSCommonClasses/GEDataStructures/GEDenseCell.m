//
//  GEDenseCell.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseCell.h"

@implementation GEDenseCell

@synthesize isSelectedSingleRow = _isSelectedSingleRow;
@synthesize isSelected = _isSelected;
@synthesize isSelectedMulti = _isSelectedMulti;

- (id)initWithTitle:(NSString *)title Type:(GECell_Type)type Alert:(BOOL)isAlert
{
    self = [super init];
    
    if (self) {
        self.title = title;
        self.value = [title floatValue];
        self.isAlert = isAlert;
        self.type = type;
    }
    
    return self;
}

- (id)initWithValue:(CGFloat)value Type:(GECell_Type)type Alert:(BOOL)isAlert
{
    self = [super init];
    
    if (self) {
        self.value = value;
        self.isAlert = isAlert;
        self.type = type;
        
        switch (type) {
            case GECell_Text:
                self.title = [NSString stringWithFormat:@"%f",value];
                break;
            case GECell_Bar:
                self.title = [NSString stringWithFormat:@"%f",value];
                break;
            case GECell_CurrencyUSD:
                self.title = [self currencyUSDStringfromValue:value];
                break;
            case GECell_Change:
                self.title = [self changeStringfromValue:value];
                break;
            case GECell_Percentage:
                self.title = [self percentageStringfromValue:value];
                break;
            case GECell_LargeNumber:
                self.title = [self largeNumberStringfromValue:value];
                break;
                
                
            default:
                self.title = [NSString stringWithFormat:@"%f",value];
                break;
        }
    }
    
    return self;
}


- (NSString*)currencyUSDStringfromValue:(CGFloat)value{
    
    NSString* formattedString;
    
    formattedString = [NSString stringWithFormat:@"$%.2f",value];
    
    return formattedString;
    
}

- (NSString*)changeStringfromValue:(CGFloat)value{
    
    NSString* formattedString;
    
    formattedString = [NSString stringWithFormat:@"%.1f",value];
    
    return formattedString;
    
}

- (NSString*)percentageStringfromValue:(CGFloat)value{
    
    NSString* formattedString;
    
    formattedString = [NSString stringWithFormat:@"%.2f%%",value];
    
    return formattedString;
    
}

- (NSString*)largeNumberStringfromValue:(CGFloat)value{
    
    NSString* formattedString;
    
    if(value < -1000000000){
        
        NSNumber *roundedValue = [NSNumber numberWithFloat:value/1000000000];
        formattedString = [NSString stringWithFormat:@"%.0fB",[roundedValue floatValue]];
    } else if (-1000000000 <= value && value < -1000000){
        NSNumber *roundedValue = [NSNumber numberWithFloat:value/1000000];
        formattedString = [NSString stringWithFormat:@"%.0fM",[roundedValue floatValue]];
        
    }else if (-1000000 <= value && value < -1000){
        NSNumber *roundedValue = [NSNumber numberWithFloat:(value+500)/1000];
        formattedString = [NSString stringWithFormat:@"%.0fK",[roundedValue floatValue]];
        
    }else if(-1000 <= value && value < 1000 ){
        
        formattedString = [NSString stringWithFormat:@"%.0f",value];
        
    }else if (1000 <= value && value < 1000000){
        NSNumber *roundedValue = [NSNumber numberWithFloat:value/1000];
        formattedString = [NSString stringWithFormat:@"%.0fK",[roundedValue floatValue]];
        
    }else if (1000000 <= value && value < 1000000000){
        
        NSNumber *roundedValue = [NSNumber numberWithFloat:value/1000000];
        formattedString = [NSString stringWithFormat:@"%.0fM",[roundedValue floatValue]];
        
    }else{
        
        NSNumber *roundedValue = [NSNumber numberWithFloat:value/1000000000];
        formattedString = [NSString stringWithFormat:@"%.0fB",[roundedValue floatValue]];
    }
    
    
    return formattedString;
    
}

-(void)setIsSelected:(BOOL)isSelected
{
    _isSelected = isSelected;
        _isSelectedSingleRow = NO;
        _isSelectedMulti = NO;

}

-(void)setIsSelectedMulti:(BOOL)isSelectedMulti
{
    _isSelectedMulti = isSelectedMulti;
    if (isSelectedMulti == YES) {
        _isSelectedSingleRow = NO;
        _isSelected = NO;
    }

}

-(void)setIsSelectedSingleRow:(BOOL)isSelectedSingleRow
{
    _isSelectedSingleRow = isSelectedSingleRow;
    if (isSelectedSingleRow == YES) {
        _isSelected = NO;
        _isSelectedMulti = NO;
    }
}

@end



