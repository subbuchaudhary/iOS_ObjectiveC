//
//  GETextField.m
//  MobileDS
//
//  Created on 5/15/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import "GETextField.h"

@implementation GETextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color
{
    self = [super init];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.fontSize = fontSize;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}


-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.frame = frame;
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}



-(id)initWithFrame:(CGRect)frame Font:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andPlaceholder:(NSString *)placeholderText
{
    self = [super initWithFrame:frame];
    self.placeholder = [placeholderText uppercaseString];
    self.contentVerticalAlignment = UIControlContentVerticalAlignmentTop;
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andPlaceholder:(NSString *)placeholderText
{
    self = [super init];
    self.placeholder = [placeholderText uppercaseString];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}





-(CGRect)textRectForBounds:(CGRect)bounds
{
    CGRect rectForBounds;
    
    rectForBounds =  CGRectMake(bounds.origin.x + 20, bounds.size.height/2 - 8,
                      bounds.size.width - 20, bounds.size.height - 16);
    
    
    return rectForBounds;

}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    return [self textRectForBounds:bounds];
}



@end
