//
//  FSR+FSRCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "FSR.h"

@interface FSR (FSRCustom)

-(NSDictionary*) asDictionary;

- (void) encryptWithKey:(NSString*) key;
- (void) decryptWithKey:(NSString*) key;

@end
