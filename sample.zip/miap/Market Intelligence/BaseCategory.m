//
//  BaseCategory.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "BaseCategory.h"


@implementation BaseCategory

@dynamic keyId;
@dynamic name;

@end
