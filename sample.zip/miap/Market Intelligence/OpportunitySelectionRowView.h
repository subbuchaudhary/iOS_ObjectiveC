//
//  OpportunitySelectionRowView.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 12/10/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpportunitySelectionRowView : UIView

@property (strong, nonatomic) IBOutlet UIView *container;
@property (strong, nonatomic) IBOutlet UILabel *label;
@property (strong, nonatomic) IBOutlet UIImageView *image;

@end
