//
//  SurveyCategory.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "BaseCategory.h"

@class SubCategory, SuperCategory;

@interface SurveyCategory : BaseCategory

@property (nonatomic, retain) NSOrderedSet *categoryList;
@property (nonatomic, retain) SuperCategory *parent;
@end

@interface SurveyCategory (CoreDataGeneratedAccessors)

- (void)insertObject:(SubCategory *)value inCategoryListAtIndex:(NSUInteger)idx;
- (void)removeObjectFromCategoryListAtIndex:(NSUInteger)idx;
- (void)insertCategoryList:(NSArray *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeCategoryListAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInCategoryListAtIndex:(NSUInteger)idx withObject:(SubCategory *)value;
- (void)replaceCategoryListAtIndexes:(NSIndexSet *)indexes withCategoryList:(NSArray *)values;
- (void)addCategoryListObject:(SubCategory *)value;
- (void)removeCategoryListObject:(SubCategory *)value;
- (void)addCategoryList:(NSOrderedSet *)values;
- (void)removeCategoryList:(NSOrderedSet *)values;
@end
