//
//  DealerViewCell.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/17/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Dealer.h"
#import "MIDealerList.h"


@protocol DealerCellDelegate <NSObject>

- (void) selectDealer : (MIDealerList*) dealer;
- (void) unselectDealer : (MIDealerList*) dealer;

@end

@interface DealerViewCell : UITableViewCell

{
    UIFont* inspiraFont;
    UIFont* inspiraBold;
}


@property (weak, nonatomic) MIDealerList* dealer;
@property (weak, nonatomic) IBOutlet UIButton *checkboxOn;
@property (weak, nonatomic) IBOutlet UIButton *checkboxOff;


@property (weak, nonatomic) IBOutlet UILabel *dealerName;
@property (weak, nonatomic) IBOutlet UILabel *branchNoAndVBU;
@property (weak, nonatomic) id<DealerCellDelegate> delegate;


- (IBAction)checkboxClicked:(UIButton *)sender;

- (void) configureWithDealer: (MIDealerList*) aDealer;
- (void) markSelected;

- (BOOL) isSelected;

@end
