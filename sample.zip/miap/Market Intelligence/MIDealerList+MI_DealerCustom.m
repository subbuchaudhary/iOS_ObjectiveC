//
//  Dealer+DealerCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MIDealerList+MI_DealerCustom.h"
#import "NSString+AESCrypt.h"
#import "MIDealerSummary.h"
#import "MIConstant.h"
@implementation MIDealerList (DealerCustom)

- (void) encryptWithKey:(NSString*) key
{
    self.customerName = [self.customerName AES256EncryptWithKey:key];
    self.customerNo = [self.customerNo AES256EncryptWithKey:key];
    self.vbu = [self.vbu AES256EncryptWithKey:key];
    
}

-(void) decryptWithKey:(NSString*) key
{
    self.customerName = [self.customerName AES256DecryptWithKey:key];
    self.customerNo = [self.customerNo AES256DecryptWithKey:key];
    self.vbu = [self.vbu AES256DecryptWithKey:key];
    
}

-(MIDealerSummary *)getDealerSummeryObject
{
    NSString *query = [NSString stringWithFormat:@"select * from %@ where masterNumber = '%@'",TABLE_DEALERSUMMERY,self.masterNumber];
    [[MIDBManager getSharedInstance] setStateSelectedTable:DEALER_SUMMERY_TABLE];
    NSMutableArray *results = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (results.count>0) {
        return  results[0];
    }
    return nil;
}

@end
