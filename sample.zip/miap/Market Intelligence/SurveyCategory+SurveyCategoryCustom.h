//
//  SurveyCategory+SurveyCategoryCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyCategory.h"

@interface SurveyCategory (SurveyCategoryCustom)
- (void)addCategoryListObject:(SubCategory *)value;

@end
