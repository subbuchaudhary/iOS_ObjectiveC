//
//  MISubCategoryType.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MISubCategory.h"
#import "MIDBManager.h"
@implementation MISubCategory
-(NSMutableArray*)getTopicList:(MISubCategory*)category
{
    NSMutableArray *arrSubCategory = [[NSMutableArray alloc] init];
    [[MIDBManager getSharedInstance] setStateSelectedTable:TOPIC_TABLE];
    NSMutableArray *objSubCategory = [[MIDBManager getSharedInstance] fetchsingleRecords:category.subCatId.stringValue];
    [arrSubCategory addObjectsFromArray:objSubCategory];
    return arrSubCategory;
}

-(MICategory*)getParentCategory
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
   NSString* query = [NSString stringWithFormat:@"select * from %@ where id = %d ",TABLE_CATEGORY,self.catId.intValue];
    NSMutableArray *results = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (results.count>0) {
        return results[0];
    }
    else
    {
        return [MICategory new];
    }
}
@end
