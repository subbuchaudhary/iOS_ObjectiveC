//
//  MIComments.m
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import "MIComments.h"
#import "MIDBManager.h"
@implementation MIComments

-(NSMutableArray*)getCommentsList
{
   return [[MIDBManager getSharedInstance] fetchCommentlist:[NSString stringWithFormat:@"select*from %@",TABLE_COMMENTS]];
}

-(void)insertCommentInDatabase:(NSArray*)commentlist
{
    if (commentlist.count>0) {
        
        //Check comment exist in database or not
        for (MIComments *objComment in commentlist) {
            NSString *selectQuery = [NSString stringWithFormat:@"select * from %@ where keyId = '%@'",TABLE_COMMENTS,objComment.keyId];
            [[MIDBManager getSharedInstance] setStateSelectedTable:COMMENTS_TABLE];
            NSArray *arrayComment = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:selectQuery];
            
            if(arrayComment.count>0)
            {
               // MIComments *comment = arrayComment[0];
                //[comment getCommentCategoryStructureForComment:objComment];
                [self updateCommentObject:objComment];
            }
            else
                [[MIDBManager getSharedInstance] insertRecrodsInComments:@[objComment]];
            

        }
        
    }
}

#pragma mark - Update comment row 
-(void)updateCommentObject:(MIComments*)dictInput
{
    NSString *contactId = (dictInput.contactName.length>0)?dictInput.contactName:@"";
    NSString *keyId  = dictInput.keyId;
    NSString *surveyType = (dictInput.surveyType.length>0)?dictInput.surveyType:@"";
    NSString *commentText  = (dictInput.text.length>0)?dictInput.text:@"";
    NSString *dealerNumber = (dictInput.dealerNumber.length>0)?dictInput.dealerNumber:@"";
    NSString *catId = [dictInput.category.catId stringValue];
    NSString *superCatId = [dictInput.superCategory.superCatId stringValue];
    NSString *topiclistIds= (dictInput.topicListIds.length>0)?dictInput.topicListIds:@"";
    NSString *subCatIds =  (dictInput.subCategoryIds.length>0)?dictInput.subCategoryIds:@"";
    NSString *dealerlistIds;
    NSMutableArray *dealerArray = [[NSMutableArray alloc] init];
    
    for (MIDealerSummary *summery in dictInput.dealerList.allObjects)
        [dealerArray addObject:summery.masterNumber];
    dealerlistIds = [dealerArray componentsJoinedByString:@","];

    dealerlistIds = dictInput.dealerListIds;
   NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET contactId = '%@' ,surveyType = '%@',commenttext = '%@',dealerNumber = '%@',catId = '%@',superCategoryId = '%@',topiclistIds = '%@',subCatIds = '%@',dealerlistIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS ,contactId,surveyType,commentText,dealerNumber,catId,superCatId,topiclistIds,subCatIds,dealerlistIds,keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}
-(MIComments*)manageCommnetobject:(NSMutableDictionary *)dictObj
{
    self.surveyType = dictObj[@"surveyType"];
    self.keyId = dictObj[@"keyid"];
    self.text = dictObj[@"commenttext"];
    self.contactName = dictObj[@"contactName"];
    
    self.dealerNumber = dictObj[@"dealerNumber"];
    self.dealerListIds = dictObj[@"dealerlistIds"];
    
    self.categoryId = dictObj[@"catId"];
    self.superCategory = dictObj[@"superCategoryId"];
    
    self.topicListIds = dictObj[@"topiclistIds"];
    self.subCategoryIds = dictObj[@"subCatIds"];
    //Get category object using categoryId
    [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
    NSMutableArray *objCat =  [[MIDBManager getSharedInstance] fetchsingleRecords:dictObj[@"catId"]];
    if (objCat.count>0)
        self.category = objCat[0];
    
    //Get Super category
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUPERCATEGORY_TABLE];
    NSMutableArray *objSuperCat =  [[MIDBManager getSharedInstance] fetchsingleRecords:dictObj[@"superCategoryId"]];
    if (objSuperCat.count>0){
        self.superCategory = objSuperCat[0];
        self.superCategoryId = self.superCategory.superCatId.stringValue;
    }
    
    
    
    //Get dealer list by id. Get string of ids from database and convert into array
    self.dealerList = [[NSMutableSet alloc] init];
    NSString *objDealerId =  dictObj[@"dealerlistIds"];
    NSArray *dealerIds = [objDealerId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:DEALER_SUMMERY_TABLE];
    for (NSString *dealerid in dealerIds) {
        NSMutableArray *record = [[MIDBManager getSharedInstance] fetchsingleRecords:dealerid];
        if (record.count>0)
            [self.dealerList addObject:record[0]];
    }

    
    //Get subcategory list by id. Get string of ids from database and convert into array
    self.subCategoryList = [[NSMutableSet alloc] init];
    NSString *objSubCatId =  dictObj[@"subCatIds"];
    NSArray *subCatIds = [objSubCatId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    for (NSString *subCatId in subCatIds) {
        NSString *selectQuery = [NSString stringWithFormat:@"select * from %@ where id = '%@'",TABLE_SUBCATEGORY,subCatId];
        NSArray *record = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:selectQuery];
        if (record.count>0)
            [self.subCategoryList addObject:record[0]];
    }
    
    //Get topic list by id. Get string of ids from database and convert into array
    self.topicList = [[NSMutableSet alloc] init];
    NSString *objtopiclistId =  dictObj[@"topiclistIds"];
    NSArray *topicslistIds = [objtopiclistId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:TOPIC_TABLE];
    for (NSString *subCatId in topicslistIds) {
        NSString *selectQuery = [NSString stringWithFormat:@"select * from %@ where id = '%@'",TABLE_TOPIC,subCatId];
        NSArray *record = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:selectQuery];
        if (record.count>0)
            [self.topicList addObject:record[0]];
    }
        return self;
}

-(void)deleteComment:(MIComments*)comment
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:COMMENTS_TABLE];
    [[MIDBManager getSharedInstance] deleteSingleRecords:comment.keyId];
}


-(void)updateSubCategoryList:(MISubCategory*)subCat
{
    NSString *subCatIds = self.subCategoryIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    [arrSubCat removeObject:subCat.subCatId];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    [self.subCategoryList removeObject:[arrSubCat filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"subCatId == %@",subCat.subCatId]]]];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET subCatIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS,(subCatIds.length>0)?subCatIds:@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

-(void)updateTopicList:(MITopic*)subCat
{
    NSString *subCatIds = self.topicListIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    [arrSubCat removeObject:subCat.topicid];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    [self.topicList removeObject:[arrSubCat filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"topicid == %@",subCat.topicid]]]];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET topiclistIds = '%@' WHERE keyId = '%@'" ,TABLE_TOPIC,(subCatIds.length>0)?subCatIds:@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

-(void)updateDealerList:(MIDealerSummary*)subCat
{
    NSString *subCatIds = self.dealerListIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"masterNumber == %@", subCat.masterNumber];

    NSArray *filteredArray = [self.dealerList.allObjects filteredArrayUsingPredicate:predicate];
    [self.dealerList removeObject:filteredArray[0]];
    
    [arrSubCat removeObject:subCat.masterNumber];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET dealerlistIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS,(subCatIds.length>0)?subCatIds:@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

//Insert Dealer list
-(void)insertDealerList:(MIDealerSummary*)subCat
{
    NSString *subCatIds = self.dealerListIds;
    NSMutableSet *arrSubCat = [NSMutableSet setWithArray:[[subCatIds componentsSeparatedByString:@","] mutableCopy]];
    
    [arrSubCat addObject:subCat.masterNumber];
    subCatIds = [[arrSubCat allObjects] componentsJoinedByString:@","];
    self.dealerListIds = subCatIds;
        
    [self.dealerList addObject:subCat];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET dealerlistIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS ,(subCatIds.length>0)?subCatIds:@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}
-(void)updateCommentText:(NSString*)comment
{
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET commenttext = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS ,(comment.length>0)?comment:@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}




#pragma mark - GET ADDED COMMENT CATEGORY STRUCTURE
//Function used to get the complete comment details fetch from database.so that if user close application and open again can reload the selected category structure for current survey selected commets
-(MIComments*)getCommentCategoryStructureForComment:(MIComments*)comment;
{
    
    //Get Super category
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUPERCATEGORY_TABLE];
    NSMutableArray *objSuperCat =  [[MIDBManager getSharedInstance] fetchsingleRecords:comment.superCategoryId];
    if (objSuperCat.count>0){
        comment.superCategory = objSuperCat[0];
    }
    
    //Get category object using categoryId
    [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
    NSMutableArray *objCat =  [[MIDBManager getSharedInstance] fetchsingleRecords:comment.categoryId];
    if (objCat.count>0)
        comment.category = objCat[0];
    
    comment.category.parentSuperCategory = comment.superCategory;
    
    
    //Get dealer list by id. Get string of ids from database and convert into array
    self.dealerList = [[NSMutableSet alloc] init];
    NSString *objDealerId =  comment.dealerListIds;
    NSArray *dealerIds = [objDealerId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:DEALER_SUMMERY_TABLE];
    for (NSString *dealerid in dealerIds) {
        NSMutableArray *record = [[MIDBManager getSharedInstance] fetchsingleRecords:dealerid];
        if (record.count>0)
            [self.dealerList addObject:record[0]];
    }
    //Fill up subcateogry,topiclist and dealer list array based on ids
    //SUBCATEGORY
    self.subCategoryList = [[NSMutableSet alloc] init];
    NSArray *subCatIds = [self.subCategoryIds componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    for (NSString *subCatId in subCatIds) {
        NSString *selectQuery = [NSString stringWithFormat:@"select * from %@ where id = '%@'",TABLE_SUBCATEGORY,subCatId];
        NSArray *record = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:selectQuery];
        if (record.count>0)
        {
            MISubCategory *subCategory = (MISubCategory*)record[0];
            subCategory.parentCategory = comment.category;
            [comment.subCategoryList addObject:record[0]];
        }
    }
    comment.category.subCategorylist = comment.subCategoryList;
    //comment.category.subCategorylist = [NSMutableSet setWithArray:[comment.category getSubCategoryList:comment.category]];
    //TOPIC LIST
    self.topicList = [[NSMutableSet alloc] init];
    NSArray *topicslistIds = [self.topicListIds componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:TOPIC_TABLE];
    for (NSString *subCatId in topicslistIds) {
        NSString *selectQuery = [NSString stringWithFormat:@"select * from %@ where id = '%@'",TABLE_TOPIC,subCatId];
        NSArray *record = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:selectQuery];
        if (record.count>0)
        {
            MITopic *topic = (MITopic*)record[0];
            NSPredicate * predicate = [NSPredicate predicateWithFormat:@"subCatId == %d", topic.subCatId.intValue];
            NSArray * topicParent = [comment.subCategoryList.allObjects filteredArrayUsingPredicate:predicate];
            NSLog(@"arr %@",topicParent);
            topic.parentSubCategory = topicParent[0];
            [comment.topicList addObject:topic];
        }
    }
    
    for (MISubCategory *objSub in comment.subCategoryList.allObjects) {
        
        NSMutableSet *topicSets = [[NSMutableSet alloc] init];
        for (MITopic *objTopic in comment.topicList.allObjects) {
            if(objTopic.parentSubCategory.subCatId.intValue == objSub.subCatId.intValue)
                [topicSets addObject:objTopic];
            objSub.topiclist = topicSets;
        }
    }
    
    return comment;
}
@end
