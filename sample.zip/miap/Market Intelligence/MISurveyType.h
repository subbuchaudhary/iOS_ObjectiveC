//
//  MISurveyType.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MISurveyType : NSObject
@property(nonatomic,strong)NSNumber *surveyId;
@property(nonatomic,strong)NSString *surveyName;
@property(nonatomic,strong)NSSet *superCategory;
@end
