//
//  DealerSummaryEntity.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Comment;

@interface DealerSummaryEntity : NSManagedObject

@property (nonatomic, retain) NSNumber * addedManually;
@property (nonatomic, retain) NSString * branchNo;
@property (nonatomic, retain) NSString * customerName;
@property (nonatomic, retain) NSString * customerNumber;
@property (nonatomic, retain) NSNumber * isValidated;
@property (nonatomic, retain) NSString * vbu;
@property (nonatomic, retain) NSSet *commentList;
@end

@interface DealerSummaryEntity (CoreDataGeneratedAccessors)

- (void)addCommentListObject:(Comment *)value;
- (void)removeCommentListObject:(Comment *)value;
- (void)addCommentList:(NSSet *)values;
- (void)removeCommentList:(NSSet *)values;

@end
