//
//  CategoryHierarchyCell.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryViewController.h"
#import "MIBaseCategory.h"
@class CategoryViewController;
@interface CategoryHierarchyCell : UITableViewCell
{
    UIFont* inspiraFont;
}

@property bool isExpanded;
@property (weak, nonatomic) CategoryViewController* parentController;
@property (weak, nonatomic) MIBaseCategory* dataObject;



- (void) configureWithHierarchy: (MIBaseCategory*) category;
- (void) selectCategory;

- (void) hideExpand;


@end
