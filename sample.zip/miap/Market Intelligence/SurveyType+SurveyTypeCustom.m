//
//  SurveyType+SurveyTypeCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyType+SurveyTypeCustom.h"

@implementation SurveyType (SurveyTypeCustom)
- (void)addSuperCategoryListObject:(SuperCategory *)value
{
    // Create a mutable set with the existing objects, add the new object, and set the relationship equal to this new mutable ordered set
    NSMutableOrderedSet *superCategoryList = [[NSMutableOrderedSet alloc] initWithOrderedSet:self.superCategoryList];
    [superCategoryList addObject:value];
    self.superCategoryList = superCategoryList;
    
}
@end
