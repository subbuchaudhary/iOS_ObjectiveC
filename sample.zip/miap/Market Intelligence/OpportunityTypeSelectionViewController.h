//
//  OpportunityTypeSelectionViewController.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/14/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "FSGBaseViewController.h"
#import "OpportunitySelectionRowView.h"
#import "SuperCategory.h"
#import "AppDelegate.h"
#import "CategoryViewController.h"
#import "ViewController.h"
#import "FSGBaseViewController.h"

@interface OpportunityTypeSelectionViewController : FSGBaseViewController
{
    AppDelegate* appDelegate ;
}
@property (strong, nonatomic) IBOutlet UIView *container;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *retentionView;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *flooringView;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *creditView;
@property (strong, nonatomic) IBOutlet OpportunitySelectionRowView *experienceView;
@property NSUInteger selectedOpportunityType;
@property (weak) MIComments* comment;


@property (weak, nonatomic) ViewController *delegate;

- (IBAction)opportunityRowSelected:(UITapGestureRecognizer *)sender;

enum {
    RETENTION_VIEW_TAG = 1,
    FLOORING_VIEW_TAG = 2,
    CREDIT_VIEW_TAG = 3,
    EXPERIENCE_VIEW_TAG = 4
};

////MI_V_1.0
@property(nonatomic,strong)NSMutableArray *arrSuperCategory;
@end
