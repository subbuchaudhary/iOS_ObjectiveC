//
//  AppDelegate.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MISurvey.h"
#import "MIFSR.h"
#import "SurveyUtil.h"
#import "FSR.h"
//#import <GD/GDiOS.h>
//MI_V_1.0
#import "MIConstant.h"
@class SurveyUtil;
@class ServiceController;
@interface AppDelegate : UIApplication <UIApplicationDelegate>
{
    NSTimer* idleTimer;
    NSDate* backgroundTimeStamp;
    BOOL started;
    ServiceController *serviceController;

}

@property (strong, nonatomic) UIWindow *window;
//@property (nonatomic, assign) GDiOS *good;



@property (strong, retain) NSDictionary *applicationConfig;

@property (strong, retain) NSManagedObjectContext* moc;
@property (strong, retain) NSManagedObjectModel* miModel;

@property(nonatomic,retain) MISurvey* currentSurvey;

-(void) loginSuccessful;

- (NSString*) configFor:(NSString*) configKey;
-(NSArray*) getProvidersForService:(NSString*)serviceId;
//-(void) onAuthorized:(GDAppEvent*)anEvent;
//-(void) onNotAuthorized:(GDAppEvent*)anEvent;


@property (strong, retain) FSR *fsr;
@property(strong,retain)SurveyUtil *surveyUtil;

//MI_V_1.0
@property (strong, retain) MIFSR *miFsr;
@property(strong,retain)MISurveyManager *miSurveyUtil;

@end
