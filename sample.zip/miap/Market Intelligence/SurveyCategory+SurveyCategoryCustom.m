//
//  SurveyCategory+SurveyCategoryCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyCategory+SurveyCategoryCustom.h"

@implementation SurveyCategory (SurveyCategoryCustom)

- (void)addCategoryListObject:(SubCategory *)value
{
    // Create a mutable set with the existing objects, add the new object, and set the relationship equal to this new mutable ordered set
    NSMutableOrderedSet *subCategoriesList = [[NSMutableOrderedSet alloc] initWithOrderedSet:self.categoryList];
    [subCategoriesList addObject:value];
    self.categoryList = subCategoriesList;
}
@end
