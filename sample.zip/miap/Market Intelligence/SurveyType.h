//
//  SurveyType.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "BaseCategory.h"

@class SuperCategory;

@interface SurveyType : BaseCategory

@property (nonatomic, retain) NSOrderedSet *superCategoryList;
@end

@interface SurveyType (CoreDataGeneratedAccessors)

- (void)insertObject:(SuperCategory *)value inSuperCategoryListAtIndex:(NSUInteger)idx;
- (void)removeObjectFromSuperCategoryListAtIndex:(NSUInteger)idx;
- (void)insertSuperCategoryList:(NSArray *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeSuperCategoryListAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInSuperCategoryListAtIndex:(NSUInteger)idx withObject:(SuperCategory *)value;
- (void)replaceSuperCategoryListAtIndexes:(NSIndexSet *)indexes withSuperCategoryList:(NSArray *)values;
- (void)addSuperCategoryListObject:(SuperCategory *)value;
- (void)removeSuperCategoryListObject:(SuperCategory *)value;
- (void)addSuperCategoryList:(NSOrderedSet *)values;
- (void)removeSuperCategoryList:(NSOrderedSet *)values;
@end
