//
//  AddCommentCell.h
//  Market Intelligence
//
//  Created by Jeff on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddCommentCell : UITableViewCell

@property SEL addComment;
@property id delegate;

@property (strong, nonatomic) IBOutlet UIView *container;
-(IBAction)addCommentClicked:(id)sender;

@end
