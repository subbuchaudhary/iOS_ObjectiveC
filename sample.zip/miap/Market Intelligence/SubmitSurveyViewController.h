//
//  SubmitSurveyViewController.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu Manuru on 1/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SurveySubmissionService.h"
#import "ViewController.h"
#import "FSGBaseViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface SubmitSurveyViewController : FSGBaseViewController <SubmitSurveyResponseReceiver>

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UILabel *statusMessage;
@property (weak, nonatomic) IBOutlet UILabel *nextStepMessage;
@property (weak, nonatomic) IBOutlet UILabel *sendingStatusMessage;
@property (weak, nonatomic) IBOutlet UIButton *continueButton;
@property (weak, nonatomic) IBOutlet UIButton *logoutButton;
@property (strong, nonatomic) AVAudioPlayer *userAlertSound;
- (IBAction)clicked:(UIButton *)sender;

@property ViewController* commentViewController;

@end