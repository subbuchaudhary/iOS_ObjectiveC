//
//  NoAnimationSegue.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/27/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoAnimationSegue : UIStoryboardSegue

@end
