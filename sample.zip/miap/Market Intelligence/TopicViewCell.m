//
//  TopicViewCell.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "TopicViewCell.h"

#import "MITopic.h"

@implementation TopicViewCell

- (void) configureWithHierarchy:(MIBaseCategory *)category
{
    [super configureWithHierarchy:category];
    MITopic* surveyTopic = (MITopic*) category;
    _objectName.text = surveyTopic.topicName;
    [_objectName setFont:[UIFont fontWithName:@"GEInspira" size:13]];
    _expand.hidden = YES;
    
    UIEdgeInsets insets;
    insets.left = 60;
    self.separatorInset = insets;
    self.contentView.backgroundColor = [UIColor clearColor];

    
}
- (void) prepareForReuse
{
    _collapse.hidden = YES;
    _expand.hidden = YES;
    
    _checkboxOn.hidden = YES;
    _checkboxOff.hidden = NO;
    
}

- (void) selectCategory
{
    _checkboxOn.hidden = NO;
    _checkboxOff.hidden = YES;
}

- (IBAction) expandClicked:(UIButton *)sender
{
    [self.parentController expandClickedOnCell:self];
    
}

- (IBAction)checkboxSelected:(UIButton *)sender {
    
    if ([sender isEqual:_checkboxOn])
    {
        _checkboxOn.hidden = YES;
        _checkboxOff.hidden = NO;
        [self.parentController unselectObject:self.dataObject];
    }
    else
    {
        _checkboxOn.hidden = NO;
        _checkboxOff.hidden = YES;
        [self.parentController selectObject:self.dataObject];
        
    }
}

- (void) hideExpand
{
    _expand.hidden = YES;
    _collapse.hidden = NO;
}


@end
