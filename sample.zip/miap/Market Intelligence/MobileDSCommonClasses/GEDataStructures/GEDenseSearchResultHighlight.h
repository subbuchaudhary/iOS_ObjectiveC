//
//  GEDenseSearchResultHighlight.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import <UIKit/UIKit.h>

typedef enum {
    kCellLocationOrigin,
    kCellLocationColumnHeader,
    kCellLocationRowHeader,
    kCellLocationContentScrollView

}CellLocation;

@interface GEDenseSearchResultHighlight : UIView

@property (nonatomic)CellLocation cellLocation;

- (id)initWithFrame:(CGRect)frame andContents:(NSString*)contentString;

@end
