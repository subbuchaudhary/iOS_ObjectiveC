//
//  GEDenseColumnHeaderView.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseColumnHeaderView.h"

@implementation GEDenseColumnHeaderView{
    UIImage *sortStateNoneImage;
    UIImage *sortStateASCImage;
    UIImage *sortStateDESCImage;
    float rowHeight;
    UIView *selectedBackground;
}

@synthesize isSorted = _isSorted;
@synthesize isSelected = _isSelected;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithframe:(CGRect)frame DataColumnTitle:(GEDenseCell*)columnHeaderCell{

    self = [super initWithFrame:frame];
    
    if(self){
        NSInteger headerFontSize;
        float cellWidthPadding;
        float sortButtonPaddingTop;
        
        float imageMargin;
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
        {
            headerFontSize = 16;
            cellWidthPadding = 40;
            sortButtonPaddingTop = 8;
            sortStateNoneImage = [UIImage imageNamed:@"GEDenseData_iPad_SortIndicator.png"];
            sortStateASCImage = [UIImage imageNamed:@"GEDenseData_iPad_SortArrowDown.png"];
            sortStateDESCImage = [UIImage imageNamed:@"GEDenseData_iPad_SortArrowUp.png"];
            rowHeight = 37;

            imageMargin = 7;
        }else{
            headerFontSize = 12;
            cellWidthPadding = 30;
            sortButtonPaddingTop = 8;
            
            sortStateNoneImage = [UIImage imageNamed:@"GEDenseData_iPhone_SortIndicator.png"];
            sortStateASCImage = [UIImage imageNamed:@"GEDenseData_iPhone_SortArrowDown.png"];
            sortStateDESCImage = [UIImage imageNamed:@"GEDenseData_iPhone_SortArrowUp.png"];
            rowHeight = 24;
            imageMargin = 4;
        }
       
        
        GELabel *tempLabel = [[GELabel alloc] initWithFont:GE_Inspira_Bold Size:headerFontSize andColor:GE_COLOR_BLUE_DARK];
        //get column headers and set position
        

        NSString *text = columnHeaderCell.title;
        float labelWidth = [self widthOfCellFromText:text Label:tempLabel] + cellWidthPadding;

        tempLabel.frame = CGRectMake(0, 0, labelWidth, rowHeight);
        tempLabel.textAlignment = NSTextAlignmentLeft;
        tempLabel.text = text;
        
        selectedBackground = [[UIView alloc]initWithFrame:CGRectMake(0, sortButtonPaddingTop - 4, self.frame.size.width, self.frame.size.height)];
        selectedBackground.backgroundColor = GE_COLOR_WHITE;
        selectedBackground.alpha = 0.0;
        [self addSubview:selectedBackground];
        
        self.selectionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        self.selectionButton.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
        [self.selectionButton setTitleColor:GE_COLOR_BLUE_DARK forState:UIControlStateNormal];
        [self.selectionButton setTitle:columnHeaderCell.title forState:UIControlStateNormal];
        self.selectionButton.titleLabel.font = tempLabel.font;
        self.selectionButton.titleLabel.textAlignment = NSTextAlignmentCenter;
        //[self.selectionButton addTarget:self action:@selector(toggleSortSelection) forControlEvents:UIControlEventTouchUpInside];
        
        
        //calculate text size to place sort indicators
        
        CGSize textSize = [text sizeWithFont:tempLabel.font];
        self.selectionButton.imageEdgeInsets = UIEdgeInsetsMake(0.0, textSize.width + imageMargin, 0.0, -textSize.width -imageMargin);
        
        
        [self addSubview:self.selectionButton];
        
        
        self.sortButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.sortButton.frame = CGRectMake(0, sortButtonPaddingTop, self.frame.size.width, self.frame.size.height);
        self.sortButton.titleLabel.font = tempLabel.font;
        [self.sortButton setTitleColor:GE_COLOR_BLUE_DARK forState:UIControlStateNormal];
        [self.sortButton setTitle:columnHeaderCell.title forState:UIControlStateNormal];
        [self.sortButton setImage:sortStateNoneImage forState:UIControlStateNormal];
    
        
        self.sortButton.imageEdgeInsets = UIEdgeInsetsMake(-sortButtonPaddingTop, textSize.width + imageMargin, sortButtonPaddingTop, -(textSize.width + imageMargin) );
        
        self.sortButton.alpha = 0.0;
        
        self.sortButton.titleEdgeInsets = UIEdgeInsetsMake(-sortButtonPaddingTop, -8.0, sortButtonPaddingTop, 8.0);
        [self addSubview:self.sortButton];
        
        

    
    }
    return self;

}

-(void)setIsSelected:(BOOL)__isSelected
{

    _isSelected = __isSelected;
    if(_isSelected){
        selectedBackground.alpha = 1.0;
    }else{
        selectedBackground.alpha = 0.0;

    }
    
}
    
-(void)setIsSorted:(BOOL)__isSorted
{

    _isSorted = __isSorted;
    
    if (_isSorted) {
        self.selectionButton.titleEdgeInsets = UIEdgeInsetsMake(0.0, -8.0, 0.0, 0.0);
    }else{
        [self.selectionButton setImage:sortStateNoneImage forState:UIControlStateNormal];
        self.selectionButton.titleEdgeInsets = UIEdgeInsetsZero;
    }
    
    
}

-(void)setCurrentSortState:(SortState)css
{

     if(css == kSortStateColumnASC){

         [self.selectionButton setImage:sortStateDESCImage forState:UIControlStateNormal];
         [self.sortButton setImage:sortStateDESCImage forState:UIControlStateNormal];

    }else if(css == kSortStateColumnDESC){
       
        [self.selectionButton setImage:sortStateASCImage forState:UIControlStateNormal];
        [self.sortButton setImage:sortStateASCImage forState:UIControlStateNormal];
    }else{
        [self.sortButton setImage:sortStateNoneImage forState:UIControlStateNormal];
    }



}

- (float)widthOfCellFromText:(NSString *)text Label:(GELabel *)label
{
    CGSize maximumSize = CGSizeMake(9999, rowHeight+1);
    CGSize myStringSize = [text sizeWithFont:label.font
                           constrainedToSize:maximumSize
                               lineBreakMode:label.lineBreakMode];
    
    return myStringSize.width;
}


-(void)toggleSortSelection
{
    if (self.sortButton.alpha == 1.0) {
        self.selectionButton.alpha = 1.0;
        self.sortButton.alpha = 0.0;
    }else{
        self.selectionButton.alpha = 0.0;
        self.sortButton.alpha = 1.0;
    }

}


@end
