//
//  GEDenseRow.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseRow.h"
#import "GEDenseCell.h"


/*
 * GEDenseRow Implementation methods
 */
@implementation GEDenseRow

- (id)initWithTitle:(NSString *)title Cells:(NSArray *)cellArray
{
    self = [super init];
    
    if (self) {
        self.header = [[GEDenseCell alloc]initWithTitle:title Type:GECell_RowHeader Alert:NO];
        self.cellArray = cellArray;
    }
    
    return self;
}

@end