//
//  GEDenseSelectionView.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import <UIKit/UIKit.h>
#import "GEColor.h"
#import <QuartzCore/QuartzCore.h>


@protocol GEDenseSelectionDelegate;



typedef enum {
   GESelectionTypeRow,
    GESelectionTypeColumn,
    GESelectionTypeCell
}GESelectionType;

@interface GEDenseSelectionView : UIView


@property (nonatomic,weak)id<GEDenseSelectionDelegate>delegate;
@property (nonatomic,strong)UIButton *selectedSortButton;
@property (nonatomic, strong)UIView *selectionMask;
@property (nonatomic) CGRect frameBeforeDrag;
@property (nonatomic, strong) UIView* outline;


-(id) initWithFrame:(CGRect)frame andSelectionType:(GESelectionType)type;
-(void)snapToNewFrame:(CGRect)newFrame;

@end

@protocol GEDenseSelectionDelegate <NSObject>

@optional

-(void)GEDenseSelector:(GEDenseSelectionView*)selectionView didRecieveTapAtPointinSuperView:(CGPoint)touchPoint;
-(void)GEDenseSelector:(GEDenseSelectionView *)selectionView didRecieveLongPressAtPointinSuperView:(CGPoint)touchPoint;
-(void)GEDenseSelector:(GEDenseSelectionView *)selectionView didRecieveDragEvent:(id)event;

@end