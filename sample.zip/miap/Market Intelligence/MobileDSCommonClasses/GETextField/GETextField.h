//
//  GETextField.h
//  MobileDS
//
//  Created on 5/15/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import <UIKit/UIKit.h>
#import "GEColor.h"
#import "GELabel.h"

/*
typedef NS_ENUM(NSInteger, GEText_Font) {
    GE_Inspira,
    GE_Inspira_Medium,
    GE_Inspira_Bold,
    GE_Inspira_Ext_Bold,
    Lucida_Grand,
    Lucida_Grand_Bold
};

*/


@interface GETextField : UITextField

@property (nonatomic) NSInteger fontSize;


-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color;

-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andFrame:(CGRect)frame;

-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andPlaceholder:(NSString *)placeholder;

-(id)initWithFrame:(CGRect)frame Font:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andPlaceholder:(NSString *)placeholderText;


@end
