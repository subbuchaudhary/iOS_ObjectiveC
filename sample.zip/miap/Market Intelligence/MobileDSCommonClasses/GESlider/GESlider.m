//
//  GESlider.m
//  GESlider
//
//  Created  on 10/3/12.
//  Copyright (c) 2012 Eric Cerney. All rights reserved.
//

#import "GESlider.h"
#import "GEColor.h"
#import "GELabel.h"

@interface GESlider ()
{
    CGFloat lastWidth;
}
@property (nonatomic, assign, readonly) float sliderRange;
@property (nonatomic, strong) NSArray *titlesArr;
@property (nonatomic, assign, readonly) float oneSlotSize;

@end

@implementation GESlider

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    [self resetTitleLabels];
}

- (float)sliderRange
{
    return self.frame.size.width - self.currentThumbImage.size.width;
}

- (float)oneSlotSize
{
    if (self.titlesArr.count > 1) {
        return self.sliderRange/self.maximumValue;
    }
    else {
        return 0;
    }
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];

    if (self) {
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
    }
    
    return self;
}

- (void)resetTitleLabels
{
    if (lastWidth != self.bounds.size.width) {
    for (int i = 0; i < self.titlesArr.count; i++) {
        [[self viewWithTag:i+50] removeFromSuperview];
    }
    
    for (int i = 0; i < self.titlesArr.count; i++) {
        NSString *title = [self.titlesArr objectAtIndex:i];
        GELabel *lbl = [[GELabel alloc] initWithFrame:CGRectMake(0, 0, self.oneSlotSize, 15) Font:Lucida_Grand Size:10 andColor:GE_COLOR_GRAY_3];
        [lbl setText:title];
        [lbl setLineBreakMode:NSLineBreakByTruncatingTail];
        [lbl setAdjustsFontSizeToFitWidth:YES];
        [lbl setMinimumScaleFactor:8];
        [lbl setTextAlignment:NSTextAlignmentCenter];
        [lbl setBackgroundColor:[UIColor clearColor]];
        [lbl setTag:i+50];
        
        
        if (self.frame.size.height <= self.currentThumbImage.size.height) { // If initing too small or from nib/storyboard
            [lbl setCenter:CGPointMake([self xPositionFromSliderValue:i], self.currentThumbImage.size.height + 10)];
        }
        else { // Else large enough to calculate correctly
            [lbl setCenter:CGPointMake([self xPositionFromSliderValue:i], self.bounds.size.height/2 + self.currentThumbImage.size.height/2 + 10)];
        }
        
        [self addSubview:lbl];
    }
        lastWidth = self.bounds.size.width;
    }
}

- (void)initWithTitles:(NSArray *)titles
{
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.titlesArr = [[NSArray alloc] initWithArray:titles];
        
        self.minimumValue = 0;
        self.maximumValue = self.titlesArr.count-1;
        
        UIImage *sliderLeftTrackImage = [[UIImage imageNamed: @"Forms_Slider_Track_Left.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0];
        UIImage *sliderRightTrackImage = [[UIImage imageNamed: @"Slider_Track.png"] stretchableImageWithLeftCapWidth:0 topCapHeight: 0];
        UIImage *thumbImage = [UIImage imageNamed:@"Slider_Switch_On.png"];
        
        
        [self setMinimumTrackImage: sliderLeftTrackImage forState: UIControlStateNormal];
        [self setMaximumTrackImage:sliderRightTrackImage forState: UIControlStateNormal];
        [self setThumbImage:thumbImage forState:UIControlStateNormal];
        [self setThumbImage:thumbImage forState:UIControlStateHighlighted];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(sliderTapped:)];
        [self addGestureRecognizer:tap];
        
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    }
}

- (id)initWithFrame:(CGRect)frame Titles:(NSArray *)titles
{
    self = [super initWithFrame:frame];
    
    if (self) {
        [self initWithTitles:titles];
    }
    
    return self;
}

- (void)initWithTitles:(NSArray *)titles LeftImage:(UIImage *)leftImage RightImage:(UIImage *)rightImage
{
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.titlesArr = [[NSArray alloc] initWithArray:titles];
        
        UIImage *sliderLeftTrackImage = [[UIImage imageNamed: @"Forms_Slider_Track_Left.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0];
        UIImage *sliderRightTrackImage = [[UIImage imageNamed: @"Slider_Track.png"] stretchableImageWithLeftCapWidth:0 topCapHeight: 0];
        UIImage *thumbImage = [UIImage imageNamed:@"Slider_Switch_On.png"];
        
        
        [self setMinimumTrackImage: sliderLeftTrackImage forState: UIControlStateNormal];
        [self setMaximumTrackImage: sliderRightTrackImage forState: UIControlStateNormal];
        [self setThumbImage:thumbImage forState:UIControlStateNormal];
        [self setThumbImage:thumbImage forState:UIControlStateHighlighted];
        
        self.minimumValue = 0;

        if (self.titlesArr.count > 1) {
            self.maximumValue = self.titlesArr.count-1;
            
        }   
        else {
            self.maximumValue = 1;
        }
    
        
        self.minimumValueImage = leftImage;
        self.maximumValueImage = rightImage;
    
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(sliderTapped:)];
        [self addGestureRecognizer:tap];
    }
}

- (id)initWithFrame:(CGRect)frame Titles:(NSArray *)titles LeftImage:(UIImage *)leftImage RightImage:(UIImage *)rightImage
{
    self = [super initWithFrame:frame];
    
    if (self) {
        [self initWithTitles:titles LeftImage:leftImage RightImage:rightImage];
    }
    
    return self;
}


#pragma mark - Helper Methods

- (float)xPositionFromSliderValue:(int)index
{
    float sliderOrigin = self.bounds.origin.x + (self.currentThumbImage.size.width / 2.0);
    float sliderValueToPixels = (index * self.oneSlotSize) + sliderOrigin;
    
    return sliderValueToPixels;
}

- (int)getSelectedIndexAtPoint:(CGPoint)pnt
{    
    float sliderOrigin = self.bounds.origin.x + (self.currentThumbImage.size.width / 2.0);
    
    float index = (pnt.x-sliderOrigin)/self.oneSlotSize;
    
    return round(index);
}


#pragma mark - Tracking and Gesture

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event
{
    [super endTrackingWithTouch:touch withEvent:event];
    
    if (self.oneSlotSize > 0) {
        CGPoint currentLocation  = [touch locationInView:self];
        
        int selectedIndex = [self getSelectedIndexAtPoint:currentLocation];
        
        [self animateHandlerToIndex:selectedIndex];
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
}

- (void)sliderTapped:(UIGestureRecognizer *)tap
{
    int selectedIndex;
    
    if (self.oneSlotSize > 0) {
        if (self.highlighted) {
            selectedIndex = round(self.value);
            //return; // tap on thumb, let slider deal with it
        }
        else {
            CGPoint pt = [tap locationInView:self];
            selectedIndex = [self getSelectedIndexAtPoint:pt];
        }
        
        [self animateHandlerToIndex:selectedIndex];
    }
}

#pragma mark - Animation Methods

- (void)animateHandlerToIndex:(int)index
{
    [self setValue:index animated:YES];
}

-(void)setSliderType:(GESliderType)sliderType{

    _sliderType = sliderType;
    
    switch (sliderType) {
        case GESliderTypeForms:{
            UIImage *sliderLeftTrackImage = [[UIImage imageNamed: @"Forms_Slider_Track_Left.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0];
            [self setMinimumTrackImage: sliderLeftTrackImage forState: UIControlStateNormal];
        
        }
            break;
        case GESliderTypeSettings:{
            UIImage *sliderLeftTrackImage = [[UIImage imageNamed: @"Settings_Slider_Track_Left.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0];
            [self setMinimumTrackImage: sliderLeftTrackImage forState: UIControlStateNormal];
            
        }
            break;
        
            
        default:
            
            
            
            break;
    }


}

@end
