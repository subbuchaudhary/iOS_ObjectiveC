//
//  GEViewController.h
//  MobileDesignSystem
//
//  Created  on 10/5/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "GEColor.h"
#import "GELabel.h"
#import "GEButton.h"
#import "GENavigationBar.h"

@interface GEViewController : UIViewController

@property (strong, nonatomic) AppDelegate *appDelegate;
@property (nonatomic, assign) BOOL shouldHideGELabel;
@end
