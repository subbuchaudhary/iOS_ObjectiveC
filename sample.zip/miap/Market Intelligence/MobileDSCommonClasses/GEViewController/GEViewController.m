//
//  GEViewController.m
//  MobileDesignSystem
//
//  Created  on 10/5/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//
// Contains all depencies for GE Mobile Applications


#import "GEViewController.h"


@interface GEViewController (){

    
}

@end

@implementation GEViewController
@synthesize appDelegate;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //hides for 
    self.navigationController.navigationItem.titleView.hidden = YES;
    self.navigationItem.hidesBackButton = YES;


    

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
      self.title = @"";
    GENavigationBar *bar = (GENavigationBar*)self.navigationController.navigationBar;
    if(bar){
        if(self.navigationController.viewControllers.count > 1){
            [bar hideFlag];
        }
        else {
            [bar hideBackButton:self.shouldHideGELabel];
            
        }
    }

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];

    GENavigationBar *bar = (GENavigationBar*)self.navigationController.navigationBar;
    self.navigationController.navigationItem.hidesBackButton = YES;

    if (bar){
        if (self.navigationController.viewControllers.count > 1) {
            [bar revealBackButton];
            [bar.backButton addTarget:self action:@selector(popVC) forControlEvents:UIControlEventTouchUpInside];
            
              self.navigationController.navigationItem.hidesBackButton = YES;
            
            
        }
        else {
            [bar hideBackButton:self.shouldHideGELabel];
            self.navigationController.navigationItem.hidesBackButton = YES;
        }
        self.navigationController.navigationItem.hidesBackButton = YES;
        bar.vcTitleLabel.hidden = NO;
    }
   
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    GENavigationBar *bar = (GENavigationBar*)self.navigationController.navigationBar;
    
    if(bar){
        
        bar.vcTitleLabel.hidden = YES;
   
        if ([[UIDevice currentDevice] userInterfaceIdiom] ==  UIUserInterfaceIdiomPhone) {
            self.title = bar.vcTitle;
        }
       
        
    if(self.navigationController.viewControllers.count == 1){
        [bar showFlag];

        [bar hideBackButton:self.shouldHideGELabel];
    }
        
    }else{
        self.title = @"";
    }
    

}


-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:YES];
    GENavigationBar *bar = (GENavigationBar*)self.navigationController.navigationBar;
    
    if(bar){
           
        
    }

}


-(void)popVC{
  
    if(self.navigationController.viewControllers.count > 1){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
