//
//  GELabel.h
//  MobileDesignSystem
//
//  Created  on 10/5/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import <UIKit/UIKit.h>
#import "GEColor.h"

typedef NS_ENUM(NSInteger, GELabel_Font) {
    GE_Inspira,
    GE_Inspira_Medium,
    GE_Inspira_Bold,
    GE_Inspira_Ext_Bold,
    Lucida_Grand,
    Lucida_Grand_Bold
};



@interface GELabel : UILabel



@property (nonatomic) GELabel_Font GE_Font;



-(id)initWithFrame:(CGRect)frame Font:(GELabel_Font) GE_Font Size:(int)FontSize andColor:(UIColor*)Color;

-(id)initWithFont:(GELabel_Font) GE_Font Size:(int)FontSize andColor:(UIColor*)Color;
- (id)initWithFrame:(CGRect)frame AttributedString:(NSAttributedString *)string;

@end
