//
//  Survey+SurveyCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "Survey.h"

@interface Survey (SurveyCustom)
- (void)addCommentListObject:(Comment *)value;
- (void) prepareForSubmit;

- (void) encryptWithKey:(NSString*) key;
- (void) decryptWithKey:(NSString*) key;

- (int) numberOfUnsentMessages;
@end
