//
//  MISurvey.h
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MISurvey : NSObject
@property (nonatomic, strong) NSString * surveyID;
@property(nonatomic,strong)NSString* commentIds;
@property (nonatomic, strong) NSMutableOrderedSet *commentList;
-(void)getSurveyComments;
-(void)clearSurveyTable;
-(void)getCurrentSurveyComments;
@end
