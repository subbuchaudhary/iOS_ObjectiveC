//
//  SubmitSurveyViewController.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu Manuru on 1/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SubmitSurveyViewController.h"
#import "AppDelegate.h"
#import "LoginViewController.h"
#import "SurveySubmissionService.h"
#import "Survey+SurveyCustom.h"

@interface SubmitSurveyViewController ()

@end

@implementation SubmitSurveyViewController
@synthesize commentViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.activityIndicator.hidden = NO;
    [self.activityIndicator startAnimating];
    self.continueButton.hidden = YES;
    self.logoutButton.hidden = YES;
    self.navigationItem.hidesBackButton = YES;
    
    // Do any additional setup after loading the view from its nib.
}

-(void) viewDidAppear:(BOOL)animated
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    SurveySubmissionService* submitService = [[SurveySubmissionService alloc] initWithDelegate:self];
    [submitService submitSurvey:appDelegate.currentSurvey];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) receiveSubmitStatus:(SubmitStatus)status
{
    [self.activityIndicator stopAnimating];
    self.activityIndicator.hidden = YES;
    
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    switch (status)
    {
        case LOCAL_SAVE:{
            NSError *error;
            NSString *saveNotSendSoundPath = [[NSBundle mainBundle] pathForResource:@"SaveNotSent" ofType:@"aiff"];
            NSURL *saveNotSendSoundURL = [NSURL fileURLWithPath:saveNotSendSoundPath];
            _userAlertSound = [[AVAudioPlayer alloc] initWithContentsOfURL:saveNotSendSoundURL error:&error];
            [_userAlertSound play];
            self.sendingStatusMessage.textColor = GE_COLOR_RED_LIGHT ;
            self.sendingStatusMessage.text = @"Your message has been saved. Please try sending again when you are connected.";
            self.nextStepMessage.text = @"What would you like to do next ?";
            
            [UIApplication sharedApplication].applicationIconBadgeNumber = [appDelegate.currentSurvey numberOfUnsentMessages];
        }
            break;
        case SF_SEND_SUCCESS:{
            NSError *error;
            NSString *sentSoundPath = [[NSBundle mainBundle] pathForResource:@"sent" ofType:@"aiff"];
            NSURL *sentSoundURL = [NSURL fileURLWithPath:sentSoundPath];
            _userAlertSound = [[AVAudioPlayer alloc] initWithContentsOfURL:sentSoundURL error:&error];
            [_userAlertSound play];
            self.sendingStatusMessage.textColor = [UIColor whiteColor];
            self.sendingStatusMessage.text = @"Your message has been sent.";
            self.nextStepMessage.text = @"What would you like to do next ?";
            [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
        }
            break;
    }
    
    self.continueButton.hidden = NO;
    self.logoutButton.hidden = NO;
    
    
}

- (IBAction)clicked:(UIButton *)sender {
    
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    if (sender == self.logoutButton)
    {
        [appDelegate.miSurveyUtil loadSurvey];
        LoginViewController* loginController =[[LoginViewController alloc] initWithNibName:nil bundle:nil callback:nil];
        //self.viewController = loginController;
        [appDelegate.window setRootViewController:loginController];
        
    }
    else
    {
        [appDelegate.miSurveyUtil loadSurvey];
        [commentViewController initComments];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}
@end
