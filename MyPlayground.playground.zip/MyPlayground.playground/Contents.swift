var an="c"
an.isEmpty
CountableRange 5
