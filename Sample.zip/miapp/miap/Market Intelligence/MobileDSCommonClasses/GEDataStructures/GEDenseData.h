//
//  GEDenseData.h
//  MobileDesignSystem
//
//  Created  on 11/6/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//

#import <Foundation/Foundation.h>
#import "GEDenseCell.h"
#import "GEDenseRow.h"

/*
 * GEDenseData is the top level container for
 * data to display in a Dense Tabular View
 */
@interface GEDenseData : NSObject

@property (nonatomic, strong) NSArray *columnTitlesArray;
@property (nonatomic, strong) NSArray *rowArray;

- (id)initWithColumnTitles:(NSArray *)titles Rows:(NSArray *)rows;

-(NSMutableArray *)searchDataForString:(NSString*)string;


-(void)givePositionInfo;

@end