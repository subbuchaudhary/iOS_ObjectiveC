//
//  GEDenseColumnHeaderView.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import <UIKit/UIKit.h>
#import "GEDenseCell.h"
#import "GELabel.h"

typedef enum {
    
    kSortStateNone,
    kSortStateColumnSelected,
    kSortStateColumnASC,
    kSortStateColumnDESC
    
    
}SortState;


@interface GEDenseColumnHeaderView : UIView

@property (nonatomic, strong) UIButton *selectionButton;
@property (nonatomic, strong)UIButton *sortButton;
@property (nonatomic)NSInteger row;
@property (nonatomic)NSInteger column;
@property (nonatomic)SortState currentSortState;
@property (nonatomic)BOOL isSelected;
@property (nonatomic)BOOL isSorted;


-(id)initWithframe:(CGRect)frame DataColumnTitle:(GEDenseCell*)columnHeaderCell;

-(void)toggleSortSelection;


@end
