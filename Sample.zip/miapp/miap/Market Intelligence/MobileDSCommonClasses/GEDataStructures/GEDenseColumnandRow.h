//
//  GEDenseColumnandRow.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import <Foundation/Foundation.h>

@interface GEDenseColumnandRow : NSObject;

@property int column;
@property int row;

- (id)initWithColumn:(int)column andRow:(int)row;
- (BOOL)isEqual:(GEDenseColumnandRow*)coord;

@end
