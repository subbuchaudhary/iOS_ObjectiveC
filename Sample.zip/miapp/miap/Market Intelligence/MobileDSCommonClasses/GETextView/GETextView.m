//
//  GETextView.m
//  MobileDS
//
//  Created on 5/24/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import "GETextView.h"

@implementation GETextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color
{
    self = [super init];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        
        self.textColor = Color;
        self.fontSize = fontSize;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}


-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.frame = frame;
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}



-(id)initWithFrame:(CGRect)frame Font:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andPlaceholder:(NSString *)placeholderText
{
    self = [super initWithFrame:frame];
   
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color andPlaceholder:(NSString *)placeholderText
{
    self = [super init];
    
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
