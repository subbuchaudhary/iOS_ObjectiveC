//
//  DealerSummaryEntity+DealerSummaryCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/6/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "MIDealerSummary+DealerSummaryCustom.h"

#import "NSString+AESCrypt.h"

@implementation MIDealerSummary (DealerSummaryCustom)


/*- (void) copyFromDealer: (MIDealerList*) dealer
{
    self.customerName = dealer.customerName;
    self.customerNumber = dealer.customerNo;
    self.branchNo = dealer.branchNo;
    self.vbu = dealer.vbu;
    self.isValidated = @YES ;
    self.addedManually = @NO;
}

- (BOOL) isEqualToDealer:(MIDealerList *)aDealer
{
    BOOL result = NO;
    if (([aDealer.customerNo isEqualToString:self.customerNumber])
            && ([aDealer.branchNo isEqualToString:self.branchNo]))
            result = YES;

    return result;
}

-(NSDictionary*) asDictionary
{
    NSMutableDictionary* asDict = [[NSMutableDictionary alloc] init];
    
    [asDict setObject:self.customerNumber forKey:@"CustomerNumber"];
    [asDict setObject:self.branchNo forKey:@"BranchNumber"];
    [asDict setObject:self.vbu forKey:@"VBU"];
    
    return  asDict;
}

- (void) encryptWithKey:(NSString*) key
{
    self.customerName = [self.customerName AES256EncryptWithKey:key];
    self.customerNumber = [self.customerNumber AES256EncryptWithKey:key];
    self.branchNo = [self.branchNo AES256EncryptWithKey:key];
    self.vbu = [self.vbu AES256EncryptWithKey:key];
}

-(void) decryptWithKey:(NSString*) key
{
    self.customerName = [self.customerName AES256DecryptWithKey:key];
    self.customerNumber = [self.customerNumber AES256DecryptWithKey:key];
    self.branchNo = [self.branchNo AES256DecryptWithKey:key];
    self.vbu = [self.vbu AES256DecryptWithKey:key];
    
}*/

@end
