//
//  MISurvey.m
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import "MISurvey.h"

@implementation MISurvey

-(void)fetchCurrencySurveyData
{
    
}
@end
