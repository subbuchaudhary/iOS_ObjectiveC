//
//  MIConstant.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#ifndef MIConstant_h
#define MIConstant_h
#import "MISurveyManager.h"
#import "MISurveyType.h"
#import "MIFSR.h"
#import "MIFSR+FSRCustom.h"
#import "MIDBManager.h"
#import "MITopic.h"
#import "MIDealerList.h"
#import "MIDealerList+MI_DealerCustom.h"
#import "MIDealerSummary.h"
#import "MISuperCategory.h"
#import "MICategory.h"
#import "MISubCategory.h"
#import "MIDealerList.h"

#import "MISurvey.h"
#import "MISurvey+SurveyCustom.h"
#import "MIDealerSummary.h"
#import "MIComments.h"
#import "MIComments+MICommentCustom.h"

#import "MITopic.h"

#import "MIBaseCategory.h"
#import "MIBaseCategory+MIBaseCategoryCustom.h"

#define  SURVEY_ID  @"surveyId"
#define SUPERCATEGORY_ID @"superCategroyId"
#define SUBCATEGORY_ID @"subCategoryId"
#define CATEGORY_ID  @"categoryId"
#define TYPE_NAME @"name"
#define TYPE_ID @"id"

//Database table name
#define TABLE_FSR @"MI_FSR"
#define TABLE_SURVEYTAPE @"MI_SurveyType"
#define TABLE_SUPERCATEGORY @"MI_SuperCategory"
#define TABLE_CATEGORY @"MI_Category"
#define TABLE_SUBCATEGORY @"MI_SubCategory"
#define TABLE_TOPIC @"MI_Topic"
#define TABLE_DEALER @"MI_Dealer"
#define TABLE_DEALERSUMMERY @"MI_DealerSummery"
#define TABLE_COMMENTS @"MI_Comments"
#define TABLE_FSR @"MI_FSR"
#define TABLE_CURRENT_SURVEY @"MI_Survey"
#endif /* MIConstant_h */


