//
//  MISuperCategory.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MIBaseCategory.h"
#import "MISurveyType.h"
@interface MISuperCategory : MIBaseCategory
@property(nonatomic,strong)NSNumber *surveyId;
@property(nonatomic,strong)NSNumber *superCatId;
@property(nonatomic,strong)NSString *superCatName;

@property(nonatomic,strong)NSSet *categorylist;
-(MISurveyType*)getSurveyType;
-(NSMutableArray*)getCategoryList;

@end
