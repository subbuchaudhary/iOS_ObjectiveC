//
//  SurveyRequest.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/24/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyRequest.h"
#import "FSR+FSRCustom.h"
#import "AppDelegate.h"

@implementation SurveyRequest



+ (NSString*) asJSONForSurvey: (Survey*) survey withFSR: (FSR*) fsr
{
    NSMutableDictionary *surveyRequest = [[NSMutableDictionary alloc] init];
    
    NSDictionary* header = [SurveyRequest headerFromFSR:fsr];
    [surveyRequest setObject:header forKey:@"header"];
    
    NSDictionary* surveyAsDict = [SurveyRequest toDictionaryFromSurvey:survey] ;
    [surveyRequest setObject:surveyAsDict forKey:@"survey"];
    
    
    
    //Create JSON Object. To avoid special characters at end (random) create non mutable dictionary before converting
    NSDictionary* surveyDict = [[NSDictionary alloc] initWithDictionary:surveyRequest];
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:surveyDict
                                                       options:NSJSONWritingPrettyPrinted error:&error];
    if (error)
    {
        NSLog(@"Error while creating JSON Request %@", error.userInfo);
    }
    NSString* surveyRequestJSON = [NSString stringWithUTF8String:[jsonData bytes]];
    return surveyRequestJSON;
}

+ (NSDictionary*) headerFromFSR: (FSR*) fsr
{
    NSMutableDictionary* header = [[NSMutableDictionary alloc] init];
    
    // Timestamp
    NSDate *current = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZZZZZ"];
    NSString* timeStamp = [formatter stringFromDate:current];
    [header setObject:timeStamp forKey:@"TimeStamp"];
    
    //
    AppDelegate* appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    NSString* apiToken = [appDelegate configFor:@"SFDC_API_TOKEN"];
    [header setObject:apiToken forKey:@"Token"];
    
    // FSR
    NSDictionary* fsrAsDict = [fsr asDictionary];
    [header setObject:fsrAsDict forKey:@"FSR"];
    
    return header;
}


+ (NSDictionary*) toDictionaryFromSurvey:(Survey*) survey
{
    NSMutableDictionary* surveyAsDictionary = [[NSMutableDictionary alloc] init];
    
    [surveyAsDictionary setObject:survey.surveyID forKey:@"SurveyId"];
    
    int noOfComments = survey.commentList.count;
    NSMutableArray* comments = [[NSMutableArray alloc] initWithCapacity:noOfComments];
    
    for (int i=0; i<noOfComments; i++)
    {
        Comment* comment = [survey.commentList objectAtIndex:i];
        [comments addObject:[SurveyRequest toDictionaryFromComment:comment]];
    }
    [surveyAsDictionary setObject:comments forKey:@"Comments"];
    
    return surveyAsDictionary;
    
}


+ (NSDictionary*) toDictionaryFromComment: (Comment*) comment
{
    NSMutableDictionary* commentAsDictionary = [[NSMutableDictionary alloc] init];
    
    [commentAsDictionary setObject:comment.keyId forKey:@"CommentId"];
    [commentAsDictionary setObject:comment.text forKey:@"CommentText"];

    [commentAsDictionary setObject:comment.surveyType forKey:@"SurveyType"];
    [commentAsDictionary setObject:comment.superCategory.name forKey:@"SuperCategory"];
    [commentAsDictionary setObject:comment.contactName forKey:@"ContactName"];
    
    NSString* category = [SurveyRequest selectedCategoryForComment:comment] ;
    [commentAsDictionary setObject:category forKey:@"Category"];
    
    NSMutableArray* subcategoryList = [[NSMutableArray alloc] init];
    
    // Get all Subcategories to be sent
    NSMutableSet* parentSubCatSet = [[NSMutableSet alloc] initWithArray:comment.subCategoryList.allObjects];
    if ((comment.topicList != nil) && (comment.topicList.count != 0))
    {
        for (int i=0; i< comment.topicList.count;i++)
        {
            Topic* aTopic = [comment.topicList.allObjects objectAtIndex:i];
            SubCategory* subCat = aTopic.parent;
            [parentSubCatSet addObject:subCat];
        }
    }
    for (int j=0; j< parentSubCatSet.count; j++)
    {
        SubCategory *subCategory = [parentSubCatSet.allObjects objectAtIndex:j];
        [subcategoryList addObject:[SurveyRequest toDictionaryFromSubCategory:subCategory forComment:comment]];
    }

    [commentAsDictionary setObject:subcategoryList forKey:@"SubCategoryList"];
    
    //*** Dealer list *****
    NSMutableArray* dealerArray = [[NSMutableArray alloc] initWithCapacity:comment.dealerList.count];
    for (int dealerCount=0; dealerCount <comment.dealerList.count;dealerCount++)
    {
        [dealerArray addObject:[[comment.dealerList.allObjects objectAtIndex:dealerCount] asDictionary]];
    }
    [commentAsDictionary setObject:dealerArray forKey:@"Dealers"];
    
    return commentAsDictionary;
}

+ (NSString*) selectedCategoryForComment: (Comment*) comment
{
    NSString* category = @"";
    if (comment.category != Nil)
    {
        category = comment.category.name;
    }
    else if ((comment.subCategoryList != nil) && (comment.subCategoryList.count >0))
    {
        SubCategory* subCategory = [comment.subCategoryList.allObjects objectAtIndex:0];
        category = subCategory.parent.name;
    }
    else if ((comment.topicList != Nil) && (comment.topicList.count >0))
    {
        Topic* topic = [comment.topicList.allObjects objectAtIndex:0];
        
        category = topic.parent.parent.name;
    }
    return category;
}

+ (NSDictionary* ) toDictionaryFromSubCategory:(SubCategory*) subCategory forComment:(Comment*) comment
{
    NSMutableDictionary* subCategoryAsDictionary = [[NSMutableDictionary alloc] init];
    [subCategoryAsDictionary setObject:subCategory.name forKey:@"Name"];
    
    NSMutableArray* topicList = [[NSMutableArray alloc] init];
    for (int i=0; i < subCategory.topicList.count;i++)
    {
        Topic* topic = [subCategory.topicList objectAtIndex:i];
        
        // See if this Topic is selected in the Comment?
        for (int j=0; j< comment.topicList.count; j++)
        {
            Topic* selectedTopic = [comment.topicList.allObjects objectAtIndex:j];
            if ([selectedTopic.name isEqualToString:topic.name])
            {
                [topicList addObject:[SurveyRequest toDictionaryFromTopic:topic]];
                break;
            }
        }
    }
    [subCategoryAsDictionary setObject:topicList forKey:@"TopicList"];
    return subCategoryAsDictionary;
}

+ (NSDictionary* ) toDictionaryFromTopic:(Topic*) topic
{
    NSMutableDictionary* topicAsDictionary = [[NSMutableDictionary alloc] init];
    [topicAsDictionary setObject:topic.name forKey:@"Name"];
    
    return topicAsDictionary;
    
}
@end
