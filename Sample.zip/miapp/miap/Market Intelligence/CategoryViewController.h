//
//  CategoryViewController.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/14/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SuperCategory.h"
#import "SurveyCategory.h"
#import "SubCategory.h"
#import "CategoryHierarchyCell.h"
#import "FSGBaseViewController.h"
#import "Comment+CommentCustom.h"

#import "MIConstant.h"
@class CategoryHierarchyCell;

@protocol CategoryViewDelegate <NSObject>
@required
- (void) categoryDataSelected:(MICategory*) category subCategoryList: (NSMutableArray*) subCategoryList topicList:(NSMutableArray*) topicList;
@end

@interface CategoryViewController : FSGBaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    MICategory* expandedCategory;
    MISubCategory* expandedSubCategory;
    
    NSMutableArray* displayedHierarchyObjects;
    

    MICategory* selectedCategory;
    NSMutableArray* subCategoryList;
    NSMutableArray* topicList;
 
}

@property (weak,nonatomic) id<CategoryViewDelegate> delegate;
@property (strong, retain) MISuperCategory* superCategory;
@property IBOutlet UITableView* categoryTable;
@property (weak) MIComments* comment;

-(IBAction) cancel:(UIBarButtonItem*) sender;
- (IBAction)doneClicked:(id)sender;
- (void) selectObject: (MICategory*) category;
- (void) unselectObject: (MICategory*) category;

- (void) expandClickedOnCell:(CategoryHierarchyCell*) cell;
- (void) collapseClickedOnCell:(CategoryHierarchyCell*) cell;

@end
