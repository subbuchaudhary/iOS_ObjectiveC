//
//  BaseCategory.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface MIBaseCategory :NSObject

@property (nonatomic, retain) NSNumber * keyId;
@property (nonatomic, retain) NSString * name;

@end
