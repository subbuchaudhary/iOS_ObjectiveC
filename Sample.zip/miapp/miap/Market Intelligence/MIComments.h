//
//  MIComments.h
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "MIConstant.h"
#import "MICategory.h"
#import "MISuperCategory.h"
#import "MISubCategory.h"
#import "MITopic.h"
#import "MIDealerSummary.h"
#import "MICategory.h"
#import "MISubCategory.h"
@interface MIComments : NSObject
@property (nonatomic, retain) NSString * contactName;
@property (nonatomic, retain) NSString * keyId;
@property (nonatomic, retain) NSString * surveyType;
@property (nonatomic, retain) NSString * text;
@property (nonatomic, retain) NSString * dealerNumber;
@property (nonatomic, retain) MICategory *category;
@property (nonatomic, retain) MISuperCategory *superCategory;

@property (nonatomic, retain) NSMutableSet *dealerList;
@property (nonatomic, retain) NSMutableSet *subCategoryList;
@property (nonatomic, retain) NSMutableSet *topicList;

//---
@property(nonatomic,strong)NSString *topicListIds;
@property(nonatomic,strong)NSString *subCategoryIds;
@property(nonatomic,strong)NSString *dealerListIds;
@property(nonatomic,strong)NSString *categoryId;
@property(nonatomic,strong)NSString *superCategoryId;


-(MIComments*)manageCommnetobject:(NSMutableDictionary *)dictObj;
-(void)deleteComment:(MIComments*)comment;
-(void)updateSubCategoryList:(MISubCategory*)subCat;
-(void)updateTopicList:(MITopic*)subCat;
-(void)updateDealerList:(MIDealerSummary*)subCat;
@end


