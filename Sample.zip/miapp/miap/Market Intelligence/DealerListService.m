//
//  DealerListService.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/7/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "DealerListService.h"
#import "AppDelegate.h"
#import "Reachability.h"
#import "KeychainItemWrapper.h"
#import "FSGFSGExternalService.h"
@implementation DealerListService

- (id)initWithDelegate:(id<DealerDataReceiver>)delegate
{
    self.delegate = delegate;
    return self;
}

- (void) dealerDataForSSO:(NSString *)sso
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    Reachability* dealerServiceReachable = [Reachability reachabilityWithHostName:
                                    [appDelegate configFor:@"FSRO_EAS_HOST"]];
    
    
    if (dealerServiceReachable.currentReachabilityStatus != NotReachable)
    {
        FSGFSGExternalService* dealerService = [FSGFSGExternalService service];
        
        dealerService.serviceUrl = [appDelegate configFor:@"FSRO_DEALER_URL"];
        dealerService.logging = NO;
        
        KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
        [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];
        
        NSString* localSSO = [keychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
        NSString* localPassword = [keychainItem objectForKey:(__bridge id)(kSecValueData)];
        
        [dealerService GetMICustomers:self action:@selector(receiveDealerSOAPCallback:)
                             userId:[appDelegate configFor:@"FSRO_ACCESS_ID"]
                             password:[appDelegate configFor:@"FSRO_ACCESS_PASSWORD"]
                             status:@""];
        
        
    }
    else
    {
        // Needs to be loaded from local store. For now send dummy List
        [self.delegate receiveDealerData:appDelegate.miSurveyUtil.dealerList];
        
    }
    
    
}

-(void) validateDealerNumber:(NSString*) dealerNumber
{

    
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    dealerNumberToValidate = dealerNumber;
    
    Reachability* dealerServiceReachable = [Reachability reachabilityWithHostName:
                                            [appDelegate configFor:@"FSRO_EAS_HOST"]];
    
    if (dealerServiceReachable.currentReachabilityStatus != NotReachable)
    {
        FSGFSGExternalService* dealerService = [FSGFSGExternalService service];
        
        dealerService.serviceUrl = [appDelegate configFor:@"FSRO_DEALER_URL"];
        dealerService.logging = NO;
        
        KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
        [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];
        
        NSString* localSSO = [keychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
        NSString* localPassword = [keychainItem objectForKey:(__bridge id)(kSecValueData)];
        

        [dealerService MIBranchNumber:self
                               action:@selector(receiveMIBranchData:)
                               userId:[appDelegate configFor:@"FSRO_ACCESS_ID"]
                               password:[appDelegate configFor:@"FSRO_ACCESS_PASSWORD"]
                               customerNumber:dealerNumber
                               status:@""];
    }
    else
    {
        [self.delegate unableToValidateDealer:dealerNumber];
    }
    

}

- (void) receiveDealerSOAPCallback : (id) result
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
	// Handle errors
	if([result isKindOfClass:[NSError class]]) {
		NSLog(@"DealerListService Error %@", result);
        [self.delegate receiveDealerData:appDelegate.miSurveyUtil.dealerList];
        return;
	}
    
	// Handle faults
	if([result isKindOfClass:[SoapFault class]]) {
		NSLog(@"DealerListService SOAPFault %@", result);
        [self.delegate receiveDealerData:appDelegate.miSurveyUtil.dealerList];
        return;
	}
    
    FSGArrayOfMICustomerData* soapDealerList = (FSGArrayOfMICustomerData*) result;
    // Clear all existing dealers for adding new downloaded dealers
    [appDelegate.miSurveyUtil clearCurrentDealers];
    NSMutableArray* dealerList = [[NSMutableArray alloc] initWithCapacity:soapDealerList.count];
    for (int i=0; i < soapDealerList.count;i++)
    {
        FSGMICustomerData* customer = [soapDealerList objectAtIndex:i];
        [dealerList addObject:[appDelegate.miSurveyUtil dealerFromSOAPCustomerData:customer]];
    }
    appDelegate.miSurveyUtil.dealerList = dealerList;
    [appDelegate.miSurveyUtil saveCurrentSurvey];
    
    [self.delegate receiveDealerData:dealerList];
    
}

- (void) receiveMIBranchData : (id) result
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
	// Handle errors
	if([result isKindOfClass:[NSError class]]) {
		NSLog(@"Error GetDealerBranchNumber %@", result);
        [self.delegate receiveValidateDealer:nil];
        return;
	}
    
	// Handle faults
	if([result isKindOfClass:[SoapFault class]]) {
		NSLog(@"SOAPFault GetDealerBranchNumber %@", result);
        [self.delegate receiveDealerData:Nil];
        return;
	}
    
    FSGMICustomerData* validCustomer = (FSGMICustomerData*) result;


    if (![validCustomer.BranchRegion isEqualToString:@""])
    {
        MIDealerSummary *dealer = [[MIDealerSummary alloc] init];
        dealer.isValidated = @YES;
        dealer.customerNumber = validCustomer.CustomerNumber;
        dealer.customerName = validCustomer.CustomerName;
        dealer.vbu = validCustomer.VBUName;
        dealer.branchNo = validCustomer.BranchRegion;
        dealer.addedManually = @YES;
        [self.delegate receiveValidateDealer:dealer];
    }
    else
    {
        [self.delegate invalidDealerNumber:dealerNumberToValidate];
        
    }
    

    
}

@end
