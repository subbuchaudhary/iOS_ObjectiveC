//
//  MISurvey.m
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import "MISurvey.h"
#import "MIDBManager.h"
@implementation MISurvey

-(void)getSurveyComments
{
    self.commentList = [[NSMutableOrderedSet alloc] init];
    NSArray *subCatIds = [self.commentIds componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:COMMENTS_TABLE];
    NSMutableArray *objComments = [[NSMutableArray alloc] init];
    for (NSString *subCatId in subCatIds) {
        NSArray*arrComment =  [[MIDBManager getSharedInstance] fetchCommentlist:[NSString stringWithFormat:@"select*from %@ where keyId = %@",TABLE_COMMENTS,subCatId]];
        if (arrComment.count>0)
            [objComments addObject:arrComment[0]];
    }
    
    if (objComments.count>0) {
        [self.commentList.array arrayByAddingObjectsFromArray:objComments];
    }
}

-(void)clearSurveyTable
{
    NSString* query = [NSString stringWithFormat:@"delete from %@ ",TABLE_CURRENT_SURVEY];
    [[MIDBManager getSharedInstance] deleteRecrodsQuery:query];
    [self.commentList removeAllObjects ];
}

-(void)getCurrentSurveyComments
{
    AppDelegate *delegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
}
@end
