//
//  Survey.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/26/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Comment;

@interface Survey : NSManagedObject

@property (nonatomic, retain) NSString * surveyID;
@property (nonatomic, retain) NSOrderedSet *commentList;
@end

@interface Survey (CoreDataGeneratedAccessors)

- (void)insertObject:(Comment *)value inCommentListAtIndex:(NSUInteger)idx;
- (void)removeObjectFromCommentListAtIndex:(NSUInteger)idx;
- (void)insertCommentList:(NSArray *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeCommentListAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInCommentListAtIndex:(NSUInteger)idx withObject:(Comment *)value;
- (void)replaceCommentListAtIndexes:(NSIndexSet *)indexes withCommentList:(NSArray *)values;
- (void)addCommentListObject:(Comment *)value;
- (void)removeCommentListObject:(Comment *)value;
- (void)addCommentList:(NSOrderedSet *)values;
- (void)removeCommentList:(NSOrderedSet *)values;
@end
