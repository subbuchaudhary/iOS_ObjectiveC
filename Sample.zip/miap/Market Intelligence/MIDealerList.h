//
//  MIDealerList.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 19/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MIDealerList : NSObject
@property(nonatomic,strong)NSString *branchDescription;
@property(nonatomic,strong)NSString *branchNo;
@property(nonatomic,strong)NSString *customerName;
@property(nonatomic,strong)NSString *customerNo;
@property(nonatomic,strong)NSString *masterNumber;
@property(nonatomic,strong)NSString *statusCode;
@property(nonatomic,strong)NSString *vbu;
@property(nonatomic,strong)NSNumber *isManuallyAdded;
@end
