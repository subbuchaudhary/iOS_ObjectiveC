//
//  MITopic.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MITopic.h"
#import "MIConstant.h"
@implementation MITopic
-(MISubCategory*)getTopicParentCategory
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    NSString* query = [NSString stringWithFormat:@"select * from %@ where id = %d ",TABLE_SUBCATEGORY,self.subCatId.intValue];
    NSMutableArray *results = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (results.count>0) {
        return results[0];
    }
    else
    {
        return [MISubCategory new];
    }
}
@end
