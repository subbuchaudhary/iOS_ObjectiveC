//
//  SubCategory+SubCategoryCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SubCategory.h"

@interface SubCategory (SubCategoryCustom)
- (void)addTopicListObject:(Topic *)value;
@end
