//
//  SurveyRequest.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/24/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyRequest.h"
#import "AppDelegate.h"

@implementation SurveyRequest



+ (NSString*) asJSONForSurvey: (MISurvey*) survey withFSR: (MIFSR*) fsr
{
    NSMutableDictionary *surveyRequest = [[NSMutableDictionary alloc] init];
    
    NSDictionary* header = [SurveyRequest headerFromFSR:fsr];
    [surveyRequest setObject:header forKey:@"header"];
    
    NSDictionary* surveyAsDict = [SurveyRequest toDictionaryFromSurvey:survey] ;
    [surveyRequest setObject:surveyAsDict forKey:@"survey"];
    
    
    
    //Create JSON Object. To avoid special characters at end (random) create non mutable dictionary before converting
    NSDictionary* surveyDict = [[NSDictionary alloc] initWithDictionary:surveyRequest];
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:surveyDict
                                                       options:NSJSONWritingPrettyPrinted error:&error];
    if (error)
    {
        NSLog(@"Error while creating JSON Request %@", error.userInfo);
    }
    NSString* surveyRequestJSON = [NSString stringWithUTF8String:[jsonData bytes]];
    return surveyRequestJSON;
}

+ (NSDictionary*) headerFromFSR: (MIFSR*) fsr
{
    NSMutableDictionary* header = [[NSMutableDictionary alloc] init];
    
    // Timestamp
    NSDate *current = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZZZZZ"];
    NSString* timeStamp = [formatter stringFromDate:current];
    [header setObject:timeStamp forKey:@"TimeStamp"];
    
    //
    AppDelegate* appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    NSString* apiToken = [appDelegate configFor:@"SFDC_API_TOKEN"];
    [header setObject:apiToken forKey:@"Token"];
    
    // FSR
    NSDictionary* fsrAsDict = [fsr asDictionary];
    if (fsrAsDict.count>0) {
        [header setObject:fsrAsDict forKey:@"FSR"];
    }
    
    
    return header;
}


+ (NSDictionary*) toDictionaryFromSurvey:(MISurvey*) survey
{
    NSMutableDictionary* surveyAsDictionary = [[NSMutableDictionary alloc] init];
    
    [surveyAsDictionary setObject:survey.surveyID forKey:@"SurveyId"];

    int noOfComments = (int)survey.commentList.array.count;
    NSMutableArray* comments = [[NSMutableArray alloc] initWithCapacity:noOfComments];
    
    for (int i=0; i<noOfComments; i++)
    {
        MIComments* comment = [survey.commentList.array objectAtIndex:i];
        //[comment getCommentCategoryStructureForComment:comment];
        [comments addObject:[SurveyRequest toDictionaryFromComment:comment]];
    }
    [surveyAsDictionary setObject:comments forKey:@"Comments"];
    
    return surveyAsDictionary;
    
}


+ (NSDictionary*) toDictionaryFromComment: (MIComments*) comment
{
    NSMutableDictionary* commentAsDictionary = [[NSMutableDictionary alloc] init];
    
    [commentAsDictionary setObject:comment.keyId forKey:@"CommentId"];
    [commentAsDictionary setObject:comment.text forKey:@"CommentText"];

    [commentAsDictionary setObject:comment.surveyType forKey:@"SurveyType"];
    [commentAsDictionary setObject:comment.superCategory.superCatName forKey:@"SuperCategory"];
    [commentAsDictionary setObject:comment.contactName forKey:@"ContactName"];
    
    NSString* category = [SurveyRequest selectedCategoryForComment:comment] ;
    [commentAsDictionary setObject:category forKey:@"Category"];
    
    NSMutableArray* subcategoryList = [[NSMutableArray alloc] init];
    
    // Get all Subcategories to be sent
    NSMutableSet* parentSubCatSet = [[NSMutableSet alloc] initWithArray:comment.subCategoryList.array];
    if ((comment.topicList != nil) && (comment.topicList.array.count != 0))
    {
        for (MITopic *topic in comment.topicList.array)
        {
            MISubCategory* subCat = topic.getTopicParentCategory;
            [parentSubCatSet addObject:subCat];
        }
    }
    for (int j=0; j< parentSubCatSet.count; j++)
    {
        MISubCategory *subCategory = [parentSubCatSet.allObjects objectAtIndex:j];
        [subcategoryList addObject:[SurveyRequest toDictionaryFromSubCategory:subCategory forComment:comment]];
    }

    [commentAsDictionary setObject:subcategoryList forKey:@"SubCategoryList"];
    
    //*** Dealer list *****
    NSMutableArray* dealerArray = [[NSMutableArray alloc] initWithCapacity:comment.dealerList.count];
    for (int dealerCount=0; dealerCount <comment.dealerList.count;dealerCount++)
    {
        [dealerArray addObject:[[comment.dealerList objectAtIndex:dealerCount] asDictionary]];
    }
    [commentAsDictionary setObject:dealerArray forKey:@"Dealers"];
    
    return commentAsDictionary;
}

+ (NSString*) selectedCategoryForComment: (MIComments*) comment
{
    NSString* category = @"";
    if (comment.category != Nil)
    {
        category = comment.category.catName;
    }
    else if ((comment.subCategoryList != nil) && (comment.subCategoryList.array.count >0))
    {
        MISubCategory* subCategory = [comment.subCategoryList.array objectAtIndex:0];
        category = subCategory.getParentCategory.catName;
    }
    else if ((comment.topicList != Nil) && (comment.topicList.array.count >0))
    {
        MITopic* topic = [comment.topicList.array objectAtIndex:0];
        
        category = topic.getTopicParentCategory.getParentCategory.catName;
    }
    return category;
}

+ (NSDictionary* ) toDictionaryFromSubCategory:(MISubCategory*) subCategory forComment:(MIComments*) comment
{
    NSMutableDictionary* subCategoryAsDictionary = [[NSMutableDictionary alloc] init];
    [subCategoryAsDictionary setObject:subCategory.subCatName forKey:@"Name"];
    
    NSMutableArray* topicList = [[NSMutableArray alloc] init];
    NSArray *objTopicList= [subCategory getTopicList:subCategory];
    for (int i=0; i < objTopicList.count;i++)
    {
        MITopic* topic = objTopicList[i];
        
        // See if this Topic is selected in the Comment?
        for (MITopic *selectedTopic in comment.topicList.array)
        {
            if ([selectedTopic.topicName isEqualToString:topic.topicName])
            {
                [topicList addObject:[SurveyRequest toDictionaryFromTopic:topic]];
                break;
            }
        }
    }
    [subCategoryAsDictionary setObject:topicList forKey:@"TopicList"];
    return subCategoryAsDictionary;
}

+ (NSDictionary* ) toDictionaryFromTopic:(MITopic*) topic
{
    NSMutableDictionary* topicAsDictionary = [[NSMutableDictionary alloc] init];
    [topicAsDictionary setObject:topic.topicName forKey:@"Name"];
    
    return topicAsDictionary;
    
}
@end
