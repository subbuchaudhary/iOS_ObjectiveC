//
//  SurveySubmissionService.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu Manuru on 1/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveySubmissionService.h"
#import "Survey+SurveyCustom.h"
#import "AppDelegate.h"
#import "SurveyRequest.h"
#import "Reachability.h"

#import "NSURLConnection+TrustGESignedCertificate.h"

@implementation SurveySubmissionService


-(id) initWithDelegate:(id<SubmitSurveyResponseReceiver>)delegate
{
    statusReceiver = delegate;
    return self;
    
}

- (void) submitSurvey: (MISurvey*) survey
{

    AppDelegate* appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    // First save the current survey
    [appDelegate.currentSurvey prepareForSubmit];
    [appDelegate.surveyUtil saveCurrentSurvey];
    

    
    // See if we have connectivity
    Reachability *sfdcHost = [Reachability reachabilityWithHostName:[appDelegate configFor:@"SFDC_SURVEY_HOST"]];
    
    
    if (sfdcHost.currentReachabilityStatus != NotReachable)
    {    NSString* surveyRequest =     [SurveyRequest asJSONForSurvey:survey withFSR:appDelegate.miFsr];
        // Send Survey Request as JSON to SFDC Host
        // Try getting JSON String if for any reason surveyRequest is nil
        if ((surveyRequest == nil ) || ([surveyRequest isEqualToString:@""]))
        {
            surveyRequest =     [SurveyRequest asJSONForSurvey:survey withFSR:appDelegate.miFsr];
        }
        
        [self clearCookies];
        NSData *postData = [surveyRequest dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
        NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        
        [NSURLConnection allowsAnyHTTPSCertificateForHost:[appDelegate configFor:@"SFDC_SURVEY_HOST"]];
        [request setURL:[NSURL URLWithString:[appDelegate configFor:@"SFDC_SURVEY_URL"]]];
        [request setHTTPMethod:@"POST"];
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        
        // Add Autehntication
        NSString* base64EncodedSSOPassword = [appDelegate configFor:@"SFDC_API_AUTHENTICATION"];
        [request addValue:base64EncodedSSOPassword forHTTPHeaderField:@"Authorization"];
        
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        
        
        NSURLResponse *response;
        
        NSURLConnection *sfdcConnection = [NSURLConnection connectionWithRequest:request delegate:self];
        [sfdcConnection start];
    }
    else
    {
        // Save the survey loacally
        [NSThread sleepForTimeInterval:1.0];
        [appDelegate.surveyUtil saveCurrentSurvey];
        [statusReceiver receiveSubmitStatus:LOCAL_SAVE];
    }
    
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    NSLog(@"Protection Space %@", protectionSpace);
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    NSLog(@"Recieved Authentication Challenge: %@", challenge);
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust])
            [challenge.sender useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
    
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}

-(void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
    NSLog(@"Recieved Authentication Challenge: %@", challenge);
        if (TRUE) {
            NSLog(@"trusting connection to host %@", challenge.protectionSpace.host);
            [challenge.sender useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        } else
            NSLog(@"Not trusting connection to host %@", challenge.protectionSpace.host);
    }
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    // A response has been received, this is where we initialize the instance var you created
    // so that we can append data to it in the didReceiveData method
    // Furthermore, this method is called each time there is a redirect so reinitializing it
    // also serves to clear it
    responseData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    // Append the new data to the instance variable you declared
    [responseData appendData:data];
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
    // Return nil to indicate not necessary to store a cached response for this connection
    return nil;
}




- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Response from server  %@", responseString );
    
    NSError* error;
    NSDictionary* responseJSON = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:&error];
    NSLog(@"Error while converting server response to JSON %@", error);
    
    NSDictionary* responseObj = (NSDictionary*)[responseJSON objectForKey:@"response"];
    NSString* status = (NSString*) [responseObj objectForKey:@"Status"];
    
    
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([status isEqualToString:@"SUCCESS"] )
    {
        //[appDelegate.surveyUtil removeEntity:appDelegate.currentSurvey];
        [appDelegate.currentSurvey clearSurveyTable];
        [appDelegate.miSurveyUtil clearDealerSummaryEntities];
        
        appDelegate.currentSurvey = [[MISurvey alloc] init];
        appDelegate.currentSurvey.surveyID = @"123";
        appDelegate.currentSurvey.commentIds = @"";
        [[MIDBManager getSharedInstance] insertCurrentSurveyRecords:@[appDelegate.currentSurvey]];
        [appDelegate.miSurveyUtil saveCurrentSurvey];
        [statusReceiver receiveSubmitStatus:SF_SEND_SUCCESS];
    }
    else
    {
        [statusReceiver receiveSubmitStatus:LOCAL_SAVE];
    }

}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"Recieved Error %@",error);
    
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [appDelegate.miSurveyUtil saveCurrentSurvey];
    [statusReceiver receiveSubmitStatus:LOCAL_SAVE];

    
}

- (void) clearCookies
{
    NSArray* cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
    
    if ((cookies != nil) && (cookies.count !=0))
    {
        
        for (int i=0; i< cookies.count;i++)
        {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:[cookies objectAtIndex:i]];
        }
    }
        
    
}
                             
@end
