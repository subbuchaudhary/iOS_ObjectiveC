//
//  SuperCategory.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "BaseCategory.h"

@class SurveyCategory, SurveyType;

@interface SuperCategory : BaseCategory

@property (nonatomic, retain) NSSet *categoryList;
@property (nonatomic, retain) SurveyType *parent;
@end

@interface SuperCategory (CoreDataGeneratedAccessors)

- (void)addCategoryListObject:(SurveyCategory *)value;
- (void)removeCategoryListObject:(SurveyCategory *)value;
- (void)addCategoryList:(NSSet *)values;
- (void)removeCategoryList:(NSSet *)values;

@end
