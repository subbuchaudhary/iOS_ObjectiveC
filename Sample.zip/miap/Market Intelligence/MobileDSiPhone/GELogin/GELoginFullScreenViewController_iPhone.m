//
//  GELoginFullScreenViewController_iPhone.m
//  MobileDS
//
//  Created  on 5/16/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import "GELoginFullScreenViewController_iPhone.h"
#define HEADER_IMAGE_TOP_MARGIN 43
#define HERO_BG_HEIGHT 213
#define AMT_TO_SHIFT_VIEW 0
#define APP_NAME_LABEL_MARGIN 10
#define APP_NAME_FONT_SIZE 15
#define FORM_ELEMENT_WIDTH 276
#define FORM_ELEMENT_HEIGHT 50
#define FORM_ELEMENT_HERO_OVERLAP 25
#define BUTTON_TOP_MARGIN 37
#define SMALL_BUTTON_MARGIN 10
#define CONTAINER_HEIGHT 585



@interface GELoginFullScreenViewController_iPhone (){
    
    UIView *heroBG;
    UIView *containerView;
    UIButton *dismissKeyboardButton;
}

@end


@implementation GELoginFullScreenViewController_iPhone

- (void)setupLogin
{
    containerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    containerView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    
    self.accentColor = GE_COLOR_PURPLE_PRIMARY;
    
	containerView.backgroundColor = GE_COLOR_GROUND_ACCENT;
    
    heroBG = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, HERO_BG_HEIGHT)];
    heroBG.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    
    [containerView addSubview:heroBG];
    
    self.heroImage = [UIImage imageNamed:@"GEBranding_iPhone.png"];
    
    self.heroImageView = [[UIImageView alloc] initWithImage:self.heroImage];
    self.heroImageView.frame = CGRectMake(heroBG.center.x - self.heroImageView.center.x, HEADER_IMAGE_TOP_MARGIN, self.heroImage.size.width,self.heroImage.size.height);
    
    self.heroImageView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    
    
    [heroBG addSubview:self.heroImageView];
    
    self.appNameLabel = [[GELabel alloc]initWithFrame:CGRectMake(0, self.heroImageView.frame.origin.y + self.heroImageView.frame.size.height + APP_NAME_LABEL_MARGIN, heroBG.frame.size.width, 32) Font:GE_Inspira_Medium Size:APP_NAME_FONT_SIZE andColor:GE_COLOR_WHITE];
    self.appNameLabel.textAlignment = NSTextAlignmentCenter;
    self.appNameLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    self.appNameLabel.text = @"App Name";
    [heroBG addSubview:self.appNameLabel];
    
    
    // Added by Easwar - Application version number 
    UILabel *versionLabel = [[GELabel alloc]initWithFrame:CGRectMake(0, self.heroImageView.frame.origin.y + self.heroImageView.frame.size.height + APP_NAME_LABEL_MARGIN + 20, heroBG.frame.size.width, 32) Font:GE_Inspira_Medium Size:12 andColor:GE_COLOR_WHITE];
    versionLabel.textAlignment = NSTextAlignmentCenter;
    versionLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    versionLabel.text = [NSString stringWithFormat:@"Version %@", [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"]];
    [heroBG addSubview:versionLabel];
    
    
    //button for keyboard dismissal
    
    dismissKeyboardButton = [UIButton buttonWithType:UIButtonTypeCustom];
    dismissKeyboardButton.frame = self.view.frame;
    dismissKeyboardButton.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [dismissKeyboardButton addTarget:self action:@selector(dismissKeyboardAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:dismissKeyboardButton];
    
    self.acctTextField = [[GETextField alloc]initWithFrame:CGRectMake(self.view.center.x - FORM_ELEMENT_WIDTH/2, HERO_BG_HEIGHT - FORM_ELEMENT_HERO_OVERLAP, FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT) Font:GE_Inspira_Bold Size:15 andColor:self.accentColor andPlaceholder:@"SSO" ];
    
    self.acctTextField.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
    self.acctTextField.backgroundColor = GE_COLOR_WHITE;
    
    self.acctTextField.layer.cornerRadius = 5.0;
    self.acctTextField.delegate = self;
//    self.acctTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

    
    
    [containerView addSubview:self.acctTextField];
    
    self.passTextField = [[GETextField alloc]initWithFrame:CGRectMake(self.view.center.x - FORM_ELEMENT_WIDTH/2, self.acctTextField.frame.origin.y + self.acctTextField.frame.size.height + 2, FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT) Font:GE_Inspira_Bold Size:15 andColor:self.accentColor andPlaceholder:@"PASSWORD" ];

    
    self.passTextField.backgroundColor = GE_COLOR_WHITE;
    self.passTextField.layer.cornerRadius = 5.0;
    self.passTextField.secureTextEntry = YES;
    self.passTextField.delegate = self;
    
    self.passTextField.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin;
    
    [containerView addSubview:self.passTextField];
    
    
    self.signInButton = [[GEButton alloc]initWithStyle:GEButtonStyleLarge andColor:self.accentColor];
    self.signInButton.frame = CGRectMake(self.view.center.x - FORM_ELEMENT_WIDTH/2, self.passTextField.frame.origin.y + self.passTextField.frame.size.height + BUTTON_TOP_MARGIN, FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT);
    self.signInButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    //self.signInButton.buttonSize = CGSizeMake(FORM_ELEMENT_WIDTH, FORM_ELEMENT_HEIGHT);
    
    self.signInButton.buttonText = @"Sign In";
    
    [self.signInButton.button addTarget:self action:@selector(signInButtonAction:) forControlEvents:UIControlEventTouchUpInside ];
    
    [containerView addSubview:self.signInButton];
    
    UIView *smallButtonBox = [[UIView alloc]initWithFrame:CGRectMake(self.view.center.x - FORM_ELEMENT_WIDTH/2, self.signInButton.frame.origin.y + self.signInButton.frame.size.height + SMALL_BUTTON_MARGIN, FORM_ELEMENT_WIDTH, 44)];
    smallButtonBox.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    
    
    UIEdgeInsets smallButtonInsets = UIEdgeInsetsMake(-16, 0, 16, 0);
    
    self.createAcctButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.createAcctButton.frame = CGRectMake(0, 0, self.signInButton.frame.size.width/2, 44);
    [self.createAcctButton setTitle:@"Create Account" forState:UIControlStateNormal];
    self.createAcctButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-Bold" size:12];
    self.createAcctButton.contentHorizontalAlignment= UIControlContentHorizontalAlignmentLeft;
    [self.createAcctButton setTitleColor:GE_COLOR_GRAY forState:UIControlStateNormal];
    [self.createAcctButton setTitleColor:GE_COLOR_CHROME forState:UIControlStateHighlighted];
    
    self.createAcctButton.hidden = YES;
    
    self.createAcctButton.titleEdgeInsets = smallButtonInsets;
    
    [smallButtonBox addSubview:self.createAcctButton];
    
    
    self.forgotPassButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.forgotPassButton.frame = CGRectMake(smallButtonBox.frame.size.width/2, 0, self.signInButton.frame.size.width/2, 44);
    [self.forgotPassButton setTitle:@"Forgot Password?" forState:UIControlStateNormal];
    self.forgotPassButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-Bold" size:12];
    [self.forgotPassButton setTitleColor:GE_COLOR_GRAY forState:UIControlStateNormal];
    [self.forgotPassButton setTitleColor:GE_COLOR_CHROME forState:UIControlStateHighlighted];
    self.forgotPassButton.contentHorizontalAlignment= UIControlContentHorizontalAlignmentRight;
    self.forgotPassButton.titleEdgeInsets = smallButtonInsets;
    self.forgotPassButton.hidden = YES;
    
    [smallButtonBox addSubview:self.forgotPassButton];
    
    [containerView addSubview:smallButtonBox];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidHide:) name:UIKeyboardDidHideNotification object:nil];
    [self.view addSubview:containerView];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = GE_COLOR_GROUND_ACCENT;
    [self setupLogin];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Actions

-(void)dismissKeyboardAction:(id)sender{
    
    [self.acctTextField resignFirstResponder];
    [self.passTextField resignFirstResponder];
    
    
}

-(void)signInButtonAction:(id)sender
{
//Here is where Authentication Happens
    
    UIAlertView *badLogin = [[UIAlertView alloc]initWithTitle:nil message:@"The user ID or password you entered is incorrect." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    
    [badLogin show];

}

#pragma mark AlertViewDelegates
-(void)alertViewCancel:(UIAlertView *)alertView
{


}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
 //go to create account 
    
}

#pragma mark GETextFieldDelegate

// Modified by Easwar - This is to avoid change of font/size while the text changes in the SSO and Password fields.

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
//    if (range.location == 0 && string.length > 0) {
//        textField.font = [UIFont fontWithName:@"LucidaGrande" size:textField.font.pointSize];
//    }
//    else if (range.location <=0 && string.length <= 0) {
//        textField.font = [UIFont fontWithName:@"GEInspira-Bold" size:textField.font.pointSize];
//    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
}

- (BOOL)textFieldDidReturn:(UITextField *)textField

{
    [textField resignFirstResponder];
    return YES;
}


- (void)keyboardDidShow:(NSNotification *)notification
{
    
    [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationCurveEaseInOut animations:^{
        CGRect newFrame = containerView.frame;
        newFrame.origin.y -= AMT_TO_SHIFT_VIEW;
        containerView.frame = newFrame;
    } completion:^(BOOL finished) {
        nil;
    }];
    
    
}

-(void)keyboardDidHide:(NSNotification *)notification
{
    [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationCurveEaseOut animations:^{
        CGRect newFrame = containerView.frame;
        newFrame.origin.y += AMT_TO_SHIFT_VIEW;
        containerView.frame = newFrame;
    } completion:^(BOOL finished) {
        nil;
    }];
    
}

#pragma mark Setters

-(void)setAccentColor:(UIColor *)accentColor
{
    _accentColor = accentColor;
    heroBG.backgroundColor = _accentColor;
    self.signInButton.buttonColor = _accentColor;
    self.acctTextField.textColor = _accentColor;
    self.passTextField.textColor = _accentColor;
    
    
}

-(void)setAppName:(NSString *)appName
{
    _appName = appName;
    self.appNameLabel.text = _appName;
}

-(void)setHeroImage:(UIImage *)heroImage
{
    _heroImage = heroImage;
    self.heroImageView.image = _heroImage;

}

-(BOOL)shouldAutorotate
{
    return YES;
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}




@end
