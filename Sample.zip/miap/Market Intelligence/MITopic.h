//
//  MITopic.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MISubCategory.h"
@interface MITopic : NSObject
@property(nonatomic,strong)NSNumber *surveyId;
@property(nonatomic,strong)NSNumber *superCatId;
@property(nonatomic,strong)NSNumber *catId;
@property(nonatomic,strong)NSNumber *subCatId;
@property(nonatomic,strong)NSNumber *topicid;
@property(nonatomic,strong)NSString *topicName;
-(MISubCategory*)getTopicParentCategory;

@end
