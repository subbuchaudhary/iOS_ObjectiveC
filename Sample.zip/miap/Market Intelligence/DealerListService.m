//
//  DealerListService.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/7/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "DealerListService.h"
#import "AppDelegate.h"
#import "Reachability.h"
#import "KeychainItemWrapper.h"
#import "FSGFSGExternalService.h"
@implementation DealerListService

- (id)initWithDelegate:(id<DealerDataReceiver>)delegate
{
    self.delegate = delegate;
    return self;
}

- (void) dealerDataForSSO:(NSString *)sso
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    Reachability* dealerServiceReachable = [Reachability reachabilityWithHostName:
                                    [appDelegate configFor:@"FSRO_EAS_HOST"]];
    
    
    if (dealerServiceReachable.currentReachabilityStatus != NotReachable)
    {
        FSGFSGExternalService* dealerService = [FSGFSGExternalService service];
        
        dealerService.serviceUrl = [appDelegate configFor:@"FSRO_DEALER_URL"];
        dealerService.logging = NO;
        
        KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
        [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];
        
        //NSString* localSSO = [keychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
        //NSString* localPassword = [keychainItem objectForKey:(__bridge id)(kSecValueData)];
        
        [dealerService GetMICustomers:self action:@selector(receiveDealerSOAPCallback:)
                             userId:[appDelegate configFor:@"FSRO_ACCESS_ID"]
                             password:[appDelegate configFor:@"FSRO_ACCESS_PASSWORD"]
                             status:@""];
        
        
    }
    else
    {
        // Needs to be loaded from local store. For now send dummy List
        [self.delegate receiveDealerData:appDelegate.miSurveyUtil.dealerList];
        
    }
    
    
}

-(void) validateDealerNumber:(NSString*) dealerNumber
{

    
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    dealerNumberToValidate = dealerNumber;
    
   /* MIDealerList* aDealer = [[MIDealerList alloc] init];
    aDealer.customerName = @"Test Plan";
    aDealer.customerNo = @"500";
    aDealer.vbu = @"MP";
    aDealer.branchNo = @"USA";
    aDealer.branchDescription = @"Market intellegent";
    aDealer.statusCode = @"OPEN";
    int r = arc4random() % 100;
    aDealer.masterNumber = [NSString stringWithFormat:@"%d",r];
    aDealer.isManuallyAdded = [NSNumber numberWithInt:1];
    
    NSMutableArray *arrObjects = [[NSMutableArray alloc] initWithArray:appDelegate.miSurveyUtil.dealerList];
    [arrObjects addObject:aDealer];
    appDelegate.miSurveyUtil.dealerList = [arrObjects mutableCopy];
   
    // Also add a Dealer Summary to Coredata
    MIDealerSummary* dealerSummary = [appDelegate.miSurveyUtil newDealerSummaryForDealer:aDealer];
    [[MIDBManager getSharedInstance] insertDealerRecords:@[aDealer]];
    [self.delegate receiveValidateDealer:dealerSummary];*/
    
   
    
   Reachability* dealerServiceReachable = [Reachability reachabilityWithHostName:
                                            [appDelegate configFor:@"FSRO_EAS_HOST"]];
    
    if (dealerServiceReachable.currentReachabilityStatus != NotReachable)
    {
        FSGFSGExternalService* dealerService = [FSGFSGExternalService service];
        
        dealerService.serviceUrl = [appDelegate configFor:@"FSRO_DEALER_URL"];
        dealerService.logging = NO;
        
        KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
        [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];
        
        //NSString* localSSO = [keychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
        //NSString* localPassword = [keychainItem objectForKey:(__bridge id)(kSecValueData)];
        

        [dealerService MIBranchNumber:self
                               action:@selector(receiveMIBranchData:)
                               userId:[appDelegate configFor:@"FSRO_ACCESS_ID"]
                               password:[appDelegate configFor:@"FSRO_ACCESS_PASSWORD"]
                               customerNumber:dealerNumber
                               status:@""];
    }
    else
    {
        [self.delegate unableToValidateDealer:dealerNumber];
    }
    

}

- (void) receiveDealerSOAPCallback : (id) result
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
	// Handle errors
	if([result isKindOfClass:[NSError class]]) {
		NSLog(@"DealerListService Error %@", result);
        [self.delegate receiveDealerData:appDelegate.miSurveyUtil.dealerList];
        return;
	}
    
	// Handle faults
	if([result isKindOfClass:[SoapFault class]]) {
		NSLog(@"DealerListService SOAPFault %@", result);
        [self.delegate receiveDealerData:appDelegate.miSurveyUtil.dealerList];
        return;
	}
    
    FSGArrayOfMICustomerData* soapDealerList = (FSGArrayOfMICustomerData*) result;
    // Clear all existing dealers for adding new downloaded dealers
    [appDelegate.miSurveyUtil clearCurrentDealers];
    NSMutableArray* dealerList = [[NSMutableArray alloc] initWithCapacity:soapDealerList.count];
    for (int i=0; i < soapDealerList.count;i++)
    {
        FSGMICustomerData* customer = [soapDealerList objectAtIndex:i];
        [dealerList addObject:[appDelegate.miSurveyUtil dealerFromSOAPCustomerData:customer]];
    }
    appDelegate.miSurveyUtil.dealerList = dealerList;
    [[MIDBManager getSharedInstance] insertDealerRecords:dealerList];
   // [appDelegate.miSurveyUtil saveCurrentSurvey];
    
    [self.delegate receiveDealerData:dealerList];
    
}

- (void) receiveMIBranchData : (id) result
{
	// Handle errors
	if([result isKindOfClass:[NSError class]]) {
		NSLog(@"Error GetDealerBranchNumber %@", result);
        [self.delegate receiveValidateDealer:nil];
        return;
	}
    
	// Handle faults
	if([result isKindOfClass:[SoapFault class]]) {
		NSLog(@"SOAPFault GetDealerBranchNumber %@", result);
        [self.delegate receiveDealerData:Nil];
        return;
	}
    
    FSGMICustomerData* validCustomer = (FSGMICustomerData*) result;


    if (![validCustomer.BranchRegion isEqualToString:@""])
    {
        NSString* query = [NSString stringWithFormat:@"delete from %@ where masterNumber = '%@' ",TABLE_DEALER,validCustomer.MasterNumber];
        [[MIDBManager getSharedInstance] setStateSelectedTable:DEALER_TABLE];
        NSArray *records = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
        AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
        if (records.count==0) {
            MIDealerList* aDealer = [[MIDealerList alloc] init];
            aDealer.customerName = validCustomer.CustomerName;
            aDealer.customerNo = validCustomer.CustomerNumber;
            aDealer.vbu = validCustomer.VBUName;
            aDealer.branchNo = validCustomer.BranchRegion;
            aDealer.branchDescription = validCustomer.BranchDescription;
            aDealer.statusCode = validCustomer.StatusCode;
            aDealer.masterNumber = validCustomer.MasterNumber;
            aDealer.isManuallyAdded = [NSNumber numberWithInt:1];
            // Also add a Dealer Summary to Coredata
            NSMutableArray *arrObjects = [[NSMutableArray alloc] initWithArray:appDelegate.miSurveyUtil.dealerList];
            [arrObjects addObject:aDealer];
            appDelegate.miSurveyUtil.dealerList = [arrObjects mutableCopy];
            
            // Also add a Dealer Summary to Coredata
            MIDealerSummary* dealerSummary = [appDelegate.miSurveyUtil newDealerSummaryForDealer:aDealer];
            [[MIDBManager getSharedInstance] insertDealerRecords:@[aDealer]];
            [self.delegate receiveValidateDealer:dealerSummary];
        }
        else
        {
            MIDealerSummary* summery = records[0];
            [self.delegate receiveValidateDealer:summery];

        }
        
        
       

    
        
        
        
    }
    else
    {
        [self.delegate invalidDealerNumber:dealerNumberToValidate];
        
    }
}

@end
