//
//  MIComments.m
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import "MIComments.h"
#import "MIDBManager.h"
@implementation MIComments

-(NSMutableArray*)getCommentsList
{
   return [[MIDBManager getSharedInstance] fetchCommentlist:[NSString stringWithFormat:@"select*from %@",TABLE_COMMENTS]];
}

-(void)insertCommentInDatabase:(NSArray*)commentlist
{
    if (commentlist.count>0) {
        [[MIDBManager getSharedInstance] insertRecrodsInComments:commentlist];
    }
}
-(MIComments*)manageCommnetobject:(NSMutableDictionary *)dictObj
{
    self.contactName = dictObj[@"contactName"];
    self.keyId = dictObj[@"keyid"];
    self.surveyType = dictObj[@"surveyType"];
    self.text = dictObj[@"commenttext"];
    self.dealerNumber = dictObj[@"dealerNumber"];
    //Get category object using categoryId
    [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
    NSMutableArray *objCat =  [[MIDBManager getSharedInstance] fetchsingleRecords:dictObj[@"catId"]];
    if (objCat.count>0)
        self.category = objCat[0];
    
    //Get Super category
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUPERCATEGORY_TABLE];
    NSMutableArray *objSuperCat =  [[MIDBManager getSharedInstance] fetchsingleRecords:dictObj[@"superCategoryId"]];
    if (objSuperCat.count>0)
        self.superCategory = objSuperCat[0];
    
    //Get dealer list by id. Get string of ids from database and convert into array
    self.dealerList = [[NSMutableSet alloc] init];
    NSString *objDealerId =  dictObj[@"dealerlistIds"];
    NSArray *dealerIds = [objDealerId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:DEALER_SUMMERY_TABLE];
    for (NSString *dealerid in dealerIds) {
        NSMutableArray *record = [[MIDBManager getSharedInstance] fetchsingleRecords:dealerid];
        if (record.count>0)
            [self.dealerList addObject:record[0]];
    }

    
    //Get subcategory list by id. Get string of ids from database and convert into array
    self.subCategoryList = [[NSMutableSet alloc] init];
    NSString *objSubCatId =  dictObj[@"subCatIds"];
    NSArray *subCatIds = [objSubCatId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    for (NSString *subCatId in subCatIds) {
        NSMutableArray *record = [[MIDBManager getSharedInstance] fetchsingleRecords:subCatId];
        if (record.count>0)
            [self.subCategoryList addObject:record[0]];
    }
    
    //Get topic list by id. Get string of ids from database and convert into array
    self.topicList = [[NSMutableSet alloc] init];
    NSString *objtopiclistId =  dictObj[@"topiclistIds"];
    NSArray *topicslistIds = [objtopiclistId componentsSeparatedByString:@","];
    [[MIDBManager getSharedInstance] setStateSelectedTable:TOPIC_TABLE];
    for (NSString *subCatId in topicslistIds) {
        NSMutableArray *record = [[MIDBManager getSharedInstance] fetchsingleRecords:subCatId];
        if (record.count>0)
            [self.topicList addObject:record[0]];
    }
        return self;
}

-(void)deleteComment:(MIComments*)comment
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:COMMENTS_TABLE];
    [[MIDBManager getSharedInstance] deleteSingleRecords:comment.keyId];
}


-(void)updateSubCategoryList:(MISubCategory*)subCat
{
    NSString *subCatIds = self.subCategoryIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    [arrSubCat removeObject:subCat.subCatId];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    [self.subCategoryList removeObject:[arrSubCat filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"subCatId == %@",subCat.subCatId]]]];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET subCatIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS,subCatIds,self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

-(void)updateTopicList:(MITopic*)subCat
{
    NSString *subCatIds = self.topicListIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    [arrSubCat removeObject:subCat.topicid];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    [self.topicList removeObject:[arrSubCat filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"topicid == %@",subCat.topicid]]]];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET topiclistIds = '%@' WHERE keyId = '%@'" ,TABLE_TOPIC,subCatIds,self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

-(void)updateDealerList:(MIDealerSummary*)subCat
{
    NSString *subCatIds = self.dealerListIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"dealerlistIds == %@", subCat.masterNumber];

    NSArray *filteredArray = [self.dealerList.allObjects filteredArrayUsingPredicate:predicate];
    [self.dealerList removeObject:filteredArray[0]];
    
    [arrSubCat removeObject:subCat.masterNumber];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET dealerlistIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS,subCatIds,self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

//Insert Dealer list
-(void)insertDealerList:(MIDealerSummary*)subCat
{
    NSString *subCatIds = self.dealerListIds;
    NSMutableSet *arrSubCat = [NSMutableSet setWithArray:[[subCatIds componentsSeparatedByString:@","] mutableCopy]];
    
    [arrSubCat addObject:subCat.masterNumber];
    subCatIds = [[arrSubCat allObjects] componentsJoinedByString:@","];
    self.dealerListIds = subCatIds;
        
    [self.dealerList addObject:subCat];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET dealerlistIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS ,subCatIds,self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

@end
