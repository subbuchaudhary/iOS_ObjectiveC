//
//  GESwitch.h
//  MobileDesignSystem
//
//  Created  on 10/15/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import <UIKit/UIKit.h>

typedef enum {

    GESwitchTypeForms,
    GESwitchTypeSettings

} GESwitchType;

static const int kDefaultSwitchWidth = 58;
static const int kDefaultSwitchHeight = 28;

@interface GESwitch : UISlider

@property(nonatomic, getter=isOn) BOOL on;
@property(nonatomic)GESwitchType switchType;

- (void)setOn:(BOOL)on animated:(BOOL)animated;

@end
