//
//  GESwitch.m
//  MobileDesignSystem
//
//  Created  on 10/15/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import "GESwitch.h"

@interface GESwitch()
{
    float oneSlotSize;
    
    UIImage *onImage, *offImage;
    BOOL beganTracking;
    BOOL switchTapped;
}

@end

@implementation GESwitch

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        self.minimumValue = 0;
        self.maximumValue = 1;
        
        UIImage *sliderLeftTrackImage = [UIImage imageNamed: @"Forms_Slider_Track_left.png"];
        UIImage *sliderRightTrackImage = [UIImage imageNamed: @"Track_Off.png"];
        onImage = [[UIImage imageNamed:@"Forms_Thumbnail_On.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];
        offImage = [[UIImage imageNamed:@"Thumbnail_Off.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];
        
        [self setMinimumTrackImage:sliderLeftTrackImage forState: UIControlStateNormal];
        [self setMaximumTrackImage:sliderRightTrackImage forState: UIControlStateNormal];
        
        [self setThumbImage:offImage forState:UIControlStateNormal];
        [self setThumbImage:offImage forState:UIControlStateHighlighted];
        
        
        float sliderRange = self.frame.size.width - self.currentThumbImage.size.width;
        oneSlotSize = sliderRange/self.maximumValue;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(switchTapped:)];
        tap.numberOfTapsRequired = 1;
        tap.enabled = YES;
        tap.cancelsTouchesInView = NO;
        [self addGestureRecognizer:tap];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        self.minimumValue = 0;
        self.maximumValue = 1;
        
        UIImage *sliderLeftTrackImage = [UIImage imageNamed: @"Forms_Slider_Track_left.png"];
        UIImage *sliderRightTrackImage = [UIImage imageNamed: @"Switch_Track.png"];
        onImage = [[UIImage imageNamed:@"Forms_Thumbnail_On.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];
        offImage = [[UIImage imageNamed:@"Thumbnail_Off.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];
        
        [self setMinimumTrackImage:sliderLeftTrackImage forState: UIControlStateNormal];
        [self setMaximumTrackImage:sliderRightTrackImage forState: UIControlStateNormal];
        
        [self setThumbImage:offImage forState:UIControlStateNormal];
        [self setThumbImage:offImage forState:UIControlStateHighlighted];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(switchTapped:)];
        tap.numberOfTapsRequired = 1;
        tap.enabled = YES;
        tap.cancelsTouchesInView = NO;
        [self addGestureRecognizer:tap];
        
        float sliderRange = self.frame.size.width - self.currentThumbImage.size.width;
        oneSlotSize = sliderRange/self.maximumValue;
    }
    return self;
}

#pragma mark - Helper Methods

- (int)getSelectedIndexAtPoint:(CGPoint)pnt
{    
    float sliderOrigin = self.bounds.origin.x + (self.currentThumbImage.size.width / 2.0);
    
    float index = (pnt.x-sliderOrigin)/oneSlotSize;
    
    int rounded = round(index);
        
    if (rounded <= 0)
        return 0;
    else
        return 1;
}


#pragma mark - Tracking and Gesture

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event
{
    beganTracking = YES;
    return YES;
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event
{
    if (!switchTapped) {
        [super endTrackingWithTouch:touch withEvent:event];
        
        CGPoint currentLocation  = [touch locationInView:self];
        
        int selectedIndex = [self getSelectedIndexAtPoint:currentLocation];
        
       
        
        [self setOn:selectedIndex animated:YES];
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
    beganTracking = NO;
    switchTapped = NO;
}

- (void)switchTapped:(UIGestureRecognizer *)tap
{
    if (!beganTracking) {
        switchTapped = YES;
        [self setOn:!self.value animated:YES];
    }
}



#pragma mark - Public methods

- (BOOL)isOn
{
    return self.value;
}

- (void)setOn:(BOOL)on animated:(BOOL)animated
{
    [self setValue:on animated:animated];
    
    if (on) {
        [self setThumbImage:onImage forState:UIControlStateNormal];
        [self setThumbImage:onImage forState:UIControlStateHighlighted];
    }
    else {
        [self setThumbImage:offImage forState:UIControlStateNormal];
        [self setThumbImage:offImage forState:UIControlStateHighlighted];
    }
}

-(void)setSwitchType:(GESwitchType)switchType {

    _switchType = switchType;
    
    switch (switchType) {
        case GESwitchTypeForms:{
            UIImage *sliderLeftTrackImage = [[UIImage imageNamed: @"Forms_Slider_Track_Left.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0];
            [self setMinimumTrackImage: sliderLeftTrackImage forState: UIControlStateNormal];
            
            onImage = [[UIImage imageNamed:@"Forms_Thumbnail_On.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];

        
        }
            break;
            
        case GESwitchTypeSettings:{
            UIImage *sliderLeftTrackImage = [[UIImage imageNamed: @"Settings_Slider_Track_Left.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:0];
            [self setMinimumTrackImage: sliderLeftTrackImage forState: UIControlStateNormal];
            
            onImage = [[UIImage imageNamed:@"Settings_Thumbnail_On.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];
            offImage = [[UIImage imageNamed:@"Thumbnail_Off.png"] stretchableImageWithLeftCapWidth: 9 topCapHeight: 0];
            
            
        }
            break;
        default:
            break;
    }


}

@end
