//
//  GEColor.h
//  MobileDesignSystem
//
//  Created  on 10/4/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//



//Semantic Color Names

//Primary
#define GE_COLOR_GRAY               [UIColor colorWithRed:0.482 green:0.482 blue:0.482 alpha:1] //hex7b7979
#define GE_COLOR_BLUE               [UIColor colorWithRed:0.231 green:0.451 blue:0.725 alpha:1] //hex3b73b9
#define GE_COLOR_CYAN               [UIColor colorWithRed:0.031 green:0.647 blue:0.882 alpha:1] //hex08a5e1
#define GE_COLOR_PURPLE             [UIColor colorWithRed:0.443 green:0.075 blue:0.443 alpha:1] //hex711371


//Secondary
#define GE_COLOR_GRAY_SECONDARY     [UIColor colorWithRed:0.71 green:0.69 blue:0.69 alpha:1] //hex89abd5
#define GE_COLOR_BLUE_SECONDARY     [UIColor colorWithRed:0.537 green:0.671 blue:0.835 alpha:1] //hex89abd5
#define GE_COLOR_CYAN_SECONDARY     [UIColor colorWithRed:0.42 green:0.788 blue:0.929 alpha:1]  //hex6bc9ed
#define GE_COLOR_PURPLE_SECONDARY   [UIColor colorWithRed:0.662 green:0.451 blue:0.662 alpha:1] //hexa670a9

//GreyScale Set
#define GE_COLOR_CHROME             [UIColor colorWithRed:0.212 green:0.212 blue:0.212 alpha:1]
#define GE_COLOR_CHROME_80A           [UIColor colorWithRed:0.212 green:0.212 blue:0.212 alpha:.8]//hex363636
#define GE_COLOR_GRAY_DARK          [UIColor colorWithRed:0.36 green:0.36 blue:0.36 alpha:1]
#define GE_COLOR_GRAY_DARK_80A        [UIColor colorWithRed:0.36 green:0.36 blue:0.36 alpha:.8]
#define GE_COLOR_GROUND             [UIColor colorWithRed:0.855 green:0.843 blue:0.843 alpha:1] //hexdad7d7
#define GE_COLOR_GROUND_ACCENT      [UIColor colorWithRed:0.933 green:0.929 blue:0.925 alpha:1] //hexeeedec
#define GE_COLOR_GROUND_ACCENT_50A      [UIColor colorWithRed:0.933 green:0.929 blue:0.925 alpha:.5]
#define GE_COLOR_GROUND_ACCENT_2    [UIColor colorWithRed:0.968 green:0.964 blue:0.964 alpha:1] //hexf7f6f6 

//Accent / Attention Set

#define GE_COLOR_POS_ALERT          [UIColor colorWithRed:0.463 green:0.725 blue:0 alpha:1]     //hex76b900
#define GE_COLOR_POS_ALERT_ACCENT   [UIColor colorWithRed:0.678 green:0.835 blue:0.4 alpha:1]   //hexadd566
#define GE_COLOR_Neg_ALERT          [UIColor colorWithRed:0.933 green:0.2 blue:0.141 alpha:1]   //hexee3324
#define GE_COLOR_Neg_ALERT_ACCENT   [UIColor colorWithRed:0.961 green:0.522 blue:0.486 alpha:1] //hexf5857c 


//Notification Set

#define GE_COLOR_NOTIFICATION        [UIColor colorWithRed:0.929 green:0.502 blue:0 alpha:1]    //hexed8000
#define GE_COLOR_NOTIFICATION_ACCENT [UIColor colorWithRed:0.957 green:0.702 blue:0.4 alpha:1]  //hexf4b366




//General Color Names
#define GE_COLOR_BLUE_PRIMARY       [UIColor colorWithRed:0.086 green:0.427 blue:0.561 alpha:1]  //hex166d8f
#define GE_COLOR_CYAN_PRIMAY        [UIColor colorWithRed:0.031 green:0.647 blue:0.882 alpha:1] //hex08a5e1
#define GE_COLOR_CYAN_LIGHT         [UIColor colorWithRed:0.42 green:0.788 blue:0.929 alpha:1] //hex6bc9ed
#define GE_COLOR_BLUE_DARK          [UIColor colorWithRed:0.231 green:0.451 blue:0.725 alpha:1] //hex3b73b9
#define GE_COLOR_BLUE_LIGHT         [UIColor colorWithRed:0.537 green:0.671 blue:0.835 alpha:1] //hex89abd5
#define GE_COLOR_BLUE_INDICATOR     [UIColor colorWithRed:0.561 green:0.663 blue:0.839 alpha:1]
#define GE_COLOR_PURPLE_PRIMARY     [UIColor colorWithRed:0.443 green:0.075 blue:0.443 alpha:1]  //hex711371
#define GE_COLOR_PURPLE_LIGHT       [UIColor colorWithRed:0.662 green:0.451 blue:0.662 alpha:1]
#define GE_COLOR_RED_PRIMARY        [UIColor colorWithRed:0.933 green:0.2 blue:0.141 alpha:1]   //hexee3324
#define GE_COLOR_RED_LIGHT          [UIColor colorWithRed:0.961 green:0.522 blue:0.486 alpha:1]  //hexf5857c
#define GE_COLOR_ORANGE_PRIMARY     [UIColor colorWithRed:0.929 green:0.502 blue:0 alpha:1]  //hexed8000
#define GE_COLOR_ORANGE_LIGHT       [UIColor colorWithRed:0.957 green:0.702 blue:0.4 alpha:1] //hexf4b366
#define GE_COLOR_GREEN_PRIMARY      [UIColor colorWithRed:0.463 green:0.725 blue:0 alpha:1]  //hex76b900
#define GE_COLOR_GREEN_LIGHT        [UIColor colorWithRed:0.678 green:0.835 blue:0.4 alpha:1]  //hexadd566
#define GE_COLOR_GRAY_0             [UIColor colorWithRed:0.212 green:0.212 blue:0.212 alpha:1]  //hex363636
#define GE_COLOR_GRAY_1             [UIColor colorWithRed:0.482 green:0.475 blue:0.475 alpha:1] //#7b7979
#define GE_COLOR_GRAY_2             [UIColor colorWithRed:0.714 green:0.69 blue:0.69 alpha:1] //hexb6b0b0
#define GE_COLOR_GRAY_3             [UIColor colorWithRed:0.855 green:0.843 blue:0.843 alpha:1] //hexdad7d7
#define GE_COLOR_GRAY_4             [UIColor colorWithRed:0.933 green:0.929 blue:0.925 alpha:1] //hexeeedec

//Setting Cell Color
//#define GE_COLOR_GRAY_5          [UIColor colorWithRed:0.357 green:0.376 blue:0.380 alpha:1]

//Setting Background Color
#define GE_COLOR_GRAY_6          [UIColor colorWithRed:0.36 green:0.36 blue:0.36 alpha:1]

//Global Nav Background Color

#define GE_COLOR_GRAY_7          [UIColor colorWithRed:0.30 green:0.31 blue:0.32 alpha:1]

//Setting Button Underscore Color
//#define GE_COLOR_GRAY_7          [UIColor colorWithRed:0.753 green:0.753 blue:0.753 alpha:1]

//Tabular Data Background Colors
//#define GE_COLOR_GRAY_8          [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1]
//#define GE_COLOR_RED_CELL        [UIColor colorWithRed:0.898 green:0.188 blue:0.235 alpha:1]

//#define GE_COLOR_White          [UIColor colorWithRed:0.944 green:0.435 blue:0.024 alpha:1]

#define GE_COLOR_WHITE           [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0]
#define GE_COLOR_WHITE_80A       [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:.8]
#define GE_COLOR_WHITE_20A       [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.2]

#define GE_COLOR_GREEN_CHART       [UIColor colorWithRed:.854 green:.905 blue:.882 alpha:1]




//GEGridDetail colors
//#define GE_COLOR_BLUE_DETAIL     [UIColor colorWithRed:0.322 green:0.631 blue:0.882 alpha:1.0]
