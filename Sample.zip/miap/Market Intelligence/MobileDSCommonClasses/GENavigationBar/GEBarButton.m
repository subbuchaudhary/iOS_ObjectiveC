//
//  GEBarButton.m
//  NavigationBarTest
//
//  Created  on 11/1/12.
//  Copyright (c) 2012 Andrew HunzekerHesed. All rights reserved.
//

#import "GEBarButton.h"
#import "GEColor.h"

@implementation GEBarButton

@synthesize button;

- (id)initWithFrame:(CGRect)frame andType:(GEBarButtonType)buttonType
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, frame.size.width,frame.size.height);
        UIEdgeInsets imageInsets = UIEdgeInsetsMake(-5, 0, 0, 0);
        UIImage *buttonImage;
        UIImage *disabledImage;
        switch (buttonType) {
            case GEBarButtonSettings:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonSettings.png"];
                break;
            case GEBarButtonFavorites:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonFavorites.png"];
                break;
            case GEBarButtonSearch:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonSearch.png"];
                break;
            case GEBarButtonSymbol:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonSearch.png"];
            break;
                
            case GEBarButtonAlert:
                buttonImage = [UIImage imageNamed:@"GENavBarAlert.png"];
                button.backgroundColor = GE_COLOR_ORANGE_PRIMARY;
            break;
            case GEBarButtonAdd:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonAdd.png"];
                break;
            case GEBarButtonFilter:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonFilter.png"];
                break;
            case GEBarButtonSlider:
                buttonImage = [UIImage imageNamed:@"GENavBarSlideButton.png"];
                break;
            case GEBarButtonLeft:
                buttonImage = [UIImage imageNamed:@"GESearchArrowLeftNormal.png"];
                disabledImage = [UIImage imageNamed:@"GESearchArrowLeftDisabled.png"];
                [button setImage:disabledImage forState:UIControlStateDisabled];
                imageInsets = UIEdgeInsetsMake(0, 0, 0, 0);
                break;
            case GEBarButtonRight:
                buttonImage = [UIImage imageNamed:@"GESearchArrowRightNormal.png"];
                disabledImage = [UIImage imageNamed:@"GESearchArrowRightDisabled.png"];
                [button setImage:disabledImage forState:UIControlStateDisabled];
                imageInsets = UIEdgeInsetsMake(0, 0, 0, 0);
                break;
            
            case GEBarButtonClose:
                buttonImage = [UIImage imageNamed:@"GENavBarClose.png"];
                imageInsets = UIEdgeInsetsMake(0, 0, 0, 0);
                break;
            
            case GEBarButtonShare:
                buttonImage = [UIImage imageNamed:@"GENavBarOpenLink.png"];
                imageInsets = UIEdgeInsetsMake(0, 0, 0, 0);
                break;
            case GEBarButtonAccount:
                buttonImage = [UIImage imageNamed:@"GENavBarAccount.png"];
                imageInsets = UIEdgeInsetsMake(0, 0, 0, 0);
                break;
                
            default:
                buttonImage = [UIImage imageNamed:@"GENavBarButtonSettings.png"];
                break;
        }
               
                [button setImage:buttonImage forState:UIControlStateNormal];
                [button setImage:buttonImage forState:UIControlStateHighlighted];
        button.imageEdgeInsets = imageInsets;
       
        [button addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchDown];
        [button addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchUpOutside];
        [button addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        
        rule = [[UIView alloc]initWithFrame:CGRectMake(10, 38, 25, 1)];
        rule.backgroundColor = GE_COLOR_GROUND_ACCENT_50A;
        [self addSubview:rule];
        
        self.backgroundColor = [UIColor clearColor];
        
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame andText:(NSString *)string
{
    self = [super initWithFrame:frame];
    if (self) {
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        
        CGSize maximumSize = CGSizeMake(9999, frame.size.height);
        CGSize myStringSize = [[string uppercaseString] sizeWithFont:[UIFont fontWithName:@"GEInspira-ExtraBold" size:12.0]
                                     constrainedToSize:maximumSize
                                         lineBreakMode:NSLineBreakByTruncatingTail];
        CGFloat touchWidth;
        UIEdgeInsets textInsets;
        if(myStringSize.width < 44){
            touchWidth = 44;
            CGFloat touchWidthDiff = myStringSize.width - touchWidth;
            textInsets = UIEdgeInsetsMake(0, touchWidthDiff, 0,0);
        }else{
            touchWidth = myStringSize.width;
            textInsets = UIEdgeInsetsZero;
        }
        self.buttonTextSize = CGSizeMake(touchWidth, myStringSize.height);
        
        self.frame = CGRectMake(frame.origin.x, frame.origin.y, touchWidth, frame.size.height);
        button.frame = CGRectMake(0, 0, touchWidth,frame.size.height);
        button.titleEdgeInsets = textInsets;
        button.titleLabel.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:12.0];
        button.titleLabel.textColor = GE_COLOR_WHITE;
        button.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        
        [button setTitle:[string uppercaseString] forState:UIControlStateNormal];
        [button setTitleColor:GE_COLOR_GRAY forState:UIControlStateDisabled];
        [button addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchDown];
        [button addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchUpOutside];
        [button addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        
        rule = [[UIView alloc]initWithFrame:CGRectMake(0, 38, myStringSize.width, 1)];
        rule.backgroundColor = GE_COLOR_GROUND_ACCENT_50A;
        [self addSubview:rule];
        
        self.backgroundColor = [UIColor clearColor];
        
    }
    return self;
}

-(void)addTarget:(id)target action:(SEL)selector forControlEvent:(UIControlEvents)controlEvent{
    [button addTarget:target action:selector forControlEvents:controlEvent];

    
}

-(void)dimRule{
    if([rule.backgroundColor isEqual:GE_COLOR_GROUND_ACCENT_50A]){
        rule.backgroundColor = GE_COLOR_GROUND;
    
    } else{
        rule.backgroundColor = GE_COLOR_GROUND_ACCENT_50A;
    }

}


- (UIImage*) imageWithImage:(UIImage*) source fixedHue:(CGFloat) hue alpha:(CGFloat) alpha;
// Note: the hue input ranges from 0.0 to 1.0, both red.  Values outside this range will be clamped to 0.0 or 1.0.
{
    // Find the image dimensions.
    CGSize imageSize = [source size];
    CGRect imageExtent = CGRectMake(0,0,imageSize.width,imageSize.height);
    
    // Create a context containing the image.
    UIGraphicsBeginImageContext(imageSize);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [source drawAtPoint:CGPointMake(0,0)];
    
    // Draw the hue on top of the image.
    CGContextSetBlendMode(context, kCGBlendModeHue);
    [[UIColor colorWithHue:hue saturation:1.0 brightness:1 alpha:alpha] set];
    UIBezierPath *imagePath = [UIBezierPath bezierPathWithRect:imageExtent];
    [imagePath fill];
    
    // Retrieve the new image.
    UIImage *result = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return result;
}

@end
