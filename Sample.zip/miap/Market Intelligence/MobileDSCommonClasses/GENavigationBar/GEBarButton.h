//
//  GEBarButton.h
//  NavigationBarTest
//
//  Created  on 11/1/12.
//  Copyright (c) 2012 Andrew HunzekerHesed. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger, GEBarButtonType) {
    GEBarButtonSettings,
    GEBarButtonFavorites,
    GEBarButtonSearch,
    GEBarButtonSymbol,
    GEBarButtonAlert,
    GEBarButtonAdd,
    GEBarButtonText,
    GEBarButtonFilter,
    GEBarButtonSlider,
    GEBarButtonLeft,
    GEBarButtonRight,
    GEBarButtonClose,
    GEBarButtonShare,
    GEBarButtonAccount
};

@interface GEBarButton : UIView{
    UIView *rule;
}

@property(nonatomic, strong) UIButton *button;
@property(nonatomic, strong) NSString *buttonImageName;
@property(nonatomic) CGSize buttonTextSize;


- (id)initWithFrame:(CGRect)frame andType:(GEBarButtonType)buttonType;
- (id)initWithFrame:(CGRect)frame andText:(NSString *)string;

-(void)addTarget:(id)target action:(SEL)selector forControlEvent:(UIControlEvents)controlEvent;

@end
