//
//  GESlider.h
//  GESlider
//
//  Created  on 10/3/12.
//  Copyright (c) 2012 Eric Cerney. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {

    //defaults to Forms
    GESliderTypeForms,
    GESliderTypeSettings
    
}GESliderType;

@interface GESlider : UISlider

@property (nonatomic)GESliderType sliderType;

- (id)initWithFrame:(CGRect)frame Titles:(NSArray *)titles;
- (id)initWithFrame:(CGRect)frame Titles:(NSArray *)titles LeftImage:(UIImage *)leftImage RightImage:(UIImage *)rightImage;

- (void)initWithTitles:(NSArray *)titles;

@end
