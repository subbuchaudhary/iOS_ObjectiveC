//
//  GEBlankViewController.m
//  MobileDesignSystem
//
//  Created  on 12/18/12.
//  Copyright (c) 2012 Monsoon Co. All rights reserved.
//

#import "GEBlankViewController.h"

@interface GEBlankViewController ()

@end

@implementation GEBlankViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
