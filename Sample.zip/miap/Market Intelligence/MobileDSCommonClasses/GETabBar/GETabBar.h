//
//  GETabBar.h
//  CustomTabBar
//
//  Created  on 10/24/12.
//
//

#import <UIKit/UIKit.h>


@class GETabBar;
@protocol GETabBarDelegate

@optional
- (void) touchUpInsideItemAtIndex:(NSUInteger)itemIndex;
- (void) touchDownAtItemAtIndex:(NSUInteger)itemIndex;
@end


@interface GETabBar : UIView
{
  
    NSArray *tabBarItems;
    NSMutableArray* tabBarItemViews;
    NSMutableArray* buttons;
    NSMutableArray* labels;
    UIView* backgroundView;
}


@property (nonatomic, strong) NSMutableArray* tabBarItemViews;
@property (nonatomic, strong) NSMutableArray* buttons;
@property (nonatomic, strong) NSMutableArray* labels;
@property (nonatomic, strong) UIColor *accentColor;
@property (nonatomic, weak) NSObject <GETabBarDelegate> *delegate;


- (id) initWithItems:(NSArray *)Items  itemSize:(CGSize)itemSize tag:(NSInteger)objectTag delegate:(NSObject <GETabBarDelegate>*)GETabBarDelegate andColor:(UIColor *)GEColor;

- (void) selectItemAtIndex:(NSInteger)index;

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration;

@end
