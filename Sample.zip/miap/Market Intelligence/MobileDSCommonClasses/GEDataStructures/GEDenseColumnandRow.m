//
//  GEDenseColumnandRow.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseColumnandRow.h"

@implementation GEDenseColumnandRow

- (id)initWithColumn:(int)column andRow:(int)row
{
    self = [super init];
    
    if (self) {
        self.column = column;
        self.row = row;
    }
    return self;
}

-(BOOL)isEqual:(GEDenseColumnandRow*)coord
{
    BOOL result = NO;
    if (self.row == coord.row && self.column == coord.column) {
        result = YES;
    }
    return result;

}

@end