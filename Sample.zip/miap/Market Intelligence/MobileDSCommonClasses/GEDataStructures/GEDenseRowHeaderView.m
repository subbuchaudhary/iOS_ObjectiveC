//
//  GEDenseRowHeaderView.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseRowHeaderView.h"

@implementation GEDenseRowHeaderView{
    float rowHeight;
    UIView *selectedBackground;

}

@synthesize isSelected = _isSelected;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithframe:(CGRect)frame DataRowTitle:(GEDenseCell*)rowHeaderCell{
    
    self = [super initWithFrame:frame];
    
    if(self){
        NSInteger headerFontSize;
        float cellWidthPadding;
        float margin;
        float actionSize;
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
        {
            headerFontSize = 16;
            cellWidthPadding = 40;
            rowHeight = 37;
            margin = 22;
            actionSize = 6;
        
           
        }else{
            headerFontSize = 12;
            cellWidthPadding = 30;
            margin = 20;
            rowHeight = 24;
            actionSize = 3;
            
        }
        
        GELabel *tempLabel = [[GELabel alloc] initWithFont:GE_Inspira_Bold Size:headerFontSize andColor:GE_COLOR_BLUE_DARK];
        //get column headers and set position
        
        NSString *text = rowHeaderCell.title;
        float labelWidth = [self widthOfCellFromText:text Label:tempLabel] + cellWidthPadding;
        
        tempLabel.frame = CGRectMake(0, 0, labelWidth, rowHeight);
        tempLabel.textAlignment = NSTextAlignmentLeft;
        tempLabel.text = text;
        
        selectedBackground = [[UIView alloc]initWithFrame:CGRectMake(actionSize, 0, self.frame.size.width, self.frame.size.height)];
        selectedBackground.backgroundColor = GE_COLOR_WHITE;
        selectedBackground.alpha = 0.0;
        [self addSubview:selectedBackground];
        
        self.selectionButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        self.selectionButton.frame = CGRectMake(actionSize, 0, self.frame.size.width, self.frame.size.height);
        [self.selectionButton setTitleColor:GE_COLOR_BLUE_DARK forState:UIControlStateNormal];
        [self.selectionButton setTitle:rowHeaderCell.title forState:UIControlStateNormal];
        self.selectionButton.titleLabel.font = tempLabel.font;
        self.selectionButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        self.selectionButton.titleLabel.textAlignment = NSTextAlignmentLeft;
        self.selectionButton.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, 0);
        

        //calculate text size to place sort indicators
        
        [self addSubview:self.selectionButton];
        
        
    }
    return self;
    
}

-(void)setIsSelected:(BOOL)__isSelected
{
    
    _isSelected = __isSelected;
    if(_isSelected){
        selectedBackground.alpha = 1.0;
    }else{
        selectedBackground.alpha = 0.0;
        
    }
    
}

#pragma mark helper functions

- (float)widthOfCellFromText:(NSString *)text Label:(GELabel *)label
{
    CGSize maximumSize = CGSizeMake(9999, rowHeight+1);
    CGSize myStringSize = [text sizeWithFont:label.font
                           constrainedToSize:maximumSize
                               lineBreakMode:label.lineBreakMode];
    
    return myStringSize.width;
}



@end
