//
//  GEDenseTabularDataLayout.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import <UIKit/UIKit.h>

@interface GEDenseTabularDataLayout : UICollectionViewLayout <UICollectionViewDelegateFlowLayout>
@property (nonatomic, strong)NSArray *widthArray;
@property (nonatomic, strong)NSMutableArray *xArray;
@property (nonatomic) float height;


-(id)initWithWidthArray:(NSArray*)widths andHeight:(float)height;
@end
