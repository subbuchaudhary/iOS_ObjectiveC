//
//  GEDenseSelectionView.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseSelectionView.h"

@implementation GEDenseSelectionView{
    UIButton *leftHandle;
    UIButton *rightHandle;
    UIButton *topHandle;
    UIButton *bottomHandle;
    UIButton *topLeftHandle;
    UIButton *bottomRightHandle;
    UIImage* handleDot;
    CGRect initialButtonFrame;
    GESelectionType currentType;
    CGRect initialFrame;
    CGRect lastSnap;
    float contentScrollViewPadding;

}

@synthesize selectedSortButton = _selectedSortButton;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame andSelectionType:(GESelectionType)type{

    self = [super initWithFrame:frame];
    if (self) {
        //set image based on idiom
        float maskSize;
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
        {
            handleDot = [UIImage imageNamed:@"GEDenseData_iPad_BlueCircleL.png"];
            maskSize = 7;
            contentScrollViewPadding = 10;
        } else{
            handleDot = [UIImage imageNamed:@"GEDenseData_iPhone_BlueCircle.png"];
            maskSize = 4.5;
            contentScrollViewPadding = 10;
        }
        currentType = type;

        
        initialFrame = frame;
        
        CGRect biggerFrame = self.frame;
        biggerFrame.origin.x -= 20;
        biggerFrame.size.width += 40;
        biggerFrame.origin.y -= 20;
        biggerFrame.size.height += 40;
        
        self.frame = biggerFrame;
       
        

        self.outline = [[UIView alloc]initWithFrame:CGRectMake(20, 20, frame.size.width, frame.size.height)];
        self.outline.layer.borderColor = GE_COLOR_BLUE_LIGHT.CGColor;
        self.outline.layer.borderWidth = 2.0f;
       
        
        [self addSubview:self.outline];
        
        if (type == GESelectionTypeColumn) {
            
            self.autoresizingMask = UIViewAutoresizingFlexibleHeight;
            self.outline.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

            
            
            leftHandle = [UIButton buttonWithType:UIButtonTypeCustom];
            leftHandle.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
            leftHandle.frame = CGRectMake(10, (self.outline.frame.size.height/2) - (handleDot.size.height/2), 40, 40);
            leftHandle.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 10);
            [leftHandle setImage:handleDot forState:UIControlStateNormal];
            [leftHandle addTarget:self action:@selector(handleGrab:withEvent:) forControlEvents:UIControlEventTouchDragInside | UIControlEventTouchDragOutside];
            [leftHandle addTarget:self action:@selector(endDragging:withEvent:) forControlEvents:UIControlEventTouchUpOutside];
            [self addSubview:leftHandle];
            
            rightHandle = [UIButton buttonWithType:UIButtonTypeCustom];
            rightHandle.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
            rightHandle.frame = CGRectMake((self.outline.frame.size.width) - 10, (self.outline.frame.size.height/2) - (handleDot.size.height/2), 40, 40);
            [rightHandle setImage:handleDot forState:UIControlStateNormal];
            rightHandle.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10);
            [rightHandle addTarget:self action:@selector(handleGrab:withEvent:) forControlEvents:UIControlEventTouchDragOutside |
             UIControlEventTouchDragInside];
            [rightHandle addTarget:self action:@selector(endDragging:withEvent:) forControlEvents: UIControlEventTouchUpOutside];

            
            [self addSubview:rightHandle];

        }else if(type == GESelectionTypeRow) {
            
            self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            self.outline.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            topHandle = [UIButton buttonWithType:UIButtonTypeCustom];
            topHandle.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
            topHandle.frame = CGRectMake((self.outline.frame.size.width/2)-(handleDot.size.width/2),  0, 40, 40);
            

            [topHandle setImage:handleDot forState:UIControlStateNormal];
            [topHandle addTarget:self action:@selector(handleGrab:withEvent:) forControlEvents:UIControlEventTouchDragOutside |
             UIControlEventTouchDragInside];
            [topHandle addTarget:self action:@selector(endDragging:withEvent:) forControlEvents: UIControlEventTouchUpOutside];
            [self addSubview:topHandle];
            
            bottomHandle = [UIButton buttonWithType:UIButtonTypeCustom];
            bottomHandle.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
            bottomHandle.frame = CGRectMake((self.outline.frame.size.width/2)-(handleDot.size.width/2), self.outline.frame.size.height, 40, 40);
            

            [bottomHandle setImage:handleDot forState:UIControlStateNormal];
            [bottomHandle addTarget:self action:@selector(handleGrab:withEvent:) forControlEvents:UIControlEventTouchDragOutside |
             UIControlEventTouchDragInside];
            [bottomHandle addTarget:self action:@selector(endDragging:withEvent:) forControlEvents: UIControlEventTouchUpOutside];
            [self addSubview:bottomHandle];
            
            //shift frame to the right
            CGRect newFrame = self.frame;
            newFrame.size.width += 6;
            self.frame = newFrame;
        
        
        } else if (type == GESelectionTypeCell)
        {
            self.autoresizingMask = UIViewAutoresizingNone;
            self.outline.autoresizingMask = UIViewAutoresizingNone;
            self.autoresizesSubviews = YES;
            topLeftHandle = [UIButton buttonWithType:UIButtonTypeCustom];
 
            topLeftHandle.frame = CGRectMake(10, 10, 40, 40);
            topLeftHandle.imageEdgeInsets = UIEdgeInsetsMake(-10, -10, 10, 10);

 
            [topLeftHandle setImage:handleDot forState:UIControlStateNormal];
           [topLeftHandle addTarget:self action:@selector(cellHandleGrab:withEvent:) forControlEvents:UIControlEventTouchDragOutside | UIControlEventTouchDragInside];

            [topLeftHandle addTarget:self action:@selector(endDragging:withEvent:) forControlEvents: UIControlEventTouchUpOutside];
            [topLeftHandle addTarget:self action:@selector(resetMask) forControlEvents: UIControlEventTouchUpOutside | UIControlEventTouchUpInside];

            [self addSubview:topLeftHandle];
            
            bottomRightHandle = [UIButton buttonWithType:UIButtonTypeCustom];

            bottomRightHandle.frame = CGRectMake(self.outline.frame.size.width, self.outline.frame.size.height, 40, 40);

            [bottomRightHandle setImage:handleDot forState:UIControlStateNormal];
           
            [bottomRightHandle addTarget:self action:@selector(cellHandleGrab:withEvent:) forControlEvents:UIControlEventTouchDragOutside | UIControlEventTouchDragInside];
            [bottomRightHandle addTarget:self action:@selector(endDragging:withEvent:) forControlEvents: UIControlEventTouchUpOutside];
            [bottomRightHandle addTarget:self action:@selector(resetMask) forControlEvents: UIControlEventTouchUpOutside | UIControlEventTouchUpInside];
            [self addSubview:bottomRightHandle];
        
        
        
        }
        
        UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        [tapRecognizer setNumberOfTapsRequired:1];
        [self addGestureRecognizer:tapRecognizer];
        
        
        //add viewSelection Masking
        self.selectionMask = [[UIView alloc]initWithFrame:CGRectMake(20, 20, frame.size.width, frame.size.height)];
        
        self.selectionMask.clipsToBounds = YES;
        if (type != GESelectionTypeCell) {
             self.selectionMask.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        }
       
        self.selectionMask.autoresizesSubviews = YES;
        UIView *upperMask = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.selectionMask.frame.size.width, maskSize)];
        upperMask.backgroundColor = GE_COLOR_WHITE;
        upperMask.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [self.selectionMask addSubview:upperMask];
        
        UIView *rightMask = [[UIView alloc] initWithFrame:CGRectMake(self.selectionMask.frame.size.width - maskSize,maskSize, maskSize, self.selectionMask.frame.size.height - maskSize)];
        rightMask.backgroundColor = GE_COLOR_WHITE;
        rightMask.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleLeftMargin;
        [self.selectionMask addSubview:rightMask];
        
        UIView *bottomMask = [[UIView alloc] initWithFrame:CGRectMake(maskSize, self.selectionMask.frame.size.height - maskSize, self.selectionMask.frame.size.width, maskSize)];
        bottomMask.backgroundColor = GE_COLOR_WHITE;
        bottomMask.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
        [self.selectionMask addSubview:bottomMask];
        
        UIView *leftMask = [[UIView alloc] initWithFrame:CGRectMake(0, maskSize, maskSize, self.selectionMask.frame.size.height - (maskSize))];
        leftMask.backgroundColor = GE_COLOR_WHITE;
        leftMask.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleRightMargin;
        [self.selectionMask addSubview:leftMask];
        
        
        self.selectionMask.userInteractionEnabled = NO;
        
        [self addSubview:self.selectionMask];
        [self sendSubviewToBack:self.selectionMask];
        //hide masks
        self.selectionMask.alpha = 1.0;
        self.autoresizesSubviews = YES;
        
    
    }
    return self;



}

-(void)snapToNewFrame:(CGRect)newFrame{
    
    self.frame = newFrame;

    CGRect biggerFrame = self.frame;
    biggerFrame.origin.x -= (contentScrollViewPadding * 2);
    biggerFrame.size.width += 40;
    biggerFrame.origin.y -= (contentScrollViewPadding *2);
    biggerFrame.size.height += 40;
    
    self.frame = biggerFrame;
    self.outline.frame = CGRectMake(20, 20, self.frame.size.width - 40, self.frame.size.height - 40);
    self.selectionMask.frame = self.outline.frame;
    
    bottomRightHandle.frame = CGRectMake(self.outline.frame.size.width, self.outline.frame.size.height, 40, 40);
    rightHandle.frame = CGRectMake(self.outline.frame.size.width - 10, (self.outline.frame.size.height/2) - (handleDot.size.height/2), 40, 40);
    bottomHandle.frame =  bottomHandle.frame = CGRectMake((self.outline.frame.size.width/2)-(handleDot.size.width/2), self.outline.frame.size.height, 40, 40);
    

    lastSnap = newFrame;
    
}

#pragma mark Actions

- (void)endDragging:(id)sender withEvent: (UIEvent *) ev
{
    self.selectionMask.alpha = 1.0;
    self.outline.alpha = 1.0;
    self.outline.frame = CGRectMake(20, 20, self.frame.size.width - 40, self.frame.size.height - 40);
    
    topLeftHandle.frame = CGRectMake(10, 10, 40, 40);
    rightHandle.frame = CGRectMake(self.outline.frame.size.width -10, (self.outline.frame.size.height/2) - (handleDot.size.height/2), 40, 40);
    bottomHandle.frame =  bottomHandle.frame = CGRectMake((self.outline.frame.size.width/2)-(handleDot.size.width/2), self.outline.frame.size.height, 40, 40);
    
 
}


-(void)resetMask{
    self.autoresizingMask = UIViewAutoresizingNone;
    self.outline.autoresizingMask = UIViewAutoresizingNone;
    self.selectionMask.autoresizingMask = UIViewAutoresizingNone;

}

-(void)handleGrab:(id)sender withEvent: (UIEvent *) ev
{

[self.delegate GEDenseSelector:self didRecieveDragEvent:ev];
    
}




-(void)cellHandleGrab:(id)sender withEvent: (UIEvent *) ev
{
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.selectionMask.autoresizingMask= UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.outline.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.delegate GEDenseSelector:self didRecieveDragEvent:ev];


}




-(void)tapAction:(UIGestureRecognizer*)sender{
    
    CGPoint superTapPoint = [sender locationInView:self.superview];
    
    [self.delegate GEDenseSelector:self didRecieveTapAtPointinSuperView:superTapPoint];
    
    
}



- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    // UIView will be "transparent" for touch events if we return NO
    BOOL result;

    if ((point.x > 20 && point.x < self.frame.size.width - 20) || (point.x < 0 || point.x > self.frame.size.width)){
    
        if ((point.y > 20 && point.y < self.frame.size.height - 20) || (point.y < 0 || point.y > self.frame.size.height)){
            result = NO;
        }else{
            result = YES;
        }

    
    }else{
        return YES;
}


    
    return result;
}

@end
