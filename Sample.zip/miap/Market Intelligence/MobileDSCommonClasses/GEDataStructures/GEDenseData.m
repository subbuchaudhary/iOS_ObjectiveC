//
//  GEDenseData.m
//  MobileDesignSystem
//
//  Created  on 11/6/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
#import "GEDenseData.h"

/*
 * GEDenseData Implementation methods
 */
@implementation GEDenseData
@synthesize rowArray = _rowArray;

- (id)initWithColumnTitles:(NSArray *)titles Rows:(NSArray *)rows
{
    self = [super init];
    
    if (self) {
        self.columnTitlesArray = titles;
        self.rowArray = rows;
        [self givePositionInfo];
    }
    return self;
}


-(NSMutableArray*)searchDataForString:(NSString *)string{
    
    NSMutableArray *results = [[NSMutableArray alloc]init];
    
    //search Titles
    for (GEDenseCell *columnHeader in self.columnTitlesArray){
        NSString *title = columnHeader.title;
        if ([title rangeOfString:string options:NSCaseInsensitiveSearch].location != NSNotFound) {
            [results addObject:columnHeader];
        }
    
    }
    
    //searchRows
    
    for (GEDenseRow *row in self.rowArray) {
        
        NSString *title = row.header.title;
        if ([title rangeOfString:string options:NSCaseInsensitiveSearch].location != NSNotFound) {
            [results addObject:row.header];
        }
        
    }
    
    for (GEDenseRow *row in self.rowArray) {

        for (GEDenseCell *contentCell in row.cellArray){
            NSString *title = contentCell.title;
            if ([title rangeOfString:string options:NSCaseInsensitiveSearch].location != NSNotFound) {
                [results addObject:contentCell];
                }
        }
    }
    

    return results;
    
}

-(void)givePositionInfo
{
    for(NSInteger i =0; i < self.rowArray.count; i++)
    {
        GEDenseRow *row = self.rowArray[i];
        for (NSInteger j = 0; j < row.cellArray.count; j++) {
            GEDenseCell* cell = row.cellArray[j];
            cell.row = i;
            cell.column = j;
        }
        
    }

    
}

//setter for row array to reset position info

-(void)setRowArray:(NSArray *)rA
{
    _rowArray = rA;
    [self givePositionInfo];


}



@end

