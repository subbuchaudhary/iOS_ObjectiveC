//
//  CategoryViewController.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/14/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CategoryViewController.h"
#import "CategoryCell.h"
#import "SubCategoryViewCell.h"
#import "TopicViewCell.h"
#import "SurveyCategory.h"
#import "SubCategory.h"
#import "Topic.h"
#import "BaseCategory+BaseCategoryCustom.h"

@interface CategoryViewController ()

@end

@implementation CategoryViewController
@synthesize superCategory;
@synthesize title;
@synthesize delegate;
@synthesize comment;

static NSString* TOPIC_CELL = @"TopicViewCell";
static NSString* CATEGORY_CELL = @"CategoryViewCell";
static NSString* SUB_CATEGORY_CELL = @"SubCategoryViewCell";


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (displayedHierarchyObjects == nil)
    {
        displayedHierarchyObjects = [[NSMutableArray alloc] initWithArray:superCategory.categorylist.allObjects];
    }
    
    self.categoryTable.tableFooterView = [[UIView alloc] init];
    UINib* cellNib = [UINib nibWithNibName:CATEGORY_CELL bundle:nil];
    [self.categoryTable registerNib:cellNib forCellReuseIdentifier:CATEGORY_CELL];
    
    UINib* subCategoryCellNib = [UINib nibWithNibName:SUB_CATEGORY_CELL bundle:nil];
    [self.categoryTable registerNib:subCategoryCellNib forCellReuseIdentifier:SUB_CATEGORY_CELL];
    
    UINib* topicNib = [UINib nibWithNibName:TOPIC_CELL bundle:nil];
    [self.categoryTable registerNib:topicNib forCellReuseIdentifier:TOPIC_CELL];
    
    
    // Set title of controller
    UILabel *label = [[UILabel alloc] init ];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:@"GEInspira-Bold" size:17.0];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor]; // change this color
    self.navigationItem.titleView = label;
    label.text = superCategory.superCatName;
    [label sizeToFit];
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"GE Inspira Medium" size:14], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
}

- (void) viewWillAppear:(BOOL)animated
{
    // Check if we are displyaing same SuperCategory as already selected
    if ((comment.superCategory != nil) && ([self.superCategory.superCatName isEqualToString:comment.superCategory.superCatName]))
    {
        if ((comment.subCategoryList != Nil) && (comment.subCategoryList.allObjects.count > 0))
        {
            subCategoryList = [[NSMutableArray alloc] initWithArray:comment.subCategoryList.allObjects];
            expandedCategory = ((MISubCategory*)[subCategoryList objectAtIndex:0]).getParentCategory;
        }
        else
        {
            subCategoryList = [[NSMutableArray alloc] init];
        }
        
        if ((comment.topicList != nil) && (comment.topicList.count > 0))
        {
            topicList = [[NSMutableArray alloc] initWithArray:comment.topicList.allObjects];
            MITopic* topic = [topicList objectAtIndex:0];
            expandedCategory = topic.getTopicParentCategory.getParentCategory;
            expandedSubCategory = topic.getTopicParentCategory;
            
        }
        else
        {
            topicList = [[NSMutableArray alloc] init];
        }
        if (comment.category != Nil)
            selectedCategory = comment.category;
        [self setDisplayHierarchy];
    }


    if (subCategoryList == nil)
        subCategoryList = [[NSMutableArray alloc] init];
    if (topicList == nil)
        topicList = [[NSMutableArray alloc] init];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [displayedHierarchyObjects count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoryHierarchyCell* cell = nil;
    MIBaseCategory* category = [displayedHierarchyObjects objectAtIndex:indexPath.row];
    
    Boolean selectCell = NO;
    if (
        (selectedCategory == category) ||
        ([subCategoryList containsObject:category]) ||
        ([topicList containsObject:category]))
        selectCell = YES;
    
    if ([category isKindOfClass:[MICategory class]])
    {
        cell = [_categoryTable dequeueReusableCellWithIdentifier:CATEGORY_CELL forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[CategoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CATEGORY_CELL];
        }
        if (selectedCategory == category)
            selectCell = YES;

    }
    if ([category isKindOfClass:[MISubCategory class]] )
    {
        cell = [_categoryTable dequeueReusableCellWithIdentifier:SUB_CATEGORY_CELL forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[SubCategoryViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SUB_CATEGORY_CELL];
        }
        if ([subCategoryList containsObject:category])
        {
            selectCell = YES;
        }
        
    }
    if ([category isKindOfClass:[MITopic class]] )
    {
        cell = [_categoryTable dequeueReusableCellWithIdentifier:TOPIC_CELL forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[TopicViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TOPIC_CELL];
        }
        if ([topicList containsObject:category])
            selectCell = YES;
    }
    
    cell.parentController = self;
    [cell configureWithHierarchy: category];
    
    if (selectCell)
        [cell selectCategory];
    
    if ((category == expandedCategory) || (category == expandedSubCategory))
    {
        [cell hideExpand];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


-(IBAction) cancel:(UIBarButtonItem*) sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)doneClicked:(id)sender {

    MICategory* category ;
    if (selectedCategory != nil)
        category = selectedCategory;
    else
    {
        if ((subCategoryList.count == 0) && (topicList.count == 0))
        {
            UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"None selected." message:@"You must select at least one category to proceed." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            [alert show];
            return;
        }
    }
    [delegate categoryDataSelected:category subCategoryList:subCategoryList topicList:topicList];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) selectObject: (MIBaseCategory*) category
{
    BOOL reset = NO;
    if ([category isKindOfClass:[MICategory class]])
    {
        selectedCategory = (MICategory*) category;
        if ((subCategoryList.count != 0 ) &&
            ([[subCategoryList objectAtIndex:0] getParentCategory] != selectedCategory))
        {
            [subCategoryList removeAllObjects];
            [topicList removeAllObjects];
        }
        
        if (topicList.count != 0)
        {
            MITopic* topic = [topicList objectAtIndex:0];
            MICategory* currentSelectedParent = [[topic getTopicParentCategory] getParentCategory];
            
            if (currentSelectedParent != selectedCategory)
            {
                [subCategoryList removeAllObjects];
                [topicList removeAllObjects];
            }
        
        }
            
    }
    if ([category isKindOfClass:[MISubCategory class]])
    {
        MISubCategory* subCategory = (MISubCategory*) category;

        
        if ((subCategoryList.count != 0 ) &&
            ([[subCategoryList objectAtIndex:0] getParentCategory] != [subCategory getParentCategory]))
        {
            [subCategoryList removeAllObjects];
            [topicList removeAllObjects];
            selectedCategory = nil;
        }
        if (topicList.count != 0)
        {
            MITopic* topic = [topicList objectAtIndex:0];
            MICategory* currentSelectedParent = [[topic getTopicParentCategory] getParentCategory];
            
            if (currentSelectedParent != [subCategory getParentCategory])
            {
                [subCategoryList removeAllObjects];
                [topicList removeAllObjects];
            }
            
        }

        
        if ([subCategory getParentCategory] != selectedCategory)
             selectedCategory = nil;
        selectedCategory = subCategory.getParentCategory;
        [subCategoryList addObject:category];
    }
    if ([category isKindOfClass:[MITopic class]])
    {
        MITopic* topic = (MITopic*) category;
        if ((subCategoryList.count != 0 ) &&
            ([[subCategoryList objectAtIndex:0] getParentCategory] != [[topic getTopicParentCategory] getParentCategory]))
        {
            [subCategoryList removeAllObjects];
            [topicList removeAllObjects];
            selectedCategory = nil;
        }
        
        if ([[topic getTopicParentCategory] getParentCategory] != selectedCategory)
            selectedCategory = nil;
        
        if (![subCategoryList containsObject:topic.getTopicParentCategory])
        {
            [subCategoryList addObject:topic.getTopicParentCategory];
        }
        selectedCategory = topic.getTopicParentCategory.getParentCategory;
        [topicList addObject:category];
    }
    [self.categoryTable reloadData];
}

- (void) unselectObject: (MIBaseCategory*) category
{
    if ([category isKindOfClass:[MICategory class]])
    {
        selectedCategory = nil;
    }
    if ([category isKindOfClass:[MISubCategory class]])
    {
        MISubCategory* subCategory = (MISubCategory*) category;
        [subCategoryList removeObject:category];
        MICategory* surveyCategory = subCategory.getParentCategory;
        
        if (![self shouldCategoryBeSelected:surveyCategory])
        {
            selectedCategory = Nil;
        }
    }
    if ([category isKindOfClass:[MITopic class]])
    {
        MITopic* topic = (MITopic*) category;
        
        // Check if parents in hierarchy are to be unselected
        MISubCategory *subCategory = topic.getTopicParentCategory;
        MICategory* surveyCategory = subCategory.getParentCategory;
        
        [topicList removeObject:category];
        if (![self shouldSubCategoryBeSelected:subCategory])
        {
            [subCategoryList removeObject:subCategory];
        }
        if (![self shouldCategoryBeSelected:surveyCategory])
        {
            selectedCategory = Nil;
        }

    }
    [self.categoryTable reloadData];
}

/*
 ** Checks if a given subcategory has any children topic selected or not
 */
- (BOOL) shouldSubCategoryBeSelected: (MISubCategory*) subCategory
{
    BOOL shouldBeSelected = NO;
    
    if (subCategory.topiclist.allObjects.count == 0)
    {
        shouldBeSelected = YES;
    }
    
    for (int i=0; i < subCategory.topiclist.allObjects.count; i++)
    {
        Topic* topic = [subCategory.topiclist.allObjects objectAtIndex:i];
        
        if ([topicList containsObject:topic])
        {
            shouldBeSelected = YES;
            break;
        }
    }
    
    return shouldBeSelected;
}

/*
 ** Checks if a given Category has any children sub topics selected or not
 */
- (BOOL) shouldCategoryBeSelected: (MICategory*) category
{
    BOOL shouldBeSelected = NO;
    
    if ([category getSubCategoryList:category].count == 0)
    {
        shouldBeSelected = YES;
    }
    
    for (int i=0;i < [category getSubCategoryList:category].count; i++)
    {
        MISubCategory* subCategory = [category getSubCategoryList:category][i];
        
        if ([subCategoryList containsObject:subCategory])
        {
            shouldBeSelected = YES;
            break;
        }
    }
    
    return shouldBeSelected;
    
}


- (void) expandClickedOnCell:(CategoryHierarchyCell *)cell
{
    
    // Check what is being expanded
    MIBaseCategory* cellType = cell.dataObject;
    NSIndexPath* index = [_categoryTable indexPathForCell:cell];
    
    if ([cellType isKindOfClass:[MICategory class]])
    {
        // Display all SubCategories
        expandedCategory = (MICategory*) cell.dataObject;
        expandedSubCategory = nil;

    }
    else
    {
        // Display all topics under this Sub Category
        
        expandedSubCategory = (MICategory*) cell.dataObject;
    }
    [self setDisplayHierarchy];
    [self.categoryTable reloadData];
}

- (int) indexForSurveyCategory:(MICategory*) category
{
    int index = NSNotFound;
    index = [superCategory.getCategoryList indexOfObject:category];
    
    
    return index;
}

- (void) collapseClickedOnCell:(CategoryHierarchyCell*) cell
{
    MIBaseCategory* category = cell.dataObject;
    
    if ([category isKindOfClass:[MICategory class]] )
    {
        expandedCategory = nil;
        expandedSubCategory = nil;
    }
    
    if ([category isKindOfClass:[MISubCategory class]] )
    {
        expandedSubCategory = nil;
    }

    [self setDisplayHierarchy];
    [self.categoryTable reloadData];
}

- (void) setDisplayHierarchy
{
    [displayedHierarchyObjects removeAllObjects];
    NSArray *categoryArray = superCategory.getCategoryList;
    for (int i = 0; i < categoryArray.count; i++)
    {
        MICategory* category = categoryArray[i];
        [displayedHierarchyObjects addObject:category];
        if (expandedCategory != nil)
        {
            if ([expandedCategory isEqual:category])
            {
                NSArray *subCategoryArray = [expandedCategory getSubCategoryList:expandedCategory];
                for (int j = 0; j < subCategoryArray.count; j++)
                {
                    MISubCategory* subCategory = subCategoryArray[j];
                    [displayedHierarchyObjects addObject:subCategory];
                
                    if (expandedSubCategory != nil)
                    {
                        if ([expandedSubCategory isEqual:subCategory])
                        {
                            NSArray *topicArray = [subCategory getTopicList:subCategory];
                            
                            for (int k=0; k < topicArray.count; k++)
                            {
                                [displayedHierarchyObjects addObject:topicArray[k]];
                            }
                        }
                    }
                }
            }
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoryHierarchyCell* cell =  (CategoryHierarchyCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    if ([cell.dataObject class] == [MICategory class])
    {
        CategoryCell* categoryCell = (CategoryCell*) cell;
        MICategory* category = (MICategory*) categoryCell.dataObject;
        
        if ([category getSubCategoryList:category].count == 0)
        {
            if (categoryCell.checkboxOff.hidden == NO)
            {
                [categoryCell checkboxSelected:categoryCell.checkboxOff];
            }
            else
            {
                [categoryCell checkboxSelected:categoryCell.checkboxOn];
            }
        }
        else
        {
            if (categoryCell.isExpanded)
                [categoryCell collapseClicked:categoryCell.collapse];
            else
                [categoryCell expandClicked:categoryCell.expand];
        }
    }
    if ([cell.dataObject class] == [MISubCategory class])
    {
        SubCategoryViewCell* subCategoryCell = (SubCategoryViewCell*) cell;
        MISubCategory* subCat = (MISubCategory*) subCategoryCell.dataObject;
        
        if ([subCat getTopicList:subCat].count ==0)
        {
            if (subCategoryCell.checkboxOff.hidden == NO)
            {
                [subCategoryCell checkboxSelected:subCategoryCell.checkboxOff];
            }
            else
            {
                [subCategoryCell checkboxSelected:subCategoryCell.checkboxOn];
            }
        }
        else
        {
            if (subCategoryCell.isExpanded)
                [subCategoryCell collaspseClicked:subCategoryCell.collapse];
            else
                [subCategoryCell expandClicked:subCategoryCell.expand];
        }
    }
    if ([cell.dataObject class] == [MITopic class])
    {
        TopicViewCell* topicCell = (TopicViewCell*) cell;
        
        if (topicCell.checkboxOff.hidden == NO)
        {
            [topicCell checkboxSelected:topicCell.checkboxOff];
        }
        else
        {
            [topicCell checkboxSelected:topicCell.checkboxOn];
        }
    }
}


@end
