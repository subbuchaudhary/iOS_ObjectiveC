//
//  Dealer.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Dealer : NSManagedObject

@property (nonatomic, retain) NSString * branchNo;
@property (nonatomic, retain) NSString * customerName;
@property (nonatomic, retain) NSString * customerNo;
@property (nonatomic, retain) NSString * masterNumber;
@property (nonatomic, retain) NSString * vbu;

@end
