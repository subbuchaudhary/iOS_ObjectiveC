//
//  MICategoryType.h
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MIBaseCategory.h"
#import "MISuperCategory.h"
@interface MICategory : MIBaseCategory
@property(nonatomic,strong)NSNumber *surveyId;
@property(nonatomic,strong)NSNumber *superCatId;
@property(nonatomic,strong)NSNumber *catId;
@property(nonatomic,strong)NSString *catName;
@property(nonatomic,strong)MISuperCategory *parentSuperCategory;

//


@property(nonatomic,strong)NSOrderedSet *subCategorylist;

-(MISuperCategory *)getSuperCategory;
-(void)getCategoryListObjects;
-(NSMutableArray*)getSubCategoryList:(MICategory*)category;
@end
