//
//  DealerListViewController.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/17/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FSGBaseViewController.h"
#import "DealerViewCell.h"
#import "MIConstant.h"
@protocol DealerListViewDelegate <NSObject>

-(void) dealerDataSelected;

@end
@interface DealerListViewController : FSGBaseViewController <UITableViewDataSource, UITableViewDelegate, DealerCellDelegate>

{
    NSMutableArray* selectedDealerList;
}
@property (strong, nonatomic) IBOutlet UIView *controllerView;
@property (weak) id<DealerListViewDelegate> delegate;

@property (weak) MIComments* comment;

@property (strong, nonatomic) NSMutableArray* dealerDataList;
@property  IBOutlet UITableView *dealerTable;
- (IBAction)doneClicked:(id)sender;

@end
