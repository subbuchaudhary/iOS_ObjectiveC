//
//  Topic.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "BaseCategory.h"

@class Comment, SubCategory;

@interface Topic : BaseCategory

@property (nonatomic, retain) SubCategory *parent;
@property (nonatomic, retain) Comment *commentList;

@end
