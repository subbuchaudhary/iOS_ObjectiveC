//
//  MISuperCategory.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MISuperCategory.h"

@implementation MISuperCategory

@end
