//
//  CommentInputViewController.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/26/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FSGBaseViewController.h"

@protocol CommentInputViewControllerDelegate <NSObject>

-(void)setTextValueFromInput:(NSString *)text;

@end

@interface CommentInputViewController : FSGBaseViewController <UITextViewDelegate>

@property (strong, nonatomic) IBOutlet UITextView *commentBox;

@property (strong, nonatomic) NSString *commentText;
@property (weak, nonatomic) UIViewController<CommentInputViewControllerDelegate> *delegate;

-(IBAction)cancelClicked:(id)sender;
-(IBAction)doneClicked:(id)sender;

-(void) keyboardShowing:(NSNotification*)notification;

@end
