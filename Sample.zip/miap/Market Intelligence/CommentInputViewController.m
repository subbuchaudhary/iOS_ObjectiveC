//
//  CommentInputViewController.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/26/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CommentInputViewController.h"

@interface CommentInputViewController ()

@end

@implementation CommentInputViewController

@synthesize commentText;

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([self.commentText length] == 0) {
        self.commentText = @"";
    }
    [self.commentBox setText:self.commentText];
    CGRect commentFrame = self.commentBox.frame;
    commentFrame.size = CGSizeMake(self.commentBox.frame.size.width, self.view.frame.size.height - self.commentBox.frame.origin.y);
    self.commentBox.frame = commentFrame;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShowing:) name:UIKeyboardDidShowNotification object:nil];
    _commentBox.delegate = self;
    _commentBox.font = [UIFont fontWithName:@"GEInspira-Bold" size:14];
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.commentBox becomeFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) textViewDidBeginEditing:(UITextView *) comBox
{
    if ([comBox.text isEqualToString:@"Enter Comment"])
        comBox.text = @"";
}

-(void)textViewDidChange:(UITextView *)textView{
    CGRect line = [textView caretRectForPosition:
                   textView.selectedTextRange.start];
    CGFloat overflow = line.origin.y + line.size.height
    - ( textView.contentOffset.y + textView.bounds.size.height
       - textView.contentInset.bottom - textView.contentInset.top );
    if ( overflow > 0 ) {
        // Scroll to visible area
        CGPoint offset = textView.contentOffset;
        offset.y += overflow + 7; // leave 7 pixels margin
        // Cannot animate with setContentOffset:animated: or caret will not appear
        [UIView animateWithDuration:.2 animations:^{
            [textView setContentOffset:offset];
        }];
    }
}


-(IBAction)cancelClicked:(id)sender {
    [self.commentBox resignFirstResponder];
    [[self navigationController] popViewControllerAnimated:NO];
}
-(IBAction)doneClicked:(id)sender {
    [self.commentBox resignFirstResponder];
    self.commentText = self.commentBox.text;
    [self.delegate setTextValueFromInput:self.commentText];
    [[self navigationController] popViewControllerAnimated:NO];
}

-(void) keyboardShowing:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = [self.commentBox textContainerInset];
    contentInsets.bottom = kbSize.height;
    
    [self.commentBox setTextContainerInset:contentInsets];
    self.commentBox.scrollIndicatorInsets = contentInsets;
}

@end
