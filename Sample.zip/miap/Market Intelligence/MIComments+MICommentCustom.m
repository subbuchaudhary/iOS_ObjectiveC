//
//  Comment+CommentCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/9/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MIComments+MICommentCustom.h"
#import "NSString+AESCrypt.h"

#import "AppDelegate.h"
#import "MISurveyManager.h"

@implementation MIComments (MICommentCustom)


- (void) clearSubCategoryList
{
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET subCatIds = '%@' WHERE keyId = %@" ,TABLE_COMMENTS,@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
    [self.subCategoryList removeAllObjects];
}
- (void) clearTopicList
{
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET topiclistIds = '%@' WHERE keyId = '%@'" ,TABLE_COMMENTS,@"",self.keyId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
    [self.topicList removeAllObjects];
}



- (void) encryptWithKey:(NSString*) key
{
    //self.text = [self.text AES256EncryptWithKey:key];
    
 /*   for (int i=0;i< self.dealerList.count;i++)
    {
        DealerSummaryEntity* dealer = [self.dealerList.allObjects objectAtIndex:i];
        [dealer encryptWithKey:key];
    } */
}

-(void) decryptWithKey:(NSString*) key
{
    //self.text = [self.text AES256DecryptWithKey:key];
/*    for (int i=0;i<self.dealerList.count;i++)
    {
        DealerSummaryEntity* dealer = [self.dealerList.allObjects objectAtIndex:i];
        [dealer decryptWithKey:key];
    } */

}

- (BOOL) isOpportunityTypeSelected
{
    BOOL returnFlag = NO;
    
    if ((self.category != Nil) || (self.subCategoryList.count !=0) || (self.topicList.array.count != 0))
        returnFlag = YES;
    
    return returnFlag;
}
- (BOOL) isDealerSelected
{
    BOOL returnFlag = NO;
    if (self.dealerList.count != 0)
        returnFlag = YES;
    
    return returnFlag;
}
- (BOOL) isContactNameSelected
{
    BOOL returnFlag = NO;
    
    if ((self.contactName != Nil) && (![self.contactName isEqualToString:@""]))
        returnFlag = YES;
    
    return returnFlag;
}

- (BOOL) isTextEntered
{
    BOOL returnFlag = NO;
    
    if ((self.text != Nil) && (![self.text isEqualToString:@""]))
        returnFlag = YES;
    
    return returnFlag;
}

/*
 ** Checks if the selected Dealer has been added to this comment
 */

- (BOOL) containsDealer:(MIDealerList *)aDealer
{
    BOOL result = NO;
    for (MIDealerSummary *selectedDealer in self.dealerList)
    {
        if ([selectedDealer isEqualToDealer:aDealer])
        {
            result = YES;
            break;
        }
    }
    return result;
}


/*
 ** Resets the dealers (selected from dealer list) with list of passed dealers
 ** Clears dealers currently selcted from list
 */
- (void) addDealersFromList:(NSArray*) selectedDealerList
{
    
    // First clear all dealers in comment not added manually
    
    NSMutableArray *clearedObjects = [NSMutableArray array];
    for (MIDealerSummary *dealer in self.dealerList)
    {
        if ([dealer.addedManually  isEqual: @NO])
        {
            [clearedObjects addObject:dealer];
        }
    }
    for (int i=0; i < clearedObjects.count;i++)
    {
        [[MIDBManager getSharedInstance] setStateSelectedTable:DEALER_SUMMERY_TABLE];
        MIDealerSummary *summey = clearedObjects[i];
        [[MIDBManager getSharedInstance] deleteSingleRecords:summey.masterNumber];
        
        //[self removeDealerListObject:[clearedObjects objectAtIndex:i]];
    }
    for (int i=0; i<selectedDealerList.count; i++) {
        [self insertDealerList :selectedDealerList[i]];
    }
    //Now add new list
    //[[MIDBManager getSharedInstance] insertDealerSummeryRecords:selectedDealerList];
    
}

@end
