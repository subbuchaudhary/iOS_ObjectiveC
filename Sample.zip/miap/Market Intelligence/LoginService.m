//
//  LoginService.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/18/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "LoginService.h"
#import "FSGFSGExternalService.h"

#import "AppDelegate.h"
#import "Reachability.h"
#import "KeychainItemWrapper.h"
#import "NSData+AESCrypt.h"
//MI_V_1.0
#import "MIConstant.h"
@implementation LoginService

-(id) initWithDelegate:(id<LoginStatusReceiver> )delegate
{
    self.delegate = delegate;
    
    return self;
}

- (void) loginWithUserId:(NSString *)userId password:(NSString *)password
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    sso = userId;
    ssoPassword = password;
    
    Reachability* loginReachable = [Reachability reachabilityWithHostName:
                                    [appDelegate configFor:@"FSRO_EAS_HOST"]];
    LoginStatus status;
    
    
    if (loginReachable.currentReachabilityStatus != NotReachable)
    {
        // Try to login against Remote server
        FSGFSGExternalService* fsroLoginService = [FSGFSGExternalService serviceWithUsername:userId andPassword:password];
        
        fsroLoginService.serviceUrl = [appDelegate configFor:@"FSRO_EAS_URL"];
        fsroLoginService.logging = NO;
        [fsroLoginService PasswordAuthenticate:self action:@selector(remoteLoginComplete:) userId:userId password:password status:@""];
        status = REMOTE_LOGIN_SUCCESSFUL;

    }
    else
    {
        // Check local login
        KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
        [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];
        NSString* localSSO = [keychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
        NSString* localPassword = [keychainItem objectForKey:(__bridge id)(kSecValueData)];
        ////MI_V_1.0
        MIFSR *miFsr = nil;
        if ((localSSO == nil) || (localPassword == nil))
        {
            status = NO_LOCAL_CREDENTIALS;
 
        }
        
        if (([localSSO isEqualToString:userId]) && ([password isEqualToString:localPassword]))
        {
            status = LOCAL_LOGIN_SUCCESSFUL;
            
            ////MI_V_1.0
            miFsr = [appDelegate.miSurveyUtil currentFSRWithSSO:localSSO];
        }
        else
        {
            status = LOCAL_LOGIN_FAILED;
        }
        //MI_V_1.0
         [self.delegate receiveLoginStatus:status FSR: miFsr];
        
    }
    

}
-(void)remoteLoginSuccessful:(AppDelegate *)appDelegate loginResult:(FSGAuthResponse*)loginResult
{
    [self saveCredentials];

if(self.delegate != nil)
{
    
    //MI_V_1.0_START
    [appDelegate.miSurveyUtil clearFSR];
    MIFSR *fsr = [[MIFSR alloc] init];
    fsr.firstName = loginResult.UserFirstName;
    fsr.lastName = loginResult.UserLastName;
    fsr.managerSSO = loginResult.ManagerId;
    fsr.sso = sso;
    [[MIDBManager getSharedInstance] insertFSRData:loginResult.UserFirstName lastNname:loginResult.UserLastName managerSSO:loginResult.ManagerId  sso:sso];
    [appDelegate.miSurveyUtil saveCurrentSurvey];
    [self.delegate receiveLoginStatus:REMOTE_LOGIN_SUCCESSFUL FSR:fsr];
}
}

- (void) remoteLoginComplete:(id) result
{
    AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    
	// Handle errors
	if([result isKindOfClass:[NSError class]]) {
		NSLog(@"Error FSROLogin %@", result);
       // [self.delegate receiveLoginStatus:REMOTE_SYSTEM_FAILURE FSR:nil];
        [self.delegate receiveLoginStatus:LOCAL_LOGIN_SUCCESSFUL FSR:nil];
        return;
    }
	// Handle faults
	if([result isKindOfClass:[SoapFault class]]) {
		NSLog(@"SOAPFault FSROLogin %@", result);
        [self.delegate receiveLoginStatus:REMOTE_LOGIN_FAILED FSR:nil];
        return;
	}
    
    
	// Do something with the FSGMIAuthResponse* result
    FSGAuthResponse* loginResult = (FSGAuthResponse*)result;
    NSInteger resultStatusCode = [loginResult.StatusCode integerValue];
    
    switch (resultStatusCode) {
        case 0:{
            [self remoteLoginSuccessful:appDelegate loginResult:loginResult];
        }
            break;
            //user is disabled
        case 6:
        {
            [self resetLocalCredentials];
            [self.delegate receiveLoginStatusWithMessage:loginResult.StatusMessage];
        }
        case 9:
        case 10:
        {
            [self remoteLoginSuccessful:appDelegate loginResult:loginResult];
            [self.delegate receiveLoginStatusWithMessage:loginResult.StatusMessage];
        }
        default:
        {
            [self.delegate receiveLoginStatusWithMessage:loginResult.StatusMessage];
        }
            break;
    }
}


-(BOOL) isResponseStatusValid: (NSString *) status{
    
    NSString *responseStatus = status;
    NSArray *splittedStrings = [responseStatus componentsSeparatedByString:@","];
    long c = splittedStrings.count;
    uint8_t *bytes = malloc(sizeof(*bytes) * c);
    
    unsigned i;
    for (i = 0; i < c; i++)
    {
        NSString *str = [splittedStrings objectAtIndex:i];
        int byte = [str intValue];
        bytes[i] = byte;
    }
    
    NSData *encryptedData = [NSData dataWithBytesNoCopy:bytes length:c freeWhenDone:YES];
    NSData *decryptedData = [encryptedData DecryptServerResponseAES256];
    NSString *decryptedStatus = [[NSString alloc] initWithData:decryptedData encoding:NSUTF8StringEncoding];
    
    NSArray *splitedStatus = [decryptedStatus componentsSeparatedByString:@">:"];
    NSString *responseSSO = nil;
    NSString *responsePwd = nil;
    NSString *responseTimeStamp = nil;
    
    if ([splitedStatus count] == 3) {
        responseSSO = [[splitedStatus objectAtIndex:0] substringFromIndex:1];
        responsePwd = [[splitedStatus objectAtIndex:1] substringFromIndex:1];
        responseTimeStamp = [splitedStatus objectAtIndex:2];
    }else{
        return NO;
    }
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MMddyyyy_HH:mm:ss"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"EDT"]];
    NSDate *responseDate  = [dateFormatter dateFromString:responseTimeStamp];
    NSLog(@"Response date : %@", responseDate);      // 2012-11-05 02:09:00 +0000
    
    NSDate *currentDate = [NSDate date];
    NSLog(@"Curr Date : %@", [NSDate date]);
    
    NSDateComponents *components= [[NSDateComponents alloc] init];
    [components setHour:-3];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *pastDate = [calendar dateByAddingComponents:components toDate:currentDate options:0];
    NSLog(@"Past date : %@", pastDate);      // 2012-11-05 02:09:00 +0000


    //Response date < current date and Response date > current date - 3 hours
    if ([responseDate compare:currentDate] == NSOrderedAscending && [responseDate compare:pastDate] == NSOrderedDescending) {
        NSLog(@"Success !");
    }
    
    return [responseSSO isEqualToString:sso] && [responsePwd isEqualToString:ssoPassword] && [responseDate compare:currentDate] == NSOrderedAscending && [responseDate compare:pastDate] == NSOrderedDescending;
}

- (void) saveCredentials
{
    
    KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
    [keychainItem setObject:(__bridge id)(kSecAttrAccessibleWhenUnlocked) forKey:(__bridge id)(kSecAttrAccessible)];
 
    [keychainItem resetKeychainItem];
    [keychainItem setObject:sso forKey:(__bridge id)(kSecAttrAccount)];
    [keychainItem setObject:ssoPassword forKey:(__bridge id)(kSecValueData)];
    
}

- (void) resetLocalCredentials
{
    KeychainItemWrapper *keychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"MIApp" accessGroup:nil];
    [keychainItem resetKeychainItem];
}


@end
