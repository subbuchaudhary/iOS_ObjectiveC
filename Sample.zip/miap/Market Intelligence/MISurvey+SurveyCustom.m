//
//  Survey+SurveyCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "MISurvey+SurveyCustom.h"
#import "MIConstant.h"
@implementation MISurvey (SurveyCustom)
- (void)addCommentListObject:(MIComments*)value
{
    // Create a mutable set with the existing objects, add the new object, and set the relationship equal to this new mutable ordered set
    NSMutableOrderedSet *commentList = [[NSMutableOrderedSet alloc] initWithOrderedSet:self.commentList];
    [commentList addObject:value];
    self.commentList = commentList;
    
}
-(void)removeCommentListObject:(MIComments*)value
{
    NSString *subCatIds = self.commentIds;
    NSMutableArray *arrSubCat = [[subCatIds componentsSeparatedByString:@","] mutableCopy];
    [arrSubCat removeObject:value.keyId];
    subCatIds = [arrSubCat componentsJoinedByString:@","];
    
    [self.commentList.array.mutableCopy removeObject:[arrSubCat filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"keyId == %@",value.keyId]]]];
    
    //Update Query
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET subCatIds = '%@' WHERE keyId = %@" ,TABLE_CURRENT_SURVEY ,subCatIds,self.surveyID];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}
- (void) prepareForSubmit
{
    NSString *oldId = self.surveyID;
    self.surveyID = [self generateSurveyID];
    NSString *updateSQL = [NSString stringWithFormat:@"UPDATE %@ SET id = '%@' WHERE id = %@" ,TABLE_CURRENT_SURVEY ,self.surveyID,oldId];
    [[MIDBManager getSharedInstance] updateRecrodsQuery:updateSQL];
}

- (NSString*) generateSurveyID
{
    NSString* surveyID;
    // Timestamp
    NSDate *current = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MM_dd_yyyy_HH_mm_ss"];
    NSString* timeStamp = [formatter stringFromDate:current];
    
    NSString *deviceID= [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    
    surveyID = [NSString stringWithFormat:@"%@_%@",deviceID,timeStamp];
    return surveyID;
}

- (void) encryptWithKey:(NSString*) key;
{
    for (int i=0; i< self.commentList.count;i++)
    {
        MIComments* comment = [self.commentList objectAtIndex:i];
        [comment encryptWithKey:key];
    }
}

- (void) decryptWithKey:(NSString*) key
{
    for (int i=0; i< self.commentList.count;i++)
    {
        MIComments* comment = [self.commentList objectAtIndex:i];
        [comment decryptWithKey:key];
    }
    
}

- (int) numberOfUnsentMessages
{
    int noOfUnsentMessages = 0;
    
    for (int i=0; i< self.commentList.count; i++)
    {
        MIComments* comment = [self.commentList objectAtIndex:i];
        
        if (([comment isContactNameSelected]) ||
           ([comment isDealerSelected]) ||
           ([comment isOpportunityTypeSelected]) ||
            ([comment isTextEntered]))
            noOfUnsentMessages++;
            
    }
    
    return noOfUnsentMessages;
    
}

@end
