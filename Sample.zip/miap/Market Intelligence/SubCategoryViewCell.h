//
//  SubCategoryViewCell.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CategoryHierarchyCell.h"

@interface SubCategoryViewCell : CategoryHierarchyCell

@property (weak, nonatomic) IBOutlet UIButton *checkboxOn;

@property (weak, nonatomic) IBOutlet UIButton *checkboxOff;

@property (weak, nonatomic) IBOutlet UILabel *objectName;

@property (weak, nonatomic) IBOutlet UIButton *collapse;
@property (weak, nonatomic) IBOutlet UIButton *expand;

- (IBAction)collaspseClicked:(id)sender;
- (IBAction)expandClicked:(id)sender;

- (void) configureWithHierarchy:(MIBaseCategory *)category;
- (IBAction)checkboxSelected:(UIButton *)sender;

@end
