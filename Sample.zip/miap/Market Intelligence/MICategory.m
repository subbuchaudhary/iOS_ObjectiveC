//
//  MICategoryType.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MICategory.h"
#import "MIDBManager.h"
@implementation MICategory
-(NSMutableArray*)getSubCategoryList:(MICategory*)category
{
    NSMutableArray *arrSubCategory = [[NSMutableArray alloc] init];
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    NSMutableArray *objSubCategory = [[MIDBManager getSharedInstance] fetchsingleRecords:category.catId.stringValue];
    [arrSubCategory addObject:objSubCategory];
    return arrSubCategory;
}
@end
