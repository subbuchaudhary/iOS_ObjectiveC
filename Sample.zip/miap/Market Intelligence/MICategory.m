//
//  MICategoryType.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 18/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MICategory.h"
#import "MIDBManager.h"
@implementation MICategory
-(NSMutableArray*)getSubCategoryList:(MICategory*)category
{
    NSMutableArray *arrSubCategory = [[NSMutableArray alloc] init];
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUBCATEGORY_TABLE];
    NSMutableArray *objSubCategory = [[MIDBManager getSharedInstance] fetchsingleRecords:category.catId.stringValue];
    [arrSubCategory addObject:objSubCategory];
    return arrSubCategory;
}

-(MISuperCategory *)getSuperCategory
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:SUPERCATEGORY_TABLE];
    NSMutableArray *objSubCategory = [[MIDBManager getSharedInstance] fetchsingleRecords:self.superCatId.stringValue];
    return (objSubCategory.count>0)? objSubCategory[0]:[MISuperCategory new];
}
-(void)getCategoryListObjects
{
    [[MIDBManager getSharedInstance] setStateSelectedTable:CATEGORY_TABLE];
    NSString *query = [NSString stringWithFormat:@"select * from %@",TABLE_CATEGORY];
    NSArray *objCategory = [[MIDBManager getSharedInstance] fetchAllRecordsFromTable:query];
    if (objCategory.count>0) {
        [self.categoryList setByAddingObjectsFromArray:objCategory];
    }
    
}
@end
