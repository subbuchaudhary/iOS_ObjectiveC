//
//  OTPViewController.m
//  HopWitApp
//
//  Created by Subbu Chaudhary on 5/7/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import "OTPViewController.h"
#import "CustomVerificationTableViewCell.h"

@interface OTPViewController ()

@end

@implementation OTPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomVerificationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CustomVerificationTableViewCell"];
    if(cell == nil)
    {
        cell = [[CustomVerificationTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CustomVerificationTableViewCell"];
    }
    return cell;
}

@end
