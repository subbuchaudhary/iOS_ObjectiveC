//
//  CustomTableViewCell.h
//  HopWitApp
//
//  Created by Subbu Chaudhary on 5/7/17.
//  Copyright © 2017 Subbu Chaudhary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@end
