//
//  FeedViewController.m
//  Hopwit.me
//
//  Created by Anyuta on 5/13/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "FeedViewController.h"
#import "FeedTableViewCell.h"
#import "GreetFeedTableViewCell.h"
#import "FeedDetailedTableViewCell.h"
@interface FeedViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation FeedViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarbutton setTarget: self.revealViewController];
        [self.sidebarbutton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tableView.estimatedRowHeight = 80;//the estimatedRowHeight but if is more this autoincremented with autolayout
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==0) {
        
        FeedTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"FeedTableViewCell"];
        if (cell==nil) {
            cell=[[FeedTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FeedTableViewCell"];
        }
        cell=contentcell;
    }else if(indexPath.row==1)
    {
        GreetFeedTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"GreetFeedTableViewCell"];
        if (cell==nil) {
            cell=[[GreetFeedTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"GreetFeedTableViewCell"];
        }
        cell=contentcell;
    }
    else
    {
        FeedDetailedTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"FeedDetailedTableViewCell"];
        if (cell==nil) {
            cell=[[FeedDetailedTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FeedDetailedTableViewCell"];
        }
        cell=contentcell;
    }
    return cell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
