//
//  TravellersCountCell.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/24/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "TravellersCountCell.h"

@implementation TravellersCountCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
