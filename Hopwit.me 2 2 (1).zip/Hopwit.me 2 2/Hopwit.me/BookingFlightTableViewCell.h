//
//  BookingFlightTableViewCell.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/23/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookingFlightTableViewCell : UITableViewCell

@end
