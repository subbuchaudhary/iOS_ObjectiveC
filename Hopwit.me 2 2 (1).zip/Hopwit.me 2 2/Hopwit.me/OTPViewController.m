//
//  OTPViewController.m
//  HopeWit_iOS
//
//  Created by Nelakudhiti, Subba on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "OTPViewController.h"
#import "VerifyOtpViewController.h"
#import "ValidateUtility.h"
//#import "RestService.h"
#import "AppDelegate.h"
#import "EnumList.h"
#import "HelperClass.h"
#import "NetworkApi.h"
@interface OTPViewController ()<UITextFieldDelegate>

@end

@implementation OTPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
    tapGesture.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGesture];
    // Do any additional setup after loading the view.
}

-(void)dismissKeyboard
{
    [self.mobileNumberField resignFirstResponder];}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.35f];
    CGRect frame = self.view.frame;
    frame.origin.y = -100;
    [self.view setFrame:frame];
    [UIView commitAnimations];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.35f];
    CGRect frame = self.view.frame;
    frame.origin.y = 0;
    [self.view setFrame:frame];
    [UIView commitAnimations];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)sendOtpClkd:(id)sender {
    
    NSString *errorMsg = @"";
    if ([ValidateUtility isEmptyString:self.mobileNumberField.text]) {
        errorMsg = @"Please enter mobilenumber";
    }
    if (errorMsg.length) {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error" message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }];
        [controller addAction:okAction];
        [self presentViewController:controller animated:YES completion:nil];
    }else{
        [[AppDelegate sharedAppdelegate]showProgressView];
     
        NSLocale *currentLocale = [NSLocale currentLocale];  // get the current locale.
        NSString *countryCode = [currentLocale objectForKey:NSLocaleCountryCode];
        countryCode=@"IN";
     
        NSString *post =[NSString stringWithFormat:@"country_code=%@&mobile=%@",countryCode,self.mobileNumberField.text];
       
        NetworkApi *network = [NetworkApi sharedInstance];
        [network startApiExecution:post andUrl:@"account/send-otp" withCompletionblock:^(NSError *error, id response)  {
            
            if(!error)
            {
                
                NSLog(@"response is %@",response);
             [[AppDelegate sharedAppdelegate]hideProgressView];
            
            VerifyOtpViewController *homeScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"VerifyOtpViewController"];
                homeScreen.verificationId=response[@"verification_id"];
                homeScreen.mobilenumber=self.mobileNumberField.text;
            [self presentViewController:homeScreen animated:NO completion:nil];
            }
        }];
    }
   
}
@end
