//
//  FlightBookingViewController.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/23/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlightBookingViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *bookingTableView;
- (IBAction)searchFlight:(id)sender;

@end
