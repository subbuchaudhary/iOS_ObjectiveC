//
//  ValidateUtility.h
//  Yoku
//
//  Created by Ramesh on 11/5/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ValidateUtility : NSObject

+ (BOOL)isEmptyString:(NSString *)string;
+ (BOOL)isEmailValid:(NSString *)string;
+ (BOOL)isPasswordValid:(NSString *)string;

@end
