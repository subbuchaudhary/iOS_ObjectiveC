//
//  ViewController.m
//  HopeWit_iOS
//
//  Created by Nelakudhiti, Subba on 5/12/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "InitialViewController.h"
#import "PageViewController.h"
#import "PageContentViewController.h"
#import "OTPViewController.h"

@interface InitialViewController ()

@end

@implementation InitialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _pageTitleArray = @[@"Plan",@"Explore your destination",@"Chat and Meet"];
    _pageImageArray = @[@"Plan.png", @"Explore.png", @"Chat.png"];
    _descrtArray = @[@"From your travel planning tp trip completion,HopWit assists with the right planning,coreect trip recommendations", @"You no longer need multiple travel apps-Plan,Book,Get trips status,Check-in,Explore & much more", @"Once you're all set,chat&meet with nearby friends and expand your horizon"];
    _btnArray = @[@"Next", @"Next", @"Done"];
    
    // Create page view controller
    self.pageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PageViewController"];
    self.pageViewController.dataSource = self;
    self.pageViewController.delegate = self;
    
    PageContentViewController *startingViewController = [self viewControllerAtIndex:0];
    NSArray *viewControllers = @[startingViewController];
    [self.pageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    // Change the size of page view controller
    self.pageViewController.view.frame = CGRectMake(0, 41, self.view.frame.size.width, self.view.frame.size.height - 81);
    
    [self addChildViewController:_pageViewController];
    [self.view addSubview:_pageViewController.view];
    [self.pageViewController didMoveToParentViewController:self];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)changePage:(UIPageViewControllerNavigationDirection)direction {
    NSUInteger pageIndex = ((PageContentViewController *) [_pageViewController.viewControllers objectAtIndex:0]).pageIndex;
    if (direction == UIPageViewControllerNavigationDirectionForward){
        pageIndex++;
    }else {
        pageIndex--;
    }
    PageContentViewController *viewController = [self  viewControllerAtIndex:pageIndex];
    if (viewController == nil) {
        OTPViewController *homeScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"OTPViewController"];
        [self presentViewController:homeScreen animated:NO completion:nil];
        
    }
    else
    {
    [_pageViewController setViewControllers:@[viewController] direction:direction animated:YES completion:nil];
    }
}

- (IBAction)nextButton:(id)sender {
     [self changePage:UIPageViewControllerNavigationDirectionForward];
    
}

- (IBAction)skipButton:(id)sender {
    OTPViewController *homeScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"OTPViewController"];
    [self presentViewController:homeScreen animated:NO completion:nil];
    
}
-(UIViewController *) pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSUInteger index = ((PageContentViewController*) viewController).pageIndex;
    if ((index == 0) || (index == NSNotFound))
    {
        return nil;
    }
    index--;
    return [self viewControllerAtIndex:index];
}
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    NSUInteger index = ((PageContentViewController*) viewController).pageIndex;
    if (index == NSNotFound)
    {
        return nil;
    }
    index++;
    if (index == [self.pageTitleArray count])
    {
        return nil;
    }
    return [self viewControllerAtIndex:index];
}
- (PageContentViewController *)viewControllerAtIndex:(NSUInteger)index
{
    if (([self.pageTitleArray count] == 0) || (index >= [self.pageTitleArray count])) {
        return nil;
    }
    // Create a new view controller and pass suitable data.
    PageContentViewController *pageContentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PageContentViewController"];
    pageContentViewController.imgFile = self.pageImageArray[index];
    pageContentViewController.txtTitle = self.pageTitleArray[index];
    pageContentViewController.descText = self.descrtArray[index];
    self.btnTitle = self.btnArray[index];
    pageContentViewController.pageIndex = index;
    return pageContentViewController;
}

-(NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController
{
    return [self.pageTitleArray count];
}
- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController
{
    return 0;
}
@end
