//
//  FlightSearchResults.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/24/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "FlightSearchResults.h"
#import "FlightResultsCell.h"

@interface FlightSearchResults ()
{
    NSArray *namesArray, *detailsArray;
}

@end

@implementation FlightSearchResults

- (void)viewDidLoad {
    [super viewDidLoad];
    self.searchResultsTable.rowHeight = UITableViewAutomaticDimension;
    self.searchResultsTable.estimatedRowHeight= 101;
    
    namesArray = @[@"BLR", @"BOM", @"CCU", @"BLR", @"BOM", @"CCU", @"BLR", @"BOM", @"CCU"];
    detailsArray = @[@"Banglore, IN - Kempegowda International Airport", @"Mumbai, IN - Chatrapathi Shivaji International Airport", @"Kolkata, IN - Nethaji Subhash Chandra Bose  International Airport", @"Banglore, IN - Kempegowda International Airport", @"Mumbai, IN - Chatrapathi Shivaji International Airport", @"Kolkata, IN - Nethaji Subhash Chandra Bose  International Airport", @"Banglore, IN - Kempegowda International Airport", @"Mumbai, IN - Chatrapathi Shivaji International Airport", @"Kolkata, IN - Nethaji Subhash Chandra Bose  International Airport"];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return detailsArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FlightResultsCell *flightResults = [tableView dequeueReusableCellWithIdentifier:@"FlightResultsCell"];
    if(flightResults == nil)
    {
        flightResults = [[FlightResultsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FlightResultsCell"];
    }
    flightResults.airportName.text = [namesArray objectAtIndex:indexPath.row];
    flightResults.airportDetails.text = [detailsArray objectAtIndex:indexPath.row];
    return flightResults;
}


@end
