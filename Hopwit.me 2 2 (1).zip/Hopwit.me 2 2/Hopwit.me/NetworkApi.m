//
//  NetworkApi.m
//  Location
//
//  Created by Raja Sinha on 07/05/15.
//  Copyright (c) 2015 Location. All rights reserved.
//

#import "NetworkApi.h"


#define BASE_URL @"http://zombieapi.hopwit.me:5000/"
@implementation NetworkApi

+ (instancetype)sharedInstance
{
    static NetworkApi *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[NetworkApi alloc] init];
    });
    return sharedInstance;
}



- (void)executePostRequestWithURLString:(NSString *)urlString parameter:(id)parameter callbackHandler:(callbackHandler)block
{
    [self executePostRequestWithURLString:urlString
                                parameter:parameter
                              contentType:@"application/x-www-form-urlencoded"
                          callbackHandler:block];
}

- (void)executePostRequestWithURLString:(NSString *)urlString

                              parameter:(id)parameter
                            contentType:(NSString *)contentType
                        callbackHandler:(callbackHandler)block
{
    NSError *error;
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"unique-consistent-string";
    // set Content-Type in HTTP header
   contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    // post body
    NSMutableData *body = [NSMutableData data];
    [parameter enumerateKeysAndObjectsUsingBlock:^(NSString *parameterKey, NSString *parameterValue, BOOL *stop) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", parameterKey] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", parameterValue] dataUsingEncoding:NSUTF8StringEncoding]];
    }];
    [request setHTTPBody:body];
    NSString *postLength = [NSString stringWithFormat:@"%d", [body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue currentQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        if(data.length > 0)
        {
           NSString *dataString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
          }
    }];
}





-(void)startApiExecution:(NSString*)post andUrl:(NSString*)apiUrl withCompletionblock:(callbackHandler)block

{
    
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init] ;
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL,apiUrl]]];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
   
    
    self.session = [NSURLSession sharedSession];  // use sharedSession or create your own
   NSURLSessionTask *task=[self.session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
    
        if (error) {
            
            NSLog(@"error = %@", error);
            
           dispatch_async(dispatch_get_main_queue(), ^{
                
                block(error , response);
                
           });
            
            return;
            
        }
        
        else
            
        {
            
           NSError *error = nil;
            
            id responseData =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
            
           dispatch_async(dispatch_get_main_queue(), ^{
                
                block(error,responseData);
            });
            
        }
        
    }];
    
    [task resume];
    
    
    
}

-(void)startApiExecutionGetUrl:(NSString*)apiUrl withCompletionblock:(callbackHandler)block {
    
    
    NSString *boundary = [self generateBoundaryString];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL,apiUrl]]];
    
    [request setHTTPMethod:@"GET"];
    [request setHTTPBody:nil];
   // NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    
    [request setValue:@"Application/JSON" forHTTPHeaderField: @"Content-Type"];
    
    [request setValue:@"" forHTTPHeaderField:@"X-Access-Token"];
  
    
    
    self.session = [NSURLSession sharedSession];  // use sharedSession or create your own
    
    NSURLSessionTask * sessionTask = [self.session dataTaskWithURL:[NSURL URLWithString:apiUrl] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        
        if (error) {
            
            NSLog(@"error = %@", error);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                block(error , response);
               
                
            });
            
            return;
            
        }
        
        else
            
        {
            
            NSError *error = nil;
            
            id responseData =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
              
                block(error,responseData);
            });
            
        }
        
        
    }];
  /*  NSURLSessionTask *task = [self.session uploadTaskWithRequest:request fromData:nil completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        if (error) {
            
            NSLog(@"error = %@", error);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                block(error , response);
                
            });
            
            return;
            
        }
        
        else
            
        {
            
            NSError *error = nil;
            
            id responseData =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
            
            block(error,responseData);
            
        }
        
    }];*/
    
    [sessionTask resume];

    
    
    
    
    
}





- (NSString *)generateBoundaryString
{
return [NSString stringWithFormat:@"Boundary-%@", [[NSUUID UUID] UUIDString]];
}
@end
