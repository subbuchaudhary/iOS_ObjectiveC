//
//  VerifyOtpViewController.m
//  Hopwit.me
//
//  Created by Anyuta on 6/4/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "VerifyOtpViewController.h"
#import "ValidateUtility.h"
#import "AppDelegate.h"
#import "NetworkApi.h"
#import "ProfileViewController.h"
@interface VerifyOtpViewController ()
@property (weak, nonatomic) IBOutlet UITextField *otpfield;

@end

@implementation VerifyOtpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)veriftbtnClicked:(id)sender {
    
    
    NSString *errorMsg = @"";
    if ([ValidateUtility isEmptyString:self.otpfield.text]) {
        errorMsg = @"Please enter your PIN";
    }
    if (errorMsg.length) {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error" message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }];
        [controller addAction:okAction];
        [self presentViewController:controller animated:YES completion:nil];
    }else{
        [[AppDelegate sharedAppdelegate]showProgressView];
        
        NSLocale *currentLocale = [NSLocale currentLocale];  // get the current locale.
        NSString *countryCode = [currentLocale objectForKey:NSLocaleCountryCode];
        countryCode=@"IN";
        
        NSString *post =[NSString stringWithFormat:@"verification_id=%@&mobile=%@&dial_code=%@&otp=%@",_verificationId,self.mobilenumber,@"91",self.otpfield.text];
        
        NetworkApi *network = [NetworkApi sharedInstance];
        [network startApiExecution:post andUrl:@"account/verify-and-register" withCompletionblock:^(NSError *error, id response)  {
            
            [[AppDelegate sharedAppdelegate]hideProgressView];
            if(!error)
            {
                
                dispatch_async(dispatch_get_main_queue(), ^{
                   
               
                
                ProfileViewController *profileScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
              
                profileScreen.token=response[@"token"];
                profileScreen.userId=response[@"user_id"];
                NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
                [defaults setObject:response[@"user_id"] forKey:@"UserID"];
                    [defaults setObject:response[@"token"] forKey:@"TokenHash"];
                [defaults synchronize];
                [self presentViewController:profileScreen animated:NO completion:nil];
                    
                });
            }
        }];
    }
    
    
    
}
- (IBAction)resendBtnClicked:(id)sender {
    
    
}

@end
