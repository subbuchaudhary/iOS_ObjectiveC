//
//  ChatWindowViewController.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChatWindowViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    int lastId;
    
    NSMutableData *receivedData;
    
    NSMutableArray *messages;
    
    NSTimer *timer;
    
    NSXMLParser *chatParser;
    NSString *msgAdded;
    NSMutableString *msgUser;
    NSMutableString *msgText;
    int msgId;
    Boolean inText;
    Boolean inUser;
}

@property (weak, nonatomic) IBOutlet UITableView *chatList;
@property (weak, nonatomic) IBOutlet UIButton *sendBtn;
- (IBAction)sendBtnClkd:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *messageTxtField;

@end
