//
//  ChatWindowViewController.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "ChatWindowViewController.h"
#import "ChatListItemCell.h"

@interface ChatWindowViewController ()
{
    NSMutableArray *messageArray;
    NSArray *namesArray;
    NSDictionary *dict;
}

@end

@implementation ChatWindowViewController


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


// Getting the message

- (void)getNewMessages {
    
}

- (void)timerCallback {
    [self getNewMessages];
}

// Driving The Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 9;
}

//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
//
//// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
//// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
//
//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 75;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ChatListItemCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ChatListItemCell"];
    if (cell == nil) {
        cell = [[ChatListItemCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ChatListItemCell"];
    }
    
    dict = [messageArray objectAtIndex:indexPath.row];
    cell.textLabel.text = @"nivas";
    cell.userLabel.text = messageArray;
    return cell;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self sendMyMessage];
    return YES;
}

// Sending the message to the server

- (IBAction)sendBtnClkd:(id)sender {
    [_messageTxtField resignFirstResponder];
    if ( [_messageTxtField.text length] > 0 ) {
        [self sendMyMessage];
    }
    
    _messageTxtField.text = @"";
}

// The inital loader

- (void)viewDidLoad {
    [super viewDidLoad];
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(didReceiveDataWithNotification:)
//                                                 name:@"MCDidReceiveDataNotification"
//                                               object:nil];
    _chatList.dataSource = self;
    _chatList.delegate = self;
    _messageTxtField.delegate = self;
    
    [self getNewMessages];
}
-(void) sendMyMessage
{
    NSData *dataToSend = [ _messageTxtField.text dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    
    if (error) {
        NSLog(@"%@", [error localizedDescription]);
    }
    
   // [_textLabel setText:[_textLabel.text stringByAppendingString:[NSString stringWithFormat:@"I wrote:\n%@\n\n", _messageTxtField.text]]];
    messageArray = [[NSMutableArray alloc] init];
    
    NSString *obj = _messageTxtField.text;
    
    [messageArray addObject:obj];
    [_messageTxtField setText:@""];
    [_messageTxtField resignFirstResponder];
}

@end
