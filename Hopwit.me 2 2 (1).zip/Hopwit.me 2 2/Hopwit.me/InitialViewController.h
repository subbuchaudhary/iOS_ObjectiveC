#import <UIKit/UIKit.h>
#import "PageContentViewController.h"

@interface InitialViewController : UIViewController<UIPageViewControllerDataSource,UIPageViewControllerDelegate>

@property (nonatomic, strong) UIPageViewController *pageViewController;
@property (nonatomic, strong) NSArray *pageTitleArray;
@property (nonatomic, strong) NSArray *pageImageArray;
@property (nonatomic, strong) NSArray *descrtArray;
@property (nonatomic, strong) NSArray *btnArray;

-(PageContentViewController *) viewControllerAtIndex:(NSUInteger)index;

- (IBAction)nextButton:(id)sender;
- (IBAction)skipButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnTitle;


@end

