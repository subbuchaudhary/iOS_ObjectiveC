//
//  ProfileHeaderCell.h
//  Yoku
//
//  Created by Ramesh on 12/14/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileHeaderCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UIImageView *userPicImgView;
@property (nonatomic, weak) IBOutlet UILabel *nameLbl;
@property (nonatomic, weak) IBOutlet UILabel *addressLbl;
@property (nonatomic, weak) IBOutlet UILabel *numOfDealsLbl;
@property (nonatomic, weak) IBOutlet UILabel *ammountLbl;

@end
