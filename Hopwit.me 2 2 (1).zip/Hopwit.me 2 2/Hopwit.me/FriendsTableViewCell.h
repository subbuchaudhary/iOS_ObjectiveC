//
//  FriendsTableViewCell.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/21/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;

@property (weak, nonatomic) IBOutlet UILabel *namesLabel;
@property (weak, nonatomic) IBOutlet UIImageView *dpImages;
@end
