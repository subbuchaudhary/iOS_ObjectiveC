//
//  FlightBookingViewController.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/23/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "FlightBookingViewController.h"
#import "BookingFlightTableViewCell.h"
#import "TripTypeTableViewCell.h"
#import "TripDetailsTableViewCell.h"
#import "JourneyDetailsCell.h"
#import "TravellersCountCell.h"
#import "FlightClassTypeCell.h"
#import "FlightSearchResults.h"

@interface FlightBookingViewController ()

@end

@implementation FlightBookingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.bookingTableView.rowHeight = UITableViewAutomaticDimension;
    self.bookingTableView.estimatedRowHeight= 101;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==0) {
        
        BookingFlightTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"BookingFlightTableViewCell"];
        if (cell==nil) {
            cell=[[BookingFlightTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"BookingFlightTableViewCell"];
        }
        cell=contentcell;
    }
    else if(indexPath.row ==1)
    {
        TripTypeTableViewCell *tripType = [tableView dequeueReusableCellWithIdentifier:@"TripTypeTableViewCell"];
        if(cell == nil)
        {
            cell = [[TripTypeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TripTypeTableViewCell"];
        }
        cell = tripType;
    }
    else if(indexPath.row ==2){
        TripDetailsTableViewCell *tripDetails = [tableView dequeueReusableCellWithIdentifier:@"TripDetailsTableViewCell"];
        if(cell == nil)
        {
            cell = [[TripDetailsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TripDetailsTableViewCell"];
        }
        cell = tripDetails;
    }
    else if(indexPath.row ==3)
    {
        JourneyDetailsCell *journeyDetails = [tableView dequeueReusableCellWithIdentifier:@"JourneyDetailsCell"];
        if(cell == nil)
        {
            cell = [[JourneyDetailsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"JourneyDetailsCell"];
        }
        cell = journeyDetails;
    }
    else if(indexPath.row == 4)
    {
        TravellersCountCell *travellersCount = [tableView dequeueReusableCellWithIdentifier:@"TravellersCountCell"];
        if(cell == nil)
        {
            cell = [[TravellersCountCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TravellersCountCell"];
        }
        cell = travellersCount;
    }
    else
    {
        FlightClassTypeCell *classType = [tableView dequeueReusableCellWithIdentifier:@"FlightClassTypeCell"];
        if(cell == nil)
        {
            cell = [[FlightClassTypeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FlightClassTypeCell"];
        }
        cell = classType;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 2)
    {
        FlightSearchResults *searchResults = [self.storyboard instantiateViewControllerWithIdentifier:@"FlightSearchResults"];
        [self.navigationController pushViewController:searchResults animated:YES];
    }
}


- (IBAction)searchFlight:(id)sender {
    FlightSearchResults *searchResults = [self.storyboard instantiateViewControllerWithIdentifier:@"FlightSearchResults"];
    [self.navigationController pushViewController:searchResults animated:YES];
}
@end
