//
//  ViewController.m
//  Hopwit.me
//
//  Created by Anyuta on 5/13/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "ViewController.h"
#import "ContentTableViewCell.h"
#import "DetailsTableViewCell.h"
#import "FlightBookingViewController.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UITabBarDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarbutton setTarget: self.revealViewController];
        [self.sidebarbutton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tableView.estimatedRowHeight = 80;//the estimatedRowHeight but if is more this autoincremented with autolayout
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.row==0) {
      
        ContentTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"ContentTableViewCell"];
        if (cell==nil) {
            cell=[[ContentTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ContentTableViewCell"];
        }
        cell=contentcell;
    }else 
    {
        DetailsTableViewCell *contentcell=[tableView dequeueReusableCellWithIdentifier:@"DetailsTableViewCell"];
        if (cell==nil) {
            cell=[[ContentTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DetailsTableViewCell"];
        }
        cell=contentcell;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
      [self performSegueWithIdentifier:@"detailedScreen" sender:nil];
}


- (IBAction)flightBooking:(id)sender {
    FlightBookingViewController *flightBookingScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"FlightBookingViewController"];
    flightBookingScreen.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:flightBookingScreen animated:YES];
}

- (IBAction)hotelBooking:(id)sender {
}

- (IBAction)cabBooking:(id)sender {
}
@end
