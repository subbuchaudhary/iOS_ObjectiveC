//
//  PassengerDetailsViewController.m
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/24/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import "PassengerDetailsViewController.h"
#import "PassengerDetailsCell.h"

@interface PassengerDetailsViewController ()<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate>

@property (nonatomic, strong) NSArray *cellTxtFiledPlacholdersArr;

@property (nonatomic, strong) NSString *titleStr;
@property (nonatomic, strong) NSString *firstNameStr;
@property (nonatomic, strong) NSString *lastNameStr;
@property (nonatomic, strong) NSString *roomStr;
@property (nonatomic, strong) NSString *mobileNumberStr;
@property (nonatomic, strong) NSString *emailStr;

@end

@implementation PassengerDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.cellTxtFiledPlacholdersArr = [NSArray arrayWithObjects:@"Title",@"First Name",@"Last Name",@"Room",@"Mobile",@"Email address", nil];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.cellTxtFiledPlacholdersArr.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PassengerDetailsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PassengerDetailsCell"];
    cell.txtField.placeholder = self.cellTxtFiledPlacholdersArr[indexPath.row];
    cell.txtField.tag = indexPath.row+1;
    cell.txtField.delegate = self;
    
    return cell;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.tag == 1) {
        self.titleStr = textField.text;
    }else if (textField.tag == 2){
        self.firstNameStr = textField.text;
    }else if (textField.tag == 3){
        self.lastNameStr = textField.text;
    }else if (textField.tag ==4){
        self.roomStr = textField.text;
    }else if (textField.tag == 5){
        self.mobileNumberStr= textField.text;
    }else{
        self.emailStr= textField.text;
        [self.view endEditing:YES];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    CGPoint pointInTable = [textField.superview convertPoint:textField.frame.origin toView:self.passengerDetails];
    CGPoint contentOffset = self.passengerDetails.contentOffset;
    
    contentOffset.y = (pointInTable.y - textField.inputAccessoryView.frame.size.height);
    if (contentOffset.y != 0) {
        contentOffset.y -= 50;
    }
    
    NSLog(@"contentOffset is: %@", NSStringFromCGPoint(contentOffset));
    [self.passengerDetails setContentOffset:contentOffset animated:YES];
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.passengerDetails scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:TRUE];
    [self.view endEditing:YES];
    
    return YES;
}
@end
