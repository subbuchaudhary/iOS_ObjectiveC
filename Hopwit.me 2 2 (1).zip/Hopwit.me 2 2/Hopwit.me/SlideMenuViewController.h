//
//  SlideMenuViewController.h
//  Yoku
//
//  Created by Ramesh on 11/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlideMenuViewController : UITableViewController

@end
