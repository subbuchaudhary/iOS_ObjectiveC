//
//  ProfileViewController.h
//  Hopwit.me
//
//  Created by Anyuta on 6/5/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileViewController : UIViewController
- (IBAction)profilesaved:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *usernamefld;

- (IBAction)uploadImgClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *selectedProfileimageview;
@property (strong,nonatomic) NSString *token;
@property (strong,nonatomic) NSString *userId;
@end
