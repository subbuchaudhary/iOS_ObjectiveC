//
//  PickTravellersViewController.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/24/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PickTravellersViewController : UIViewController
- (IBAction)adultsIncrement:(id)sender;
- (IBAction)adultsDecrement:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *adultsNumber;

@end
