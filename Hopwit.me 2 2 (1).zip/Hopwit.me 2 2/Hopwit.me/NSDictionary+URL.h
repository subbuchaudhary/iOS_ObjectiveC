//
//  NSDictionary+URL.h
//  Yoku
//
//  Created by Ramesh on 10/27/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EnumList.h"

@interface NSDictionary (URL)

+(NSString*)getURLString:(enum APICommandList)commandID withArguments:(NSArray*) arguments;

@end
