//
//  FlightResultsCell.h
//  Hopwit.me
//
//  Created by Subbu Chaudhary on 5/24/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlightResultsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *airportName;
@property (weak, nonatomic) IBOutlet UILabel *airportDetails;

@end
