//
//  VerifyOtpViewController.h
//  Hopwit.me
//
//  Created by Anyuta on 6/4/17.
//  Copyright © 2017 Anyuta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VerifyOtpViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *verifybtn;
@property (weak, nonatomic) IBOutlet UIButton *resendbtn;
@property(nonatomic,strong)NSString *verificationId;
@property(nonatomic,strong)NSString *mobilenumber;
@end
