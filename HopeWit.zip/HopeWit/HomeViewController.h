//
//  HomeViewController.h
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/9/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *tripsView;
@property (weak, nonatomic) IBOutlet UIView *homeView;
@property (weak, nonatomic) IBOutlet UIView *findView;
@property (weak, nonatomic) IBOutlet UIView *conversationView;
- (IBAction)tripBtnClkd:(id)sender;
- (IBAction)homeBtnClkd:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *findBtnClkd;
- (IBAction)conversationBtnClkd:(id)sender;
- (IBAction)findBtnClkd:(id)sender;

@end
