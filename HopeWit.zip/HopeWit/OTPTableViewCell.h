//
//  OTPTableViewCell.h
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/8/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTPTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *verificationField;
@property (weak, nonatomic) IBOutlet UILabel *mobileNumberDataPass;

@property (weak, nonatomic) IBOutlet UIButton *verifyBtn;
@property (weak, nonatomic) IBOutlet UIButton *resendBtn;
@end
