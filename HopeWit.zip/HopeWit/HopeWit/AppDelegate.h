//
//  AppDelegate.h
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/8/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

