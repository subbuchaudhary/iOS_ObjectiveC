//
//  OTPViewController.m
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/8/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "OTPViewController.h"
#import "OTPTableViewCell.h"
#import "HomeViewController.h"

@interface OTPViewController ()

@end

@implementation OTPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OTPTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OTPTableViewCell"];
    if(cell == nil)
    {
        cell = [[OTPTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"OTPTableViewCell"];
    }
    cell.verifyBtn.tag = indexPath.row;
    [cell.verifyBtn addTarget:self action:@selector(verifyBtnClkd:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

-(void) verifyBtnClkd:(UIButton*) sender
{
    HomeViewController *homeScreen = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self presentViewController:homeScreen animated:YES completion:nil];
}

@end
