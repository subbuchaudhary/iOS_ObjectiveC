//
//  HomeViewController.m
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/9/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import "HomeViewController.h"
#import "TripViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.tripsView setBackgroundColor:[UIColor whiteColor]];
    [self.homeView setBackgroundColor:[UIColor orangeColor]];
    [self.findView setBackgroundColor:[UIColor orangeColor]];
    [self.conversationView setBackgroundColor:[UIColor orangeColor]];
    TripViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"TripViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 150, self.view.frame.size.width, self.view.frame.size.height-150);
    [self.view addSubview:firstChildVC.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)tripBtnClkd:(id)sender {
    [self.tripsView setBackgroundColor:[UIColor whiteColor]];
    [self.homeView setBackgroundColor:[UIColor orangeColor]];
    [self.findView setBackgroundColor:[UIColor orangeColor]];
    [self.conversationView setBackgroundColor:[UIColor orangeColor]];
    TripViewController *firstChildVC = [self.storyboard instantiateViewControllerWithIdentifier:@"TripViewController"];
    [self addChildViewController:firstChildVC];
    [firstChildVC didMoveToParentViewController:self];
    firstChildVC.view.frame = CGRectMake(0, 150, self.view.frame.size.width, self.view.frame.size.height-150);
    [self.view addSubview:firstChildVC.view];
}

- (IBAction)homeBtnClkd:(id)sender {
}
- (IBAction)conversationBtnClkd:(id)sender {
}

- (IBAction)findBtnClkd:(id)sender {
}
@end
