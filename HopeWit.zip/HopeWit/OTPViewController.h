//
//  OTPViewController.h
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/8/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTPViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *otpTableView;

@end
