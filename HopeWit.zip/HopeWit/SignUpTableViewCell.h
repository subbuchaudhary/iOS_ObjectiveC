//
//  SignUpTableViewCell.h
//  HopeWit
//
//  Created by Nelakudhiti, Subba on 5/8/17.
//  Copyright © 2017 com.wellsfargo.internalapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *mobileNumberField;
@property (weak, nonatomic) IBOutlet UIButton *nextBtn;
@property (weak, nonatomic) IBOutlet UIButton *ageCheckBoxBtn;
@property (weak, nonatomic) IBOutlet UIButton *termsChkBox;

@end
