//
//  UIView+FSGViewSetFont.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "UIView+FSGViewSetFont.h"

@implementation UIView (FSGViewSetFont)

-(void) setFontForViewAndSubviews:(UIFont *)font {
    if ([self respondsToSelector:@selector(setFont:)]) {
        UIFont *oldFont = [self valueForKey:@"font"];
        UIFont *newFont = [font fontWithSize:oldFont.pointSize];
        [self setValue:newFont forKey:@"font"];
    }
    
    for (UIView *subview in self.subviews) {
        [subview setFontForViewAndSubviews:font];
    }
}

@end
