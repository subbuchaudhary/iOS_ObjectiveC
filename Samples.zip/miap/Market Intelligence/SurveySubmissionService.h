//
//  SurveySubmissionService.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu Manuru on 1/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MISurvey.h"
typedef NS_ENUM(NSInteger, SubmitStatus) {
    SF_SEND_SUCCESS,
    LOCAL_SAVE
};


@protocol SubmitSurveyResponseReceiver <NSObject>

-(void) receiveSubmitStatus:(SubmitStatus) status;

@end

@interface SurveySubmissionService : NSObject <NSURLConnectionDelegate>
{
    NSMutableData* responseData;
    id<SubmitSurveyResponseReceiver> statusReceiver;
}

-(id) initWithDelegate:(id<SubmitSurveyResponseReceiver>) delegate;

-(void) submitSurvey:(MISurvey*) survey;

@end
