//
//  SurveyType.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SurveyType.h"
#import "SuperCategory.h"


@implementation SurveyType

@dynamic superCategoryList;

@end
