//
//  DealerListService.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/7/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
//MI_V_1.0
#import "MIConstant.h"

@protocol DealerDataReceiver <NSObject>
@required
- (void) receiveDealerData: (NSMutableArray*) dealerData;
@optional
- (void) receiveValidateDealer:(MIDealerSummary*) dealer;
- (void) unableToValidateDealer:(NSString*) dealerNumber;
- (void) invalidDealerNumber:(NSString*) dealerNumber;
@end


@interface DealerListService : NSObject
{
    NSString* dealerNumberToValidate;
}


@property (weak,nonatomic) id<DealerDataReceiver> delegate;

-(id) initWithDelegate:(id<DealerDataReceiver>) delegate;
- (void) dealerDataForSSO:(NSString*) sso;

- (void) validateDealerNumber:(NSString*) dealerNumber;
@end
