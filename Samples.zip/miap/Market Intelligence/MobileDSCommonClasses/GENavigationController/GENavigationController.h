//
//  GENavigationController.h
//  MobileDS
//
//  Created  on 4/11/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import <UIKit/UIKit.h>

@interface GENavigationController : UINavigationController

@end
