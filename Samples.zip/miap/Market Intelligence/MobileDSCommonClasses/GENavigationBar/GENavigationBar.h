//
//  GENavigationBar.h
//  NavigationBarTest
//
//  Created  on 10/31/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com

#import <UIKit/UIKit.h>
#import "GEBarButton.h"
#import "GELabel.h"

#define RIGHTBARBUTTON_WIDTH 44
#define RIGHTBARBUTTON_HEIGHT 44

@interface GENavigationBar : UINavigationBar
{
    BOOL backButtonIsVisible;
    UIButton *backButton;
    UIView *rule;
    UIImageView *backImageView;
    UIView *backButtonContainer;
    float maxBackButtonWidth;
    UIImageView *GELogo;
}

@property(nonatomic, strong) UIColor *navColor;
@property(nonatomic,strong) UIView * GELogoBG;
@property(nonatomic,strong) GEBarButton *rightBarButton;
@property(nonatomic,strong) GEBarButton *secondaryRightBarButton;
@property(nonatomic,strong) GEBarButton *leftBarButton;
@property(nonatomic,strong) GEBarButton *secondaryLeftBarButton;

@property (nonatomic) GEBarButtonType rightBarButtonType;
@property (nonatomic) GEBarButtonType secondaryRightBarButtonType;
@property (nonatomic) GEBarButtonType leftBarButtonType;
@property (nonatomic) GEBarButtonType secondaryLeftBarButtonType;

@property (nonatomic, copy) NSString *leftBarButtonText;
@property (nonatomic, copy) NSString *secondaryLeftBarButtonText;

@property (nonatomic, copy) NSString *rightBarButtonText;

@property(nonatomic, strong) UIButton *backButton;
@property(nonatomic, strong)GELabel *vcTitleLabel;
@property(nonatomic, strong)NSString *vcTitle;
@property(nonatomic) BOOL keepsFlagIniPad;



- (void)revealBackButton;
- (void)hideBackButton:(BOOL)hideGELabel;
- (void)hideGEButtonAnimated:(BOOL)animated;
- (void)showGEButton;
- (void)setLeftBarButtonText:(NSString *)string;
- (void)setRightBarButtonText:(NSString *)string;
- (void)showFlag;
- (void)hideFlag;
- (void)removeFlag;
- (void)coverBackButton;



@end
