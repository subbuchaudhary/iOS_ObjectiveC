//
//  GENavigationBar.m
//  NavigationBar
//
//  Created  on 10/31/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com

#import "GENavigationBar.h"
#import "GEColor.h"
#import <QuartzCore/QuartzCore.h>

@implementation GENavigationBar
@synthesize rightBarButtonType = _rightBarButtonType;
@synthesize secondaryRightBarButtonType = _secondaryRightBarButtonType;
@synthesize navColor = _navColor;
@synthesize GELogoBG;
@synthesize backButton;
@synthesize vcTitleLabel;
@synthesize vcTitle = _vcTitle;



-(id)init{
    self = [super init];
    if(self){
               [self sharedInit];
    }
    return self;
}

-(void)sharedInit{
    if (self) {
        
        [self setNeedsDisplay];
    }
}

- (id)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
      
        self.frame = CGRectMake(0, 0, 320, 48);

        UIImageView *bgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, 44)];
       
        
        bgView.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth;
        
        bgView.image = [UIImage imageNamed:@"GENavigationBG.png"];
        
        [self addSubview:bgView];
        
        [self setBackgroundImage:[UIImage imageNamed:@"GENavigationBG.png"] forBarMetrics:UIBarMetricsDefault];
        
        self.shadowImage = [[UIImage alloc]init];
        
        

        
        GELogoBG = [[UIView alloc]initWithFrame:CGRectMake(10, -5, 48, 53)];
     
        if(!_navColor){
            _navColor = GE_COLOR_BLUE_DARK;
        }
        
        GELogoBG.frame = CGRectMake(10, -5, 48, 53);
        GELogoBG.layer.cornerRadius = 2;
        GELogoBG.backgroundColor = _navColor;
        
        [self addSubview:GELogoBG];
        
        
        
        
        if(self.items.count > 1){
 
            backButton = [UIButton buttonWithType:UIButtonTypeCustom];
            NSString *bbtext = [self.backItem.title uppercaseString];
            CGSize backButtonSize = [bbtext sizeWithFont:[UIFont fontWithName:@"GEInspira-ExtraBold" size:12]];
            backButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:12];
            backButton.frame = CGRectMake(22, 0, backButtonSize.width, 48);
            [backButton setTitle:bbtext forState:UIControlStateNormal];
            [backButton addTarget:self action:@selector(backButtonPressed) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:backButton];
            rule = [[UIView alloc]initWithFrame:CGRectMake(22, 35, backButtonSize.width, 1)];
            rule.backgroundColor = GE_COLOR_GROUND_ACCENT_50A;
            [self addSubview:rule];
            
        }
        
        
        GELogo = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 48, 48)];
        
        GELogo.image = [UIImage imageNamed:@"GENavBarLogo.png"];
        
        [GELogoBG addSubview:GELogo];
        
        vcTitleLabel = [[GELabel alloc]initWithFont:GE_Inspira_Ext_Bold Size:12 andColor:GE_COLOR_WHITE];
        [self addSubview:vcTitleLabel];
        
        self.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    }
    
    return self;
}





- (void)setNavColor:(UIColor*)color
{
    GELogoBG.backgroundColor = color;
    [self setNeedsDisplay];

}

- (void)setRightBarButtonType:(GEBarButtonType)buttonType
{
    [_rightBarButton removeFromSuperview];

    _rightBarButtonType = buttonType;
    _rightBarButton = [[GEBarButton alloc]initWithFrame:CGRectMake(self.bounds.size.width - RIGHTBARBUTTON_WIDTH, 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andType:_rightBarButtonType];
    _rightBarButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
   [self addSubview:_rightBarButton];

}


- (void)setSecondaryRightBarButtonType:(GEBarButtonType)buttonType
{
    [_secondaryRightBarButton removeFromSuperview];
    
    _secondaryRightBarButtonType = buttonType;
    _secondaryRightBarButton = [[GEBarButton alloc]initWithFrame:CGRectMake(self.bounds.size.width - (RIGHTBARBUTTON_WIDTH *2), 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andType:_secondaryRightBarButtonType];
    _secondaryRightBarButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:_secondaryRightBarButton];
    
}

- (void)setLeftBarButtonType:(GEBarButtonType)buttonType
{
    [_leftBarButton removeFromSuperview];
    _leftBarButtonType = buttonType;
    _leftBarButton = [[GEBarButton alloc]initWithFrame:CGRectMake(0, 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andType:_leftBarButtonType];
    _leftBarButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    [self addSubview:_leftBarButton];
    
}

- (void)setSecondaryLeftBarButtonType:(GEBarButtonType)buttonType
{
    [_secondaryLeftBarButton removeFromSuperview];
    
    _secondaryLeftBarButtonType = buttonType;
    _secondaryLeftBarButton = [[GEBarButton alloc]initWithFrame:CGRectMake(2*RIGHTBARBUTTON_WIDTH, 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andType:_secondaryLeftBarButtonType];
    _secondaryLeftBarButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    [self addSubview:_secondaryLeftBarButton];
}

- (void)setLeftBarButtonText:(NSString *)string
{
    [_leftBarButton removeFromSuperview];
    _leftBarButtonType = GEBarButtonText;
    _leftBarButton = [[GEBarButton alloc] initWithFrame:CGRectMake(10, 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andText:string];
    _leftBarButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    [self addSubview:_leftBarButton];
}

- (void)setSecondaryLeftBarButtonText:(NSString *)string
{
    [_secondaryLeftBarButton removeFromSuperview];
    _secondaryLeftBarButtonType = GEBarButtonText;
    _secondaryLeftBarButton = [[GEBarButton alloc] initWithFrame:CGRectMake(self.leftBarButton.frame.origin.x+self.leftBarButton.frame.size.width + 20, 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andText:string];
    _secondaryLeftBarButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    [self addSubview:_secondaryLeftBarButton];
}

- (void)setRightBarButtonText:(NSString *)string
{
    [_rightBarButton removeFromSuperview];
    _rightBarButtonType = GEBarButtonText;
    _rightBarButton = [[GEBarButton alloc] initWithFrame:CGRectMake(self.bounds.size.width - RIGHTBARBUTTON_WIDTH, 0, RIGHTBARBUTTON_WIDTH, RIGHTBARBUTTON_HEIGHT) andText:string];
    _rightBarButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:_rightBarButton];
}

-(void)setVcTitle:(NSString *)title{
    _vcTitle = [title uppercaseString];
    CGFloat actualSize;
    float maxTitleSize = (self.frame.size.width/2 - 68)*2;
 
    CGSize titleSize = [_vcTitle sizeWithFont:[UIFont fontWithName:@"GEInspira-ExtraBold" size:12] minFontSize:12 actualFontSize:&actualSize forWidth:maxTitleSize lineBreakMode:NSLineBreakByTruncatingTail];
    vcTitleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    vcTitleLabel.frame = CGRectMake(roundf(self.frame.size.width/2 - titleSize.width/2), roundf(self.frame.size.height/2 - titleSize.height/2), titleSize.width, titleSize.height);
    vcTitleLabel.text = _vcTitle;
    vcTitleLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
   
    maxBackButtonWidth = (self.frame.size.width/2 - vcTitleLabel.frame.size.width/2)  - 18 - 25-55;
    if (maxBackButtonWidth < 55) {
        maxBackButtonWidth = 55;
    }
}

-(void)revealBackButton{
    
    UIImage *backImage = [UIImage imageNamed:@"GENavBarBackButton.png"];;
    backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    if (!backButtonContainer) {
        backButtonContainer = [[UIView alloc]init];
        
        backImageView = [[UIImageView alloc]initWithImage:backImage];
        backImageView.frame = CGRectMake(0, 29 - backImage.size.height, backImage.size.width, backImage.size.height);
        
        CGFloat actualSize;
        NSString *bbtext = [self.backItem.title uppercaseString];
        CGSize backButtonSize = [bbtext sizeWithFont:[UIFont fontWithName:@"GEInspira-ExtraBold" size:12] minFontSize:10 actualFontSize:&actualSize forWidth:maxBackButtonWidth lineBreakMode:NSLineBreakByTruncatingTail];
        float backButtonWidth;
        if (backButtonSize.width < maxBackButtonWidth) {
            if (backButtonSize.width < 44) {
                backButtonWidth = 44;
            }else{
            backButtonWidth = backButtonSize.width;
            }
        }else{
            backButtonWidth = maxBackButtonWidth;
        }
        backButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:12];
        backButton.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        backButton.frame = CGRectMake(1 + backImage.size.width, 0, backButtonWidth, 48);
        [backButton setTitle:bbtext forState:UIControlStateNormal];
        
        
        
        rule = [[UIView alloc]initWithFrame:CGRectMake(0, 35, backButtonSize.width + backImage.size.width + 4, 1)];
        rule.backgroundColor = GE_COLOR_GROUND_ACCENT_50A;

        backButtonContainer.frame = CGRectMake(18,-1, backButtonSize.width + backImage.size.width + 4, 48);
        [backButtonContainer addSubview:backImageView];
        [backButtonContainer addSubview:backButton];
        [backButtonContainer addSubview:rule];
        backButtonContainer.alpha = 0;
        [self addSubview:backButtonContainer];
    } else{
        
        NSString *bbtext = [self.backItem.title uppercaseString];
        CGSize backButtonSize = [bbtext sizeWithFont:[UIFont fontWithName:@"GEInspira-ExtraBold" size:12]];
                float backButtonWidth;
        if (backButtonSize.width < maxBackButtonWidth) {
            if (backButtonSize.width < 44) {
                backButtonWidth = 44;
            }else{
                backButtonWidth = backButtonSize.width;
            }
        }else{
            backButtonWidth = maxBackButtonWidth;
        }

        
        backButton.titleLabel.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:12];
        backButton.frame = CGRectMake(4 + backImage.size.width, -1, backButtonWidth, 48);
        [backButton setTitle:bbtext forState:UIControlStateNormal];
        backButtonContainer.frame = CGRectMake(18,-1, backButtonWidth+ backImage.size.width + 4, 48);

    
    
    }
    [backButton addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchDown];
    [backButton addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchUpOutside];
    [backButton addTarget:self action:@selector(dimRule) forControlEvents:UIControlEventTouchUpInside];

    
    [UIView animateWithDuration:.1 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
    
    
        backButtonContainer.alpha = 1;
        
    }completion:^(BOOL complete){
    
        [self hideGEButtonAnimated:YES];
    }];

 

}

-(void)coverBackButton{

backButtonContainer.alpha = 0;
}

- (void)hideBackButton:(BOOL)hideGELabel
{
    if (!hideGELabel) {
        [UIView animateWithDuration:.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            GELogoBG.frame = CGRectMake(10, -5, 48, 53);

            backButtonContainer.alpha = 0;
        } completion:^(BOOL complete){
            [backButtonContainer removeFromSuperview];
            backButtonContainer = nil;
            
            [self showGEButton];
        }];
    }
}


-(void)removeFlag{
    
    GELogoBG.frame =  CGRectMake(-200, -5, 52, 53);
    GELogoBG.alpha = 0.0;
}

-(void)hideFlag{

    if(GELogoBG.frame.origin.x == 10){
        [UIView animateWithDuration:.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
       GELogoBG.frame =  CGRectMake(-42, -5, 52, 53);
                          }completion:^(BOOL finished) {
                              
                          }];
    }
}

-(void)showFlag{

    if(GELogoBG.frame.origin.x != 10){
        [UIView animateWithDuration:.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            GELogoBG.frame = CGRectMake(10, -5, 48, 53);
        }completion:^(BOOL finished) {
            
        }];
    }
}

- (void)hideGEButtonAnimated:(BOOL)animated
{
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
    if (animated) {
        [UIView animateWithDuration:.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            if(!self.keepsFlagIniPad){
                {
                    GELogoBG.alpha = 0;
                }
        }
        }completion:^(BOOL finished) {
            
        }];
        }
    else {
        if(!self.keepsFlagIniPad){
        GELogoBG.alpha = 0;
        }
    }
    }
}

- (void)showGEButton
{
    [UIView animateWithDuration:.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{

    GELogoBG.alpha = 1;
        }completion:^(BOOL finished) {
    
}];
}

-(void)dimRule{
    if([rule.backgroundColor isEqual:GE_COLOR_GROUND_ACCENT_50A]){
        rule.backgroundColor = GE_COLOR_GROUND;
        
    } else{
        rule.backgroundColor = GE_COLOR_GROUND_ACCENT_50A;
    }
    
}

@end
