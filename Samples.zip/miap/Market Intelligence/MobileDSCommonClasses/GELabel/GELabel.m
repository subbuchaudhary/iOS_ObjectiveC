//
//  GELabel.m
//  MobileDesignSystem
//
//  Created  on 10/5/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import "GELabel.h"

@implementation GELabel

-(id)initWithFrame:(CGRect)frame Font:(GELabel_Font) GE_Font Size:(int)fontSize andColor:(UIColor *)Color
{
    self = [super initWithFrame:frame];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(id)initWithFont:(GELabel_Font)GE_Font Size:(int)fontSize andColor:(UIColor *)Color
{
    self = [super init];
    if (self) {
        switch (GE_Font) {
            case GE_Inspira:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
            case GE_Inspira_Medium:
                self.font = [UIFont fontWithName:@"GEInspira-Medium" size:fontSize];
                break;
            case GE_Inspira_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-Bold" size:fontSize];
                break;
            case GE_Inspira_Ext_Bold:
                self.font = [UIFont fontWithName:@"GEInspira-ExtraBold" size:fontSize];
                break;
            case Lucida_Grand:
                self.font = [UIFont fontWithName:@"LucidaGrande" size:fontSize];
                break;
            case Lucida_Grand_Bold:
                self.font = [UIFont fontWithName:@"LucidaGrande-Bold" size:fontSize];
                break;
            default:
                self.font = [UIFont fontWithName:@"GEInspira" size:fontSize];
                break;
        }
        self.textColor = Color;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
    
}
- (id)initWithFrame:(CGRect)frame AttributedString:(NSAttributedString *)string
{
    self = [super initWithFrame:frame];
    
    if (self) {
        self.attributedText = string;
    }
    
    return self;
}



-(void)awakeFromNib
{
    [super awakeFromNib];
        self.backgroundColor = [UIColor clearColor];
    self.font = [UIFont fontWithName:@"GEInspira" size:17];
    self.textColor = GE_COLOR_GRAY_0;
}





@end
