//
//  GETabBarViewController.h
//  MobileDesignSystem
//
//  Created  on 10/26/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import "GEViewController.h"
#import "GETabBar.h"

@interface GETabBarViewController : GEViewController<GETabBarDelegate>

@property (nonatomic, strong)GETabBar *tabBar;

@property (nonatomic, weak)NSArray *tabBarItems;
@property (nonatomic, strong)UIColor *accentColor;

@end
