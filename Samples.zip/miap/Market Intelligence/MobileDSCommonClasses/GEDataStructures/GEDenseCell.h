//
//  GEDenseCell.h
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, GECell_Type) {
    GECell_Text,
    GECell_Bar,
    GECell_CurrencyUSD,
    GECell_Percentage,
    GECell_Change,
    GECell_LargeNumber,
    GECell_ColumnHeader,
    GECell_RowHeader
};

/*
 * GEDenseCell represents one cell of content within a row
 * of Dense Tabular Data
 */
@interface GEDenseCell : NSObject

@property (nonatomic, strong) NSString *title;
@property (nonatomic) CGFloat value;
@property (nonatomic) BOOL isAlert;
@property (nonatomic) BOOL isSelected;
@property (nonatomic) BOOL isSelectedMulti;
@property (nonatomic) BOOL isSelectedSingleRow;
@property (nonatomic) NSInteger column;
@property (nonatomic) NSInteger row;
@property (nonatomic, assign) GECell_Type type;

- (id)initWithTitle:(NSString *)title Type:(GECell_Type)type Alert:(BOOL)isAlert;
- (id)initWithValue:(CGFloat)value Type:(GECell_Type)type Alert:(BOOL)isAlert;


@end


