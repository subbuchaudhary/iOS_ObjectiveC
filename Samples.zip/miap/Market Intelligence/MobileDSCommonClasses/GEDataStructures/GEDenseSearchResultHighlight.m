//
//  GEDenseSearchResultHighlight.m
//  MobileDesignSystem
//
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//

#import "GEDenseSearchResultHighlight.h"
#import "GEColor.h"
#import "GELabel.h"
#import <QuartzCore/QuartzCore.h>

@implementation GEDenseSearchResultHighlight

- (id)initWithFrame:(CGRect)frame andContents:(NSString*)contentString
{
    self = [super initWithFrame:frame];
    if (self) {
        float sidePadding;
        float topPadding;
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
        {
            sidePadding = 7;
            topPadding = 14;
        } else{
            sidePadding = 5;
            topPadding = 8;
        }
    
    
    self.backgroundColor = GE_COLOR_NOTIFICATION;
    self.layer.borderColor = GE_COLOR_WHITE.CGColor;
    self.layer.borderWidth = 2.0f;
    self.layer.cornerRadius = 5.0;
    
    GELabel *highlightedTextLabel = [[GELabel alloc]initWithFont:Lucida_Grand_Bold Size:15 andColor:GE_COLOR_WHITE];
    CGSize highlightSize = [self widthOfCellFromText:contentString Label:highlightedTextLabel];
    highlightedTextLabel.frame = CGRectMake(sidePadding, topPadding, highlightSize.width, highlightSize.height);
        highlightedTextLabel.text = contentString;
    
    self.frame = CGRectMake(frame.origin.x, frame.origin.y, highlightSize.width + (2*sidePadding), highlightSize.height + (2*topPadding));
   
    [self addSubview:highlightedTextLabel];
    
    
    }
    
    
    return self;
}

- (CGSize)widthOfCellFromText:(NSString *)text Label:(GELabel *)label
{
    CGSize maximumSize = CGSizeMake(9999, 44+1);
    CGSize myStringSize = [text sizeWithFont:label.font
                           constrainedToSize:maximumSize
                               lineBreakMode:label.lineBreakMode];
    
    return myStringSize;
}

@end
