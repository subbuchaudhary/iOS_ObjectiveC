//
//  GEBlankViewController.h
//  MobileDesignSystem
//
//  Created  on 12/18/12.
//  Copyright (c) 2012 Monsoon Co. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GEBlankViewController : UIViewController

@end
