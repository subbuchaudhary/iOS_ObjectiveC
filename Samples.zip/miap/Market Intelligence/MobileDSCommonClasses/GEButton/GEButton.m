//
//  GEButton.m
//  MobileDesignSystem
//
//  Created  on 10/5/12.
//  Copyright (c) 2012 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//
//
//
//

#import "GEButton.h"




@implementation GEButton{

}
@synthesize button;
@synthesize buttonTextLabel;
@synthesize rule;
@synthesize buttonText;
@synthesize attributedbuttonText;
@synthesize iconImage;
@synthesize gridImage;


//Basic Init
- (id)initWithFrame:(CGRect)frame color:(UIColor *)GEColor andAttributedString:(NSAttributedString *)attributedString
{
    self = [super initWithFrame:frame];
    if (self) {
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0,0,self.frame.size.width,self.frame.size.height);
       
        
        CALayer *ImageLayer = [[CALayer alloc]init];
        ImageLayer.frame = CGRectMake(0,0,self.frame.size.width,self.frame.size.height);
        ImageLayer.cornerRadius = 5;
        ImageLayer.backgroundColor = GEColor.CGColor ;

        CALayer *TapLayer = [[CALayer alloc]init];
        TapLayer.frame = CGRectMake(0,0,self.frame.size.width,self.frame.size.height);
        TapLayer.cornerRadius = 5;
        TapLayer.backgroundColor = [self tapColorforColor:GEColor].CGColor;
        
    
        
        UIImage *defaultBackgroundImage = [self imageFromLayer:ImageLayer];
        [button setBackgroundImage:defaultBackgroundImage forState:UIControlStateNormal];
        
        [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];

        
        [self addSubview:button];
        
        rule = [[UIView alloc]initWithFrame:CGRectMake(6, frame.size.height - 6, frame.size.width - 12, 2)];
        rule.backgroundColor = GE_COLOR_WHITE_20A;
        [self addSubview:rule];
        buttonTextLabel = [[GELabel alloc]initWithFrame:CGRectMake(4, 0, frame.size.width - 8, frame.size.height) Font:GE_Inspira_Medium Size:18 andColor:GE_COLOR_WHITE];
        buttonTextLabel.textAlignment = NSTextAlignmentCenter;
        buttonTextLabel.attributedText = attributedString;
        
        [self addSubview:buttonTextLabel];
        
        
       
    }
    return self;
}

- (id)initWithStyle:(GEButtonStyle)GEButtonStyle
           andColor:(UIColor *)GEColor{
    
    self = [super init];
    if(self){
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        
        CALayer *ImageLayer = [[CALayer alloc]init];
        
        ImageLayer.cornerRadius = 5;
        ImageLayer.backgroundColor = GEColor.CGColor;
        
        CALayer *TapLayer = [[CALayer alloc]init];
        TapLayer.cornerRadius = 5;
        TapLayer.backgroundColor = [self tapColorforColor:GEColor].CGColor;
        
        //Set size for various types
        CGSize buttonSize;
        
        if (GEButtonStyle == GEButtonStyleLarge) {
            
            buttonSize = CGSizeMake(LARGE_BUTTON_WIDTH, LARGE_BUTTON_HEIGHT);
            ImageLayer.frame = CGRectMake(0,0, buttonSize.width, buttonSize.height);
            TapLayer.frame = ImageLayer.frame;
        
            //Create Button Background
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            button.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            self.frame = button.frame;
            [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
            
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
            
            [self addSubview:button];
                
            rule = [[UIView alloc]initWithFrame:CGRectMake(6, buttonSize.height - 6, buttonSize.width - 12, 2)];
            rule.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
            
            rule.backgroundColor = GE_COLOR_WHITE_20A;
            [self addSubview:rule];
                
                
            buttonTextLabel = [[GELabel alloc]initWithFrame:CGRectMake(4, 0, buttonSize.width - 8, buttonSize.height) Font:GE_Inspira_Medium Size:18 andColor:GE_COLOR_WHITE];
            buttonTextLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
            
            buttonTextLabel.textAlignment = NSTextAlignmentCenter;

                
            [self addSubview:buttonTextLabel];
        
        } else if(GEButtonStyle == GEButtonStyleIcon) {
            buttonSize = CGSizeMake(ICON_BUTTON_WIDTH, ICON_BUTTON_HEIGHT);
            ImageLayer.frame = CGRectMake(0,0, buttonSize.width, buttonSize.height);
            TapLayer.frame = ImageLayer.frame;
            
            //Create Button and BackgroundBackground
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            self.frame = button.frame;
            [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
            
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
            
            [self addSubview:button];
            
            rule = [[UIView alloc]initWithFrame:CGRectMake(6, buttonSize.height - 3, buttonSize.width - 12, 2)];
            rule.backgroundColor = GE_COLOR_WHITE_20A;
            [self addSubview:rule];
            
            
            iconImageView = [[UIImageView alloc]initWithFrame:CGRectMake(6, 6, ICON_BUTTON_ICON_SQR, ICON_BUTTON_ICON_SQR)];
                        
            
            [self addSubview:iconImageView];
   
        

        } else if(GEButtonStyle == GEButtonStyleNavigationImage){
        
            
            buttonSize = CGSizeMake(NAVIGATION_BUTTON_WIDTH, NAVIGATION_BUTTON_HEIGHT);
            ImageLayer.backgroundColor = GE_COLOR_WHITE.CGColor;
            ImageLayer.frame = CGRectMake(0,0, buttonSize.width, buttonSize.height);
            TapLayer.frame = ImageLayer.frame;
            TapLayer.backgroundColor = GE_COLOR_GRAY_4.CGColor;
            
            
            //Create Button Background
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            self.frame = button.frame;
            [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateSelected];
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
            
            [self addSubview:button];
            
            rule = [[UIView alloc]initWithFrame:CGRectMake(buttonSize.width - 6,  6, 2, buttonSize.height-12)];
            rule.backgroundColor = GEColor;
            [self addSubview:rule];
            
            //Create Icon ImageView
            
            iconImageView = [[UIImageView alloc]initWithFrame:CGRectMake(4, 4, NAVIGATION_BUTTON_ICON_SQR, NAVIGATION_BUTTON_ICON_SQR)];
            
            [self addSubview:iconImageView];
            
            
        
            
            //Create Text Label
            
            
            
            buttonTextLabel = [[GELabel alloc]initWithFrame:CGRectMake(4 + NAVIGATION_BUTTON_ICON_SQR + 8, 6, buttonSize.width - 8 - NAVIGATION_BUTTON_ICON_SQR, buttonSize.height- 12) Font:Lucida_Grand Size:10 andColor:GE_COLOR_GRAY_1];
            buttonTextLabel.textAlignment = NSTextAlignmentLeft;
            buttonTextLabel.numberOfLines = 3;
          
            
            [self addSubview:buttonTextLabel];
        
           
        
        }else if(GEButtonStyle == GEButtonStyleThumbnailGrid){
        
            int ruleSize;
            if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
                buttonSize = CGSizeMake(THUMNAILGRID_BUTTON_SIZE_iPhone, THUMNAILGRID_BUTTON_SIZE_iPhone);
                ruleSize = 2;
            }
            else {
                buttonSize = CGSizeMake(THUMNAILGRID_BUTTON_SIZE_iPad, THUMNAILGRID_BUTTON_SIZE_iPad);
                ruleSize = 3;
            }
            //buttonSize = CGSizeMake(THUMBNAILGRID_BUTTON_WIDTH, THUMNAILGRID_BUTTON_HEIGHT);
            ImageLayer.backgroundColor = GE_COLOR_WHITE.CGColor;
            ImageLayer.frame = CGRectMake(0,0, buttonSize.width, buttonSize.height);
            TapLayer.frame = ImageLayer.frame;
            TapLayer.backgroundColor = GE_COLOR_GRAY_SECONDARY.CGColor;
            
            
            //Create Button Background
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            self.frame = button.frame;
            
            [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
            
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
            
            [self addSubview:button];
            

            
            //Create Icon ImageView
            
            iconImageView = [[UIImageView alloc]initWithFrame:CGRectMake(4, 4, buttonSize.width-4, buttonSize.height-4)];
            
            [self addSubview:iconImageView];
            
            
            rule = [[UIView alloc]initWithFrame:CGRectMake(buttonSize.width - 6,  6, ruleSize, buttonSize.height-12)];
            rule.backgroundColor = GEColor;
            [self addSubview:rule];
        }
        else if (GEButtonStyle == GEButtonStyleDetail) {
            buttonSize = CGSizeMake(LARGE_BUTTON_WIDTH, LARGE_BUTTON_HEIGHT);
            ImageLayer.frame = CGRectMake(0,0, buttonSize.width, buttonSize.height);
            TapLayer.frame = ImageLayer.frame;
            
            //Create Button Background
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            self.frame = button.frame;
            [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
            
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
            
            [self addSubview:button];
            
            rule = [[UIView alloc]initWithFrame:CGRectMake(6, buttonSize.height - 6, buttonSize.width - 12, 2)];
            rule.backgroundColor = GE_COLOR_WHITE_20A;
            [self addSubview:rule];
            
            
            buttonTextLabel = [[GELabel alloc]initWithFrame:CGRectMake(4, 0, buttonSize.width - 8, buttonSize.height) Font:GE_Inspira_Medium Size:16 andColor:GE_COLOR_WHITE];
            buttonTextLabel.textAlignment = NSTextAlignmentCenter;
            
            
            [self addSubview:buttonTextLabel];
        }
        else if (GEButtonStyle == GEButtonStyleChartFilter) {
            buttonSize = CGSizeMake(CHART_BUTTON_WIDTH, CHART_BUTTON_HEIGHT);
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            self.frame = button.frame;
           
                //Create Button Background
            UIView *chartBG = [[UIView alloc]initWithFrame:CGRectMake(0,0, buttonSize.width, buttonSize.height)];
            chartBG.backgroundColor = [UIColor clearColor];
            UIView *chartIcon = [[UIView alloc]initWithFrame:CGRectMake(0, 2.0, 10.0, 10.0)];
            chartIcon.layer.cornerRadius = 2.0;
            chartIcon.backgroundColor = GEColor;
            [chartBG addSubview:chartIcon];
            
            UIView* chartrule = [[UIView alloc]initWithFrame:CGRectMake(0, buttonSize.height - 3, buttonSize.width, 3)];
            chartrule.backgroundColor = GEColor;
            [chartBG addSubview:chartrule];
            [button setBackgroundImage:[self imageWithView:chartBG] forState:UIControlStateNormal];
            
            chartIcon.backgroundColor = GE_COLOR_GROUND;
            chartrule.backgroundColor = GE_COLOR_GROUND;
            chartrule.frame = CGRectMake(chartrule.frame.origin.x, chartrule.frame.origin.y, chartrule.frame.size.width,2);
            
            [button setBackgroundImage:[self imageWithView:chartBG] forState:UIControlStateHighlighted];
            [button setBackgroundImage:[self imageWithView:chartBG] forState:UIControlStateSelected];
            
        
            [self addSubview:button];
            

            
            
            buttonTextLabel = [[GELabel alloc]initWithFrame:CGRectMake(14.0, 0, buttonSize.width - 10, buttonSize.height - 12) Font:GE_Inspira_Medium Size:16 andColor:GE_COLOR_CHROME];
            buttonTextLabel.textAlignment = NSTextAlignmentLeft;
            
            
            [self addSubview:buttonTextLabel];
        }
        else if (GEButtonStyle == GEButtonStyleDetailIcon) {
            buttonSize = CGSizeMake(DETAILICON_BUTTON_WIDTH, DETAILICON_BUTTON_HEIGHT);
            iconImageView = [[UIImageView alloc]initWithFrame:CGRectMake(18, 10, DETAILICON_ICON_SQR, DETAILICON_ICON_SQR)];
            ImageLayer.frame = CGRectMake(0,0, buttonSize.width, buttonSize.height);
            TapLayer.frame = ImageLayer.frame;
            
            //Create Button Background
            
            button.frame = CGRectMake(0,0,buttonSize.width, buttonSize.height);
            self.frame = button.frame;
            [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
            
            [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
            
            [self addSubview:button];
            [self addSubview:iconImageView];
            
            rule = [[UIView alloc]initWithFrame:CGRectMake(6, buttonSize.height - 6, buttonSize.width - 12, 2)];
            rule.backgroundColor = GE_COLOR_WHITE_20A;
            [self addSubview:rule];
            
            
            buttonTextLabel = [[GELabel alloc]initWithFrame:CGRectMake(18 + DETAILICON_ICON_SQR + 6, 0, buttonSize.width - 8, buttonSize.height) Font:GE_Inspira_Medium Size:18 andColor:GE_COLOR_WHITE];
            buttonTextLabel.textAlignment = NSTextAlignmentLeft;
            
            
            [self addSubview:buttonTextLabel];
        }

    }

    return self;
}



-(void)setButtonText:(NSString *)buttonText_{

    if(buttonText == buttonText_) return;
    
    buttonText = buttonText_;

    //TODO:Resize Subviews with larger string
    
    //    CGSize newSize = [buttonText sizeWithFont:[UIFont fontWithName:@"GEInspira-Medium" size:18]];
//    self.frame = CGRectMake(self.frame.origin.x,self.frame.origin.y,newSize.width + 16,newSize.height);
    
    buttonTextLabel.text = buttonText;



}

-(void)setAttributedButtonText:(NSAttributedString *)attributedbuttonText_{
    
    if([attributedbuttonText isEqualToAttributedString:attributedbuttonText_]) return;
    
    attributedbuttonText = attributedbuttonText_;
    
    //TODO:Resize Subviews with larger string
    
    
    buttonTextLabel.attributedText = attributedbuttonText;
    

}


-(void)setIconImage:(UIImage *)iconImage_{
    
    if([iconImage isEqual:iconImage_]) return;
    
    iconImage = iconImage_;
    
    iconImageView.image = iconImage;
    
    
}

-(void)setGridImage:(UIImage *)gridImage_{
    
    if([gridImage isEqual:gridImage_]) return;
    
    gridImage = gridImage_;
    
    [self.button setImage:gridImage forState:UIControlStateNormal];
    
    UIImageView *tapStateImage = [[UIImageView alloc]initWithImage:gridImage];
    UIView *overlay = [[UIView alloc]initWithFrame:tapStateImage.frame];
    overlay.backgroundColor = GE_COLOR_GRAY;
    overlay.alpha = 0.5;
    overlay.layer.cornerRadius = 5;
    
    [tapStateImage addSubview:overlay];
    tapStateImage.layer.cornerRadius = 5;
    [self.button setImage:[self imageWithView:tapStateImage] forState:UIControlStateHighlighted];
    
    
    
    
}

-(void)setButtonColor:(UIColor *)buttonColor
{
    _buttonColor = buttonColor;
    
    CALayer *ImageLayer = [[CALayer alloc]init];
    
    ImageLayer.cornerRadius = 5;
    ImageLayer.backgroundColor = _buttonColor.CGColor;
    
    CALayer *TapLayer = [[CALayer alloc]init];
    TapLayer.cornerRadius = 5;
    TapLayer.backgroundColor = [self tapColorforColor:_buttonColor].CGColor;
    
    ImageLayer.frame = CGRectMake(0,0, button.frame.size.width, button.frame.size.height);
    TapLayer.frame = ImageLayer.frame;
    
    [button setBackgroundImage:[self imageFromLayer:ImageLayer] forState:UIControlStateNormal];
    
    [button setBackgroundImage:[self imageFromLayer:TapLayer] forState:UIControlStateHighlighted];
    
    


}



#pragma mark Utility Methods

- (UIImage *)imageFromLayer:(CALayer *)layer
{
    UIGraphicsBeginImageContext([layer frame].size);
    
    [layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *outputImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();

    UIImage *resizeableImage = [outputImage resizableImageWithCapInsets:UIEdgeInsetsMake(5,5,5,5) resizingMode:UIImageResizingModeStretch];
    return resizeableImage;
}





-(UIColor *)tapColorforColor:(UIColor*)GEColor{
    
    if ([GEColor isEqual: GE_COLOR_BLUE_PRIMARY])
        return GE_COLOR_BLUE_LIGHT;
    
    if ([GEColor isEqual: GE_COLOR_CYAN_PRIMAY])
        return GE_COLOR_CYAN_LIGHT;
    
    if ([GEColor isEqual:GE_COLOR_CYAN_LIGHT])
        return GE_COLOR_CYAN_PRIMAY;
    
    if ([GEColor isEqual: GE_COLOR_BLUE_DARK])
        return GE_COLOR_BLUE_PRIMARY;
    
    if ([GEColor isEqual: GE_COLOR_BLUE_LIGHT])
         return GE_COLOR_BLUE_PRIMARY;
         
    if ([GEColor isEqual: GE_COLOR_PURPLE_PRIMARY])
        return GE_COLOR_PURPLE_LIGHT;
    
    if ([GEColor isEqual: GE_COLOR_PURPLE_LIGHT])
        return GE_COLOR_PURPLE_PRIMARY;
        
    if ([GEColor isEqual: GE_COLOR_RED_PRIMARY])
       return GE_COLOR_RED_LIGHT;
   
    if ([GEColor isEqual: GE_COLOR_RED_LIGHT])
        return GE_COLOR_RED_PRIMARY;

    if ([GEColor isEqual: GE_COLOR_ORANGE_PRIMARY])
        return GE_COLOR_ORANGE_LIGHT;
    
    if ([GEColor isEqual: GE_COLOR_ORANGE_LIGHT])
        return GE_COLOR_ORANGE_PRIMARY;
    
    if ([GEColor isEqual: GE_COLOR_GREEN_PRIMARY])
        return GE_COLOR_GREEN_LIGHT;
    
    if ([GEColor isEqual: GE_COLOR_GREEN_LIGHT])
        return GE_COLOR_GREEN_PRIMARY;
    
    if ([GEColor isEqual: GE_COLOR_GRAY_0])
        return GE_COLOR_GRAY_4;
    
    if ([GEColor isEqual: GE_COLOR_GRAY_1])
        return GE_COLOR_GRAY_3;
    
    if ([GEColor isEqual: GE_COLOR_GRAY_2])
        return GE_COLOR_WHITE;
    
    if ([GEColor isEqual: GE_COLOR_GRAY_3])
        return GE_COLOR_GRAY_2;
    
    if ([GEColor isEqual:GE_COLOR_GRAY_4])
        return GE_COLOR_GRAY_1;
    
    if ([GEColor isEqual:GE_COLOR_WHITE])
        return GE_COLOR_GRAY_SECONDARY;
    
    return GE_COLOR_WHITE_80A;

}

#pragma mark - chart Button Actions


- (UIImage *) imageWithView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, [[UIScreen mainScreen] scale]);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

@end
