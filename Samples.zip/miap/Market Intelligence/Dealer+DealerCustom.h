//
//  Dealer+DealerCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/17/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "Dealer.h"

@interface Dealer (DealerCustom)

- (void) encryptWithKey:(NSString*) key;
-(void) decryptWithKey:(NSString*) key;

@end
