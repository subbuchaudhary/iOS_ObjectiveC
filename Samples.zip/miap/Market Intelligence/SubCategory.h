//
//  SubCategory.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/10/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "BaseCategory.h"

@class Comment, SurveyCategory, Topic;

@interface SubCategory : BaseCategory

@property (nonatomic, retain) SurveyCategory *parent;
@property (nonatomic, retain) NSOrderedSet *topicList;
@property (nonatomic, retain) NSSet *commentList;
@end

@interface SubCategory (CoreDataGeneratedAccessors)

- (void)insertObject:(Topic *)value inTopicListAtIndex:(NSUInteger)idx;
- (void)removeObjectFromTopicListAtIndex:(NSUInteger)idx;
- (void)insertTopicList:(NSArray *)value atIndexes:(NSIndexSet *)indexes;
- (void)removeTopicListAtIndexes:(NSIndexSet *)indexes;
- (void)replaceObjectInTopicListAtIndex:(NSUInteger)idx withObject:(Topic *)value;
- (void)replaceTopicListAtIndexes:(NSIndexSet *)indexes withTopicList:(NSArray *)values;
- (void)addTopicListObject:(Topic *)value;
- (void)removeTopicListObject:(Topic *)value;
- (void)addTopicList:(NSOrderedSet *)values;
- (void)removeTopicList:(NSOrderedSet *)values;
- (void)addCommentListObject:(Comment *)value;
- (void)removeCommentListObject:(Comment *)value;
- (void)addCommentList:(NSSet *)values;
- (void)removeCommentList:(NSSet *)values;

@end
