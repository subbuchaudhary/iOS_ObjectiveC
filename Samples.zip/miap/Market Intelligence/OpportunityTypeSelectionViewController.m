//
//  OpportunityTypeSelectionViewController.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/14/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "OpportunityTypeSelectionViewController.h"
#import "MIConstant.h"
@interface OpportunityTypeSelectionViewController ()

@end

@implementation OpportunityTypeSelectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //MI_V_1.0
    appDelegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    NSArray *temoSales = appDelegate.miSurveyUtil.sales.superCategory.array;
   // NSArray *salesSuperCat = [temoSales sortedArrayUsingComparator:^NSComparisonResult(MISuperCategory *p1, MISuperCategory *p2){
        //return [p1.superCatId compare:p2.superCatId];
   // }];
    
    NSArray *custSupperCat = appDelegate.miSurveyUtil.custExp.superCategory.array;
    
    self.arrSuperCategory = [[NSMutableArray alloc] initWithArray:temoSales];
    [self.arrSuperCategory addObjectsFromArray:custSupperCat];
    //MI_V_1.0_CLOSE

    
    // Do any additional setup after loading the view from its nib.
    self.retentionView.image.image = [UIImage imageNamed:@"icon_opp_retention"];
    MISuperCategory *cat1 = self.arrSuperCategory[0];
    self.retentionView.label.text =cat1.superCatName;
    if([self.comment.superCategory.superCatName isEqual:self.retentionView.label.text])
        self.retentionView.label.textColor = [UIColor colorWithRed:173/255.0 green:213/255.0 blue:102/255.0 alpha:1];
    self.flooringView.image.image = [UIImage imageNamed:@"icon_opp_flooring"];
    MISuperCategory *cat2 = self.arrSuperCategory[1];
    self.flooringView.label.text =cat2.superCatName;
    if([self.comment.superCategory.superCatName isEqual:self.flooringView.label.text])
        self.flooringView.label.textColor = [UIColor colorWithRed:173/255.0 green:213/255.0 blue:102/255.0 alpha:1];
    self.creditView.image.image = [UIImage imageNamed:@"icon_opp_credit" ];
    MISuperCategory *cat3 = self.arrSuperCategory[2];
    self.creditView.label.text =cat3.superCatName;
    if([self.comment.superCategory.superCatName isEqual:self.creditView.label.text])
        self.creditView.label.textColor = [UIColor colorWithRed:173/255.0 green:213/255.0 blue:102/255.0 alpha:1];
    self.experienceView.image.image = [UIImage imageNamed:@"icon_opp_experience"];
    self.experienceView.label.text = @"Customer Experience";
    if([self.comment.superCategory.superCatName isEqual:@"CX"])
        self.experienceView.label.textColor = [UIColor colorWithRed:173/255.0 green:213/255.0 blue:102/255.0 alpha:1];
    
    //Set the tags
    self.retentionView.tag = RETENTION_VIEW_TAG;
    self.flooringView.tag = FLOORING_VIEW_TAG;
    self.creditView.tag = CREDIT_VIEW_TAG;
    self.experienceView.tag = EXPERIENCE_VIEW_TAG;
    
    // Setting title
    UILabel *label = [[UILabel alloc] init ];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:@"GEInspira-Bold" size:17.0];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor]; // change this color
    self.navigationItem.titleView = label;
    label.text = @"Select Opportunity";
    [label sizeToFit];
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont
                                                                           fontWithName:@"GEInspira-Bold" size:14], NSFontAttributeName,
                                [UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attributes];
    
    [self.navigationItem.backBarButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];
    
    self.view.backgroundColor = [UIColor darkGrayColor];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"ToOpportunityList"]) {

        MISuperCategory *superCategory = nil;
        
        switch (self.selectedOpportunityType)
        {
            case RETENTION_VIEW_TAG:
                superCategory = self.arrSuperCategory[0];
                break;
            case FLOORING_VIEW_TAG:
                superCategory = self.arrSuperCategory[1];
                break;
            case CREDIT_VIEW_TAG:
                superCategory = self.arrSuperCategory[2];
                break;
            case EXPERIENCE_VIEW_TAG:
                superCategory = self.arrSuperCategory[3];
                break;
        }
        CategoryViewController *categoryViewController = segue.destinationViewController;
        categoryViewController.superCategory = superCategory;
        categoryViewController.comment = self.comment;
        categoryViewController.delegate = self.delegate;
        
    }
}

- (IBAction)opportunityRowSelected:(UITapGestureRecognizer *)sender {
    UIView *selectedView = sender.view;
    self.selectedOpportunityType = sender.view.tag;
    [self performSegueWithIdentifier:@"ToOpportunityList" sender:selectedView];
}

@end
