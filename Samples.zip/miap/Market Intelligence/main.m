//
//  main.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"
//#import <GD/GDiOS.h>

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, @"AppDelegate", NSStringFromClass([AppDelegate class]));
    }
}
