//
//  BaseCategory+BaseCategoryCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/12/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "BaseCategory.h"

@interface BaseCategory (BaseCategoryCustom)

- (BOOL) isSameAs:(id)object;
@end
