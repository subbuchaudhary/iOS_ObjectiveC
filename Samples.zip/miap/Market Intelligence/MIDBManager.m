//
//  MIDBManager.m
//  SqlLiteDemo
//
//  Created by devness on 17/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MIDBManager.h"
#import "MIConstant.h"
#import "MISurveyType.h"
#import <sqlite3.h>
#import "MISurveyType.h"
#import "MISuperCategory.h"
#import "MISubCategory.h"
#import "MICategory.h"
#import "MISurveyManager.h" 
#import "MITopic.h"
#import "MIDealerList.h"
#import "MIDealerSummary.h"
#import "MIFSR.h"
const NSString* MI_ENCRYPTION_KEY1 = @"MI-MarketIntelligence";

//#import <GD/GDFileManager.h>
@implementation MIDBManager

static MIDBManager *sharedInstance = nil;

+(MIDBManager*)getSharedInstance{
    if (!sharedInstance) {
        sharedInstance = [[MIDBManager alloc]init];
        [sharedInstance createDatabase];
    }
    return sharedInstance;
}

- (id)init{
    self = [super init];
    return self;
}

- (void)createDatabase{
    NSString *docsDir;
    // Get the documents directory
    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    // Build the path to the database file
    _databasePath = [[NSString alloc]initWithString: [docsDir stringByAppendingPathComponent: @"MIAPP.db"]];
    NSLog(@"database path %@",_databasePath);
    //GDFileManager *fileManager = [GDFileManager defaultManager];
     NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:_databasePath] == NO) {
        
        if ((sqlite3_open( [self.databasePath UTF8String], &database)) == SQLITE_OK){
            const char *createTable = "create table if not exists MI_FSR (firstname text, lastname text, managersso text, sso text)";
            char *error;
            if (sqlite3_exec(database, createTable, NULL, NULL, &error) == SQLITE_OK) {
                //NSLog(@"database created");
                [self createSurveyType_table];
                [self createSuperCategory_table];
                [self createCategory_table];
                [self createSubCategory_table];
                [self createTopic_table];
                [self createDealerTable];
                [self createDealSummeryTable];
                [self createCommentsTable];
                [self createCurrentSurvey_table];
            }
            else{
                //NSLog(@"db not created");
            }
            sqlite3_close(database);
        }
    }
    
}

#pragma mark - Create table Query
-(void)createTableUsingQuery:(NSString*)createTable
{
    if ((sqlite3_open( [self.databasePath UTF8String], &database)) == SQLITE_OK){
        
        const char* create_query=  [createTable UTF8String];
        char *error;
        if (sqlite3_exec(database, create_query, NULL, NULL, &error) == SQLITE_OK) {
           // NSLog(@"Survey table created");
        }
        else{
           // NSLog(@"db not created");
        }
        sqlite3_close(database);
    }
}

#pragma mark - Insert Recordrs in table
-(void)insertRecordsQuery:(NSString*)query
{
    sqlite3_stmt *statement;
    const char *dbpath = [self.databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        
        const char *insert_stmt = [query UTF8String];
        sqlite3_prepare_v2(database, insert_stmt, -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE) {
            //NSLog(@"added");
        }else{
           // NSLog(@"Error while creating database. '%s'", sqlite3_errmsg(database));
        }
        sqlite3_finalize(statement);
        sqlite3_close(database);
    }
}

#pragma mark - Delete Recrods from table
-(void)deleteRecrodsQuery:(NSString*)deleteSql
{
    sqlite3_stmt *statement;
    const char *dbpath = [self.databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        
        const char *delete_stmt = [deleteSql UTF8String];
        sqlite3_prepare_v2(database, delete_stmt, -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE) {
            //NSLog(@"deleted");
        }else{
            //NSLog(@"Error while creating database. '%s'", sqlite3_errmsg(database));
        }
        sqlite3_finalize(statement);
        sqlite3_close(database);
    }
}

#pragma mark - Delete Recrods from table
-(void)updateRecrodsQuery:(NSString*)updateSql
{
    sqlite3_stmt *statement;
    const char *dbpath = [self.databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        
        const char *update_stmt = [updateSql UTF8String];
        sqlite3_prepare_v2(database, update_stmt, -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE) {
           // NSLog(@"updated");
        }else{
           // NSLog(@"Error while creating database. '%s'", sqlite3_errmsg(database));
        }
        sqlite3_finalize(statement);
        sqlite3_close(database);
    }
}


#pragma mark - FSR Records Save and Delete
- (void)insertFSRData:(NSString *)firstName lastNname:(NSString *)lastName managerSSO:(NSString *)managerSSO sso:(NSString *)sso{
    NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_FSR (firstname, lastname, managersso, sso) VALUES (\"%@\", \"%@\", \"%@\", \"%@\") ", firstName, lastName, managerSSO, sso];
    [self insertRecordsQuery:insertSql];
}

- (void)deleteFSRData
{
    NSString *deleteSql =[NSString stringWithFormat:@"DELETE FROM MI_FSR"];
    [self deleteRecrodsQuery:deleteSql];
}



//INSERT CATEGORY RECORDS IN DATABASE
-(void)createCategoryStructureInDatabase
{
    if (self.surveyType == nil)
        return ;
    
    [self insertSurveyType:self.surveyType.surveyId AndName:self.surveyType.surveyName];
    [self insertRecrodsInSuperCategory:self.surveyType.superCategory.array];
    NSArray *superCatgoryList = self.surveyType.superCategory.array;
    for (MISuperCategory *superCat in superCatgoryList) {
        NSArray *categoryList  = superCat.categorylist.array;
        [self insertRecrodsInCategory:categoryList];
        for (MICategory *catObj in categoryList) {
            NSArray *subCatList = catObj.subCategorylist.array;
            if (subCatList.count>0) {
                [self insertRecrodsInSubCategory:subCatList];
                
            }
        }
    }
    
}

//SURVEY TYPE SECTIONS
#pragma mark -  CREATE SSURVEY TYPE TABLE AND STORE RECORDS IN SURVEY TYPE TABLE
-(void)createSurveyType_table
{
    NSString *createTable = @"create table if not exists MI_SurveyType (id integer, name text)";
    [self createTableUsingQuery:createTable];
}

-(void)createCurrentSurvey_table
{
    NSString *createTable = @"create table if not exists MI_Survey (id text, commentIds text)";
    [self createTableUsingQuery:createTable];
}
-(void)insertCurrentSurveyRecords:(NSArray*)dealerlist
{
    for (int i=0; i<dealerlist.count; i++) {
        
        MISurvey *dictInput = dealerlist[i];
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_Survey (id,commentIds) VALUES (\"%@\",\"%@\") ", dictInput.surveyID, dictInput.commentIds];
        [self insertRecordsQuery:insertSql];
    }
}
-(void)insertSurveyType:(NSNumber*)surveyId AndName:(NSString*)surveyName
{
     NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_SurveyType (id, name) VALUES (\"%@\", \"%@\") ", surveyId, surveyName];
    [self insertRecordsQuery:insertSql];
}

//SUPER CATEGROY SECTIONS
#pragma mark -  CREATE SUPER CATEOGORY TABLE AND STORE RECORDS IN SUBPER CATEGORY TABLE
-(void)createSuperCategory_table
{
   NSString *createTable = @"create table if not exists MI_SuperCategory (surveyid integer, id integer, name text)";
    [self createTableUsingQuery:createTable];
}
-(void)insertRecrodsInSuperCategory:(NSArray*)supercategory
{
    for (int i=0; i<supercategory.count; i++) {
        
        MISuperCategory *dictInput = supercategory[i];
        NSNumber *surveyId = dictInput.surveyId;
        NSNumber *superCateroryId = dictInput.superCatId;
        NSString *superCategoryName = dictInput.superCatName;
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_SuperCategory (surveyid,id, name) VALUES (\"%@\",\"%@\", \"%@\") ", surveyId, superCateroryId,superCategoryName];
        [self insertRecordsQuery:insertSql];
    }
}

//CATEGORY SECTION
#pragma mark -  CREATE CATEOGORY TABLE AND STORE RECORDS IN CATEGORY TABLE
-(void)createCategory_table
{
    NSString *createTable = @"create table if not exists MI_Category (surveyid integer ,superCatId integer, id integer, name text)";
    [self createTableUsingQuery:createTable];
}
-(void)insertRecrodsInCategory:(NSArray*)supercategory
{
    for (int i=0; i<supercategory.count; i++) {
        MICategory *dictInput = supercategory[i];
        NSNumber *surveyId = dictInput.surveyId;
        NSNumber *superCateroryId = dictInput.superCatId;
        NSNumber *CategoryId = dictInput.catId;
        NSString *categoryName = dictInput.catName;
        
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_Category (surveyid,superCatId,id, name) VALUES (\"%@\",\"%@\", \"%@\",\"%@\") ", surveyId, superCateroryId,CategoryId,categoryName];
        [self insertRecordsQuery:insertSql];
    }
}

//SUB CATEGORY SECTION
#pragma mark -  CREATE SUB CATEOGORY TABLE AND STORE RECORDS IN SUB CATEGORY TABLE
-(void)createSubCategory_table
{
    NSString *createTable = @"create table if not exists MI_SubCategory (surveyid integer ,superCatId integer,catId integer, id integer, name text)";
    [self createTableUsingQuery:createTable];
}
-(void)insertRecrodsInSubCategory:(NSArray*)supercategory
{
    for (int i=0; i<supercategory.count; i++) {
        MISubCategory *dictInput = supercategory[i];
        NSNumber *surveyId = dictInput.surveyId;
        NSNumber *superCateroryId = dictInput.superCatId;
        NSNumber *CategoryId = dictInput.catId;
        NSNumber *subCategoryId = dictInput.subCatId;
        NSString *subCategoryName = dictInput.subCatName;
        
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_SubCategory (surveyid,superCatId,catId,id, name) VALUES (\"%@\",\"%@\",\"%@\", \"%@\",\"%@\") ", surveyId, superCateroryId,CategoryId,subCategoryId,subCategoryName];
        [self insertRecordsQuery:insertSql];
        
        if (dictInput.topiclist.array.count>0) {
            [self insertRecrodsInTopic:dictInput.topiclist.array];
        }
    }
}

//TOPIC LIST SECTION
#pragma mark -  CREATE TOPIC TABLE AND STORE RECORDS IN TOPIC TABLE
-(void)createTopic_table
{
    NSString *createTable = @"create table if not exists MI_Topic (surveyid integer ,superCatId integer,catId integer,subCatId integer, id integer, name text)";
    [self createTableUsingQuery:createTable];
}

-(void)insertRecrodsInTopic:(NSArray*)supercategory
{
    for (int i=0; i<supercategory.count; i++) {
        MITopic *dictInput = supercategory[i];
        NSNumber *surveyId = dictInput.surveyId;
        NSNumber *superCateroryId = dictInput.superCatId;
        NSNumber *CategoryId = dictInput.catId;
        NSNumber *subCategoryId = dictInput.subCatId;
        NSNumber *topicId =  dictInput.topicid;
        NSString *topicName = dictInput.topicName;
        
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_Topic (surveyid,superCatId,catId,subCatId,id, name) VALUES (\"%@\",\"%@\",\"%@\",\"%@\", \"%@\",\"%@\") ", surveyId, superCateroryId,CategoryId,subCategoryId,topicId,topicName];
        [self insertRecordsQuery:insertSql];
        
    }
}

#pragma mark - QUERY TO FETCH ALL RECORDS FROM ANY TABLE
-(NSMutableArray*)fetchAllRecordsFromTable:(NSString*)query
{
    sqlite3_stmt *statement;
    const char *utf8Dbpath = [self.databasePath UTF8String];
    if (sqlite3_open(utf8Dbpath, &database) == SQLITE_OK) {
        
        const char *utf8QuerySQL = [query UTF8String];
        
        if (sqlite3_prepare_v2(database, utf8QuerySQL, -1, &statement, NULL) == SQLITE_OK) {
            
            NSMutableArray *recordsArray = [[NSMutableArray alloc] init];
            
            while (sqlite3_step(statement) == SQLITE_ROW) {
                
                int totalColumns = sqlite3_column_count(statement);
                switch (self.stateSelectedTable) {
                    case SURVERY_TABLE:
                    {
                        MISurveyType *survey = [self handleSurveyTypeList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case  SUPERCATEGORY_TABLE:
                    {
                        MISuperCategory *survey = [self handleSuperCategoryList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case CATEGORY_TABLE:
                    {
                        MICategory *survey=  [self handleCategoryList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case SUBCATEGORY_TABLE:
                    {
                        MISubCategory *survey=  [self handleSubCategoryList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case TOPIC_TABLE:
                    {
                        MITopic *survey=  [self handleTopicList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case DEALER_TABLE:
                    {
                        MIDealerList *survey=  [self handleDealerList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case DEALER_SUMMERY_TABLE :
                    {
                        MIDealerSummary *survey=  [self handleDealerSummeryList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case FSR_TABLE:
                    {
                        MIFSR *survey=  [self handleFSRList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case COMMENTS_TABLE:
                    {
                        MIComments *survey=  [self handleCommentsList:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    case CURRENT_SURVEY_TABLE:
                    {
                        MISurvey *survey=  [self handleCurrentSurvey:totalColumns forStatemet:statement];
                        [recordsArray addObject:survey];
                    }
                        break;
                    default:
                        break;
                }
            }
            
            sqlite3_reset(statement);
            
            return [recordsArray copy];
            
        } else {
            //if (debugEnable) NSLog(@"%s - %d # sqlite3_prepare_v2 is NOT ok", __PRETTY_FUNCTION__, __LINE__);
        }
    } else {
        //if (debugEnable) NSLog(@"%s - %d # Fail to open DB", __PRETTY_FUNCTION__, __LINE__);
        return nil;
    }
    
    return nil;
}

//---------- FETCH RECORDS FROM TABLES
#pragma mark - GET SURVEY TYPE RECORDS
-(MISurveyType*)handleSurveyTypeList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MISurveyType *undergrad = [MISurveyType alloc];
    NSString *surveyId;
    NSString *surveyName;
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        
        if (dbDataAsChars != NULL) {
            
            switch (i) {
                case 0:
                    surveyId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 1:
                    surveyName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            undergrad.surveyName = surveyName;
            undergrad.surveyId = [NSNumber numberWithInt:[surveyId intValue]];
        }
    }
    return undergrad;
}

#pragma mark - GET SUPER CATEGORY RECORDS
-(MISuperCategory*)handleSuperCategoryList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MISuperCategory *objSuperCat = [MISuperCategory alloc];
    NSString *surveyId;
    NSString *superCatId;
    NSString *superCatName;
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        
        if (dbDataAsChars != NULL) {
            
            switch (i) {
                case 0:
                    surveyId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 1:
                    superCatId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    superCatName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            objSuperCat.surveyId = [NSNumber numberWithInt:[surveyId intValue]];
            objSuperCat.superCatId = [NSNumber numberWithInt:[superCatId intValue]];
            objSuperCat.superCatName = superCatName;
        }
    }
    return objSuperCat;
}

#pragma mark - GET CATEGORY RECORDS
-(MICategory*)handleCategoryList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MICategory *objSuperCat = [MICategory alloc];
    NSString *surveyId;
    NSString *superCatId;
    NSString *catId;
    NSString *catName;
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        
        if (dbDataAsChars != NULL) {
            
            switch (i) {
                case 0:
                    surveyId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 1:
                    superCatId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    catId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 3:
                    catName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            objSuperCat.surveyId = [NSNumber numberWithInt:[surveyId intValue]];
            objSuperCat.superCatId = [NSNumber numberWithInt:[superCatId intValue]];
            objSuperCat.catId = [NSNumber numberWithInt:[catId intValue]];
            objSuperCat.catName = catName;
            //[objSuperCat getSuperCategory];
        }
    }
    return objSuperCat;
}

#pragma mark - GET SUB CATEGORY RECORDS
-(MISubCategory*)handleSubCategoryList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MISubCategory *objSuperCat = [MISubCategory alloc];
    NSString *surveyId;
    NSString *superCatId;
    NSString *catId;
    NSString *subCatId;
    NSString *subCatName;
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        
        if (dbDataAsChars != NULL) {
            
            switch (i) {
                case 0:
                    surveyId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 1:
                    superCatId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    catId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 3:
                    subCatId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 4:
                    subCatName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            objSuperCat.surveyId = [NSNumber numberWithInt:[surveyId intValue]];
            objSuperCat.superCatId = [NSNumber numberWithInt:[superCatId intValue]];
            objSuperCat.catId = [NSNumber numberWithInt:[catId intValue]];
            objSuperCat.subCatId = [NSNumber numberWithInt:[subCatId intValue]];
            objSuperCat.subCatName = subCatName;
            
        }
    }
    return objSuperCat;
}

#pragma mark - GET TOPIC RECORDS
-(MITopic*)handleTopicList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MITopic *objSuperCat = [MITopic alloc];
    NSString *surveyId;
    NSString *superCatId;
    NSString *catId;
    NSString *subCatId;
    NSString *topicId;
    NSString *topicName;
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        
        if (dbDataAsChars != NULL) {
            
            switch (i) {
                case 0:
                    surveyId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 1:
                    superCatId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    catId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 3:
                    subCatId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 4:
                    topicId = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 5:
                    topicName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            objSuperCat.surveyId = [NSNumber numberWithInt:[surveyId intValue]];
            objSuperCat.superCatId = [NSNumber numberWithInt:[superCatId intValue]];
            objSuperCat.catId = [NSNumber numberWithInt:[catId intValue]];
            objSuperCat.subCatId = [NSNumber numberWithInt:[subCatId intValue]];
            objSuperCat.topicid =  [NSNumber numberWithInt:topicId.intValue];
            objSuperCat.topicName = topicName;
            
        }
    }
    return objSuperCat;
}
#pragma mark - GET DEALER LIST 
-(MIDealerList*)handleDealerList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MIDealerList *objSuperCat = [MIDealerList alloc];
    NSString *addedManually;
       for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        
        if (dbDataAsChars != NULL) {
            
            switch (i) {
                case 0:
                    objSuperCat.branchDescription= [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 1:
                    objSuperCat.branchNo = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    objSuperCat.customerName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 3:
                    objSuperCat.customerNo = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 4:
                    objSuperCat.masterNumber = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 5:
                    objSuperCat.statusCode = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 6:
                    objSuperCat.vbu = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 7:
                    addedManually = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            
        }
    }
    objSuperCat.isManuallyAdded = [NSNumber numberWithInt:addedManually.intValue];
    return objSuperCat;
}

#pragma mark - GET DEALER LIST
-(MIDealerSummary*)handleDealerSummeryList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MIDealerSummary *objSuperCat = [MIDealerSummary alloc];
    NSString *addedManually;
    NSString *isvalidated;
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
    if (dbDataAsChars != NULL) {
            
            
            switch (i) {
                case 0:
                    addedManually  = [NSString stringWithUTF8String:dbDataAsChars] ;
                    break;
                case 1:
                    objSuperCat.branchDescription = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    objSuperCat.branchNo = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 3:
                    objSuperCat.customerName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 4:
                    objSuperCat.customerNumber = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 5:
                      isvalidated  = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 6:
                    objSuperCat.masterNumber = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 7:
                    objSuperCat.statusCode = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 8:
                    objSuperCat.vbu = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            
        }
    }
    objSuperCat.addedManually = [NSNumber numberWithBool:[addedManually boolValue]];
    objSuperCat.isValidated = [isvalidated boolValue];
    return objSuperCat;
}

-(MIFSR*)handleFSRList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MIFSR *objSuperCat = [MIFSR alloc];
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        if (dbDataAsChars != NULL) {
            
            
            switch (i) {
                case 0:
                    objSuperCat.firstName  = [NSString stringWithUTF8String:dbDataAsChars] ;
                    break;
                case 1:
                    objSuperCat.lastName = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 2:
                    objSuperCat.managerSSO = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                case 3:
                    objSuperCat.sso = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            
        }
    }
    return objSuperCat;
}

-(MISurvey*)handleCurrentSurvey:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MISurvey *objSuperCat = [MISurvey alloc];
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        if (dbDataAsChars != NULL) {
            switch (i) {
                case 0:
                    objSuperCat.surveyID  = [NSString stringWithUTF8String:dbDataAsChars] ;
                    break;
                case 1:
                    objSuperCat.commentIds = [NSString stringWithUTF8String:dbDataAsChars];
                    break;
                default:
                    break;
            }
            //[objSuperCat getSurveyComments];
        }
    }
    return objSuperCat;
}

#pragma mark - GET ALL SALES SURVEY TYPE RECORDS - SUPERCATEGORY, CATEGORY , SUB CATEGORY
-(MISurveyType*)getSurveyRecordsFromSurveyId:(int)surveyId
{
    //Get Survey Sales Type
    NSString *querySurveyType = [NSString stringWithFormat:@"select*from %@ where id = %d",TABLE_SURVEYTAPE,surveyId];
    self.stateSelectedTable = 0;
    MISurveyType *objSurveyType =[self fetchAllRecordsFromTable:querySurveyType][0];
    
    //Get SuperCategory For Sales Survery
    NSString *querySuperCategory = [NSString stringWithFormat:@"select * from %@ where surveyid = %d",TABLE_SUPERCATEGORY,objSurveyType.surveyId.intValue];
    self.stateSelectedTable = 1;
    NSArray *objSuperCategory  = [self fetchAllRecordsFromTable:querySuperCategory];
    objSurveyType.superCategory = [[NSOrderedSet alloc] initWithArray:objSuperCategory];
   
    
    
    //Get Sales category for sales survey
    for (MISuperCategory *modelSuperCat in objSuperCategory) {
        
        [modelSuperCat fetchCategoryStructure];
        /*NSString *queryCategory = [NSString stringWithFormat:@"select * from %@ where surveyid = %d AND superCatId = %d ",TABLE_CATEGORY,modelSuperCat.surveyId.intValue,modelSuperCat.superCatId.intValue];
        self.stateSelectedTable = 2;
        NSArray *objCategory = [self fetchAllRecordsFromTable:queryCategory];
        modelSuperCat.categorylist  = [NSSet setWithArray:objCategory];
        
        //Get Sales sub Category
        for (MICategory *modelCat in modelSuperCat.categorylist.allObjects) {
            NSString *queryCategory = [NSString stringWithFormat:@"select * from %@ where surveyid = %d AND superCatId = %d AND catId = %d ",TABLE_SUBCATEGORY,modelSuperCat.surveyId.intValue,modelSuperCat.superCatId.intValue,modelCat.catId.intValue];
            self.stateSelectedTable = 3;
            NSArray *objCategory = [self fetchAllRecordsFromTable:queryCategory];
            modelCat.subCategorylist  = [NSSet setWithArray:objCategory];
            
            //GetTopicList
            for (MISubCategory *modelSubCat in objCategory) {
                NSString *queryCategory = [NSString stringWithFormat:@"select * from %@ where surveyid = %d AND superCatId = %d AND catId = %d AND subCatId = %@",TABLE_TOPIC,modelSuperCat.surveyId.intValue,modelSuperCat.superCatId.intValue,modelSubCat.catId.intValue,modelSubCat.subCatId];
                self.stateSelectedTable = 4;
                NSArray *objCategory = [self fetchAllRecordsFromTable:queryCategory];
                if (objCategory.count>0) {
                    modelSubCat.topiclist  = [NSSet setWithArray:objCategory];
                 }
            }
            
            
        }*/
        
    }
    return objSurveyType;
}


//=================================================================
//=================================================================
#pragma mark - DEALER SECTIONS
-(void)createDealerTable
{
    NSString *createTable = @"create table if not exists MI_Dealer (branchDescription text, branchNo text,customerName text, customerNo text,masterNumber text,statusCode text, vbu text,addedManually integer)";
    [self createTableUsingQuery:createTable];
}
-(void)insertDealerRecords:(NSArray*)dealerlist
{
    for (int i=0; i<dealerlist.count; i++) {
        
        MIDealerList *dictInput = dealerlist[i];
        //[dictInput encryptWithKey:MI_ENCRYPTION_KEY1];
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_Dealer (branchDescription,branchNo, customerName,customerNo,masterNumber,statusCode,vbu,addedManually) VALUES (\"%@\",\"%@\", \"%@\",\"%@\",\"%@\", \"%@\",\"%@\",\"%d\") ", dictInput.branchDescription, dictInput.branchNo,dictInput.customerName,dictInput.customerNo,dictInput.masterNumber,dictInput.statusCode,dictInput.vbu,dictInput.isManuallyAdded.intValue];
        [self insertRecordsQuery:insertSql];
    }
}
-(NSMutableArray*)fetchDealerList
{
    NSString *querySurveyType = [NSString stringWithFormat:@"select*from %@",TABLE_DEALER];
    self.stateSelectedTable = 5;
    NSMutableArray *objDealerlist =[self fetchAllRecordsFromTable:querySurveyType];
    return objDealerlist;
}
-(void)deleteDealerlist
{
    NSString *deleteSql =[NSString stringWithFormat:@"DELETE FROM %@",TABLE_DEALER ];
    [self deleteRecrodsQuery:deleteSql];
}
#pragma MARK - DEALER SUMMERY
-(void)createDealSummeryTable
{
    NSString *createTable = @"create table if not exists MI_DealerSummery (addedManually integer,branchDescription text, branchNo text,customerName text, customerNo text,isValidated integer , masterNumber text,statusCode text, vbu text)";
    [self createTableUsingQuery:createTable];
}
-(void)deleteDealerSummerylist
{
    NSString *deleteSql =[NSString stringWithFormat:@"DELETE FROM %@",TABLE_DEALERSUMMERY];
    [self deleteRecrodsQuery:deleteSql];
}
-(void)insertDealerSummeryRecords:(NSArray*)dealerlist
{
    for (int i=0; i<dealerlist.count; i++) {
        
        MIDealerSummary *dictInput = dealerlist[i];
        int addedmanually = dictInput.addedManually.intValue;
        int isValidated = [[NSNumber numberWithBool:dictInput.isValidated] intValue];

        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_DealerSummery (addedManually,branchDescription,branchNo, customerName,customerNo,isValidated,masterNumber,statusCode,vbu) VALUES (\"%d\",\"%@\",\"%@\",\"%@\", \"%@\",\"%d\",\"%@\", \"%@\",\"%@\") ", addedmanually, dictInput.branchDescription, dictInput.branchNo,dictInput.customerName,dictInput.customerNumber,isValidated,dictInput.masterNumber,dictInput.statusCode,dictInput.vbu];
        [self insertRecordsQuery:insertSql];
    }
}
-(NSMutableArray*)fetchDealerSummery
{
    NSString *querySurveyType = [NSString stringWithFormat:@"select*from %@",TABLE_DEALERSUMMERY];
    self.stateSelectedTable = 6;
    NSMutableArray *objDealerlist =[self fetchAllRecordsFromTable:querySurveyType];
    return objDealerlist;
}

#pragma mark - FETCH FSR DETAIL
-(NSMutableArray*)fetchFSRDetail
{
    NSString *querySurveyType = [NSString stringWithFormat:@"select*from %@",TABLE_FSR];
    self.stateSelectedTable = 7;
    NSMutableArray *objDealerlist =[self fetchAllRecordsFromTable:querySurveyType];
    return objDealerlist;
}
-(void)deleteFSRDetail
{
  NSString *deleteSql =[NSString stringWithFormat:@"DELETE FROM %@",TABLE_FSR];
  [self deleteRecrodsQuery:deleteSql];
}

//==========================================================
    //COMMENTS SECTIONS
//==========================================================

#pragma mark - Comments Section
-(void)createCommentsTable
{
    NSString *createTable = @"create table if not exists MI_Comments (contactId text,keyId text, surveyType text,commenttext text, dealerNumber text,catId text , superCategoryId text,topiclistIds text, subCatIds text,dealerlistIds text,masterNumber text)";
    [self createTableUsingQuery:createTable];
}

-(void)insertRecrodsInComments:(NSArray*)supercategory
{
    for (int i=0; i<supercategory.count; i++) {
        
        MIComments *dictInput = supercategory[i];
        NSString *contactId = (dictInput.contactName.length>0)?dictInput.contactName:@"";
        NSString *keyId  = (dictInput.keyId.length>0)?dictInput.keyId:@"";
        NSString *surveyType = (dictInput.surveyType.length>0)?dictInput.surveyType:@"";
        NSString *commentText  = (dictInput.text.length>0)?dictInput.text:@"";
        NSString *dealerNumber = (dictInput.dealerNumber.length>0)?dictInput.dealerNumber:@"";
        NSString *catId = [dictInput.category.catId stringValue];
        NSString *superCatId = [dictInput.superCategory.superCatId stringValue];
        NSString *topiclistIds= (dictInput.topicListIds.length>0)?dictInput.topicListIds:@"";
        NSString *subCatIds =  (dictInput.subCategoryIds.length>0)?dictInput.subCategoryIds:@"";
        NSString *dealerlistIds = @"";
        NSMutableArray *dealerArray = [[NSMutableArray alloc] init];
        for (MIDealerSummary *summery in dictInput.dealerList.array)
            [dealerArray addObject:summery.masterNumber];
        
        dealerlistIds = [dealerArray componentsJoinedByString:@","];
           
        
        NSString *insertSql =[NSString stringWithFormat:@"INSERT INTO MI_Comments (contactId ,keyId, surveyType ,commenttext, dealerNumber,catId , superCategoryId,topiclistIds, subCatIds,dealerlistIds) VALUES (\"%@\",\"%@\", \"%@\",\"%@\",\"%@\", \"%@\",\"%@\",\"%@\", \"%@\",\"%@\") ",contactId,keyId,surveyType ,commentText, dealerNumber,catId,superCatId,topiclistIds,subCatIds,dealerlistIds];
        [self insertRecordsQuery:insertSql];
    }
}
-(NSMutableArray*)fetchCommentlist:(NSString*)query
{
    NSString *querySurveyType = query;
    self.stateSelectedTable = 8;
    NSMutableArray *objDealerlist =[self fetchAllRecordsFromTable:querySurveyType];
    return objDealerlist;
}

-(MIComments*)handleCommentsList:(int)records forStatemet:(sqlite3_stmt*)statement
{
    MIComments *objComments = [MIComments alloc];
    //NSMutableDictionary *dictComments = [[NSMutableDictionary alloc] init];
    for (int i=0; i<records; i++){
        char *dbDataAsChars = (char *)sqlite3_column_text(statement, i);
        if (dbDataAsChars != NULL) {
            
            
            switch (i) {
                case 0:
                    [objComments setContactName:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 1:
                    [objComments setKeyId:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 2:
                    [objComments setSurveyType:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 3:
                    [objComments setText:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 4:
                    [objComments setDealerNumber:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 5:
                   [objComments setCategoryId:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 6:
                    [objComments setSuperCategoryId:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 7:
                    [objComments setTopicListIds:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 8:
                    [objComments setSubCategoryIds:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;
                case 9:
                    [objComments setDealerListIds:[NSString stringWithUTF8String:dbDataAsChars]];
                    break;

                default:
                    break;
            }
            
        }
    }
    //Manage comment records here then return
    //[objComments manageCommnetobject:dictComments];
    //[objComments manageCommnetobject:dictComments]
    return objComments;
}

-(void)deleteCommentListAll:(BOOL)isAllDelete withId:(NSString*)commentId
{
    
}


//================================
//FETCH RECRODS QUERY FOR SINGLE
//================================

-(NSMutableArray*)fetchsingleRecords:(NSString*)recordId
{
    NSString *query;
    switch (self.stateSelectedTable) {
        case CATEGORY_TABLE:
            query = [NSString stringWithFormat:@"select * from %@ where id = %d ORDER BY id ASC",TABLE_CATEGORY,recordId.intValue];
            break;
        case SUPERCATEGORY_TABLE:
            query = [NSString stringWithFormat:@"select * from %@ where id = %d ORDER BY id ASC",TABLE_SUPERCATEGORY,recordId.intValue];
            break;
        case SUBCATEGORY_TABLE:
            query = [NSString stringWithFormat:@"select * from %@ where catId = %d ORDER BY id ASC",TABLE_SUBCATEGORY,recordId.intValue];
            break;
        case TOPIC_TABLE:
            query = [NSString stringWithFormat:@"select * from %@ where subCatId = %d ORDER BY id ASC",TABLE_TOPIC,recordId.intValue];
            break;
            
        case DEALER_TABLE:
            query = [NSString stringWithFormat:@"select * from %@ where masterNumber = %d ORDER BY id ASC",TABLE_DEALER,recordId.intValue];
            break;
        case DEALER_SUMMERY_TABLE:
            query = [NSString stringWithFormat:@"select * from %@ where masterNumber = %d ",TABLE_DEALERSUMMERY,recordId.intValue];
            break;
    
        default:
            break;
    }
    NSMutableArray *results = [self fetchAllRecordsFromTable:query];
    return results;
}


-(void)deleteSingleRecords:(NSString*)recordId
{
    NSString *query;
    switch (self.stateSelectedTable) {
        case CATEGORY_TABLE:
            query = [NSString stringWithFormat:@"delete  from %@ where id = %d ",TABLE_CATEGORY,recordId.intValue];
            break;
        case SUPERCATEGORY_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where id = %d ",TABLE_SUPERCATEGORY,recordId.intValue];
            break;
        case DEALER_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where id = %d ",TABLE_DEALER,recordId.intValue];
            break;
        case DEALER_SUMMERY_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where masterNumber = '%@' ",TABLE_DEALERSUMMERY,recordId];
            break;
        case COMMENTS_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where keyId = '%@' ",TABLE_COMMENTS ,recordId];
            break;
    
        default:
            break;
    }
     [self deleteRecrodsQuery:query];
}

-(void)updateSingleRecords:(NSString*)recordId
{
    NSString *query;
    switch (self.stateSelectedTable) {
        case CATEGORY_TABLE:
            query = [NSString stringWithFormat:@"delete  from %@ where id = %d ",TABLE_CATEGORY,recordId.intValue];
            break;
        case SUPERCATEGORY_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where id = %d ",TABLE_SUPERCATEGORY,recordId.intValue];
            break;
        case DEALER_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where id = %d ",TABLE_DEALER,recordId.intValue];
            break;
        case DEALER_SUMMERY_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where masterNumber = '%@' ",TABLE_DEALERSUMMERY,recordId];
            break;
        case COMMENTS_TABLE:
            query = [NSString stringWithFormat:@"delete from %@ where keyId = '%@' ",TABLE_COMMENTS ,recordId];
            break;
            
        default:
            break;
    }
    [self updateRecrodsQuery:query];
}

-(void)deleteComments:(NSArray*)commentlist
{
    
}//MiComments object will be in array

@end
