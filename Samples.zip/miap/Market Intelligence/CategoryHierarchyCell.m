//
//  CategoryHierarchyCell.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/20/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CategoryHierarchyCell.h"


@implementation CategoryHierarchyCell


@synthesize parentController;
@synthesize dataObject;
@synthesize isExpanded;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        inspiraFont = [UIFont fontWithName:@"GE Inspira" size:8.0];
    }
    isExpanded = false;
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}



- (void) configureWithHierarchy:(MIBaseCategory*) category
{
    dataObject = category;
    
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    float indentPoints = self.indentationLevel * self.indentationWidth;
    
    self.contentView.frame = CGRectMake(
                                        indentPoints,
                                        self.contentView.frame.origin.y,
                                        self.contentView.frame.size.width - indentPoints,
                                        self.contentView.frame.size.height
                                        );
}


@end
