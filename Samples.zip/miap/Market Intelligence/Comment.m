//
//  Comment.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 3/11/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "Comment.h"
#import "DealerSummaryEntity.h"
#import "SubCategory.h"
#import "SuperCategory.h"
#import "SurveyCategory.h"
#import "Topic.h"


@implementation Comment

@dynamic contactName;
@dynamic keyId;
@dynamic surveyType;
@dynamic text;
@dynamic dealerNumber;
@dynamic category;
@dynamic dealerList;
@dynamic subCategoryList;
@dynamic superCategory;
@dynamic topicList;

@end
