//
//  GELoginFullScreenViewController_iPhone.h
//  MobileDS
//
//  Created  on 5/16/13.
//  Copyright (c) 2013 General Electric, All rights reserved
//  Learn more about the Mobile Design System at http://gesdh.com
//

#import <UIKit/UIKit.h>
#import "GEViewController.h"
#import "GETextField.h"


@interface GELoginFullScreenViewController_iPhone : GEViewController<UITextFieldDelegate, UIAlertViewDelegate>

@property (nonatomic, strong) UIImageView *heroImageView;
@property (nonatomic, strong) UIImage *heroImage;
@property (nonatomic, strong) UIColor *accentColor;
@property (nonatomic, strong) GELabel *appNameLabel;
@property (nonatomic, strong) NSString *appName;
@property (nonatomic, strong) GEButton *signInButton;
@property (nonatomic, strong) UIButton *createAcctButton;
@property (nonatomic, strong) UIButton *forgotPassButton;
@property (nonatomic, strong) GETextField *acctTextField;
@property (nonatomic, strong) GETextField *passTextField;

@end
