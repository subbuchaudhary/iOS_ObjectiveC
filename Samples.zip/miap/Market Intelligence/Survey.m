//
//  Survey.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/26/14.
//  Copyright (c) 2014 Jeff Roberts . All rights reserved.
//

#import "Survey.h"
#import "Comment.h"


@implementation Survey

@dynamic surveyID;
@dynamic commentList;

@end
