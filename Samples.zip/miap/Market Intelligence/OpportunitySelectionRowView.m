//
//  OpportunitySelectionRowView.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 12/10/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "OpportunitySelectionRowView.h"

@implementation OpportunitySelectionRowView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        //Custom Initialization code here
        [[NSBundle mainBundle] loadNibNamed:@"OpportunitySelectionRowView" owner:self options:nil];
        
        [self addSubview:self.container];
        //Need to set this so the old autoresizing mask doesnt rear its ugly head
//        [self.container setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        //Need to set the constraints on the container view as it is not possible to do this in the XIB
        /*NSArray *horizontalConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[container]|" options:0 metrics:nil views:@{@"container":self.container}];
        NSArray *verticalConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[container]|" options:0 metrics:nil views:@{@"container":self.container}];
        
        NSArray *allConstraints = [horizontalConstraints arrayByAddingObjectsFromArray:verticalConstraints];
        
        [self addConstraints:allConstraints];*/
        
    }
    return self;
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    self.container.alpha = 0.8;
    self.label.highlighted = YES;
}

-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    self.container.alpha = 1.0;
    self.label.highlighted = NO;
}

-(void) touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event {
    self.container.alpha = 1.0;
    self.label.highlighted = NO;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
