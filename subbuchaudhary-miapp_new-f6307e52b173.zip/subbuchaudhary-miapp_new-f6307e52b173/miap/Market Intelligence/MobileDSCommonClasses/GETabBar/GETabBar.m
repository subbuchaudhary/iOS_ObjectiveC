//
//  GETabBar.m
//  CustomTabBar
// based on
//  CustomTabBar.m
//  CustomTabBar
//  Created by Peter Boctor on 1/2/11.
//
//  Created  on 10/24/12.
//
//

#import "GETabBar.h"
#import "GELabel.h"
#define SELECTED_ITEM_TAG 9914356


@interface GETabBar ()

@end

@implementation GETabBar
@synthesize tabBarItemViews;
@synthesize buttons;
@synthesize labels;
@synthesize accentColor = _accentColor;
@synthesize delegate;

- (id) initWithItems:(NSArray *)Items itemSize:(CGSize)itemSize tag:(NSInteger)objectTag delegate:(NSObject <GETabBarDelegate>*)GETabBarDelegate andColor:(UIColor *)GEColor
{
    if (self = [super initWithFrame:[[UIScreen mainScreen] bounds]])
    {
        tabBarItems = Items;
        CGSize tabBarSize = CGSizeMake([[UIScreen mainScreen] bounds].size.width, 49);
        // The tag allows callers with multiple controls to distinguish between them
        self.tag = objectTag;
        
        // Set the delegate
        delegate = GETabBarDelegate;
        
        // Add the background
        backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tabBarSize.width, tabBarSize.height)];
        backgroundView.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth;
        backgroundView.backgroundColor = GEColor;
        [self addSubview:backgroundView];
        int itemCount  = tabBarItems.count;
        // Adjust our width based on the number of items & the width of each item
        //self.frame = CGRectMake(0, 0, 319, itemSize.height);
        
        // Initalize the array we use to store our buttons
        self.tabBarItemViews = [[NSMutableArray alloc] initWithCapacity:itemCount];
        self.buttons = [[NSMutableArray alloc] initWithCapacity:itemCount];
        self.labels = [[NSMutableArray alloc] initWithCapacity:itemCount];

        // horizontalOffset tracks the proper x value as we add buttons as subviews
        CGFloat horizontalOffset = (tabBarSize.width - itemCount*itemSize.width) / 2; //22;

        UIView *containerView = [[UIView alloc] initWithFrame:CGRectMake(horizontalOffset, 0, tabBarSize.width- 2*horizontalOffset, 49)];
        containerView.backgroundColor = [UIColor clearColor];
        containerView.autoresizingMask =  UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        containerView.backgroundColor = [UIColor clearColor];
        [backgroundView addSubview:containerView];
                
        horizontalOffset = 0;
        // Iterate through each item
        for (NSUInteger i = 0 ; i < itemCount ; i++)
        {
            NSDictionary *data =[ tabBarItems objectAtIndex:i];
            
            
            //Create a View
            float itemWidth = itemSize.width;// (self.frame.size.width-44)/itemCount;
            
            UIView *tabBarItem = [[UIView alloc] initWithFrame:CGRectMake(horizontalOffset, 0.0, itemWidth,49)];
            //tabBarItem.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
            // Create a button
            //UIButton* button = [self buttonAtIndex:i width:self.frame.size.width/itemCount];
            UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
            UIImage *iconImage = [UIImage imageNamed:data[@"image"]];
            UIImage *nonSelectedState = [self setImage:iconImage Alpha:.8];
            [button setImage:nonSelectedState forState:UIControlStateNormal];
            
            
            [button setImage:iconImage forState:UIControlStateSelected];
            [button setImage:iconImage forState:UIControlStateHighlighted];
            
            button.imageEdgeInsets = UIEdgeInsetsMake(-15, 0, 0, 0);
            
            
            // Register for touch events
            [button addTarget:self action:@selector(touchDownAction:) forControlEvents:UIControlEventTouchDown];
            [button addTarget:self action:@selector(touchUpInsideAction:) forControlEvents:UIControlEventTouchUpInside];
            [button addTarget:self action:@selector(otherTouchesAction:) forControlEvents:UIControlEventTouchUpOutside];
            [button addTarget:self action:@selector(otherTouchesAction:) forControlEvents:UIControlEventTouchDragOutside];
            [button addTarget:self action:@selector(otherTouchesAction:) forControlEvents:UIControlEventTouchDragInside];
            
            // Add the button to our buttons array
            [buttons addObject:button];
            
            // Set the button's x offset
            button.frame = CGRectMake(0.0, 0.0, itemWidth, 49);
            
            // Add the button as our subview
            [tabBarItem addSubview:button];
            
            //Create the Label
           
            
            GELabel *tabBarLabel = [[GELabel alloc]initWithFrame:CGRectZero Font:GE_Inspira_Ext_Bold Size:8 andColor:GE_COLOR_WHITE_80A];
            NSString *LabelText = [tabBarItems objectAtIndex:i][@"title"];
            
            
            LabelText = [LabelText uppercaseString];
            CGSize labelSize = [LabelText sizeWithFont:[UIFont fontWithName:@"GEInspira-ExtraBold" size:8]];
            
            tabBarLabel.frame = CGRectMake((round(itemWidth/2) - round(labelSize.width/2) -2), 30, labelSize.width + 4, labelSize.height);
            tabBarLabel.textAlignment = NSTextAlignmentCenter;
            tabBarLabel.text = LabelText;
            //add label to Array
            [labels addObject:tabBarLabel];
            
            [tabBarItem addSubview:tabBarLabel];
            [tabBarItemViews addObject:tabBarItem];
            
            [containerView addSubview:tabBarItem];
            //[self addSubview:tabBarItem];
            // Advance the horizontal offset
            horizontalOffset += (containerView.frame.size.width - itemSize.width) / (itemCount-1);//horizontalOffset + itemSize.width;
        }
    }
    
    return self;
}

-(void) dimAllButtonsExcept:(UIButton*)selectedButton
{
    for (UIButton* button in buttons)
    {
        if (button == selectedButton)
        {
            button.selected = YES;
            button.highlighted = button.selected ? NO : YES;
            button.tag = SELECTED_ITEM_TAG;
            
        }
        else
        {
            button.selected = NO;
            button.highlighted = NO;
            button.tag = 0;
        }
    }
}

-(void) dimAllLablesExcept:(GELabel*)selectedLabel
{
    for (GELabel* label in labels)
    {
        if (label == selectedLabel)
        {
            label.textColor = GE_COLOR_WHITE;
            
        }
        else
        {
            label.textColor = GE_COLOR_WHITE_80A;
        }
    }
}



-(void) setRuleOnSelectedView:(UIView*)selectedView withLabel:(UILabel*)labelAtIndex
{

   
    for (UIView* view in tabBarItemViews) {
        if(view == selectedView){
   
            
            UIView *rule = [[UIView alloc]initWithFrame:CGRectMake(view.frame.size.width/2 - labelAtIndex.frame.size.width/2, view.frame.size.height-2, labelAtIndex.frame.size.width, 2)];
            labelAtIndex.textColor = GE_COLOR_WHITE;
            rule.backgroundColor = GE_COLOR_WHITE_80A;
            rule.tag = 1234321;
            [view addSubview:rule];
        
        
        
        }else{
            
            if((UIView*)[view viewWithTag:1234321]){
            UIView * rule = (UIView*)[view viewWithTag:1234321];
                
            [rule removeFromSuperview];
            }
        
        }
    }


}

- (UIImage *)setImage:(UIImage*)startImage Alpha:(CGFloat) alpha {
    UIGraphicsBeginImageContextWithOptions(startImage.size, NO, 0.0f);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGRect area = CGRectMake(0, 0, startImage.size.width, startImage.size.height);
    
    CGContextScaleCTM(ctx, 1, -1);
    CGContextTranslateCTM(ctx, 0, -area.size.height);
    
    CGContextSetBlendMode(ctx, kCGBlendModeMultiply);
    
    CGContextSetAlpha(ctx, alpha);
    
    CGContextDrawImage(ctx, area, startImage.CGImage);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return newImage;
}

#pragma mark setters

- (void)setAccentColor:(UIColor *)color
{

    _accentColor = color;
    backgroundView.backgroundColor = _accentColor;


}

#pragma mark Touch Actions

- (void)touchDownAction:(UIButton*)button
{
    [self dimAllButtonsExcept:button];
    
    if ([delegate respondsToSelector:@selector(touchDownAtItemAtIndex:)])
        [delegate touchDownAtItemAtIndex:[buttons indexOfObject:button]];
}

- (void)touchUpInsideAction:(UIButton*)button
{
    [self dimAllButtonsExcept:button];
    
    if ([delegate respondsToSelector:@selector(touchUpInsideItemAtIndex:)])
        [delegate touchUpInsideItemAtIndex:[buttons indexOfObject:button]];
}

- (void)otherTouchesAction:(UIButton*)button
{
    [self dimAllButtonsExcept:button];
}

- (void) selectItemAtIndex:(NSInteger)index
{
    // Get the right button to select
    UIButton* button = buttons[index];
    
    UIView* viewAtIndex = tabBarItemViews[index];
    
    GELabel *labelAtIndex = labels[index];
    
    
   [self dimAllButtonsExcept:button];
   [self setRuleOnSelectedView:viewAtIndex withLabel:labelAtIndex];
    [self dimAllLablesExcept:labelAtIndex];
}




- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    CGFloat itemWidth = ((toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight)  ? self.window.frame.size.height : self.window.frame.size.width)/buttons.count;
    // horizontalOffset tracks the x value
    CGFloat horizontalOffset = 0;
    
    // Iterate through each button
    for (UIButton* button in buttons)
    {
        // Set the button's x offset
        button.frame = CGRectMake(horizontalOffset, 0.0, button.frame.size.width, button.frame.size.height);
        
        // Advance the horizontal offset
        horizontalOffset = horizontalOffset + itemWidth;
    }
    
    // Move the arrow to the new button location
    UIButton* selectedButton = (UIButton*)[self viewWithTag:SELECTED_ITEM_TAG];
    [self dimAllButtonsExcept:selectedButton];
}


@end
