//
//  MIComments.h
//  Market Intelligence
//
//  Created by devness on 21/02/17.
//  Copyright © 2017 Jeff Roberts . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MIConstant.h"
@interface MIComments : NSObject
@property (nonatomic, retain) NSString * contactName;
@property (nonatomic, retain) NSNumber * keyId;
@property (nonatomic, retain) NSString * surveyType;
@property (nonatomic, retain) NSString * text;
@property (nonatomic, retain) NSString * dealerNumber;
@property (nonatomic, retain) MICategory *category;
@property (nonatomic, retain) NSSet *dealerList;
@property (nonatomic, retain) NSSet *subCategoryList;
@property (nonatomic, retain) MISuperCategory *superCategory;
@property (nonatomic, retain) NSSet *topicList;
@end


