//
//  NSURLConnection+TrustGESignedCertificate.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/28/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "NSURLConnection+TrustGESignedCertificate.h"

@implementation NSURLConnection (TrustGESignedCertificate)

+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host
{
    return YES;
}

@end
