//
//  LoginViewController.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/12/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "GELoginFullScreenViewController_iPhone.h"
#import "LoginService.h"
#import "DealerListService.h"

@interface LoginViewController : GELoginFullScreenViewController_iPhone <LoginStatusReceiver, DealerDataReceiver>
{
    SEL loginCallback;
    UIActivityIndicatorView* activityView;
    LoginService* loginService;
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil callback:(SEL) callback;

@end
