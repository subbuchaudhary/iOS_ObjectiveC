//
//  DealerViewCell.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 12/17/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Dealer.h"

@protocol DealerCellDelegate <NSObject>

- (void) selectDealer : (Dealer*) dealer;
- (void) unselectDealer : (Dealer*) dealer;

@end

@interface DealerViewCell : UITableViewCell

{
    UIFont* inspiraFont;
    UIFont* inspiraBold;
}


@property (weak, nonatomic) Dealer* dealer;
@property (weak, nonatomic) IBOutlet UIButton *checkboxOn;
@property (weak, nonatomic) IBOutlet UIButton *checkboxOff;


@property (weak, nonatomic) IBOutlet UILabel *dealerName;
@property (weak, nonatomic) IBOutlet UILabel *branchNoAndVBU;
@property (weak, nonatomic) id<DealerCellDelegate> delegate;


- (IBAction)checkboxClicked:(UIButton *)sender;

- (void) configureWithDealer: (Dealer*) aDealer;
- (void) markSelected;

- (BOOL) isSelected;

@end
