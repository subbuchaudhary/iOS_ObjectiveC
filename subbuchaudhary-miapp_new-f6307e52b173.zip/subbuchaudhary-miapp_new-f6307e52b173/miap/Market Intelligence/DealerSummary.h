//
//  DealerSummary.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu Manuru on 1/13/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Dealer.h"

@interface DealerSummary : NSObject <NSCoding>

@property (strong, retain) NSString* customerName;
@property (strong, retain) NSString* customerNumber;
@property (strong, retain) NSString* branchNo;
@property (strong, retain) NSString* vbu;
@property BOOL isValidated;

-(id) initWithDealer: (Dealer*) dealer;
-(id) initWithDealerNumber:(NSString *)dealerNo;

- (BOOL)isEqual:(id)object;

-(NSDictionary*) asDictionary;
- (void) encryptWithKey:(NSString*) key;
-(void) decryptWithKey:(NSString*) key;

@end
