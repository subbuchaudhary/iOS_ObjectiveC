//
//  CommentRowView.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectedDataViewCell.h"
#import "Comment+CommentCustom.h"
#import "DealerSummaryEntity+DealerSummaryCustom.h"

@protocol CommentRowViewDeleteDelegate <NSObject>
-(void) deleteSelectedDealer : (DealerSummaryEntity *) dealer;
-(void) deleteSelectedOpportunityType : (BaseCategory*) opportunityType;

@end

@interface CommentRowView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) IBOutlet UILabel *title;
@property (nonatomic) IBOutlet UIView *container;
@property (nonatomic) IBOutlet UIImageView *icon;
@property (nonatomic) IBOutlet UIImageView *checkbox;
@property (nonatomic) IBOutlet UIImageView *accessory;
@property UIColor *defaultColor;
@property (weak, nonatomic) IBOutlet UITextField *dealerText;

@property (weak, nonatomic) IBOutlet UITableView *selectedDataTable;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableHeight;

@property (nonatomic) IBOutlet UIView *lineView;

@property (weak) NSArray* dealerList;
@property(strong, nonatomic) NSMutableArray *dataList;

@property Comment* comment;
@property DataCellType type;

@property(strong, nonatomic) id<CommentRowViewDeleteDelegate> delegate;

- (void) displayValidationError: (BOOL) flag;
- (void) displayData: (BOOL) display;

- (int) height;



@end
