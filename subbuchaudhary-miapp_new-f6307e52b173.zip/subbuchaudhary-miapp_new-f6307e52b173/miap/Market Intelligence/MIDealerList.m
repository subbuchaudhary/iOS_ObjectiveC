//
//  MIDealerList.m
//  SqlLiteDemo
//
//  Created by Anil Godawat on 19/02/17.
//  Copyright © 2017 devness. All rights reserved.
//

#import "MIDealerList.h"

@implementation MIDealerList

@end
