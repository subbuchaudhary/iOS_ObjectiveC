//
//  FSR.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "FSR.h"


@implementation FSR

@dynamic firstName;
@dynamic lastName;
@dynamic managerSSO;
@dynamic sso;

@end
