//
//  SelectedDataViewCell.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 2/6/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SelectedDataViewCell.h"
#import "SurveyCategory+SurveyCategoryCustom.h"
#import "SubCategory+SubCategoryCustom.h"
#import "Topic.h"

@implementation SelectedDataViewCell
@synthesize type;
@synthesize dealer;
@synthesize opportunityType;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code

    }
    return self;
}
- (void) prepareForReuse
{

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (IBAction)deletePressed:(id)sender {
}

- (void) configureWithOpportunityType:(BaseCategory*)type
{
    self.opportunityType = type;
    self.dataLabel.text = self.opportunityType.name;
    
    UIEdgeInsets insets;

    if ([opportunityType isKindOfClass:[SurveyCategory class]])
    {
        SurveyCategory* category = (SurveyCategory*) opportunityType;
        self.indentationLevel = 0;
    }
    if ([opportunityType isKindOfClass:[SubCategory class]])
    {
        SubCategory* subCategory = (SubCategory*) opportunityType;
        self.indentationLevel = 1;

    }
    if ([opportunityType isKindOfClass:[Topic class]])
    {
        Topic* topic = (Topic*) opportunityType;
        self.indentationLevel = 3;

    }
    
    
    insets.right = 25;
    insets.left = 25;
    self.separatorInset = insets;
}

- (void) configureWithDealer:(DealerSummaryEntity *)dealerSummary
{
    self.dealer = dealerSummary;
    
    self.dataLabel.text = [NSString stringWithFormat:@"%@-%@", self.dealer.customerName, self.dealer.vbu];

    
    UIEdgeInsets insets;
    insets.left = 25;
    insets.right = 25;
    self.separatorInset = insets;
    
}

// Added by Easwar - To change the font of Delete button in the tableview cell.

-(void)layoutSubviews{
    [super layoutSubviews];
    for (UIView *currentView in super.subviews) {
        for (UIView *currentView1 in currentView.subviews) { // Traversing the cell
            if ([NSStringFromClass([currentView1 class]) isEqualToString:@"UITableViewCellDeleteConfirmationView"]) { // Traversing teh delete view
                for (UIView *currentView2 in currentView1.subviews) { // To get the button
                    for (UIView *currentView3 in currentView2.subviews) { // Traversing the button
                        if ([currentView3 isKindOfClass:[UILabel class]]) { // To get the delete label
                            UILabel *deleteLabel = (UILabel *) currentView3;
                            deleteLabel.font = [UIFont fontWithName:@"GEInspira-Bold" size:15.0];
                        }
                    }
                }
            }
        }
    }
    float indentPoints = self.indentationLevel * self.indentationWidth;
    self.contentView.frame = CGRectMake(indentPoints,
                                        self.contentView.frame.origin.y,
                                        self.contentView.frame.size.width - indentPoints,
                                        self.contentView.frame.size.height);
}

@end
