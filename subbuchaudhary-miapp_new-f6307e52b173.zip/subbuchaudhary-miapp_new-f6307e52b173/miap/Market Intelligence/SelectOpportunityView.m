//
//  SelectOpportunityView.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 12/9/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "SelectOpportunityView.h"

@implementation SelectOpportunityView

@synthesize selectedOpportunityType;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [[NSBundle mainBundle] loadNibNamed:@"SelectOpportunityView" owner:self options:nil];
        [self addSubview:self.container];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        //Custom Initialization code here
        [[NSBundle mainBundle] loadNibNamed:@"SelectOpportunityView" owner:self options:nil];
        [self addSubview:self.container];

        //Set the images and labels for the opportunity selections
        self.retentionView.image.image = [UIImage imageNamed:@"icon_opp_retention"];
        self.retentionView.label.text = @"Customer Retention";
        self.flooringView.image.image = [UIImage imageNamed:@"icon_opp_flooring"];
        self.flooringView.label.text = @"Flooring Opportunity";
        self.creditView.image.image = [UIImage imageNamed:@"icon_opp_credit" ];
        self.creditView.label.text = @"Credit Line Increase";
        self.experienceView.image.image = [UIImage imageNamed:@"icon_opp_experience"];
        self.experienceView.label.text = @"Customer Experience";
        

        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (IBAction)opportunityRowSelected:(UITapGestureRecognizer *)sender {
    
    UIView *selectedView = sender.view;
    self.selectedOpportunityType = sender.view.tag;
    
    
     [self.delegate performSegueWithIdentifier:@"ToOpportunityList" sender:selectedView];
}
@end
