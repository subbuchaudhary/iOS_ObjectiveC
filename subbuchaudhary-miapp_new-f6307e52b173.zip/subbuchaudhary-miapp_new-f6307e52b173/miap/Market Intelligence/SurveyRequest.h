//
//  SurveyRequest.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/24/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Survey.h"
#import "FSR.h"

#import "Comment.h"
#import "SuperCategory.h"
#import "SurveyCategory.h"
#import "SubCategory.h"
#import "Topic.h"

@interface SurveyRequest : NSObject


+ (NSString*) asJSONForSurvey: (Survey*) survey withFSR: (FSR*) fsr;
@end
