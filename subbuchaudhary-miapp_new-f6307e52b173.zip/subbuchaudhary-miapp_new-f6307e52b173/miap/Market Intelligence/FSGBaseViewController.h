//
//  FSGBaseViewController.h
//  Market Intelligence
//
//  Created by Jeff Roberts on 12/2/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSGBaseViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIBarButtonItem *doneBarButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelBarButton;

- (IBAction)cancelPressed:(UIBarButtonItem *)sender;
@property (strong, retain) NSString* titleText;
@end
