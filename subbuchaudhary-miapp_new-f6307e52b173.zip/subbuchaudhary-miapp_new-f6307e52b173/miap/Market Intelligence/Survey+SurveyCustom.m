//
//  Survey+SurveyCustom.m
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "Survey+SurveyCustom.h"
#import "Comment+CommentCustom.h"

@implementation Survey (SurveyCustom)
- (void)addCommentListObject:(Comment *)value
{
    // Create a mutable set with the existing objects, add the new object, and set the relationship equal to this new mutable ordered set
    NSMutableOrderedSet *commentList = [[NSMutableOrderedSet alloc] initWithOrderedSet:self.commentList];
    [commentList addObject:value];
    self.commentList = commentList;
    
}

- (void) prepareForSubmit
{
    self.surveyID = [self generateSurveyID];
}

- (NSString*) generateSurveyID
{
    NSString* surveyID;
    // Timestamp
    NSDate *current = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MM_dd_yyyy_HH_mm_ss"];
    NSString* timeStamp = [formatter stringFromDate:current];
    
    NSString *deviceID= [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    
    surveyID = [NSString stringWithFormat:@"%@_%@",deviceID,timeStamp];
    return surveyID;
}

- (void) encryptWithKey:(NSString*) key;
{
    for (int i=0; i< self.commentList.count;i++)
    {
        Comment* comment = [self.commentList objectAtIndex:i];
        [comment encryptWithKey:key];
    }
}

- (void) decryptWithKey:(NSString*) key
{
    for (int i=0; i< self.commentList.count;i++)
    {
        Comment* comment = [self.commentList objectAtIndex:i];
        [comment decryptWithKey:key];
    }
    
}

- (int) numberOfUnsentMessages
{
    int noOfUnsentMessages = 0;
    
    for (int i=0; i< self.commentList.count; i++)
    {
        Comment* comment = [self.commentList objectAtIndex:i];
        
        if (([comment isContactNameSelected]) ||
           ([comment isDealerSelected]) ||
           ([comment isOpportunityTypeSelected]) ||
            ([comment isTextEntered]))
            noOfUnsentMessages++;
            
    }
    
    return noOfUnsentMessages;
    
}

@end
