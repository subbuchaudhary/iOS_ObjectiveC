//
//  CommentView.m
//  Market Intelligence
//
//  Created by Jeff Roberts on 11/25/13.
//  Copyright (c) 2013 GE Capital, Americas. All rights reserved.
//

#import "CommentView.h"
#import <QuartzCore/QuartzCore.h>

#import "SurveyCategory.h"
#import "SubCategory.h"
#import "Topic.h"
#import "Comment+CommentCustom.h"
#import "AppDelegate.h"

@implementation CommentView

const int SELECTED_DATA_HEIGHT = 44;

@synthesize comment;
@synthesize dealerNumberValidated;

-(id)init {
    self = [super init];
    if (self) {
        //Custom Initialization code here
        [[NSBundle mainBundle] loadNibNamed:@"CommentView" owner:self options:nil];
        [self addSubview:self.container];
        self.opportunityType.title.text = @"Opportunity Type";
        self.opportunityType.accessory.image = [UIImage imageNamed:@"burger"];
//        [self.opportunityType.accessory sizeToFit];
        self.opportunityType.icon.image = [UIImage imageNamed:@"icon_opp"];
        self.opportunityType.dealerText.hidden = YES;
        editingDealer = NO;
        
        self.dealerInfo.title.text = @"Dealer No.";
        self.dealerInfo.accessory.image = [UIImage imageNamed:@"chevron"];
//        [self.dealerInfo.accessory sizeToFit];
        self.dealerInfo.icon.image = [UIImage imageNamed:@"icon_dealer"];
        self.dealerInfo.hidden = NO;
        self.dealerInfo.title.hidden = YES;
        self.dealerInfo.dealerText.delegate = self;
        self.contactName.delegate = self;
        editingContactName = false;
        
        
        _activityIndicator.hidden = YES;
        
        self.dealerInfo.type = DEALER_DATA_CELL;
        self.opportunityType.type = OPPORTUNITY_DATA_CELL;
        
        validatingDealerNumberForSend = NO;
        dealerNumberValidated = NO;
        
        self.commentArea.font = [UIFont fontWithName:@"GEInspira-Bold" size:14]; // Added by Easwar
        self.contactName.font = [UIFont fontWithName:@"GEInspira-Bold" size:14]; // Added by Easwar
        
        self.contactName.autocapitalizationType = UITextAutocapitalizationTypeWords;
        
        // Delegate setup for the CommentRowView
        self.dealerInfo.delegate = self;
        self.opportunityType.delegate = self;
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.dealerInfo.type = DEALER_DATA_CELL;
        self.opportunityType.type = OPPORTUNITY_DATA_CELL;
    }
    return self;
}


-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        //Custom Initialization code here
        [[NSBundle mainBundle] loadNibNamed:@"CommentView" owner:self options:nil];
        [self addSubview:self.container];

        
        if ((self.comment.category != nil) || (self.comment.subCategoryList != nil) || (self.comment.topicList != nil))
        {
            self.opportunityType.checkbox.hidden = NO;
        }
        else
        {
            self.opportunityType.checkbox.hidden = YES;
        }
    }
    self.dealerInfo.type = DEALER_DATA_CELL;
    self.opportunityType.type = OPPORTUNITY_DATA_CELL;
    return self;
}

-(void) awakeFromNib {
    [super awakeFromNib];
    self.opportunityType.title.text = @"Opportunity Type";
    [self.opportunityType.title setFont:[UIFont fontWithName:@"GE Inspira ExtraBold" size:25]];
    self.opportunityType.accessory.image = [UIImage imageNamed:@"burger"];
//    [self.opportunityType.accessory sizeToFit];
    self.opportunityType.icon.image = [UIImage imageNamed:@"icon_opp"];
    self.dealerInfo.title.text = @"Dealer No.";
    [self.dealerInfo.title setFont:[UIFont fontWithName:@"GE Inspira ExtraBold" size:17]];
    self.dealerInfo.accessory.image = [UIImage imageNamed:@"chevron"];
//    [self.dealerInfo.accessory sizeToFit];
    self.dealerInfo.icon.image = [UIImage imageNamed:@"icon_dealer"];
    [self.commentArea setText:comment.text];
    [self.contactName setText:comment.contactName];
    
    if (self.objectID.intValue == 0)
    {
        self.deleteComment.hidden = YES;
    }
    
    if ([comment isOpportunityTypeSelected])
        self.opportunityType.checkbox.hidden = NO;
    else
        self.opportunityType.checkbox.hidden = YES;
    
    if ([comment isDealerSelected])
        self.dealerInfo.checkbox.hidden = NO;
    else
        self.dealerInfo.checkbox.hidden = YES;
    
    self.dealerInfo.comment = comment;
    self.opportunityType.comment = comment;
    
    self.dealerInfo.type = DEALER_DATA_CELL;
    self.opportunityType.type = OPPORTUNITY_DATA_CELL;
    
}

-(IBAction) rowSelected:(id)sender {

    if ([sender respondsToSelector:@selector(setBackgroundColor:)]) {
        [sender setBackgroundColor:[UIColor blueColor]];
    }
    [self.delegate rowSelectedWithTag:[[sender view] tag] forCommentID:self.objectID] ;
}

-(IBAction)textViewSelected:(id)sender {
    [self.delegate performSelector:_updateCurrentComment withObject:_objectID];
    [self.delegate performSegueWithIdentifier:@"ToCommentInput" sender:self.delegate];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        [self.delegate deleteComment:_objectID];
    }
 }

- (IBAction)deleteComment:(UIButton *)sender
{
    UIAlertView* deleteAlert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"You are about to delete current comment. Are you sure?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Continue", nil];
    [deleteAlert show];

}

- (BOOL) validateText
{
    BOOL valid = YES;
    if ((comment.text == Nil) || ([comment.text isEqualToString:@""]))
    {
        valid = NO;
        [self displayValidationError:YES forView:self.commentArea];
    }
    else
    {
        [self displayValidationError:NO forView:self.commentArea];
    }
    return valid;
}

- (BOOL) validateOptionSelections
{
    BOOL valid = YES;
    if ((comment.category == nil) && (comment.subCategoryList.allObjects.count ==0) &&
        (comment.topicList.allObjects.count ==0))
    {
        valid = NO;
        [self.opportunityType displayValidationError:YES];
    }
    else
    {
        [self.opportunityType displayValidationError:NO];
    }
    return valid;
}

- (BOOL) validateDealerSelections
{
    BOOL valid = YES;
    
    NSArray* dealerList = comment.dealerList.allObjects;
    if ((comment.dealerList.count == 0) && ([self.dealerInfo.dealerText.text isEqualToString:@""]))
    {
        valid = NO;
        [self.dealerInfo displayValidationError:YES];
    }
    else
    {
        // Validate each of the dealers
        for (int i=0; i< dealerList.count;i++)
        {
            DealerSummaryEntity* dealer = [dealerList objectAtIndex:i];
            if (dealer.isValidated)
                continue;
                
        }
        [self.dealerInfo displayValidationError:NO];
    }

    return valid;
}

-(void) displayValidationError:(BOOL) flag forView:(UIView*) view
{
    if (flag)
    {
        view.layer.borderWidth = 1.0f;
        view.layer.borderColor = [[UIColor redColor] CGColor];
    }
    else
    {
        view.layer.borderWidth = 0.0f;
    }
}


- (BOOL) validateContactName
{
    BOOL valid = YES;
    comment.contactName = [self.contactName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    self.contactName.text = comment.contactName;
    if ((comment.contactName == Nil) || ([comment.contactName isEqualToString:@""]))
    {
        valid = NO;
        _contactCheckBox.hidden = YES;
        [self displayValidationError:YES forView:self.contactName];
    }
    else
    {
        _contactCheckBox.hidden = NO;
        [self displayValidationError:NO forView:self.contactName];
    }
    return valid;
}

- (BOOL) isValid
{
    
    BOOL validText = [self validateText];
    BOOL validCategorySelections = [self validateOptionSelections];
    BOOL validDealerSelections = [self validateDealerSelections];
    BOOL validContactName = [self validateContactName];

    return (validText && validCategorySelections && validDealerSelections && validContactName);
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self.delegate performSelector:_updateCurrentComment withObject:_objectID];
    if (textField == _contactName)
    {
        CGPoint textFieldPos = [self.delegate positionOfTextField:textField];
        [self animateTextField: textField up: YES];
        editingContactName = YES;
    }
    else
    {
        editingDealer = YES;
        [self animateTextField: textField up: YES];
       
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textField == self.contactName) {
        [textField resignFirstResponder];
        [self.delegate enteredContactName:self.contactName.text];
        if (![textField.text isEqualToString:@""]){
            _contactCheckBox.hidden = NO;
        }else{
            _contactCheckBox.hidden = YES;
        }
        return NO;
    }
    else
    {
        [textField resignFirstResponder];
        if (![textField.text isEqualToString:@""])
        {
            comment.dealerNumber = textField.text;
            AppDelegate* appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [appDelegate.surveyUtil saveCurrentSurvey];
            
            DealerListService* service = [[DealerListService alloc] initWithDelegate:self];
            _activityIndicator.hidden = NO;
            [_activityIndicator startAnimating];
            NSString* dealerNumber = textField.text;
            [service validateDealerNumber:dealerNumber];
        }
        else
        {
            [self.dealerInfo displayValidationError:NO];
            if ([comment isDealerSelected])
                self.dealerInfo.checkbox.hidden = NO;
            else
                self.dealerInfo.checkbox.hidden = YES;
        }
        
        return NO;
    }
    return YES;
}

- (BOOL) textFieldShouldEndEditing:(UITextField *)textField
{
    [self animateTextField: textField up: NO];
    [self endEditing:YES];
    [textField resignFirstResponder];

    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if (textField.text.length < 40 || string.length == 0)
        return YES;
    else
        return NO;
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    
    int movementDistance = 50; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    if ([self height] > 425)
        movementDistance = 225;
    else
        if ([self height] > 325)
            movementDistance = 200;
    if (editingDealer)
    {
        if (!up)
            editingDealer = NO;
    }
    else
    {
        if (!up)
            editingContactName = NO;
    }
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.frame = CGRectOffset(self.frame, 0, movement);
    [UIView commitAnimations];
}

- (CGFloat) height
{
    CGFloat height = 327;
    
   if ([self shouldDisplayOptions])
   {
       height += self.opportunityType.tableHeight.constant;
       height += 1;
   }
    if ([self shouldDisplayDealers])
    {
        height += self.dealerInfo.tableHeight.constant;
        height += 1;
    }

    return height;
}

- (BOOL) shouldDisplayDealers
{
    return [comment isDealerSelected];
}

- (BOOL) shouldDisplayOptions
{
    BOOL displayOptions = NO;
    
    if ((comment.category != Nil) ||
        (comment.topicList.count >0) ||
        (comment.subCategoryList.count > 0))
    {
        displayOptions = YES;
    }else{
        if (comment.superCategory) {
            comment.superCategory = Nil; // For making the color default for the selected opportunity
        }
    }
    return displayOptions;
}

- (void) displayDealersAndOptionsIfPresent
{
    
    self.dealerInfo.type = DEALER_DATA_CELL;
    self.opportunityType.type = OPPORTUNITY_DATA_CELL;
    self.dealerInfo.comment = comment;
    self.opportunityType.comment = comment;
    
    // Check if Categories should be displayed
    if ([self shouldDisplayOptions])
    {
        
        [self.opportunityType displayData:YES];
        self.optionViewHeight.constant = [self.opportunityType height];
    }
    else
    {
        [self.opportunityType displayData:NO];
        self.optionViewHeight.constant = 44; // To restore height after deleting the rows of the tableview inside this.
    }
    
    // Check if dealers are to be displayed
    if ([self shouldDisplayDealers])
    {
        [self.dealerInfo displayData:YES];
        self.dealerViewHeight.constant = [self.dealerInfo height];
    }
    else
    {
        [self.dealerInfo displayData:NO];
        self.dealerViewHeight.constant = 44; // To restore height after deleting the rows of the tableview inside this.
    
    }
    
    //Adjust height of CommentView Frame
    CGRect currentViewFrame = self.frame;
    currentViewFrame.size.height = [self height];
    self.frame = currentViewFrame;

    [self layoutIfNeeded];
}

-(void) setDefaultBorderForView:(UIView*) view
{
    // To adjust for UI layout losing border
    view.layer.borderColor = (__bridge CGColorRef)([UIColor darkGrayColor]);
    view.layer.borderWidth = 2.0f;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void) receiveDealerData:(NSMutableArray *)dealerData
{
    // Not implemented
}

- (void) unableToValidateDealer:(NSString *)dealerNumber
{
    self.dealerInfo.dealerText.text = dealerNumber;
    
    if (validatingDealerNumberForSend)
    {
        validatingDealerNumberForSend = NO;
        dealerNumberValidated = YES;
        [self.dealerInfo displayValidationError:YES];
        [self.delegate validationComplete:NO];
        return;
    }
    
    if ([comment isDealerSelected])
        self.dealerInfo.checkbox.hidden = NO;
    else
        self.dealerInfo.checkbox.hidden = YES;
    
    self.activityIndicator.hidden = YES;
    [self.activityIndicator stopAnimating];
    
    [self.delegate refreshView];
}

- (void) invalidDealerNumber:(NSString *)dealerNumber
{
    if (validatingDealerNumberForSend)
    {
        validatingDealerNumberForSend = NO;
        dealerNumberValidated = YES;
        [self.dealerInfo displayValidationError:YES];
        [self.delegate validationComplete:NO];
        return;
    }
    // There is connectivity. But dealer number is invalid

    self.dealerInfo.dealerText.text = dealerNumber;
    [self.dealerInfo displayValidationError:YES];
    [self.activityIndicator stopAnimating];
    self.activityIndicator.hidden = YES;
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Dealer Number" message:@"Specified Dealer Number is invalid" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    
}

- (void) receiveValidateDealer:(DealerSummaryEntity *)dealer
{
    comment.dealerNumber = @"";
    [_activityIndicator stopAnimating];
    _activityIndicator.hidden = YES;
    
    if (validatingDealerNumberForSend)
    {
        validatingDealerNumberForSend = NO;
        dealerNumberValidated = YES;
        // Connectivity but dealer no is invalid
        if (dealer.isValidated)
        {
            [comment addDealerListObject:dealer];
            self.dealerInfo.dealerText.text = @"";
            [self.delegate validationComplete:YES];
        }
        else
        {
            [self.delegate validationComplete:NO];
            [self.dealerInfo displayValidationError:YES];
           
        }
        return;
    }

    
    [comment addDealerListObject:dealer];
    
    if (comment.isDealerSelected)
    {
        self.dealerInfo.checkbox.hidden = NO;
        [self.dealerInfo displayValidationError:NO];
    }
    self.dealerInfo.dealerText.text = @"";
    [self displayDealersAndOptionsIfPresent];
    [self.delegate refreshView];
}

/*
 ** Function called by Parent controller if any dealer# is entered and there is no connectivity
 */
- (void) validateDealerNumber
{
    DealerListService* service = [[DealerListService alloc] initWithDelegate:self];
    validatingDealerNumberForSend = YES;
    [service validateDealerNumber:self.dealerInfo.dealerText.text];
}

#pragma mark CommentRowViewDeleteDelegate

-(void) deleteSelectedOpportunityType:(BaseCategory *)opportunityType
{
    
    if (comment.category != Nil)
    {
        if([comment.category isEqual:opportunityType]){
            comment.category = Nil;
        }
    }
    
    if ([opportunityType isKindOfClass:[SubCategory class]])
    {
        SubCategory* removedSubCat = (SubCategory*) opportunityType;
        [comment removeSubCategoryListObject:removedSubCat];
    }
    if ([opportunityType isKindOfClass:[Topic class]])
    {
        Topic* removedTopic = (Topic*) opportunityType;
        [comment removeTopicListObject:removedTopic];
    }

    if (![comment isOpportunityTypeSelected])
        self.opportunityType.checkbox.hidden = YES;
    [self displayDealersAndOptionsIfPresent];
    [self.delegate refreshView];
}

- (void) deleteSelectedDealer:(DealerSummaryEntity *)dealer
{
    
    [self.comment removeDealerListObject:dealer];
    
    if (![comment isDealerSelected])
    {
        self.dealerInfo.checkbox.hidden = YES;
    }
    [self displayDealersAndOptionsIfPresent];
    [self.delegate refreshView];
}

@end
