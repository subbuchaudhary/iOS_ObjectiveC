//
//  SuperCategory+SuperCategoryCustom.h
//  Market Intelligence
//
//  Created by Panduranga Prabhu on 1/27/14.
//  Copyright (c) 2014 Jeff Roberts. All rights reserved.
//

#import "SuperCategory.h"

@interface SuperCategory (SuperCategoryCustom)
- (void)addCategoryListObject:(SurveyCategory *)value;
@end
