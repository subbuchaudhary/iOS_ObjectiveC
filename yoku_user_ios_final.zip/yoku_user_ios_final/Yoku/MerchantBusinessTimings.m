//
//  MerchantBusinessTimings.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantBusinessTimings.h"

@implementation MerchantBusinessTimings

- (id)initWithData:(NSDictionary *)data {
    
    self.closesAt = data[@"closesAt"];
    self.opensAt = data[@"opensAt"];
    
    return self;
}

@end
