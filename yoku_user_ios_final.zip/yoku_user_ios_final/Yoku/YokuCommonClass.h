//
//  YokuCommonClass.h
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface YokuCommonClass : NSObject


+(void)TextViewPadding:(UITextField*)txt;
@end