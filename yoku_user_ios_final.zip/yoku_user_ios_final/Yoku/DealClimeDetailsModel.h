//
//  DealClimeDetailsModel.h
//  Yoku
//
//  Created by Ramesh on 12/3/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TransactionModel.h"
#import "DealDetailsModel.h"

@interface DealClimeDetailsModel : NSObject

@property (nonatomic, strong) TransactionModel *transactionModel;
@property (nonatomic, strong) DealDetailsModel *dealDetailModel;
@property (nonatomic, strong) NSString *redeemCode;
@property (nonatomic, strong) NSString *claimId;
@property (nonatomic, strong) NSNumber *expiryDuration;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *claimTime;
@property (nonatomic, strong) NSString *expirationTime;

- (id)initWithData:(NSDictionary *)data;

@end
