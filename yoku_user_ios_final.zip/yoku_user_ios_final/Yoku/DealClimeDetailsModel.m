//
//  DealClimeDetailsModel.m
//  Yoku
//
//  Created by Ramesh on 12/3/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "DealClimeDetailsModel.h"

@implementation DealClimeDetailsModel

- (id)initWithData:(NSDictionary *)data {
    
    self.transactionModel = [[TransactionModel alloc]initWithData:data[@"transaction"]];
    self.dealDetailModel = [[DealDetailsModel alloc]initWithData:data[@"deal"]];
    self.redeemCode = data[@"redeemCode"];
    self.claimId = data[@"claimId"];
    self.expiryDuration = data[@"expiryDuration"];
    self.status = data[@"status"];
    self.claimTime = data[@"claimTime"];
    self.expirationTime = data[@"expirationTime"];
    
    return self;
}

@end
