//
//  DealDetailsModel.m
//  Yoku
//
//  Created by Ramesh on 12/3/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "DealDetailsModel.h"

@implementation DealDetailsModel

- (id)initWithData:(NSDictionary *)data {
    
    self.transaction = data[@"transaction"];
    self.dealId = data[@"dealId"];
    self.merchantId = data[@"merchantId"];
    self.title = data[@"title"];
    self.initiatedAt = data[@"initiatedAt"];
    self.beginsAt = data[@"beginsAt"];
    self.endsAt = data[@"endsAt"];
    self.totalClaims = data[@"totalClaims"];
    self.dealDescription = data[@"description"];
    self.instructions = data[@"instructions"];
    self.status = data[@"status"];
    self.claimExpiryDuration = data[@"claimExpiryDuration"];
    self.claimPerCustomer = data[@"claimPerCustomer"];
    self.redeemed = data[@"redeemed"];
    self.activeClaims = data[@"activeClaims"];
    self.dealType = data[@"dealType"];
    self.percentOff = data[@"percentOff"];
    self.image = data[@"image"];

    return self;
}

@end
