//
//  RedeemCodeViewController.m
//  Yoku
//
//  Created by Ramesh on 11/14/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "RedeemCodeViewController.h"
#import "RedeemTableViewCell.h"
#import "OfferCodeTableViewCell.h"

@interface RedeemCodeViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, weak) IBOutlet UIButton *makeMyPaymentBtn;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, assign) NSInteger rowCount;


@end

@implementation RedeemCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.rowCount = 1;
    self.tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    self.tableView.estimatedRowHeight = UITableViewAutomaticDimension;
    self.tableView.rowHeight = 250;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(redeemOkClick:) name:@"RedeemOkNotification" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(redeemCancelClick:) name:@"RedeemCancelNotification" object:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - NSNotifications 

- (void) redeemOkClick:(NSNotification *)notification {
    self.rowCount = 2;
    [self.tableView reloadData];
}

- (void) redeemCancelClick:(NSNotification *)notification {
    
}

#pragma mark - Actions


- (IBAction)tapOnMakePayment:(id)sender {
    
}

#pragma mark - UITableView Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.rowCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        RedeemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"redeemDelasCell"];
        [self setLblCustomText:cell.redeemInfoLbl];
        return cell;
    }

    
    OfferCodeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"offerCodeCell"];
    
    return cell;
}

#pragma mark - Private Method

- (void)setLblCustomText:(UILabel *)redeemInfoLbl {
    NSRange range1 = [redeemInfoLbl.text rangeOfString:@"Ok:"];
    NSRange range2 = [redeemInfoLbl.text rangeOfString:@"Close"];
    
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:redeemInfoLbl.text];
    
    [attributedText setAttributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:18]}
                            range:range1];
    [attributedText setAttributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:18]}
                            range:range2];
    
    redeemInfoLbl.attributedText = attributedText;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
