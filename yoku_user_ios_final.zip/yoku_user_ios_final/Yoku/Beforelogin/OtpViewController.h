//
//  OtpViewController.h
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomerRegistrationModel.h"

@interface OtpViewController : UIViewController

@property (nonatomic, strong) CustomerRegistrationModel *registartionModel;

@end
