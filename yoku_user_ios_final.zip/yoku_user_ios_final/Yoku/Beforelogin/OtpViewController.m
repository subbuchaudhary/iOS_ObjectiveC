//
//  OtpViewController.m
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "OtpViewController.h"
#import "UITextField+ContinerImageView.h"
#import "RestService.h"
#import "CustomerActivationModel.h"

@interface OtpViewController ()

@property (nonatomic, weak) IBOutlet UITextField *otpTxtFld;
@property (nonatomic, weak) IBOutlet UIButton *verifyBtn;
@property (nonatomic, weak) IBOutlet UIButton *resentOTPBtn;

@property (nonatomic, weak) IBOutlet UIImageView *tickMarkImgView;
@property (nonatomic, weak) IBOutlet UILabel *thankUlbl;
@property (nonatomic, weak) IBOutlet UILabel *numVerifiedLbl;

@property (nonatomic, weak) IBOutlet UIView *otpSuccessView;


@end

@implementation OtpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.otpTxtFld setLeftImageView:@"OTP"];
//    [self callOTPService];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Service Calls

- (void)callOTPService {
    [RestService sendAPICommand:CL_CUSTOMER_ACTIVATE methodType:GET withArgument:@[self.registartionModel.registrationId] paramas:nil withHeaders:[NSArray arrayWithObjects:self.registartionModel.otpRefNo,self.otpTxtFld.text, nil] isAuthRequired:NO withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            CustomerActivationModel *activationModel = responseObject;
            if ([activationModel.status isEqualToString:@"SUCCESS"]) {
                self.otpSuccessView.hidden = NO;
                self.otpTxtFld.hidden = YES;
                self.verifyBtn.hidden = YES;
                self.resentOTPBtn.hidden = YES;
                [self performSegueWithIdentifier:@"AddressViewController" sender:nil];
            }
        }
    }];
}

- (void)callResendOTPService {
    [RestService sendAPICommand:CL_RESEND_OTP_CUSTOMER methodType:GET withArgument:@[self.registartionModel.registrationId] paramas:nil withHeaders:[NSArray arrayWithObjects:self.registartionModel.otpRefNo, nil] isAuthRequired:NO withHandler:^(id responseObject, NSError *error) {
        if (!error) {
//            self.otpSuccessView.hidden = NO;
//            self.otpTxtFld.hidden = YES;
//            self.verifyBtn.hidden = YES;
//            self.resentOTPBtn.hidden = YES;
//            [self performSegueWithIdentifier:@"AddressViewController" sender:nil];
            //            [self performSelector:@selector(popToRoot) withObject:nil afterDelay:1.0];
        }
    }];
}

- (void)popToRoot
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - UITextFiled Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    
    return YES;
}

#pragma mark - Touch handlers

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

#pragma mark - Button Action

- (IBAction)tapOnVerifyButton:(id)sender {
       [self callOTPService];
}

- (IBAction)tapOnResendOTP:(id)sender {
    [self callResendOTPService];
}

#pragma mark - UIGestureRecogiser

- (IBAction)tapOnSuccessView:(id)sender {
    [self performSegueWithIdentifier:@"AddressViewController" sender:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
