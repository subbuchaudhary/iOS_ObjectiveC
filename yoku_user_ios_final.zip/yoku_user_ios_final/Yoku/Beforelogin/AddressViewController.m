//
//  AddressViewController.m
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "AddressViewController.h"
#import "TextFiledCell.h"
#import "UITextField+ContinerImageView.h"
#import "RestService.h"
#import "HelperClass.h"
#import "UserAuthModel.h"

@interface AddressViewController ()<UITextFieldDelegate>
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *cellImgNamesArr;
@property (nonatomic, strong) NSArray *cellTxtFiledPlacholdersArr;

@property (nonatomic, strong) NSString *titleStr;
@property (nonatomic, strong) NSString *descriptionStr;
@property (nonatomic, strong) NSString *line1Str;
@property (nonatomic, strong) NSString *landMarkStr;
@property (nonatomic, strong) NSString *cityStr;
@property (nonatomic, strong) NSString *stateStr;
@property (nonatomic, strong) NSString *countryStr;
@property (nonatomic, strong) NSString *pinCodeStr;

@end

@implementation AddressViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // self.cellImgNamesArr = [NSArray arrayWithObjects:@"name",@"email",@"password",@"password",@"smartphone", nil];
    self.cellTxtFiledPlacholdersArr = [NSArray arrayWithObjects:@"Title",@"Description",@"Line1 ",@"Lamdmark",@"City",@"State",@"Country",@"Pin Code", nil];
    
    // Do any additional setup after loading the view.
}

#pragma mark - UITableView Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.cellTxtFiledPlacholdersArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TextFiledCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.txtFiled.placeholder = self.cellTxtFiledPlacholdersArr[indexPath.row];
    cell.txtFiled.tag = indexPath.row+1;
    cell.txtFiled.delegate = self;
    
    if (indexPath.row == 0) {
        cell.txtFiled.text = self.titleStr;
    }else if (indexPath.row == 1) {
        cell.txtFiled.text = self.descriptionStr;
    }else if (indexPath.row == 2) {
        cell.txtFiled.text = self.line1Str;
    }else if (indexPath.row == 3) {
        cell.txtFiled.text = self.landMarkStr;
    }else if (indexPath.row == 4) {
        cell.txtFiled.text = self.cityStr;
    }else if (indexPath.row == 5) {
        cell.txtFiled.text = self.stateStr;
    }else if (indexPath.row == 6) {
        cell.txtFiled.text = self.countryStr;
    }else if (indexPath.row == 7) {
        cell.txtFiled.text = self.pinCodeStr;
    }

    [cell.txtFiled setLeftImageView:@""];
    
    return cell;
}

#pragma mark - UITextFiled Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.tag == 1) {
        self.titleStr = textField.text;
    }else if (textField.tag == 2){
        self.descriptionStr = textField.text;
    }else if (textField.tag == 3){
        self.line1Str = textField.text;
    }else if (textField.tag == 4){
        self.landMarkStr = textField.text;
    }else if (textField.tag == 5){
        self.cityStr = textField.text;
    }else if (textField.tag == 6){
        self.stateStr = textField.text;
    }else if (textField.tag == 7){
        self.countryStr = textField.text;
    }else if (textField.tag == 8){
        self.pinCodeStr = textField.text;
        [self.view endEditing:YES];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    CGPoint pointInTable = [textField.superview convertPoint:textField.frame.origin toView:self.tableView];
    CGPoint contentOffset = self.tableView.contentOffset;
    
    contentOffset.y = (pointInTable.y - textField.inputAccessoryView.frame.size.height);
    if (contentOffset.y != 0) {
        contentOffset.y -= 50;
    }
    
    NSLog(@"contentOffset is: %@", NSStringFromCGPoint(contentOffset));
    [self.tableView setContentOffset:contentOffset animated:YES];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:TRUE];
    [self.view endEditing:YES];
    
    return YES;
}

#pragma mark - UIButton Actions

- (IBAction)clickOnDone:(id)sender {
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view.superview.superview animated:YES];
//    hud.label.text = NSLocalizedString(@"Loading...", @"HUD loading title");

    NSString *fullAddressStr = [NSString stringWithFormat:@"%@, %@- %@",self.line1Str,self.cityStr,self.pinCodeStr];
    
    NSDictionary *postDict = [NSDictionary dictionaryWithObjectsAndKeys:self.countryStr,@"country",self.stateStr,@"state",self.cityStr,@"city",self.line1Str,@"line1",self.pinCodeStr,@"zipcode",self.landMarkStr,@"landmark",self.titleStr,@"title",self.descriptionStr,@"description",fullAddressStr,@"addressInFull", nil];
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_CUSTOMER_FETCH_SAVED_ADDRESS methodType:POST withArgument:@[model.userHash] paramas:[HelperClass getJsonPostData:postDict] withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
//            CustomerRegistrationModel *model = responseObject;
//            if ([model.status isEqual:@"SUCCESS"]) {
                dispatch_async(dispatch_get_main_queue(), ^{
//                    [self performSegueWithIdentifier:@"OtpViewController" sender:model];
                });
//            }
        }
//        [hud hideAnimated:YES];

    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
