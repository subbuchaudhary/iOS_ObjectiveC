//
//  SignUpViewController.m
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "SignUpViewController.h"
#import "TextFiledCell.h"
#import "UITextField+ContinerImageView.h"
#import "HelperClass.h"
#import "RestService.h"
#import "CustomerRegistrationModel.h"
#import "OtpViewController.h"

@interface SignUpViewController ()<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate>

@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *cellImgNamesArr;
@property (nonatomic, strong) NSArray *cellTxtFiledPlacholdersArr;

@property (nonatomic, strong) NSString *userNameSrt;
@property (nonatomic, strong) NSString *emailSrt;
@property (nonatomic, strong) NSString *passwordSrt;
@property (nonatomic, strong) NSString *phoneNumberSrt;

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.cellImgNamesArr = [NSArray arrayWithObjects:@"name",@"email",@"password",@"password",@"smartphone", nil];
    self.cellTxtFiledPlacholdersArr = [NSArray arrayWithObjects:@"Enter your name",@"Enter your email id",@"Password",@"Confirm password",@"Mobile number", nil];

    // Do any additional setup after loading the view.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.cellImgNamesArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TextFiledCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.txtFiled.placeholder = self.cellTxtFiledPlacholdersArr[indexPath.row];
    cell.txtFiled.tag = indexPath.row+1;
    cell.txtFiled.delegate = self;
    [cell.txtFiled setLeftImageView:self.cellImgNamesArr[indexPath.row]];
    
    return cell;
}

#pragma mark - UITextFiled Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    
    //    UITableViewCell *cell;
//    cell = (UITableViewCell *) textField.superview.superview;
//    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.tag == 1) {
        self.userNameSrt = textField.text;
    }else if (textField.tag == 2){
         self.emailSrt = textField.text;
    }else if (textField.tag == 3){
         self.passwordSrt = textField.text;
    }else if (textField.tag == 5){
         self.phoneNumberSrt = textField.text;
        [self.view endEditing:YES];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    CGPoint pointInTable = [textField.superview convertPoint:textField.frame.origin toView:self.tableView];
    CGPoint contentOffset = self.tableView.contentOffset;
    
    contentOffset.y = (pointInTable.y - textField.inputAccessoryView.frame.size.height);
    if (contentOffset.y != 0) {
        contentOffset.y -= 50;
    }
    
    NSLog(@"contentOffset is: %@", NSStringFromCGPoint(contentOffset));
    [self.tableView setContentOffset:contentOffset animated:YES];
    return YES;
}

//-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
//{
////    [textField resignFirstResponder];
//////    if ([textField.superview.superview isKindOfClass:[UITableViewCell class]])
//////    {
////        CGPoint buttonPosition = [textField convertPoint:CGPointZero
////                                                  toView: self.tableView];
////        NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
////        
////        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:TRUE];
//////    }
//    
//    return YES;
//}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:TRUE];
    [self.view endEditing:YES];

    return YES;
}
#pragma mark - Button Actions 

- (IBAction)tapOnRegisterButton:(id)sender {
//    "header:
//    Content-Type : application/json
//    {
//        ""username"": ""<required>"",
//        ""password"": ""<required>"",
//        ""deviceId"": ""<required>"",
//        ""phoneNumber"": ""<required>"",
//        ""customerName"":""required"",
//        ""emailId"":""<optional>""
//    }"
    
    NSDictionary *postDict = [NSDictionary dictionaryWithObjectsAndKeys:self.userNameSrt,@"userName",self.passwordSrt,@"password",[HelperClass getUDID],@"deviceId",self.phoneNumberSrt,@"phoneNumber",self.userNameSrt,@"customerName",self.emailSrt,@"emailId", nil];
    
//    NSDictionary *postDict = [NSDictionary dictionaryWithObjectsAndKeys:@"abc@yoku.com",@"emailId",@"==dfgdfg",@"password",@"MiDevice",@"deviceId",@"3477755557",@"phoneNumber",@"ram",@"customerName",@"sri",@"userName", nil];
    
    [RestService sendAPICommand:CL_CUSTOMER_REGISATER methodType:POST withArgument:nil paramas:[HelperClass getJsonPostData:postDict] withHeaders:nil isAuthRequired:nil withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            CustomerRegistrationModel *model = responseObject;
            if ([model.status isEqual:@"SUCCESS"]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self performSegueWithIdentifier:@"OtpViewController" sender:model];
                });
            }
        }
    }];
}

#pragma mark - UIStoryBoard Delegate 

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"OtpViewController"]) {
        OtpViewController *vc = segue.destinationViewController;
        vc.registartionModel = sender;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
