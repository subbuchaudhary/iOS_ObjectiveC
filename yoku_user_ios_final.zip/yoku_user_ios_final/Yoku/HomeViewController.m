//
//  HomeViewController.m
//  Yoku
//
//  Created by Ramesh on 11/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "HomeViewController.h"
#import "SWRevealViewController.h"
#import "PageItemController.h"
#import "FilterCollectionViewCell.h"
#import "UITextField+ContinerImageView.h"
#import "RestService.h"
#import "EnumList.h"
#import "UserAuthModel.h"
#import "MerchantList.h"
#import "HelperClass.h"
#import "CustomerProfileModel.h"

@interface HomeViewController ()<UIPageViewControllerDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UITabBarDelegate,CLLocationManagerDelegate>

{
    CLLocationManager *locationManager;
    CLGeocoder *geocoder;
    int locationFetchCounter;

}

@property (nonatomic, strong) NSArray *contentImages;
@property (nonatomic, strong) NSArray *filterItemsArr;
@property (nonatomic, strong) UIPageViewController *pageViewController;
@property (weak, nonatomic) IBOutlet UIView *pageContentView;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;
@property (weak, nonatomic) IBOutlet UITextField *searchTxtFiled;
@property (weak, nonatomic) IBOutlet UILabel *streetNameLbl;;
@property (weak, nonatomic) IBOutlet UILabel *cityNAmeLbl;

@property (nonatomic, strong) CustomerProfileModel *profileModel;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClickOnLeftMenuItem:) name:@"LeftMenuItemClicked" object:nil];
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    [self createPageViewController];
    [self setupPageControl];
    [self setUpSearhFiled];
    
    [self.searchTxtFiled setRightImageView:@"search"];
    [self.searchTxtFiled setLeftImageView:@""];

    self.filterItemsArr = [NSArray arrayWithObjects:@{@"name":@"Restaurants",@"image":@"Restaurants"},@{@"name":@"Fashion",@"image":@"shirt"},@{@"name":@"Pubs",@"image":@"cocktail"},@{@"name":@"Medicines",@"image":@"emergency-kit"},@{@"name":@"Movies",@"image":@"film"}, @{@"name":@"Fun",@"image":@"balloons-couple"},@{@"name":@"Vegitables",@"image":@"carrot"},@{@"name":@"Electronics",@"image":@"plug"},@{@"name":@"Fitness",@"image":@"fitness"},@{@"name":@"Kitchen",@"image":@"pot"},nil];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    geocoder = [[CLGeocoder alloc] init];
    [locationManager startUpdatingLocation];
    [locationManager requestWhenInUseAuthorization]; // Add This Line
    
    [self FetchingdealsfromnearbymerchantsusinglocationforaCustomer];
//    [self FetchingdealsfromnearbymerchantsusingaddressforaCustomer];
//    [self FetchingdealsfromnearbymerchantsusingplaceIdforaCustomer];
    [self fetchCustomerProfile];
}

#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.filterItemsArr.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FilterCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    NSDictionary *dict = self.filterItemsArr[indexPath.row];
    cell.titleLbl.text = dict[@"name"];
    cell.imgView.image = [UIImage imageNamed:dict[@"image"]];
    
    return cell;
}

#pragma mark - Service Calls

- (void)getfetchCustomerFullDetails {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_FETCH_CUSTOMER_ALL_DETAILS methodType:GET withArgument:@[model.userHash] paramas:nil withHeaders:nil isAuthRequired:NO withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

- (void)getCustomerFetchNearbyMerchantsBasedOnLatAndLong {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    NSString *lat = @"42.36686";
    NSString *longt = @"-71.09";
    [RestService sendAPICommand:CL_CUSTOMER_FETCH_NEARBY_MERCHANTS_LAT_LONG methodType:GET withArgument:@[model.userHash,lat,longt] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            MerchantList *merchantList = responseObject;
        }
    }];
}

- (void)getCustomerFetchNearbyMerchantsBasedAddress {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    NSString *addressStr = @"39 Higgins Street, Boston, MA, 02134, US";
    [RestService sendAPICommand:CL_CUSTOMER_FETCH_NEARBY_MERCHANTS_ADDRESS methodType:GET withArgument:@[model.userHash,addressStr] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            MerchantList *merchantList = responseObject;
        }
    }];
}

- (void)getDealClaimNotMoreThanThree {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    NSString *dealId = @"DL2016111507503246";
    [RestService sendAPICommand:CL_CUSTOMER_CAN_CLAIM_DEALS_NOT_MORETHAN_THREE methodType:POST withArgument:@[model.userHash,dealId] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

-(void)customerClimeDeals {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    NSString *dealId = @"DL2016111507503246";
    [RestService sendAPICommand:CL_CUSTOMER_CLAIMING_DEAL methodType:POST withArgument:@[model.userHash,dealId] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

- (void)fetchingAllDealsOfParticularMerchant {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_FETCHING_ALL_DEALS_OF_PARTICULAR_MERCHANT methodType:POST withArgument:@[model.userHash] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

- (void)FetchingdealsfromnearbymerchantsusinglocationforaCustomer
{
    UserAuthModel *model = [UserAuthModel sharedInstance];
    NSString *lat = @"19.0151";
    NSString *longt = @"72.8581";
    [RestService sendAPICommand:CL_FETCHING_DEALS_FROM_NEARBY_MERCHANT_CUSTOMER_LOCATION methodType:GET withArgument:@[model.userHash,lat,longt,@""] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}
- (void)FetchingdealsfromnearbymerchantsusingaddressforaCustomer
 {
    UserAuthModel *model = [UserAuthModel sharedInstance];
     NSString *addressStr = @"Prem Court Building, J. Tata Road, Churchgate, Mumbai, Maharashtra 400020";

    [RestService sendAPICommand:CL_FETCHING_DEALS_FROM_NEARBY_MERCHANT_CUSTOMER_ADDRESS methodType:GET withArgument:@[model.userHash,addressStr] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

- (void)FetchingdealsfromnearbymerchantsusingplaceIdforaCustomer
 {
    UserAuthModel *model = [UserAuthModel sharedInstance];
     NSString *placeId = @"xxxyyyyzzz";
    [RestService sendAPICommand:CL_FETCHING_DEALS_FROM_NEARBY_MERCHANT_CUSTOMER_PLACEID methodType:GET withArgument:@[model.userHash,placeId] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

- (void)saveAddressOfCustomer {
     NSString *country = @"India";
     NSString *state = @"Maharashtra";
     NSString *city = @"Mumbai";
     NSString *line1 = @"Band stand";
     NSString *zipcode = @"400031";
     NSString *landmark = @"Mono High School";
     NSString *title = @"Home Address";
     NSString *description = @"Vriddhiman soc";
     NSString *addressInFull = @"Wadala, Mumbai- 400031";
    
    NSDictionary *postDict = [NSDictionary dictionaryWithObjectsAndKeys:country,@"country",state ,@"state",city,@"city",line1,@"line1",zipcode ,@"zipcode",landmark,@"landmark",title ,@"title",description,@"description",addressInFull,@"addressInFull", nil];

    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_CUSTOMER_ADDRESS_SAVE methodType:POST withArgument:@[model.userHash] paramas:[HelperClass getJsonPostData:postDict] withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

- (void)fetchCustomerProfile {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_FETCH_CUSTOMER_PROFILE methodType:GET withArgument:@[model.userHash] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            model.userProfileModel = responseObject;
        }
    }];
}

- (void)customerFetchSavedAddress {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_CUSTOMER_FETCH_SAVED_ADDRESS methodType:GET withArgument:@[model.userHash] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
        }
    }];
}

#pragma mark - Customazation methods

//- (void)setSearchTxtFiledCustomization {
//    [self.searchTxtFiled.layer setBackgroundColor: [[UIColor whiteColor] CGColor]];
//    [self.searchTxtFiled.layer setBorderColor: [[UIColor grayColor] CGColor]];
//    [self.searchTxtFiled.layer setBorderWidth: 0.0];
//    [self.searchTxtFiled.layer setCornerRadius:12.0f];
//    [self.searchTxtFiled.layer setMasksToBounds:NO];
//    [self.searchTxtFiled.layer setShadowRadius:2.0f];
//    self.searchTxtFiled.layer.shadowColor = [[UIColor blackColor] CGColor];
//    self.searchTxtFiled.layer.shadowOffset = CGSizeMake(1.0f, 1.0f);
//    self.searchTxtFiled.layer.shadowOpacity = 1.0f;
//    self.searchTxtFiled.layer.shadowRadius = 1.0f;
//}

#pragma mark - Actions

- (IBAction)tapOnAddressChangeIcon:(id)sender {
    
}

#pragma mark - NSNotificationCenter

- (void)didClickOnLeftMenuItem:(NSNotification *)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TapOnMenuButton" object:nil];
    NSIndexPath *indexPath = [sender.object objectForKey:@"indexpath"];
    if (indexPath.row == 0) {
        [self performSegueWithIdentifier:@"Profile" sender:nil];
    }else  if (indexPath.row == 1) {
        
    }else if (indexPath.row == 2) {
        
    }else if (indexPath.row == 3) {
        [self performSegueWithIdentifier:@"help" sender:nil];
    }else if (indexPath.row == 4) {
    }else if (indexPath.row == 5) {
        UserAuthModel *model = [UserAuthModel sharedInstance];
        [RestService sendAPICommand:CL_CUSTOMER_LOGOFF methodType:DELETE withArgument:@[model.userHash] paramas:nil withHeaders:nil isAuthRequired:NO withHandler:^(id responseObject, NSError *error) {
            if (!error) {
                [self dismissViewControllerAnimated:NO completion:nil];
            }
        }];
    }
}

#pragma mark - Pagination

- (void)createPageViewController
{
    _contentImages = @[@"nature_pic_1",
                       @"nature_pic_2",
                       @"nature_pic_3",
                       @"nature_pic_4"];
    
    UIPageViewController *pageController = [self.storyboard instantiateViewControllerWithIdentifier:@"PageController"];
    
    pageController.dataSource = self;
    
    if([_contentImages count])
    {
        NSArray *startingViewControllers = @[[self itemControllerForIndex:0]];
        [pageController setViewControllers:startingViewControllers
                                 direction:UIPageViewControllerNavigationDirectionForward
                                  animated:YES
                                completion:nil];
    }
    
    self.pageViewController = pageController;
   // [self addChildViewController:self.pageViewController];
    [_pageContentView layoutIfNeeded];
    
    NSArray *subviews = self.pageViewController.view.subviews;
    UIPageControl *thisControl = nil;
    for (int i=0; i<[subviews count]; i++) {
        if ([[subviews objectAtIndex:i] isKindOfClass:[UIPageControl class]]) {
            thisControl = (UIPageControl *)[subviews objectAtIndex:i];
        }
    }
    
    thisControl.hidden = true;
    self.pageViewController.view.frame = CGRectMake(0, 0, _pageContentView.frame.size.width, _pageContentView.frame.size.height+40);
    [_pageContentView addSubview:self.pageViewController.view];
    _pageContentView.backgroundColor = [UIColor greenColor];
    self.pageControl.numberOfPages = _contentImages.count;

}

- (void)setUpSearhFiled {
//    _searchTxtFiled.layer.shadowOpacity = 1.0;
//    _searchTxtFiled.layer.shadowRadius = 1.0;
//    _searchTxtFiled.layer.shadowColor = [UIColor blackColor].CGColor;
//    _searchTxtFiled.layer.shadowOffset = CGSizeMake(0.0, -1.0);
    _searchTxtFiled.layer.masksToBounds = false;
    _searchTxtFiled.layer.shadowRadius = 3.0;
    _searchTxtFiled.layer.shadowColor = [UIColor blackColor].CGColor;
    _searchTxtFiled.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    _searchTxtFiled.layer.shadowOpacity = 1.0;
}

- (void)setupPageControl
{
    UIPageControl *pageControl = [UIPageControl appearance];
    pageControl.hidden = YES;
    [pageControl setPageIndicatorTintColor:[UIColor grayColor]];
    [pageControl setCurrentPageIndicatorTintColor:[UIColor whiteColor]];
    [pageControl setBackgroundColor:[UIColor redColor]];
}

#pragma mark - UIPageViewControllerDataSource

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    PageItemController *itemController = (PageItemController *)viewController;
    
    if (itemController.itemIndex > 0)
    {
        return [self itemControllerForIndex:itemController.itemIndex-1];
    }
    
    return nil;
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    PageItemController *itemController = (PageItemController *)viewController;
    
    if (itemController.itemIndex+1 < [_contentImages count])
    {
        return [self itemControllerForIndex:itemController.itemIndex+1];
    }
    
    return nil;
}

- (PageItemController *)itemControllerForIndex:(NSUInteger)itemIndex
{
    
    if (itemIndex < [_contentImages count])
    {
        PageItemController *pageItemController = [self.storyboard instantiateViewControllerWithIdentifier:@"ItemController"];
        pageItemController.itemIndex = itemIndex;
        pageItemController.imageName = _contentImages[itemIndex];

        return pageItemController;
    }
    
    return nil;
}

#pragma mark - CLLocationManager Delegate

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    // this delegate method is constantly invoked every some miliseconds.
    // we only need to receive the first response, so we skip the others.
//    if (locationFetchCounter > 0) return;
//    locationFetchCounter++;
    
    // after we have current coordinates, we use this method to fetch the information data of fetched coordinate
    UserAuthModel *model =  [UserAuthModel sharedInstance];
    model.userLocation = [locations lastObject];
    [geocoder reverseGeocodeLocation:[locations lastObject] completionHandler:^(NSArray *placemarks, NSError *error) {
        CLPlacemark *placemark = [placemarks lastObject];
        
        NSString *street = placemark.thoroughfare;
        NSString *city = placemark.locality;
        NSString *posCode = placemark.postalCode;
        NSString *country = placemark.country;
        model.userAddress = [NSString stringWithFormat:@"%@,%@,%@,%@",street,city,posCode,country];
        
        self.streetNameLbl.text = street;
        self.cityNAmeLbl.text = city;
        
        NSLog(@"we live in %@,%@,%@,%@",street,city,posCode,country);
        
        // stopping locationManager from fetching again
        [locationManager stopUpdatingLocation];
    }];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSLog(@"failed to fetch current location : %@", error);
}

#pragma mark - Page Indicator


- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController
{
    return [_contentImages count];
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController
{
    return 0;
}

#pragma mark - UITabbar Delegate

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
    switch (item.tag) {
        case 1:
            [self performSegueWithIdentifier:@"NearByDeals" sender:nil];
        break;
        case 2:
            [self performSegueWithIdentifier:@"ChatList" sender:nil];
        break;
        case 3:
            [self performSegueWithIdentifier:@"wallet" sender:nil];
        break;
        case 4:
            [self performSegueWithIdentifier:@"mydeals" sender:nil];
        break;
        case 5:
        [self performSegueWithIdentifier:@"Profile" sender:nil];
        default:
        break;
    }
}

#pragma mark - Additions

- (NSUInteger)currentControllerIndex
{
    PageItemController *pageItemController = (PageItemController *) [self currentController];
    
    if (pageItemController)
    {
        return pageItemController.itemIndex;
    }
    
    return -1;
}

- (UIViewController *)currentController
{
    if ([self.pageViewController.viewControllers count])
    {
        return self.pageViewController.viewControllers[0];
    }
    
    return nil;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
