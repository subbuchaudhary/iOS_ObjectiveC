//
//  CustomerLoginModel.h
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"

@interface CustomerLoginModel : TransactionModel

@property (nonatomic, strong) NSString *authenticationToken;
@property (nonatomic, strong) NSString *userHash;
@property (nonatomic, strong) NSString *customerId;

- (id)initWithData:(NSDictionary *)data;


@end
