//
//  APIResponseParser.h
//  Yoku
//
//  Created by Ramesh on 10/27/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface APIResponseParser : NSObject



@end
