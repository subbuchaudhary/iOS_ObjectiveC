//
//  UpdateCustomerDetailsModel.m
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "UpdateCustomerDetailsModel.h"

@implementation UpdateCustomerDetailsModel

- (id)initWithData:(NSDictionary *)data {
    
    return self;
}


@end
