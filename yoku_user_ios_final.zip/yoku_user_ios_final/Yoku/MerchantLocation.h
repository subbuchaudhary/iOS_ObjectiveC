//
//  MerchantLocation.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TransactionModel.h"

@interface MerchantLocation : TransactionModel

@property (nonatomic, strong) NSString *latitude;
@property (nonatomic, strong) NSString *longitude;
@property (nonatomic, strong) NSString *placeId;

- (id)initWithData:(NSDictionary *)data;

@end
