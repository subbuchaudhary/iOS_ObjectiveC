//
//  BestDealsViewController.m
//  Yoku
//
//  Created by Ramesh on 11/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "BestDealsViewController.h"
#import "DealsTableViewCell.h"

@interface BestDealsViewController ()

@property (nonatomic, strong) NSArray *bestDelasArr;
@property (nonatomic, weak) IBOutlet UIView *filterContainerView;


@end

@implementation BestDealsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.bestDelasArr = [NSArray arrayWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Actions

- (IBAction)clickOnFilterButton:(id)sender {
    self.filterContainerView.hidden = NO;
}

#pragma mark - UITableView Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.bestDelasArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DealsTableViewCell *dealsCell=[tableView dequeueReusableCellWithIdentifier:@"dealsCell"];
    //    chatListCell.profileImage.layer.cornerRadius=chatListCell.profileImage.frame.size.width/2;
    //    chatListCell.profileImage.clipsToBounds=YES;
    return dealsCell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
