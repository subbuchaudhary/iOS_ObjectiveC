//
//  HelpViewController.m
//  Yoku
//
//  Created by Ramesh on 11/29/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "HelpViewController.h"

@interface HelpViewController()<UITableViewDataSource>


@end

@implementation HelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma maek - UITableView Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (indexPath.row == 0) {
        UILabel *titleLbl = [cell.contentView viewWithTag:2];
        titleLbl.text = @"Call us on this number";
        UILabel *subTitleLbl = [cell.contentView viewWithTag:3];
        subTitleLbl.text = @"357-154-8929";
    }else if (indexPath.row == 1) {
        UILabel *titleLbl = [cell.contentView viewWithTag:2];
        titleLbl.text = @"Mail us on this address";
        UILabel *subTitleLbl = [cell.contentView viewWithTag:3];
        subTitleLbl.text = @"help@yoku.com";
    }
    
    return cell;
}

@end
