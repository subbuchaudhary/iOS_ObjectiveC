//
//  NearByViewController.m
//  Yoku
//
//  Created by Ramesh on 11/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "NearByViewController.h"
#import <MapKit/MapKit.h>
#import "UserAuthModel.h"

@interface NearByViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic, strong) NSArray *nearByArr;

@property (nonatomic, weak) IBOutlet UIView *filterContainerView;

@end

@implementation NearByViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.nearByArr = [NSArray arrayWithObjects:@"",@"",@"",@"",@"",@"", nil];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - Actions

- (IBAction)clickOnFilterButton:(id)sender {
    self.filterContainerView.hidden = NO;
}

#pragma mark - UICollectionView DataSource 


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.nearByArr.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
//    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
//    recipeImageView.image = [UIImage imageNamed:[recipeImages objectAtIndex:indexPath.row]];
    
    return cell;
}

#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
