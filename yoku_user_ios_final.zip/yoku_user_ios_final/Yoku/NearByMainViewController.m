//
//  NearByMainViewController.m
//  Yoku
//
//  Created by Ramesh on 11/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "NearByMainViewController.h"
#import "UserAuthModel.h"
#import "RestService.h"


typedef enum : NSUInteger {
    eMapType,
    eListType
} NearByMapType;

typedef enum : NSUInteger {
    eNearByMapViewType,
    eBestDealsViewType,
    eNearByDealsListViewType
} ViewType;





@interface NearByMainViewController ()

@property (nonatomic, weak) IBOutlet UIBarButtonItem *nearByOffersListBarBtn;
@property (nonatomic, weak) IBOutlet UIView *nearByContinerView;
@property (nonatomic, weak) IBOutlet UIView *nearByListContinerView;
@property (nonatomic, weak) IBOutlet UIView *bestDealsContinerView;
@property (nonatomic, assign) ViewType viewType;
@property (nonatomic, assign) NearByMapType mapViewType;
@property (nonatomic, weak) IBOutlet UISegmentedControl *segmentControl;

@end

@implementation NearByMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.viewType = eNearByMapViewType;
    // Do any additional setup after loading the view.
    [self updateContainerView];
//    [self getNearByMerchantList];
    [self getNearByDelasList];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private Methods 

- (void)updateContainerView;
{
    if (self.viewType == eNearByMapViewType) {
        self.nearByOffersListBarBtn.image = [UIImage imageNamed:@"ic_format_list_bulleted"];
        self.bestDealsContinerView.hidden = YES;
        self.nearByContinerView.hidden = NO;
        self.nearByListContinerView.hidden = YES;

    }else if (self.viewType == eBestDealsViewType) {
        self.nearByOffersListBarBtn.image = [UIImage imageNamed:@"ic_format_list_bulleted"];
        self.bestDealsContinerView.hidden = NO;
        self.nearByContinerView.hidden = YES;
        self.nearByListContinerView.hidden = YES;
        
    }else if (self.viewType == eNearByDealsListViewType) {
        self.nearByOffersListBarBtn.image = [UIImage imageNamed:@"ic_map"];
        self.bestDealsContinerView.hidden = YES;
        self.nearByContinerView.hidden = YES;
        self.nearByListContinerView.hidden = NO;
        
    }
}


#pragma mark - Service Calls

- (void)getNearByMerchantList {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_GET_NEARBY_MERCHANTS methodType:GET  withArgument:@[model.userHash,@"42.36686",@"-71.09"] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            
        }
    }];
}

- (void)getNearByDelasList {
    UserAuthModel *model = [UserAuthModel sharedInstance];
    [RestService sendAPICommand:CL_GET_NEARBY_DEALS methodType:GET withArgument:@[model.userHash,@"42.36686",@"-71.09"] paramas:nil withHeaders:nil isAuthRequired:YES withHandler:^(id responseObject, NSError *error) {
        if (!error) {
            
        }
    }];
}

#pragma mark - Actions

- (IBAction)tapOnSegment:(UISegmentedControl *)sender {
    if (sender.selectedSegmentIndex == 0) {
        self.viewType = eNearByMapViewType;
    }else{
        self.viewType = eBestDealsViewType;
    }
   
    [self updateContainerView];
}

- (IBAction)touchOnNearByListBarButtonItem:(id)sender {
    if (self.mapViewType == eMapType) {
        self.mapViewType = eListType;
    }else{
        self.mapViewType = eMapType;
    }
    
    if (self.viewType == eNearByMapViewType) {
        self.viewType = eNearByDealsListViewType;
    }else{
        self.viewType = eNearByMapViewType;
    }
    self.segmentControl.selectedSegmentIndex = 0;
    [self updateContainerView];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
