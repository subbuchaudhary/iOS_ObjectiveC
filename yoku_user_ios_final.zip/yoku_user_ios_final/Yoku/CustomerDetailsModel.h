//
//  CustomerDetailsModel.h
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"
#import "LocationModel.h"

@interface CustomerDetailsModel : TransactionModel

@property (nonatomic, strong) NSString *phoneNumber;
@property (nonatomic, strong) NSString *customerName;
@property (nonatomic, strong) LocationModel *location;

- (id)initWithData:(NSDictionary *)data;

@end
