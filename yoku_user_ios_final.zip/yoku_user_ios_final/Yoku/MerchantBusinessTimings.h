//
//  MerchantBusinessTimings.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MerchantBusinessTimings : NSObject

@property (nonatomic, strong) NSString *closesAt;
@property (nonatomic, strong) NSString *opensAt;

- (id)initWithData:(NSDictionary *)data;

@end
