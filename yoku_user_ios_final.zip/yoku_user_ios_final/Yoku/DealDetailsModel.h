//
//  DealDetailsModel.h
//  Yoku
//
//  Created by Ramesh on 12/3/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DealDetailsModel : NSObject
@property (nonatomic, strong) NSString *transaction;
@property (nonatomic, strong) NSString *dealId;
@property (nonatomic, strong) NSString *merchantId;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *initiatedAt;
@property (nonatomic, strong) NSString *beginsAt;
@property (nonatomic, strong) NSString *endsAt;
@property (nonatomic, strong) NSNumber *totalClaims;
@property (nonatomic, strong) NSString *dealDescription;
@property (nonatomic, strong) NSString *instructions;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSNumber *claimExpiryDuration;
@property (nonatomic, strong) NSNumber *claimPerCustomer;
@property (nonatomic, strong) NSNumber *redeemed;
@property (nonatomic, strong) NSNumber *activeClaims;
@property (nonatomic, strong) NSString *dealType;
@property (nonatomic, strong) NSNumber *percentOff;
@property (nonatomic, strong) NSString *image;

- (id)initWithData:(NSDictionary *)data;

@end
