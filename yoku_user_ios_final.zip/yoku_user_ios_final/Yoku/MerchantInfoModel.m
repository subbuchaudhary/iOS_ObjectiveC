//
//  MerchantInfoModel.m
//  Yoku
//
//  Created by Ramesh on 11/22/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantInfoModel.h"

@implementation MerchantInfoModel

- (id)initWithData:(NSDictionary *)data {
    
    self.merchantDetails = [[MerchantDetails alloc]initWithData:data[@"merchant"]];
    self.merchantId = data[@"merchantId"];
    
    return self;
}

@end
