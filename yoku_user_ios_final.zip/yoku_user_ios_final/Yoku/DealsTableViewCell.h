//
//  DealsTableViewCell.h
//  Yoku
//
//  Created by Ramesh on 11/11/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DealsTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UIImageView *dealImgView;
@property (nonatomic, weak) IBOutlet UILabel *dealLbl;

@end
