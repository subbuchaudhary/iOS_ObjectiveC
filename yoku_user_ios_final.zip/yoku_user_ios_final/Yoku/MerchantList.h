//
//  MerchantList.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"

@interface MerchantList : TransactionModel

@property (nonatomic, strong) NSArray *merchantList; //MerchantDetails

- (id)initWithData:(NSDictionary *)data;


@end
