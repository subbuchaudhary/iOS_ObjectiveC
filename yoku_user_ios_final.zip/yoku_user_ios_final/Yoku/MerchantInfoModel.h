//
//  MerchantInfoModel.h
//  Yoku
//
//  Created by Ramesh on 11/22/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MerchantDetails.h"

@interface MerchantInfoModel : NSObject

@property (nonatomic, strong) MerchantDetails *merchantDetails;
@property (nonatomic, strong) NSString *merchantId;

- (id)initWithData:(NSDictionary *)data;

@end
