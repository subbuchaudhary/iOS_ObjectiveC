//
//  MerchantLocation.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantLocation.h"

@implementation MerchantLocation

- (id)initWithData:(NSDictionary *)data {
    self.latitude = data[@"latitude"];
    self.longitude = data[@"longitude"];
    self.placeId = data[@"placeId"];

    return self;
}

@end
