//
//  TransactionModel.h
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TransactionModel : NSObject

@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) NSArray *errors;
@property (nonatomic, strong) NSArray *warnings;

- (id)initWithData:(NSDictionary *)data;

@end
