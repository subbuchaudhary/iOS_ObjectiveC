//
//  NSDictionary+URL.m
//  Yoku
//
//  Created by Ramesh on 10/27/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "NSDictionary+URL.h"
#import "EnumList.h"

@implementation NSDictionary (URL)

+(NSString*)getURLString:(enum APICommandList)commandID withArguments:(NSArray*) arguments {
    
    NSString* commandString = [[NSDictionary apiDictionary] objectForKey:[NSNumber numberWithInt: commandID]];
    
    for (int index = 0; index < arguments.count; index++)
    {
        commandString = [commandString stringByReplacingOccurrencesOfString: [NSString stringWithFormat:@"@%dARG", index] withString: [arguments objectAtIndex:index] ];
    }
    
    return commandString;
}

+(NSDictionary *)apiDictionary {
    static NSDictionary* apiDict = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        apiDict = [[NSDictionary alloc] initWithObjectsAndKeys:
                  @"/customer/register" ,[NSNumber numberWithInt:CL_CUSTOMER_REGISATER],
                  @"/customer/\"@0ARG\"/activate" ,[NSNumber numberWithInt:CL_CUSTOMER_ACTIVATE ],
                  @"/customer/auth-n/login" ,[NSNumber numberWithInt:CL_CUSTOMER_LOGIN ],
                  @"/customer/auth-n/logout?customerId=\"@0ARG\"" ,[NSNumber numberWithInt:CL_CUSTOMER_LOGOFF],
                  @"/customer/\"@0ARG\"" ,[NSNumber numberWithInt:CL_FETCH_CUSTOMER_ALL_DETAILS ]  ,
                  @"/customer/\"@0ARG\"" ,[NSNumber numberWithInt:CL_UPDATE_CUSTOMER_DETAILS ]  ,
                  @"/customer/\"@0ARG\"/location" ,[NSNumber numberWithInt:CL_GET_CUSTOMER_LOCATION ] ,
                   @"/customer/\"@0ARG\"/location" ,[NSNumber numberWithInt:CL_UPDATE_CUSTOMER_LOCATION],
                   @"/customer/\"@0ARG\"/merchants?lat=\"@1ARG\"&long=\"@2ARG\"" ,[NSNumber numberWithInt:CL_GET_NEARBY_MERCHANTS],
                   @"/customer/\"@0ARG\"/deals?lat=\"@1ARG\"/&long=\"@2ARG\"/" ,[NSNumber numberWithInt:CL_GET_NEARBY_DEALS],
                   @"/customer/\"@0ARG\"/address" ,[NSNumber numberWithInt:CL_SAVE_CUSTOMER_ADDRESS],
                   @"/customer/\"@0ARG\"/address/\"@1ARG\"" ,[NSNumber numberWithInt:CL_UPDATE_CUSTOMER_ADDRESS],
                   @"/customer/\"@0ARG\"/merchants?lat=\"@1ARG\"&long=\"@2ARG\"" ,[NSNumber numberWithInt:CL_CUSTOMER_FETCH_NEARBY_MERCHANTS_LAT_LONG],
                   @"/customer/\"@0ARG\"/merchants?address=\"@1ARG\"" ,[NSNumber numberWithInt:CL_CUSTOMER_FETCH_NEARBY_MERCHANTS_ADDRESS],
                   @"/customer/\"@0ARG\"/deals/\"@1ARG\"" ,[NSNumber numberWithInt:CL_CUSTOMER_CAN_CLAIM_DEALS_NOT_MORETHAN_THREE],
                   @"/customer/\"@0ARG\"/deals?lat=\"@1ARG\"&long=\"@2ARG\"&businessType=\"@3ARG\"" ,[NSNumber numberWithInt:CL_FETCHING_DEALS_FROM_NEARBY_MERCHANT_CUSTOMER_LOCATION],
                   @"/customer/\"@0ARG\"/merchants?address=\"@1ARG\"" ,[NSNumber numberWithInt:CL_FETCHING_DEALS_FROM_NEARBY_MERCHANT_CUSTOMER_ADDRESS],
                   @"/customer/\"@0ARG\"/merchants?placeId=\"@1ARG\"" ,[NSNumber numberWithInt:CL_FETCHING_DEALS_FROM_NEARBY_MERCHANT_CUSTOMER_PLACEID],
                   @"/customer/\"@0ARG\"/deals/\"@1ARG\"" ,[NSNumber numberWithInt:CL_CUSTOMER_CLAIMING_DEAL],
                   @"/customer/\"@0ARG\"/address" ,[NSNumber numberWithInt:CL_CUSTOMER_CLAIMING_DEAL],
                   @"/customer/\"@0ARG\"" ,[NSNumber numberWithInt:CL_FETCH_CUSTOMER_PROFILE],
                    @"/customer/\"@0ARG\"/address" ,[NSNumber numberWithInt:CL_CUSTOMER_FETCH_SAVED_ADDRESS],
                    @"/customer/\"@0ARG\"/activate/validateAndResend" ,[NSNumber numberWithInt:CL_RESEND_OTP_CUSTOMER],
                   nil];
                   });
                   return apiDict;
}
@end
