//
//  FilterOptionViewController.m
//  Yoku
//
//  Created by Ramesh on 11/11/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "FilterOptionViewController.h"
#import "FilterCollectionViewCell.h"

@interface FilterOptionViewController ()

@property (nonatomic, strong) NSArray *filterItemsArr;


@end

@implementation FilterOptionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.filterItemsArr = [NSArray arrayWithObjects:@{@"name":@"Restaurants",@"image":@"Restaurants"},@{@"name":@"Fashion",@"image":@"shirt"},@{@"name":@"Pubs",@"image":@"cocktail"},@{@"name":@"Medicines",@"image":@"emergency-kit"},@{@"name":@"Movies",@"image":@"film"}, @{@"name":@"Fun",@"image":@"balloons-couple"},@{@"name":@"Vegitables",@"image":@"carrot"},@{@"name":@"Electronics",@"image":@"plug"},@{@"name":@"Fitness",@"image":@"fitness"},@{@"name":@"Kitchen",@"image":@"pot"},nil];
    
}

#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.filterItemsArr.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FilterCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    NSDictionary *dict = self.filterItemsArr[indexPath.row];
    cell.titleLbl.text = dict[@"name"];
    cell.imgView.image = [UIImage imageNamed:dict[@"image"]];
    
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark - Actions

- (IBAction)tapOnResetButton:(id)sender {
    
}

- (IBAction)tapOnApplyButton:(id)sender {
    
}

- (IBAction)tapOnCloseButton:(id)sender {
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
