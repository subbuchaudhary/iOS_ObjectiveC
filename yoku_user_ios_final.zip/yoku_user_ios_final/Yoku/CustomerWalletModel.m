//
//  CustomerWalletModel.m
//  Yoku
//
//  Created by Ramesh on 12/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "CustomerWalletModel.h"

@implementation CustomerWalletModel

-(id)initWithData:(NSDictionary *)data {
    
    self.transaction = data[@"transaction"];
    self.walletAmount = data[@"amount"];
    
    return self;
}

@end
