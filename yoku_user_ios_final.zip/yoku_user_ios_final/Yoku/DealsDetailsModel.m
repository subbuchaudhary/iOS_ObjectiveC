//
//  DealsDetails.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "DealsDetailsModel.h"

@implementation DealsDetailsModel

- (id)initWithData:(NSDictionary *)data {
    self.status = data[@"status"];
    self.dealDescription = data[@"description"];
    self.endsAt = data[@"endsAt"];
    self.totalClaims = data[@"totalClaims"];
    self.dealId = data[@"dealId"];
    self.claimPerCustomer = data[@"claimsPerCustomer"];
    self.percentOff = data[@"percentageOff"];
    self.merchantId = data[@"merchantId"];
    self.instructions = data[@"instructions"];
//    self.additionalInfo = data[@"additionalInfo"];
    self.beginsAt = data[@"beginsAt"];
    self.dealType = data[@"dealType"];
    self.activeClaims = data[@"activeClaims"];
    self.claimExpiryDuration = data[@"claimExpiryDuration"];
    self.image = data[@"image"];
    self.initiatedAt = data[@"initiatedAt"];
    self.percentOff = data[@"percentOff"];
    self.redeemed = data[@"redeemed"];
    self.transaction = data[@"transaction"];
    
    return self;
}

@end
