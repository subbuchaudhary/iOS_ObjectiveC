//
//  MerchantAddressDetails.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MerchantLocation.h"

@interface MerchantAddressDetails : NSObject

@property (nonatomic, strong) NSString *addressInFull;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *country;
@property (nonatomic, strong) NSString *merchantDescription;
@property (nonatomic, strong) NSString *merchantId;
@property (nonatomic, strong) NSString *line1;
@property (nonatomic, strong) NSString *line2;
@property (nonatomic, strong) NSString *state;
@property (nonatomic, strong) NSString *landmark;
@property (nonatomic, strong) MerchantLocation *location;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *userType;
@property (nonatomic, strong) NSString *zipcode;


- (id)initWithData:(NSDictionary *)data;

@end
