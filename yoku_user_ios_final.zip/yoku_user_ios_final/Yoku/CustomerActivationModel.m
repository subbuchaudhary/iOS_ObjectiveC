//
//  CustomerActivationModel.m
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "CustomerActivationModel.h"

@implementation CustomerActivationModel

- (id)initWithData:(NSDictionary *)data {
    
    if (data) {
        NSDictionary *transDict = data[@"transaction"];
        self.status = transDict[@"status"];
        self.message = transDict[@"message"];
        self.errors = transDict[@"errors"];
        self.warnings = transDict[@"warnings"];
        
        self.dataDict = data[@"data"];
    }
    
    return self;
}


@end
