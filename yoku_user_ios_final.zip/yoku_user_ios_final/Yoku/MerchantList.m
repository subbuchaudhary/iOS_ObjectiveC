//
//  MerchantList.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantList.h"
#import "MerchantInfoModel.h"

@implementation MerchantList

- (id)initWithData:(NSDictionary *)data {
    NSDictionary *transDict = data[@"transaction"];
    self.status = transDict[@"status"];
    self.message = transDict[@"message"];
    self.errors = transDict[@"errors"];
    self.warnings = transDict[@"warnings"];
    
    NSArray *merchantList = data[@"merchants"];
    
    NSMutableArray *merchantMutArr = [NSMutableArray array];
    for (NSDictionary *merchantDict in merchantList) {
        MerchantInfoModel *merchants = [[MerchantInfoModel alloc]initWithData:merchantDict];
        [merchantMutArr addObject:merchants];
    }

    self.merchantList = merchantMutArr.copy;
    
    return self;
}

@end
