//
//  ViewController.m
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "ViewController.h"
#import "UITextField+ContinerImageView.h"
#import "RestService.h"
#import "EnumList.h"
#import "HelperClass.h"
#import "ValidateUtility.h"
#import "CustomerLoginModel.h"

@interface ViewController ()
{
    
    YokuCommonClass *yokuCommonClass;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    yokuCommonClass=[YokuCommonClass new];
    
    loginView.layer.cornerRadius=5.5f;
    btnLogin.layer.cornerRadius=5.0f;
    
    [self.txtfldEmail setLeftImageView:@"name-1"];
    [self.txtfldPassword setLeftImageView:@"password"];
}

- (void)viewWillAppear:(BOOL)animated {
    self.title = @"Login";
    self.txtfldEmail.text = @"";
    self.txtfldPassword.text = @"";
}

- (void)viewDidDisappear:(BOOL)animated {
    self.title = @"Back";
}

#pragma mark - Button actions

- (IBAction)tapOnLogin:(id)sender {
    
    NSString *errorMsg = @"";
    if ([ValidateUtility isEmptyString:self.txtfldEmail.text]) {
        errorMsg = @"Please enter Emailid";
    }else if ([ValidateUtility isEmptyString:self.txtfldPassword.text]){
        errorMsg = @"Please enter Password";
    }
//    else if ([ValidateUtility isEmailValid:self.txtfldEmail.text]){
//        errorMsg = @"Please enter valid Emailid";
//    }
    if (errorMsg.length) {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error" message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }];
        [controller addAction:okAction];
        [self presentViewController:controller animated:YES completion:nil];
    }else{
        NSDictionary *postDict = [NSDictionary dictionaryWithObjectsAndKeys:self.txtfldEmail.text,@"userName",self.txtfldPassword.text ,@"password",[HelperClass getUDID],@"deviceId", nil];
        
        //    NSDictionary *postDict = [NSDictionary dictionaryWithObjectsAndKeys:@"sanui",@"userName",@"welcome1" ,@"password",@"",@"deviceId", nil];
        NSLog(@"%@",postDict);
        [RestService sendAPICommand:CL_CUSTOMER_LOGIN methodType:POST withArgument:nil paramas:[HelperClass getJsonPostData:postDict] withHeaders:nil isAuthRequired:NO withHandler:^(id responseObject, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!error) {
                    CustomerLoginModel *model = responseObject;
                    if ([model.status isEqual:@"SUCCESS"]) {
                        [self performSegueWithIdentifier:@"HomeView" sender:nil];
                    }
                }
            });
        }];
    }
}

- (IBAction)tapOnFaceBook:(id)sender {
    
}

- (IBAction)tapOnGooglePlus:(id)sender {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
