//
//  HelperClass.h
//  Yoku
//
//  Created by Ramesh on 11/15/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HelperClass : NSObject

+ (NSData *)getJsonPostData:(id)obj;

+ (NSString *)getUDID;

@end
