//
//  NSString+NullCheck.h
//  Yoku
//
//  Created by Ramesh on 12/15/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NullCheck)

- (NSString *)checkNullValue;

@end
