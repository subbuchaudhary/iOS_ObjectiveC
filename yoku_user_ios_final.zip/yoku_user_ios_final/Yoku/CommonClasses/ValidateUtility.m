//
//  ValidateUtility.m
//  Yoku
//
//  Created by Ramesh on 11/5/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "ValidateUtility.h"

@implementation ValidateUtility

+ (BOOL)isEmptyString:(NSString *)string {
    return !(string && string.length);
}
+ (BOOL)isEmailValid:(NSString *)string {
    if([string length]==0){
        return NO;
    }
    
    NSString *regExPattern = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSRegularExpression *regEx = [[NSRegularExpression alloc] initWithPattern:regExPattern options:NSRegularExpressionCaseInsensitive error:nil];
    NSUInteger regExMatches = [regEx numberOfMatchesInString:string options:0 range:NSMakeRange(0, [string length])];
    
    if (regExMatches == 0) {
        return NO;
    } else {
        return YES;
    }
}

+ (BOOL)isPasswordValid:(NSString *)string {
    BOOL strongPwd = YES;
    
    //Checking length
    if([string length] < 8 && [string length] > 16)
        strongPwd = NO;
    
    //Checking uppercase characters
    NSCharacterSet *charSet = [NSCharacterSet uppercaseLetterCharacterSet];
    NSRange range = [string rangeOfCharacterFromSet:charSet];
    if(range.location == NSNotFound)
        strongPwd = NO;
    
    //Checking lowercase characters
    charSet = [NSCharacterSet lowercaseLetterCharacterSet];
    range = [string rangeOfCharacterFromSet:charSet];
    if(range.location == NSNotFound)
        strongPwd = NO;
    
    //Checking special characters
    charSet = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
    range = [string rangeOfCharacterFromSet:charSet];
    if(range.location == NSNotFound)
        strongPwd = NO;
    
    return strongPwd;
}

@end
