//
//  UITextField+ContinerImageView.h
//  Yoku
//
//  Created by Ramesh on 11/7/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (ContinerImageView)

- (void)setLeftImageView:(NSString *)imgName;
- (void)setRightImageView:(NSString *)imgName;

@end
