//
//  NSString+NullCheck.m
//  Yoku
//
//  Created by Ramesh on 12/15/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "NSString+NullCheck.h"

@implementation NSString (NullCheck)

- (NSString *)checkNullValue {
    if ([self isEqual:[NSNull null]])
        return @"";
    
    return self;
}

@end
