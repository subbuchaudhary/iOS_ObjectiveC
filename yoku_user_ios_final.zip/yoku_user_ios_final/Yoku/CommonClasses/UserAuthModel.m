//
//  UserAuthModel.m
//  Yoku
//
//  Created by Ramesh on 11/20/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "UserAuthModel.h"

@implementation UserAuthModel

+ (id)sharedInstance {
    static UserAuthModel *authModel;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        authModel = [[UserAuthModel alloc]init];
    });
    return authModel;
}

@end
