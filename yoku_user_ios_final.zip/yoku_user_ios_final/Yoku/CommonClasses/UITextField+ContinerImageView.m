//
//  UITextField+ContinerImageView.m
//  Yoku
//
//  Created by Ramesh on 11/7/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "UITextField+ContinerImageView.h"

@implementation UITextField (ContinerImageView)

- (void)setLeftImageView:(NSString *)imgName {
    UIImageView *imgSearch=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 32, 28)]; // Set frame as per space required around icon
    [imgSearch setImage:[UIImage imageNamed:imgName]];
    
    [imgSearch setContentMode:UIViewContentModeCenter];// Set content mode centre
    self.leftView=imgSearch;
    self.leftViewMode=UITextFieldViewModeAlways;
}

- (void)setRightImageView:(NSString *)imgName;
{
    UIImageView *imgSearch=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 32, 28)]; // Set frame as per space required around icon
    [imgSearch setImage:[UIImage imageNamed:imgName]];
    
    [imgSearch setContentMode:UIViewContentModeCenter];// Set content mode centre
    self.rightView=imgSearch;
    self.rightViewMode= UITextFieldViewModeAlways;
}

@end
