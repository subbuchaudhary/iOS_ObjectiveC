//
//  UserAuthModel.h
//  Yoku
//
//  Created by Ramesh on 11/20/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "CustomerProfileModel.h"

@interface UserAuthModel : NSObject

@property (nonatomic, strong) NSString *userHash;
@property (nonatomic, strong) NSString *authToken;

@property (nonatomic, strong) CLLocation  *userLocation;

@property (nonatomic, strong) NSString *userAddress;

@property (nonatomic, strong) CustomerProfileModel *userProfileModel;

+ (id)sharedInstance;

@end
