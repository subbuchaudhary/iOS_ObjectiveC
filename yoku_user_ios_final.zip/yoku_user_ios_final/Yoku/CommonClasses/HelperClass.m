//
//  HelperClass.m
//  Yoku
//
//  Created by Ramesh on 11/15/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "HelperClass.h"
#import <UIKit/UIKit.h>

@implementation HelperClass

+(NSData *)getJsonPostData:(id)obj {
    NSError *err;
    NSData *data = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:&err];
    return data;
}

+ (NSString *)getUDID {
    NSString* identifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString]; // IOS 6+
    return identifier;
}

@end
