//
//  CustomerDetailsModel.m
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "CustomerDetailsModel.h"

@implementation CustomerDetailsModel

- (id)initWithData:(NSDictionary *)data {
    NSDictionary *transDict = data[@"transaction"];
    self.status = transDict[@"status"];
    self.message = transDict[@"message"];
    self.errors = transDict[@"errors"];
    self.warnings = transDict[@"warnings"];
    
    NSDictionary *tempData = data[@"data"];
    self.phoneNumber = tempData[@"phoneNumber"];
    self.customerName = tempData[@"customerId"];
    
    NSDictionary *locationDict = tempData[@"overLoad"][@"location"];
    LocationModel *locationModel = [[LocationModel alloc]init];
    locationModel.latitude = locationDict[@"latitude"];
    locationModel.longitude = locationDict[@"longitude"];
    return self;
}


@end
