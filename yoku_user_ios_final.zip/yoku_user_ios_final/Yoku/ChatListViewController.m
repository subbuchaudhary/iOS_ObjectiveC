//
//  ChatListViewController.m
//  Yoku
//
//  Created by Ramesh on 11/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "ChatListViewController.h"
#import "ChatListCell.h"

@interface ChatListViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation ChatListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.dataArray=[NSArray arrayWithObjects:@"Hari",@"Ramesh",@"Mahi", nil];
}

#pragma mark - UITableView Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChatListCell*chatListCell=[tableView dequeueReusableCellWithIdentifier:@"ChatListCell"];
    chatListCell.nameLbl.text=[self.dataArray objectAtIndex:indexPath.row];
//    chatListCell.profileImage.layer.cornerRadius=chatListCell.profileImage.frame.size.width/2;
//    chatListCell.profileImage.clipsToBounds=YES;
      return chatListCell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
