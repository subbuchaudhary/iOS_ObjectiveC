//
//  BIMessageThreadViewController.m
//  MessageList
//
//  Created by Angel Wingartz on 2/13/15.
//  Copyright (c) 2015 BroadSoft, Inc. All rights reserved.
//

#import "BIMessageThreadViewController.h"
#import "BIModel.h"
#import "BICoreDataBroker.h"
#import "BIMessageInputBarViewController.h"
#import "BICallingMediator.h"
#import "BIContact.h"
#import "BIAvatarFactory.h"
#import "BIContactMediator.h"
#import "BIColorPalette.h"
#import "NSDate+Iris.h"
#import "BIGroupParticipantsViewController.h"
#import "UIViewController+Iris.h"
#import "NSMutableArray+Queue.h"
#import "BIMessageView.h"
#import "BIPresenceTitleView.h"
#import "UITableView+Iris.h"
#import "BIMainViewController.h"
#import "BIWKWebViewController.h"
#import "BIHubMediator.h"
#import "BIProfileViewController.h"

/* Different types of BIMessages classes */
typedef NS_ENUM(NSInteger, BIMessageCellType) {
    BIMessageCellTypeOutgoing,
    BIMessageCellTypeOutgoingError,
    BIMessageCellTypeIncoming,
    BIMessageCellTypeIncomingFirst,
    BIMessageCellTypeIncomingFirstGroup
};

/* Used when determining the position of a balloon in a sequence */
typedef struct  {
    __unsafe_unretained BIMessage *previous;
    __unsafe_unretained BIMessage *current;
    __unsafe_unretained BIMessage *next;
} BISurroundingMessages;

static CGFloat const pageControlPaddingTop    = 8.f;
static CGFloat const pageControlPaddingBottom = 8.f;

/* Assertion failure in UITextView : the view debugger in Xcode and capturing the view hierarchy */
@interface UITextView(MYTextView)

@end

@implementation UITextView (MYTextView)
- (void)_firstBaselineOffsetFromTop {
    
}

- (void)_baselineOffsetFromBottom {
    
}

@end

@interface BIMessageThreadViewController () <NSFetchedResultsControllerDelegate, BIMessageInputBarViewControllerDelegate, UIPageViewControllerDataSource, UIPageViewControllerDelegate>

@property (strong, nonatomic) UITableView *tableView;
@property (assign, nonatomic) BOOL isFirstAppearance;
@property (assign, nonatomic) BOOL shouldMarkRead;
@property (strong, nonatomic) NSMutableArray *markReadQueue;
@property (strong, nonatomic) UIView *headerView;
@property (strong, nonatomic) UIView *spacingView;

@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (readonly, nonatomic) BIPerson *person;
@property (strong, nonatomic) NSString *copiedText;
@property (nonatomic) BOOL    isCopyingCell;
@property (strong, nonatomic) NSString *selectedMessageId;
@property (assign, nonatomic) NSInteger copyingRowNumber;
@property (strong, nonatomic) BIPerson *myPerson;
@property (strong, nonatomic) BIPresenceTitleView *presenceTitleView;
@property (strong, nonatomic) UILabel *groupParticipantsLabel;
@property (strong, nonatomic) UIView *readOnlyView;
@property (nonatomic) BOOL    showingDate;
@property (strong, nonatomic) UIView *headerBackground;
@property (assign, nonatomic) BOOL scrollToMostRecentAfterUpdate;
@property (assign, nonatomic) BOOL usesKeyboard;
@property (assign, nonatomic) CGFloat headerHeight;
@property (strong, nonatomic) UIPageViewController *pageViewController;
@property (strong, nonatomic) UIPageControl *pageControl;
@property (strong, nonatomic) NSMutableArray *arrayOfPages;
@property (strong, nonatomic) NSLayoutConstraint *pageControlVerticalPosConstraint;

@property (strong, nonatomic) BIMessageInputBarViewController *inputBarViewController;
@property (assign, nonatomic) CGFloat lastKnownKeyboardHeight;

// Mutable Set used to keep track of which rows are being animated and avoid conflicts in animations.
@property (strong, nonatomic) NSMutableSet *rowBeingAnimatedSet;

@property (strong, nonatomic) BIWKWebViewController *hubViewController;
@property (assign, nonatomic, getter=isHubEnabled) BOOL hubEnabled;

@end

@implementation BIMessageThreadViewController

#pragma mark - view life cycle
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.isFirstAppearance = YES;
    [self initScreenTitle];
    [self initViews];
    self.showingDate = NO;
    self.lastKnownKeyboardHeight = 0.f;
    self.headerHeight = nan(nil);
    self.copyingRowNumber = -1;

    // listen for app state changes
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appWillEnterForeground:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appWillResignActive:)
                                                 name:UIApplicationWillResignActiveNotification
                                               object:nil];
    /* Need to know when the system font size changed to reset caches that depend on font size */
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(contentSizeCategoryDidChange:)
                                                 name:UIContentSizeCategoryDidChangeNotification
                                               object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    if (self.fetchedResultsController) {
        /* Re-link the FRC to self to get notifications */
        self.fetchedResultsController.delegate = self;
    }

    if (self.isFirstAppearance || self.needsToCheckForNewMessagesNextTimeShowing) {
        [self fetchEvents];
        self.needsToCheckForNewMessagesNextTimeShowing = NO;
    }

     [self setBarButtonItems];

    self.shouldMarkRead = YES;
    [self markConversationRead];

    if ([self showsPresenceView])
    {
        // listen for Main MOC saves
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(mainMocDidSaveNotification:)
                                                     name:NSManagedObjectContextDidSaveNotification
                                                   object:[BICoreDataBroker sharedInstance].mainManagedObjectContext];

        // request a presence update
        if (self.person.impId.length > 0)
        {
            [[BIUmsRequestManager sharedInstance] queryPresenceForImpIds:@[self.person.impId]
                                                             onSuccess:nil
                                                             onFailure:nil];
        }
    }

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(menuDidHide:)
                                                 name:UIMenuControllerDidHideMenuNotification
                                               object:[UIMenuController sharedMenuController]];

    if (self.isFirstAppearance)
    {
        [BIMessageBaseView resetCachedValues];
        [BIMessageBaseView setPreferredMaxLayoutWidth:CGRectGetWidth(self.view.bounds)];

        [self scrollToMessageOnFetch];
    }

    if (self.usesKeyboard) {
         [self registerForKeyboardNotifications];
    }

    [self assignFirstResponder];
}

- (void)assignFirstResponder
{
    if (self.isHubEnabled && self.pageControl.currentPage != 0) {
        // Only page 0 can show input bar. (become first responder).
        return;
    }

    if (!self.usesKeyboard)
    {
        /* ios9 keeps showing a keyboard if there was any. Even resigning first responder status.
         Setting self to first responder makes the keyboard dissapear */
        [self becomeFirstResponder];
    }
    else
    {
        // the inputBarViewController.view has an accessory view that will be displayed as a
        // consequence of becoming the first responder.
        [self.inputBarViewController.view becomeFirstResponder];
    }
}

/**
 This view can only become the first responder in read-only threads.
   By having this VC as first responder, the inputBarViewController's view won't be the first responder
   and the keyboard and inputAccessoryView are not shown.
 */
- (BOOL)canBecomeFirstResponder
{
    return !self.usesKeyboard;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    if (self.isFirstAppearance) {
        BITrackViewUsage(BILogConversationDetailsView);
    }

    self.isFirstAppearance = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

    // stop listening for menu hiding
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIMenuControllerDidHideMenuNotification
                                                  object:[UIMenuController sharedMenuController]];

    if ([self showsPresenceView])
    {
        // stop listening for MOC saves
        [[NSNotificationCenter defaultCenter] removeObserver:self
                                                        name:NSManagedObjectContextDidSaveNotification
                                                      object:[BICoreDataBroker sharedInstance].mainManagedObjectContext];
    }

    // cleanup
    self.navigationItem.rightBarButtonItems = nil;

    if (self.usesKeyboard) {
        // dismiss the keyboard if present.
        [self.inputBarViewController dismissKeyboard];
    }
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];

    // Stop being the FRC delegate and stop listening for notifications if we are returning to the
    // top.  "isMovingFromParentViewController" does not work here because the split view VC keeps
    // hold of us; however, continue to check for it just in case this view is used outside of a
    // split VC.
    if (self.isMovingFromParentViewController || ([self.navigationController.viewControllers lastObject] == self))
    {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        self.fetchedResultsController.delegate = nil;
        self.messageIds = nil;
        self.latestFoundMessageId = nil;
    }

    self.shouldMarkRead = NO;
}

-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];

    [BIMessageBaseView resetCachedValuesForOrientation];
    [BIMessageBaseView setPreferredMaxLayoutWidth:size.width];

    [self.presenceTitleView setNeedsLayoutDueToNewHeight];
}

-(void)willTransitionToTraitCollection:(UITraitCollection *)newCollection withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [super willTransitionToTraitCollection:newCollection withTransitionCoordinator:coordinator];

    /* Visible cells, right before the the transition (rotation) */
    NSIndexPath *lastVisibleCellIndexPath = [[self.tableView indexPathsForVisibleRows] lastObject];

    /* scroll to last one, only if is visible at least 20% */
    CGRect rectForLastVisibleCell = [self.tableView rectForRowAtIndexPath:lastVisibleCellIndexPath];
    CGFloat maxYPosForTableView = CGRectGetMaxY(self.tableView.bounds);
    CGFloat minYPosForLastCell = CGRectGetMinY(rectForLastVisibleCell);
    CGFloat cellHeight = CGRectGetHeight(rectForLastVisibleCell);
    if ( ((maxYPosForTableView - minYPosForLastCell)/cellHeight) < 0.20) {
        if (lastVisibleCellIndexPath.row - 1 > 0) {
            lastVisibleCellIndexPath = [NSIndexPath indexPathForRow:lastVisibleCellIndexPath.row-1 inSection:lastVisibleCellIndexPath.section];
        }
    }

    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context) {
    } completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
    {
        /* Scrolling adjustment not needed when the content fits in the window */
        if (self.tableView.contentSize.height > CGRectGetHeight(self.tableView.bounds)) {
            /* Ideally we would use tableviews' scroll to bottom. But using scroll to bottom causes the
             tableView to load a crazy number of rows that are not visible making it slow and not efficient.
             Using offsets manually here instead. */
            [self.tableView reloadData];
            [self.tableView layoutIfNeeded];

            /* Offset the row to the bottom of the tableView */
            CGPoint newOffset = self.tableView.contentOffset;
            CGFloat tableHeight = CGRectGetHeight(self.tableView.bounds);
            CGFloat minYPosCell = CGRectGetMinY([self.tableView rectForRowAtIndexPath:lastVisibleCellIndexPath]);
            CGFloat cellHeight  = CGRectGetHeight([self.tableView rectForRowAtIndexPath:lastVisibleCellIndexPath]);
            newOffset.y = minYPosCell - tableHeight + cellHeight + 4;

            self.tableView.contentOffset = newOffset;
        }
    }];
}

- (void)appWillEnterForeground:(NSNotification *)notification
{
    if (self.isViewLoaded && self.view.window)
    {
        self.shouldMarkRead = YES;
        [self markConversationRead];
    }
}

- (void)appWillResignActive:(NSNotification *)notification
{
    self.shouldMarkRead = NO;
}

- (void)contentSizeCategoryDidChange:(NSNotification *)notification
{
    /* Reset the caches that hold current sizes of balloons */
    [BIMessageBaseView resetCachedValuesForChangeOfFont];
}

#pragma mark -

- (NSMutableArray *)markReadQueue
{
    if (!_markReadQueue) {
        _markReadQueue = [NSMutableArray array];
    }
    return _markReadQueue;
}

- (BIPerson *)myPerson
{
    BICoreDataBroker *broker = [BICoreDataBroker sharedInstance];

    if (broker.mainManagedObjectContext == nil)
    {
        BSLogDebug(BILogUIModule, @"Error fetching my person! Core data stack not initalized.");
        return nil;
    }

    NSError *error = nil;
    BIPerson *person = [broker myPerson:broker.mainManagedObjectContext error:&error];
    if (error)
    {
        BSLogDebug(BILogUIModule, @"Error fetching my person!\n%@", error);
        return nil;
    }

    return person;
}

- (NSString *)myMessagingId
{
    return [BICoreDataBroker sharedInstance].myMessagingId;
}

- (BOOL)showsParticipantHeader
{
    // Group Alias and Alert (outgoing) should list the participants.
    return ([self.conversation isGroupConversation] &&
            ([(BIGroupConversation *)self.conversation groupConversationType] == BIGroupAliasConversation ||
             [(BIGroupConversation *)self.conversation groupConversationType] == BIOutgoingGroupAlertConversation));
}

- (BOOL)showsReadOnlyFooter
{
    // Group conversations that user can send msgs are: Alias and Alert (outgoing).
    return ([self.conversation isGroupConversation] &&
            ([(BIGroupConversation *)self.conversation groupConversationType] != BIGroupAliasConversation) &&
            ([(BIGroupConversation *)self.conversation groupConversationType] != BIOutgoingGroupAlertConversation));
}

- (BOOL)showsPresenceView
{
    // person converstions and My Room groups show the presence view
    return ([self.conversation isPersonConversation] || ([self.conversation isGroupConversation] &&
            ([(BIGroupConversation *)self.conversation groupConversationType] == BIMyRoomConversation)));
}

- (UIView *)readOnlyView
{
    if (!_readOnlyView)
    {
        _readOnlyView = [[UIView alloc] initWithFrame:CGRectZero];
        _readOnlyView.layer.cornerRadius = 32.f/2;
        [_readOnlyView.layer setMasksToBounds:YES];
         _readOnlyView.backgroundColor = BIColorForPaletteKey(BIColorContentBackground);
        [_readOnlyView setTranslatesAutoresizingMaskIntoConstraints:NO];

        UIButton *readOnly = [UIButton buttonWithType:UIButtonTypeSystem];
        readOnly.titleLabel.font = BIFontForStyle(BIFontRestrictiveButtonStyle);
        [readOnly setTitleColor:BIColorForPaletteKey(BIColorDimmedText) forState:UIControlStateNormal];
        [readOnly setTranslatesAutoresizingMaskIntoConstraints:NO];

        if ([self isConversationGroupAlertIncoming])
        {
            [readOnly setTitle:BILocalizedString(@"One-way Broadcast") forState:UIControlStateNormal];
        }
        else
        {
            [readOnly setTitle:BILocalizedString(@"Read only") forState:UIControlStateNormal];
            [readOnly addTarget:self action:@selector(readOnlyAlert) forControlEvents:UIControlEventTouchUpInside];

            UIButton *questionMark = [UIButton buttonWithType:UIButtonTypeSystem];
            [questionMark setTitleColor:BIColorForPaletteKey(BIColorPrimaryButton) forState:UIControlStateNormal];
            questionMark.titleLabel.font =  BIFontForStyle(BIFontRestrictiveButtonStyle);
            [questionMark setTitle:@"?" forState:UIControlStateNormal];
            questionMark.layer.cornerRadius =24.f/2.f;
            questionMark.layer.borderColor = [BIColorForPaletteKey(BIColorPrimaryButton) CGColor];
            questionMark.layer.borderWidth = 1.5f;
            [questionMark.layer setMasksToBounds:YES];
            [questionMark addTarget:self action:@selector(readOnlyAlert) forControlEvents:UIControlEventTouchUpInside];

            [questionMark setTranslatesAutoresizingMaskIntoConstraints:NO];
            [_readOnlyView addSubview:questionMark];

            [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:questionMark
                                                                      attribute:NSLayoutAttributeCenterY
                                                                      relatedBy:NSLayoutRelationEqual
                                                                         toItem:questionMark.superview
                                                                      attribute:NSLayoutAttributeCenterY
                                                                     multiplier:1.f
                                                                       constant:0.f]];
            [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:questionMark
                                                                      attribute:NSLayoutAttributeTrailing
                                                                      relatedBy:NSLayoutRelationEqual
                                                                         toItem:questionMark.superview
                                                                      attribute:NSLayoutAttributeTrailing
                                                                     multiplier:1.f
                                                                       constant:-4.f]];
            [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:questionMark
                                                                      attribute:NSLayoutAttributeHeight
                                                                      relatedBy:NSLayoutRelationEqual
                                                                         toItem:nil
                                                                      attribute:NSLayoutAttributeNotAnAttribute
                                                                     multiplier:1.f
                                                                       constant:24.f]];
            [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:questionMark
                                                                      attribute:NSLayoutAttributeWidth
                                                                      relatedBy:NSLayoutRelationEqual
                                                                         toItem:nil
                                                                      attribute:NSLayoutAttributeNotAnAttribute
                                                                     multiplier:1.f
                                                                       constant:24.f]];
        }

        [_readOnlyView addSubview:readOnly];

        [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:readOnly
                                                                  attribute:NSLayoutAttributeLeading
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:readOnly.superview
                                                                  attribute:NSLayoutAttributeLeading
                                                                 multiplier:1.f
                                                                   constant:12.f]];
        [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:readOnly
                                                                  attribute:NSLayoutAttributeTop
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:readOnly.superview
                                                                  attribute:NSLayoutAttributeTop
                                                                 multiplier:1.f
                                                                   constant:0.f]];
        [_readOnlyView addConstraint:[NSLayoutConstraint constraintWithItem:readOnly
                                                                  attribute:NSLayoutAttributeBottom
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:readOnly.superview
                                                                  attribute:NSLayoutAttributeBottom
                                                                 multiplier:1.f
                                                                   constant:0.f]];
    }

    return _readOnlyView;
}

- (void)readOnlyAlert
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:BILocalizedString(@"Read Only Chat")
                                                                   message:BILocalizedString(@"Rooms are not supported in this App. You can view conversations, but not send messages.")
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:BILocalizedString(@"OK") style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {}];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}

- (UIView *)headerBackground
{
    if (!_headerBackground) {
        _headerBackground = [[UIView alloc] initWithFrame:CGRectMake(0,
                                                                     0,
                                                                     self.view.frame.size.width,
                                                                     self.headerHeight)];
        [_headerBackground setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
                                               UIViewAutoresizingFlexibleLeftMargin |
                                               UIViewAutoresizingFlexibleRightMargin];

        _headerBackground.backgroundColor = BIColorForPaletteKey(BIColorChatBackground);
    }
    return _headerBackground;
}

- (CGFloat)headerHeight
{
    if (isnan(_headerHeight))
    {
        if ([self showsParticipantHeader]) {
            CGSize fontSize = [@"T" sizeWithFont:BIFontForStyle(BIFontRestrictiveSmallLabelStyle)];
            // give it 2 points up and bottom for gap.
            // The shadow png height is not considered here, the shadow is placed over the rows space.
            _headerHeight = fontSize.height+4 < 16 ? 16 : fontSize.height+4; // 2 top + 2 bottom
        }
        else {
            _headerHeight = 0.f;
        }
    }

    return _headerHeight;
}

- (UIView *)headerView
{
    if (!_headerView)
    {
        BOOL hasGroupHeader = [self showsParticipantHeader];

        _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.headerHeight)];
        [_headerView setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
                                         UIViewAutoresizingFlexibleLeftMargin |
                                         UIViewAutoresizingFlexibleRightMargin];
        _headerView.autoresizesSubviews = YES;

        [_headerView addSubview:self.headerBackground];

        if (hasGroupHeader)
        {
            self.groupParticipantsLabel = [[UILabel alloc] initWithFrame:CGRectZero];
            self.groupParticipantsLabel.font = BIFontForStyle(BIFontRestrictiveSmallLabelStyle);
            self.groupParticipantsLabel.textColor = BIColorForPaletteKey(BIColorPrimaryButton);
            self.groupParticipantsLabel.textAlignment = NSTextAlignmentCenter;
            self.groupParticipantsLabel.numberOfLines = 1;
            self.groupParticipantsLabel.lineBreakMode = NSLineBreakByTruncatingTail;

            // participant label bounds
            CGSize fontSize = [@"T" sizeWithFont:BIFontForStyle(BIFontRestrictiveSmallLabelStyle)];
            CGFloat participantsLabelHeight = fontSize.height < 16 ? 16 : fontSize.height;
            CGFloat participantsLabelWidth = _headerView.frame.size.width - 16.f;

            [_headerView addSubview:self.groupParticipantsLabel];
            self.groupParticipantsLabel.frame = CGRectMake(_headerView.frame.origin.x + 8.f,
                                                           _headerView.frame.origin.y + 2.f, // bottom gap 2 pts
                                                           participantsLabelWidth,
                                                           participantsLabelHeight);

            [self.groupParticipantsLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
                                                        UIViewAutoresizingFlexibleLeftMargin |
                                                        UIViewAutoresizingFlexibleRightMargin];

            // get the list of participant (member) short list names
            BICoreDataBroker *broker = [BICoreDataBroker sharedInstance];
            BIGroupConversation *groupConv = (BIGroupConversation *)self.conversation;
            NSArray *members = [groupConv membersSortedByShortListName:broker.myMessagingId];

            // determine the "and more" size
            NSString *more = [BILocalizedString(@"More") lowercaseStringWithLocale:[NSLocale currentLocale]];
            CGSize andMoreSize = [[@" & 99 " stringByAppendingString:more] sizeWithFont:self.groupParticipantsLabel.font];

            // collect the names that will fit
            CGSize membersLabelSize = CGSizeZero;
            NSMutableString *membersLabelText = [NSMutableString new];
            NSInteger count = 0;
            for (; count < members.count; ++count)
            {
                BIContact *contact = [BIContact contactWithPerson:members[count]];
                NSMutableString *name = [NSMutableString new];
                BOOL last = (count == (members.count - 1));

                if (count == 0) {
                    [name appendString:[contact shortListName]];
                }
                else if (last) {
                    [name appendFormat:@" & %@", [contact shortListName]];
                }
                else {
                    [name appendFormat:@", %@", [contact shortListName]];
                }

                CGSize nameSize = [name sizeWithFont:self.groupParticipantsLabel.font];

                if ((membersLabelSize.width + nameSize.width) < participantsLabelWidth)
                {
                    if (!last && ((membersLabelSize.width + nameSize.width + andMoreSize.width) >= participantsLabelWidth))
                    {
                        // don't accumulate the name, append "and more", and stop here
                        [membersLabelText appendFormat:@" & %@ %@", @(members.count - count), more];
                        break;
                    }
                    else
                    {
                        // accumulate the name
                        [membersLabelText appendString:name];
                        // recalculate the size for the next pass
                        membersLabelSize = [membersLabelText sizeWithFont:self.groupParticipantsLabel.font];
                    }
                }
                else if ((membersLabelSize.width + andMoreSize.width) < participantsLabelWidth)
                {
                    // append "and more" and stop here
                    [membersLabelText appendFormat:@" & %@ %@", @(members.count - count), more];
                    break;
                }
                else
                {
                    // a really long name?  apply special handling and stop
                    membersLabelText = [NSMutableString stringWithFormat:@"%@ %@",
                                        @(members.count),
                                        [BILocalizedString(@"Participants") lowercaseStringWithLocale:[NSLocale currentLocale]]];
                    break;
                }
            }

            self.groupParticipantsLabel.text = [membersLabelText copy];

            // View (gapView) used as a gap between the participants label and the rows.
            // This view is composed first by a gradient and an imageView with the "shadow" image that is placed
            // on top of the gradient. When scrolling up, the bubbles dissapear gradually behind this view.
            // This view is framed in the rows area (right below the header frame boundaries), the method
            // heightForHeaderInSection, pushes the rows down so the first bubble does not look partially hidden
            // when there's only a few rows.
            UIView *gapView = [[UIView alloc] initWithFrame:CGRectMake(0,
                                                                       CGRectGetMaxY(_headerView.frame),
                                                                       CGRectGetWidth(_headerView.bounds),
                                                                       6.0f)];
            gapView.backgroundColor = [UIColor clearColor];

            // gradient layer for gapView
            CAGradientLayer *gradientLayer = [CAGradientLayer layer];
            gradientLayer.frame = gapView.bounds;
            UIColor *topColor = BIColorForPaletteKey(BIColorChatBackground);
            UIColor *bottomColor = [topColor colorWithAlphaComponent:0.0];
            gradientLayer.colors = [NSArray arrayWithObjects:(id)[topColor CGColor], (id)[bottomColor CGColor], nil];
            gradientLayer.startPoint = CGPointMake(0.0f, 0.0f);
            gradientLayer.endPoint = CGPointMake(0.0f, 1.f);
            [gapView.layer insertSublayer:gradientLayer atIndex:0];

            // Shadow view.
            UIImageView *shadowView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"groupChatParticipantsShadow"]];
            [shadowView setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
                                            UIViewAutoresizingFlexibleLeftMargin |
                                            UIViewAutoresizingFlexibleRightMargin];

            // This shadow view, is framed below (outside) the header frame so it is shown on top of the rows
            // area, it will not cover the first row though because the heightForHeaderInSection method provides
            // a height that takes this shadow height into account.
            [shadowView setFrame:CGRectMake(0,
                                            0,
                                            CGRectGetWidth(gapView.bounds),
                                            6.0f)];

            [gapView addSubview:shadowView];

            [_headerView addSubview:gapView];
        }
    }
    return _headerView;
}

- (UIView *)spacingView
{
    if (!_spacingView)
    {
        _spacingView = [UIView new];
        _spacingView.opaque = NO;
        _spacingView.backgroundColor = [UIColor clearColor];
    }

    return _spacingView;
}

- (BIWKWebViewController *)hubViewController
{
    if (!_hubViewController)
    {
        _hubViewController = [[BIHubMediator sharedInstance] cachedGadgetViewForContact:[BIContact contactWithPerson:self.person]];
    }
    return _hubViewController;
}

- (void)initViews
{
    self.navigationController.navigationBar.translucent = NO;

    self.view.backgroundColor = BIColorForPaletteKey(BIColorChatBackground);

    [self setBarButtonItems];

    self.tableView = [[UITableView alloc] init];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.scrollsToTop = YES;
    self.tableView.backgroundColor = BIColorForPaletteKey(BIColorChatBackground);
    self.tableView.allowsSelection = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.delegate = self;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;

    /* This two properties below need to be set for cell height auto-sizing to work properly */
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 80.f;

    self.hubEnabled = [self.conversation isPersonConversation] && [[BIHubMediator sharedInstance] isHubEnabledForType:BIHubRequestTypeContextualGadget];

    if (self.isHubEnabled)
    {
        self.pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
        self.pageViewController.dataSource = self;
        self.pageViewController.delegate = self;
        self.pageViewController.view.translatesAutoresizingMaskIntoConstraints = NO;

        UIViewController *detail = [[UIViewController alloc] init];
        _arrayOfPages = [NSMutableArray arrayWithObjects:detail, nil];

        [self.pageViewController setViewControllers:@[detail] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
        
        [self addChildViewController:self.pageViewController];
        [self.view addSubview:self.pageViewController.view];
        [self.pageViewController didMoveToParentViewController:self];
        
        NSDictionary *views = @{@"pageViewController": self.pageViewController.view};
        
        [self.view addConstraints:[NSLayoutConstraint
                                   constraintsWithVisualFormat:@"H:|[pageViewController]|"
                                   options:0 metrics:nil views:views]];
        
        [self.view addConstraints:[NSLayoutConstraint
                                   constraintsWithVisualFormat:@"V:|[pageViewController]|"
                                   options:0 metrics:nil views:views]];
        
        [detail.view addSubview:self.tableView];


        self.pageControl = [[UIPageControl alloc] init];
        self.pageControl.translatesAutoresizingMaskIntoConstraints = NO;
        self.pageControl.backgroundColor = [UIColor clearColor];
        self.pageControl.numberOfPages = 2;
        self.pageControl.currentPage = 0;
        self.pageControl.pageIndicatorTintColor = BIColorForPaletteKey(BIColorDimmedText);
        self.pageControl.currentPageIndicatorTintColor = BIColorForPaletteKey(BIColorPrimaryBackground);
        [self.view addSubview: self.pageControl];
        [self.view bringSubviewToFront:self.pageControl];

        NSDictionary *viewsDict = @{@"messages":self.tableView, @"pageControl":self.pageControl};
        
        [[detail view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[messages]|"
                                                                              options:0
                                                                              metrics:nil
                                                                                views:viewsDict]];
        [[detail view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[messages]|"
                                                                              options:0
                                                                              metrics:nil
                                                                                views:viewsDict]];

        [[self view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[pageControl]|"
                                                                              options:0
                                                                              metrics:nil
                                                                                views:viewsDict]];

        [[self view] addConstraint:[NSLayoutConstraint constraintWithItem:self.pageControl
                                                                  attribute:NSLayoutAttributeCenterX
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:self.pageControl.superview
                                                                  attribute:NSLayoutAttributeCenterX
                                                                 multiplier:1.f
                                                                   constant:0.f]];

        // Limit its height to its minimum (we observed a default height of 37 pts) possible that shows the dots (7 pts).
        [self.pageControl addConstraint:[NSLayoutConstraint constraintWithItem:self.pageControl
                                                                     attribute:NSLayoutAttributeHeight
                                                                     relatedBy:NSLayoutRelationEqual
                                                                        toItem:nil
                                                                     attribute:NSLayoutAttributeNotAnAttribute
                                                                    multiplier:1.f
                                                                      constant:CGRectGetHeight(self.pageControl.subviews[0].bounds)]];

        CGFloat pageControlViewHeight = [self getPageControlVerticalPosConstraintOffset];
        // This
        self.pageControlVerticalPosConstraint = [NSLayoutConstraint constraintWithItem:self.pageControl
                                                                             attribute:NSLayoutAttributeBottom
                                                                             relatedBy:NSLayoutRelationEqual
                                                                                toItem:self.pageControl.superview
                                                                             attribute:NSLayoutAttributeBottom
                                                                            multiplier:1.f
                                                                              constant:pageControlViewHeight];

        [self.view addConstraint:self.pageControlVerticalPosConstraint];
    }
    else
    {
        [self.view addSubview:self.tableView];
        [self configureConstraints];
    }

    self.usesKeyboard = ![self showsReadOnlyFooter];

    if (self.usesKeyboard) {
        /* Adds the "empty" view whose input accessory view (input bar) will float above the table view
         when self.inputBarViewController.view becomes the first responder */
        [self.tableView addSubview:self.inputBarViewController.view];
    }
}

- (UIViewController *)viewControllerAtIndex:(NSUInteger)index
{
    if (([_arrayOfPages count] == 0) || (index >= [_arrayOfPages count]))
    {
        return nil;
    }
    
    if (index == 0)
    {
        UIViewController *detailViewController=[_arrayOfPages objectAtIndex:index];
        return detailViewController;
    }
    else
    {
        BIWKWebViewController *webViewController = [_arrayOfPages objectAtIndex:index];
        webViewController.webPageIndex = index;
        return webViewController;
    }
}

- (void)showinputbar
{
    [self.inputBarViewController.view endEditing:NO];
    [self assignFirstResponder];
}

- (void)setBarButtonItems
{
    UIBarButtonItem *callButton = nil;
    UIBarButtonItem *moreButton = nil;
    UIBarButtonItem *membersItem = nil;
    UIBarButtonItem *backButton = nil;

    backButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"backButton"]
                                                  style:UIBarButtonItemStylePlain
                                                 target:self
                                                 action:@selector(didPressBackButton:)];

    [self.navigationItem setLeftBarButtonItem:backButton];

    moreButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"chatDetailsMore"]
                                                  style:UIBarButtonItemStylePlain
                                                 target:self
                                                 action:@selector(moreOptions)];

    if ([self.conversation isGroupConversation])
    {
        BIGroupConversation *groupConversation = (BIGroupConversation *)self.conversation;
        switch ([groupConversation groupConversationType])
        {
            case BIMyRoomConversation:
            {
                callButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"chatDetailsCall"]
                                                              style:UIBarButtonItemStylePlain
                                                             target:self
                                                             action:@selector(callRoom)];
                break;
            }
            case BIGroupAliasConversation:
            case BIOutgoingGroupAlertConversation:
            {
                membersItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"viewParticipants"]
                                                               style:UIBarButtonItemStylePlain
                                                              target:self
                                                              action:@selector(showGroupParticipants)];
                moreButton = nil;
                break;
            }
            case BIIncomingGroupAlertConversation:
            {
                // there is no bar button with the system Info image; manufacture one
                UIButton *ibtn = [UIButton buttonWithType:UIButtonTypeInfoLight];
                [ibtn addTarget:self action:@selector(showProfile) forControlEvents:UIControlEventTouchUpInside];

                membersItem = [[UIBarButtonItem alloc] initWithCustomView:ibtn];
                moreButton = nil;
                break;
            }
            default:
                break;

        }
    }
    else
    {
        callButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"chatDetailsCall"]
                                                      style:UIBarButtonItemStylePlain
                                                     target:self
                                                     action:@selector(call)];
    }

    if (moreButton)
    {
        if (callButton) {
            self.navigationItem.rightBarButtonItems = @[ moreButton, callButton ];
        }
        else {
            self.navigationItem.rightBarButtonItems = @[ moreButton ];
        }
    }
    else if (membersItem)
    {
        self.navigationItem.rightBarButtonItems = @[ membersItem ];
    }
    
    [self.presenceTitleView navigationBarDidChange];
}

- (void)configureConstraints
{
    NSDictionary *views = @{@"messages":self.tableView};

    [[self view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[messages]|"
                                                                        options:0
                                                                        metrics:nil
                                                                          views:views]];
    [[self view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[messages]|"
                                                                        options:0
                                                                        metrics:nil
                                                                          views:views]];
}

- (void)updateViewConstraints
{
    [super updateViewConstraints];
    if (self.isHubEnabled) {
        self.pageControlVerticalPosConstraint.constant = [self getPageControlVerticalPosConstraintOffset];
    }
}

- (CGFloat)getPageControlVerticalPosConstraintOffset
{
    CGFloat pageControlHeight = ceil(CGRectGetHeight(self.pageControl.bounds));
    if (pageControlHeight == 0) {
        // First time this is called (because the keyboard willShow) the UIPageControl hasn't been laid out. Force it
        // so we can get an accurate offset.
        [self.pageControl layoutIfNeeded];
        pageControlHeight = ceil(CGRectGetHeight(self.pageControl.bounds));
    }
    // The goal is to lay out the UIPageControl's dots 8 pts (pageControlPaddingBottom) above the input bar.
    return  - self.lastKnownKeyboardHeight + (pageControlHeight - (CGRectGetHeight(self.pageControl.subviews[0].bounds)))/2 - pageControlPaddingBottom;
}


- (NSFetchedResultsController *)createFetchedResultsController
{
    if (!self.fetchedResultsController && self.conversation)
    {
        BICoreDataBroker *broker = [BICoreDataBroker sharedInstance];
        NSManagedObjectContext *moc = broker.mainManagedObjectContext;
        NSFetchRequest *messageFetchRequest = [broker fetchRequestForConversationMessages:self.conversation];
        messageFetchRequest.includesPendingChanges = NO;
        if (messageFetchRequest && moc)
        {
            messageFetchRequest.fetchBatchSize = 15;
            NSFetchedResultsController *frc = [[NSFetchedResultsController alloc]
                                               initWithFetchRequest:messageFetchRequest
                                               managedObjectContext:moc
                                               sectionNameKeyPath:nil
                                               cacheName:nil];
            frc.delegate = self;
            self.fetchedResultsController = frc;
        }
    }
    return self.fetchedResultsController;
}

- (BIPerson *)person
{
    if ([self.conversation isPersonConversation]) {
        return ((BIPersonConversation *)self.conversation).person;
    }
    else {
        return ((BIGroupConversation *)self.conversation).owner;
    }
}

- (UIImage *)avatarForPerson:(BIPerson *)person
{
    UIImage *avatar = nil;

    if (person.avatar)
    {
        avatar = [BIAvatarFactory avatarWithPerson:person andAvatarSize:BIAvatarSizeMessageThreadView];
    }

    if (!avatar)
    {
        if ([self.conversation isGroupConversation])
        {
            switch ([(BIGroupConversation *)self.conversation groupConversationType])
            {

                case BIMyRoomConversation:
                    avatar = [BIAvatarFactory avatarWithImageNamed:@"avatarPersonalRoom" andAvatarSize:BIAvatarSizeMessageThreadView];
                    break;
                default:
                    avatar = [BIAvatarFactory avatarWithImageNamed:@"avatarGroup" andAvatarSize:BIAvatarSizeMessageThreadView];
                    break;
            }
        }
        else
        {
            avatar = [BIAvatarFactory avatarWithPerson:person andAvatarSize:BIAvatarSizeMessageThreadView];
        }
    }
    
    if (!avatar)
    {
        avatar = [BIAvatarFactory avatarWithImageNamed:@"avatarEmpty" andAvatarSize:BIAvatarSizeMessageThreadView];
    }

    return avatar;
}

- (void)mainMocDidSaveNotification:(NSNotification *)notification
{
    // perhaps update the contact details if this a person of interest
    NSSet *updatedSet = [notification.userInfo objectForKey:NSUpdatedObjectsKey];
    for (id managedObject in updatedSet)
    {
        if ([managedObject isMemberOfClass:[BIPerson class]])
        {
            BIPerson *person = (BIPerson *)managedObject;
            if ([person.personId isEqualToString:[self.person personId]])
            {
                dispatch_main_async(^{
                    [self updateScreenTitle];
                });
                return;
            }
        }
    }
}

- (BOOL)isConversationGroupAlert
{
    return ([self.conversation isGroupConversation] &&
            ([(BIGroupConversation *)self.conversation groupConversationType] == BIIncomingGroupAlertConversation ||
             [(BIGroupConversation *)self.conversation groupConversationType] == BIOutgoingGroupAlertConversation));
}

- (BOOL)isConversationGroupAlertIncoming
{
    return ([self.conversation isGroupConversation] &&
            ([(BIGroupConversation *)self.conversation groupConversationType] == BIIncomingGroupAlertConversation));
}

- (BOOL)isConversationGroupAlertOutgoing
{
    return ([self.conversation isGroupConversation] &&
            ([(BIGroupConversation *)self.conversation groupConversationType] == BIOutgoingGroupAlertConversation));
}

- (BIPresenceTitleView *)presenceTitleView
{
    if (!_presenceTitleView)
    {
        if (self.navigationController.navigationController.navigationBar)
        {
            // From within the detail navigation controller of the splitview navigation controller,
            // passing in its navigation bar (e.g. by EventSummaryViewController)
            _presenceTitleView = [[BIPresenceTitleView alloc] initWithNavBar:self.navigationController.navigationController.navigationBar];
        }
        else
        {
            // Message thread view presented (e.g. by MessageSearchViewController)
            _presenceTitleView = [[BIPresenceTitleView alloc] initWithNavBar:self.navigationController.navigationBar];
        }
    }
    return _presenceTitleView;
}

-(BIMessageInputBarViewController *)inputBarViewController
{
    if (!_inputBarViewController) {
        BIMessageInputBarViewController *vc = [BIMessageInputBarViewController new];
        vc.delegate = self;

        if ([self isConversationGroupAlertOutgoing])
        {
            vc.placeholderText = BILocalizedString(@"Broadcast your message");
            vc.promptImage = [[UIImage imageNamed:@"drawerBroadcast"] imageWithReplacementColor:BIColorForPaletteKey(BIColorDimmedText)];
        }
        else
        {
            vc.placeholderText = BILocalizedString(@"Type your message");
        }

        UISwipeGestureRecognizer *swipeDown = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                                        action:@selector(dismissKeyboard)];
        swipeDown.direction = UISwipeGestureRecognizerDirectionDown;
        [vc.messageInputBarView addGestureRecognizer:swipeDown];

        _inputBarViewController = vc;
    }

    return _inputBarViewController;
}

#pragma mark - UIPageViewControllerDataSource

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSString *className=[NSString stringWithFormat:@"%@", viewController.class ];
    NSUInteger index;
    
    if ([className isEqualToString:@"BIWKWebViewController"])
    {
        index = ((BIWKWebViewController*) viewController).webPageIndex;
    }
    else
    {
        index = 0;
        [self performSelector:@selector(showinputbar) withObject:nil afterDelay:0.2];
    }
    
    if ((index == 0) || (index == NSNotFound))
    {
        return nil;
    }
    
    index--;
    return [self viewControllerAtIndex:index];
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    if (self.arrayOfPages.count == 1)
    {
        [self.arrayOfPages addObject:self.hubViewController];
    }
    
    NSUInteger index;
    
    if ([pageViewController.viewControllers[0] isKindOfClass:[BIWKWebViewController class]])
    {
        index = ((BIWKWebViewController*) viewController).webPageIndex;
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showinputbar) object:nil];
    }
    else
    {
        index = 0;
        
    }
    if (index == NSNotFound)
    {
        return nil;
    }
    index++;
    
    if (index == [self.arrayOfPages count])
    {
        return nil;
    }
    return [self viewControllerAtIndex:index];
}

#pragma mark - UIPageViewControllerDelegate

- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed
{
    if ([pageViewController.viewControllers[0] isKindOfClass:[BIWKWebViewController class]])
    {
        self.pageControl.currentPage = 1;
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showinputbar) object:nil];
    }
    else
    {
        self.pageControl.currentPage = 0;
        [self performSelector:@selector(showinputbar) withObject:nil afterDelay:0.2];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // When the "read only" footer is needed, it is added as a second section's footer.
    // This makes the read only view to scroll next to the last msg, instead of floating
    // always visible at the bottom of the visible rows.
    if ([self showsReadOnlyFooter]) {
        return 2;
    }

    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        id<NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
        return [sectionInfo numberOfObjects];
    }
    else {
        return 0;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdIncoming      = @"cellIdIncoming";
    static NSString *cellIdIncomingFirst = @"cellIdIncomingFirst";
    static NSString *cellIdIncomingFirstGroup = @"cellIdIncomingFirstGroup";
    static NSString *cellIdOutgoing      = @"cellIdOutgoing";
    static NSString *cellIdOutgoingError = @"cellIdOutgoingError";

    BISurroundingMessages messages = [self getSurroundingMessagesForIndex:indexPath];
    BIBalloonSequence shape = [self balloonShapeForMessageInSurroungingMessages:messages];
    BIMessage *message = messages.current;
    BIBallonDirection direction = [[BICoreDataBroker sharedInstance] messageSenderIsMe:message] ? BIBalloonDirectionRight : BIBalloonDirectionLeft;

    BOOL isGroupConversation = [self.conversation isGroupConversation];

    /* Determine the cell type */
    BIMessageCellType cellType;
    if (direction == BIBalloonDirectionLeft) {
        /* Incoming */
        if (shape == BIBalloonSequenceFirst) {
            if (isGroupConversation) {
                cellType = BIMessageCellTypeIncomingFirstGroup;
            }
            else {
                cellType = BIMessageCellTypeIncomingFirst;
            }
        }
        else {
            cellType = BIMessageCellTypeIncoming;
        }
    }
    else if (direction == BIBalloonDirectionRight){
        /* Outgoing */
        if ([message messageStatus] == BIMessageStatusSendError) {
            cellType = BIMessageCellTypeOutgoingError;
        }
        else {
            cellType = BIMessageCellTypeOutgoing;
        }
    }
    else {
        return nil;
    }

    /* Retrieve an instance of the specific message view */
    UITableViewCell *cell;
    BIMessageBaseView *messageView;
    BOOL isNewMessageView = NO;
    switch (cellType) {
        case BIMessageCellTypeIncoming:
        {
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdIncoming];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdIncoming];
                // remove all parameters... not needed.
                messageView = [[BIMessageIncomingView alloc] initWithSequence:shape];
                isNewMessageView = YES;
            }
            break;
        }
        case BIMessageCellTypeIncomingFirst:
        {
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdIncomingFirst];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdIncomingFirst];
                // remove all parameters... not needed.
                messageView = [[BIMessageIncomingFirstView alloc] init];
                isNewMessageView = YES;
            }
            break;
        }
        case BIMessageCellTypeIncomingFirstGroup:
        {
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdIncomingFirstGroup];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdIncomingFirstGroup];
                // remove all parameters... not needed.
                messageView = [[BIMessageIncomingFirstGroupView alloc] init];
                isNewMessageView = YES;
            }
            break;
        }
        case BIMessageCellTypeOutgoing:
        {
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdOutgoing];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdOutgoing];
                // remove all parameters... not needed.
                messageView = [[BIMessageOutgoingView alloc] initWithSequence:shape];
                isNewMessageView = YES;
            }
            break;
        }
        case BIMessageCellTypeOutgoingError:
        {
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdOutgoingError];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdOutgoingError];
                // remove all parameters... not needed.
                messageView = [[BIMessageOutgoingErrorView alloc] initWithSequence:shape];
                isNewMessageView = YES;
            }
            break;
        }

        default: return nil; break;
    }

    if (isNewMessageView)
    {
        /* When it was not retrieve from the table's cache fully initialize the view */
        messageView.translatesAutoresizingMaskIntoConstraints = NO;

        cell.contentView.layoutMargins = UIEdgeInsetsZero;
        [cell.contentView addSubview:messageView];

        /* pin the message view to the content view edges.
           The four constraints below is equivalent to adding the constraints with visual format as:
           @"H:|[messageView]|" and @"V:|[messageView]|"*/
        NSLayoutConstraint *constH1 = [NSLayoutConstraint constraintWithItem:messageView
                                                                   attribute:NSLayoutAttributeLeading
                                                                   relatedBy:NSLayoutRelationEqual
                                                                      toItem:messageView.superview
                                                                   attribute:NSLayoutAttributeLeading
                                                                  multiplier:1.f
                                                                    constant:0.f];
        NSLayoutConstraint *constH2 = [NSLayoutConstraint constraintWithItem:messageView
                                                                   attribute:NSLayoutAttributeTrailing
                                                                   relatedBy:NSLayoutRelationEqual
                                                                      toItem:messageView.superview
                                                                   attribute:NSLayoutAttributeTrailing
                                                                  multiplier:1.f
                                                                    constant:0.f];
        NSLayoutConstraint *constV1 = [NSLayoutConstraint constraintWithItem:messageView
                                                                   attribute:NSLayoutAttributeTop
                                                                   relatedBy:NSLayoutRelationEqual
                                                                      toItem:messageView.superview
                                                                   attribute:NSLayoutAttributeTop
                                                                  multiplier:1.f
                                                                    constant:0.f];
        NSLayoutConstraint *constV2 = [NSLayoutConstraint constraintWithItem:messageView
                                                                   attribute:NSLayoutAttributeBottom
                                                                   relatedBy:NSLayoutRelationEqual
                                                                      toItem:messageView.superview
                                                                   attribute:NSLayoutAttributeBottom
                                                                  multiplier:1.f
                                                                    constant:0.f];

        [cell.contentView addConstraints:@[constH1, constH2, constV1, constV2]];

        /* Gesture recognizers */
        // Long press gesture to show the "Copy" pop up window.
        UILongPressGestureRecognizer *copyTap = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(didSelectCell:)];
        copyTap.minimumPressDuration = 0.35;

        //Tap gesture to show the date of the message.
        UITapGestureRecognizer *timeTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showMessageTimeAtIndexPath:)];

        [messageView addGestureRecognizersForBalloon:@[copyTap, timeTap]];
    }
    else
    {
        messageView = cell.contentView.subviews[0];
        [messageView resetContents];
    }

    messageView.sequence = shape;

    /* set the row as view tag. Used for gesture recognizers */
    messageView.tag = indexPath.row;

    /* Message text */
    messageView.message = [message bodyForPresentation];

    /* Broadcast No Reply ?? (draws the placeholder icon if so */
    messageView.broadcastNoReplyMessageType = [self isConversationGroupAlert];

    /* selected */
    if ((self.messageIds.count > 0) && [self foundMessagesContainsMessageId:message.eventId]) {
        messageView.selected = YES;
    }
    if (!cell.isSelected && [self.selectedMessageId isEqualToString:message.eventId]) {
        messageView.selected = YES;
    }

    /*  timestamp interval */
    if (indexPath.row == 0) {
        // first msg. Display timeStamp
        messageView.timeStampInterval = [[message date] relativeShortDateTimeString];
    }
    else
    {
        // show timeStamp if at least one hour has passed since last msg.
        BIMessage *prevMsg = messages.previous;

        NSTimeInterval timeInterval = [[message date] timeIntervalSinceDate:[prevMsg date]];
        static const NSUInteger secsInHour = 3600;// 60 * 60
        if (timeInterval >= secsInHour) {
            messageView.timeStampInterval = [[message date] relativeShortDateTimeString];
        }
    }

    /* All first incoming messages, must show the sender's avatar */
    if ([messageView isKindOfClass:[BIMessageIncomingFirstView class]])
    {
        /* Avatar */
        BIMessageIncomingFirstView *incomingFirstView = (BIMessageIncomingFirstView *)messageView;
        if (message.sender.avatar == nil) {
            incomingFirstView.avatarImage = [self avatarForPerson:message.sender];
            incomingFirstView.usingDefaultAvatar = YES;
        }
        else{
            incomingFirstView.avatarImage = [self avatarForPerson:message.sender];
            incomingFirstView.usingDefaultAvatar = NO;
        }

        /* Incoming group (that is not group alert type ) show the sender for first in sequence */
        if ([messageView isKindOfClass:[BIMessageIncomingFirstGroupView class]])
        {
            BIMessageIncomingFirstGroupView *incomingFirstGroupView = (BIMessageIncomingFirstGroupView *)messageView;
            incomingFirstGroupView.senderName = message.sender.firstLastName;
        }

        if (isNewMessageView) {
            // Tap gesture to show the profile of the participant.
            UITapGestureRecognizer *avatarTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapCellAvatar:)];
            [incomingFirstView addGestureRecognizerForAvatar:avatarTap];
        }
    }
    else if ([messageView isKindOfClass:[BIMessageOutgoingErrorView class]])
    {
        if (isNewMessageView) {
            /* Avatar */
            BIMessageOutgoingErrorView *outgoingErrorView = (BIMessageOutgoingErrorView *)messageView;
            // Tap gesture to show the profile of the participant.
            UITapGestureRecognizer *errorTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(messageFailedActions:)];
            [outgoingErrorView addGestureRecognizerForErrorIcon:errorTap];
        }
    }

    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return self.headerView;
    }

    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    // header only in section 0, where the messages are placed.
    if (section == 0) {
        // When there's a header, this 6 pts make the effect of a gap between the header and first row
        if (self.headerHeight > 0) {
            return self.headerHeight + 6;
        }
    }

    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    CGFloat footerHeight = 0.f;

    if (section == 0)
    {
        footerHeight = 10.f; // Have a separation of 10 points to bottom.
    }
    else if (section == 1)
    {
        if ([self showsReadOnlyFooter]) {
            footerHeight = 48.f;
        }
    }

    return footerHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section == 0 ) {
        // section 0, where the messages are placed, show a transparent space of 10 points.
        return self.spacingView;
    }

    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [footerView addSubview:self.readOnlyView];

    // Estimate the width that needs to be allocated for the readOnlyView.
    CGFloat estimatedReadOnlyViewWidth = 0;
    NSString *textInView;
    if ([self isConversationGroupAlertIncoming])
    {
        textInView = BILocalizedString(@"One-way Broadcast");
        estimatedReadOnlyViewWidth = 24; // 12 left + 12 right
    }
    else
    {
        textInView = BILocalizedString(@"Read only");
        estimatedReadOnlyViewWidth = 42; // 12 left + 8 + image width (24) + 8
    }

    CGSize estimatedTextSize = [textInView sizeWithFont:BIFontForStyle(BIFontRestrictiveButtonStyle)];
    estimatedReadOnlyViewWidth = estimatedReadOnlyViewWidth + ceilf(estimatedTextSize.width);

    [footerView addConstraint:[NSLayoutConstraint constraintWithItem:self.readOnlyView
                                                          attribute:NSLayoutAttributeHeight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:nil
                                                          attribute:NSLayoutAttributeNotAnAttribute
                                                         multiplier:1.f
                                                           constant:32.f]];
    [footerView addConstraint:[NSLayoutConstraint constraintWithItem:self.readOnlyView
                                                          attribute:NSLayoutAttributeTrailing
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.readOnlyView.superview
                                                          attribute:NSLayoutAttributeTrailing
                                                         multiplier:1.f
                                                           constant:-8.f]];
    [footerView addConstraint:[NSLayoutConstraint constraintWithItem:self.readOnlyView
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.readOnlyView.superview
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.f
                                                           constant:-16.f]];
    [footerView addConstraint:[NSLayoutConstraint constraintWithItem:self.readOnlyView
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationGreaterThanOrEqual
                                                             toItem:nil
                                                          attribute:NSLayoutAttributeNotAnAttribute
                                                         multiplier:1.f
                                                           constant:estimatedReadOnlyViewWidth]];
    return footerView;
}

- (BOOL)foundMessagesContainsMessageId:(NSString *)messageId
{
    for (NSString *foundMessageId in [self.messageIds allObjects]) {
        if ([messageId isEqualToString:foundMessageId]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark - Options

- (void)didPressBackButton:(id)sender
{
    if (self.presentingViewController)
    {
        // Message thread view presented (e.g. by MessageSearchViewController)
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if (self.navigationController.navigationController)
    {
        // From within the detail navigation controller of the splitview navigation controller
        // Message thread view pushed (e.g. by EventSummaryViewController)
        [self.navigationController.navigationController popToRootViewControllerAnimated:YES];
    }
    else
    {   // Go back to conversation summary
        [self.mainViewController showConversationSummaryView:YES];
    }
}

- (void)moreOptions
{
    /* Hide the input bar */
    [self.inputBarViewController.view endEditing:YES];

    UIAlertController* actionSheet = [UIAlertController
                                      alertControllerWithTitle:nil
                                      message:nil
                                      preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* defaultAction = [UIAlertAction
                                    actionWithTitle:BILocalizedString(@"Cancel")
                                    style:UIAlertActionStyleCancel
                                    handler:^(UIAlertAction * action) {
                                        // restore the correct first responder
                                        [self assignFirstResponder];
                                    }];

    
    
    UIAlertAction *callRoom = nil;
    UIAlertAction * showProfileAction = nil;
//    UIAlertAction *joinRoom = nil;
    if ([self.conversation isPersonConversation])
    {
        showProfileAction = [UIAlertAction
                             actionWithTitle:BILocalizedString(@"View Profile")
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action) {
                                 [self showProfile];
                             }];

        // Add My Room functionality only if my room is available for the contact.
        BIContact *contact = [BIContact contactWithPerson:self.person];
        if([contact myRoom]) {
            callRoom = [UIAlertAction actionWithTitle:BILocalizedString(@"Call Room")
                                                style:UIAlertActionStyleDefault
                                              handler:^(UIAlertAction *action) {
                                                  [self callRoom];
                                                  // restore the correct first responder
                                                  [self assignFirstResponder];
                                              }];
        }

//Uncomment to check if meet App is installed and open that App
//        if ([self isMeetAppInstalled]) {
//            joinRoom = [UIAlertAction actionWithTitle:BILocalizedString(@"Join Room…")
//                                                style:UIAlertActionStyleDefault
//                                              handler:^(UIAlertAction *action) {
//                                                  //TODO: Join Room, Open Meet App
//                                              }];
//        }
        
    }


    
    [actionSheet addAction:defaultAction];
    if (callRoom)  {
        [actionSheet addAction:callRoom];
    }
    if (showProfileAction) {
        [actionSheet addAction:showProfileAction];
    }

    #ifdef DEBUG
    UIAlertAction* refresh = [UIAlertAction
                              actionWithTitle:BILocalizedString(@"Get New Messages")
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action) {
                                  [[BIUmsRequestManager sharedInstance]
                                   queryMessageHistory:^(BIRequestOperation *operation) {
                                       [self scrollToMostRecent:YES];
                                   }
                                   onFailure:nil];
                                  // restore the correct first responder
                                  [self assignFirstResponder];
                              }];
    [actionSheet addAction:refresh];
    #endif

    /**
       The code below is used to anchor the action sheet when running in iPad.
       Uncomment when iPad is supported. JSantana.

    actionSheet.modalPresentationStyle = UIModalPresentationPopover;
    UIPopoverPresentationController *popPresenter = [actionSheet popoverPresentationController];
    popPresenter.sourceView = self.navigationController.navigationBar;
    popPresenter.sourceRect = self.navigationController.navigationBar.bounds;
     */

    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (void)call
{
    BIContact *contact = [BIContact contactWithPerson:self.person];
    [[BICallingMediator sharedInstance] callContact:contact atNumber:contact.phoneNumber];
}

- (void)callRoom
{
    BIContact *contact = nil;
    if ([self.conversation isPersonConversation]) {
        contact = [BIContact contactWithPerson:self.person];
    }
    else if([self.conversation isGroupConversation]) {
        BIGroupConversation *group = (BIGroupConversation *)self.conversation;
        if([group groupConversationType] == BIMyRoomConversation) {
            contact = [BIContact contactWithPerson:[group owner]];
        }
    }

    if ([contact myRoom]) {
        [[BICallingMediator sharedInstance] callContact:contact atRoom:contact.myRoom];
    }
}

- (void)showProfile
{
    BIProfileViewController *detailVC = [BIProfileViewController initWithProfileStyle:BIContactProfileDisplayStyle];
    detailVC.contact = self.person;
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (void)showGroupParticipants
{
    if ([self.conversation isGroupConversation])
    {
        BIGroupConversation *groupConversation = (BIGroupConversation *)self.conversation;
        BIGroupParticipantsViewController *participantsVC = nil;

        switch ([groupConversation groupConversationType])
        {
            case BIOutgoingGroupAlertConversation:
                participantsVC = [[BIGroupParticipantsViewController alloc] initWithTitle:BILocalizedString(@"Recipients")];
                break;
            case BIGroupAliasConversation:
                participantsVC = [[BIGroupParticipantsViewController alloc] initWithTitle:BILocalizedString(@"Participants")];
                break;
            default:
                BSLogDebug(BILogAppModule, @"Unexpected group type %@", @([groupConversation groupConversationType]));
                break;
        }

        if (participantsVC)
        {
            participantsVC.participants = [groupConversation membersSortedByCompositeName:self.myMessagingId];
            [self.navigationController pushViewController:participantsVC animated:YES];
        }
    }
}

#pragma mark - scrolling

- (void)scrollToMostRecent:(BOOL)animated
{
    NSInteger section = 0;
    if (self.fetchedResultsController) {
        id<NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
        if ([sectionInfo numberOfObjects] - 1 > 0) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:([sectionInfo numberOfObjects] - 1) inSection:section];

            /* Normally you would use UITableViewScrollPositionBottom to scroll row to the bottom of the table's view. But
               using bottom triggers the table to load lots of rows and it is time consuming, seoconds for long threads of messages.
               You expect it load only those that will be shown in the screen. Using in the other hand UITableViewScrollPositionMiddle 
               does just that, loads only the rows that will be shown and the last row is placed at the bottom, I guess the tableView
               does some validation where it checks the resulting content offset is below the max valid offset and uses max. */
            [self scrollToIndexPath:indexPath position:UITableViewScrollPositionMiddle animated:animated];
        }
    }
}


- (void)scrollToMessageWithId:(NSString *)messageId
{
    NSInteger section = 0;
    if (self.fetchedResultsController) {
        id<NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
        for (int i = 0; i < [sectionInfo numberOfObjects] ; i++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:section];
            BIMessage *message = [self.fetchedResultsController objectAtIndexPath:indexPath];
            if ([[message eventId] isEqualToString:messageId])
            {
                [self scrollToIndexPath:indexPath position:UITableViewScrollPositionMiddle animated:YES];
                break;
            }
        }
    }
}

- (void)scrollToIndexPath:(NSIndexPath *)indexPath position:(UITableViewScrollPosition)tableScrollPosition animated:(BOOL)animated
{
    // Trying to avoid accessing an outdated/invalid indexPath. IRIS-521
    if (![self.tableView indexPathIsValid:indexPath]) { return; }

    /* There seems to be a bug when using scrollToRowAtIndexPath when using rows with automatic sizing.
     The final position is often not accurate. There's some workarounds as mentioned in following thread:

     http://stackoverflow.com/questions/25686490/ios-8-auto-cell-height-cant-scroll-to-last-row

     Doing two calls here to the same API and seems to work.
     */

    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:tableScrollPosition animated:animated];

    /* Second call almost immediately after the first one */
    int64_t delay = 0.1 * NSEC_PER_SEC;
    dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, delay);
    dispatch_after(time, dispatch_get_main_queue(), ^{
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:tableScrollPosition animated:animated];
    });
}

#pragma mark - Keyboard methods

- (void)dismissKeyboard
{
    [self.inputBarViewController dismissKeyboard];
    self.selectedMessageId = nil;
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (void)keyboardWillShow:(NSNotification*)notification
{
    NSDictionary* info = [notification userInfo];
    CGRect r = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    r = [self.view convertRect:r toView:nil];

    /* When using a Bluetooth keyboard or using the computer keyboard in the simulator
       the frame of the keyboard is offscreen. We make adjustments for the entire keyboard
       frame only when there is an actualy keyboard shown in the screen. Otherwise only for 
       input bar. */
    BOOL showingKeyboardView = r.origin.y < CGRectGetHeight(self.view.window.bounds);

    CGFloat heightEnd = 0;
    if (showingKeyboardView) {
        heightEnd = CGRectGetHeight(r);
    }
    else {
        heightEnd = CGRectGetHeight(self.inputBarViewController.messageInputBarView.bounds);
    }

    [self adjustTableViewContent:heightEnd];
}

- (void)keyboardWillHide:(NSNotification*)notification
{
    /* Keyboard is hiding, the table needs to readjust insets and offsets.
       The keyboard (and its input accessory view) will endup with only the height
       of the accessory view (inputBarView) */
    [self adjustTableViewContent:CGRectGetHeight(self.inputBarViewController.messageInputBarView.bounds)];
}

- (void)adjustTableViewContent:(CGFloat)newInputBarHeight
{
    if (self.lastKnownKeyboardHeight == newInputBarHeight) return;

    CGFloat originalBottomContentInset = self.tableView.contentInset.bottom;
    CGFloat originalVerticalContentOffset = self.tableView.contentOffset.y;

    /* Change the bottom inset to be the height of the keyboard (along with the input bar view) */
    UIEdgeInsets tableInsets = self.tableView.contentInset;
    tableInsets.bottom = newInputBarHeight;
    if (self.isHubEnabled) {
        // push the bubbles a bit higher to make room for the dots shown by the UIPageControl.
        tableInsets.bottom += ceil(CGRectGetHeight(self.pageControl.subviews[0].bounds)) + pageControlPaddingTop;
    }
    self.tableView.contentInset = tableInsets;
    self.tableView.scrollIndicatorInsets = tableInsets;

    /* When the keyboard is being hidden and height of the keyboard is less than the height to the 
       bottom of the content bottom, and the bottom inset is modified, the table adjusts the vertical 
       content offset automatically. Conversely, when the view is at any other position changing 
       changing the content inset, the table does not adjust the vertical content offset, we have to do it*/
    if (originalVerticalContentOffset == self.tableView.contentOffset.y) {
        /* Content Offset is only necessary when the content is greater than the view */
        if (self.tableView.contentSize.height > (CGRectGetHeight(self.tableView.bounds) - newInputBarHeight)) {
            /* Calculate the Y position of the last visible portion of the content area.
               We have to compare the content height vs the view size, otherwise we may offset more than needed */
            CGFloat lastVisiblePoint = self.tableView.contentOffset.y +
            MIN(self.tableView.contentSize.height,
                (CGRectGetHeight(self.tableView.bounds) - originalBottomContentInset));

            /* The table content bottom inset changed. We need a new content Y offset.
             Simply isolate the contentOffsetY from the initial calculation to obtain the new vertical offset */
            CGFloat newOffsetY = lastVisiblePoint -
            MIN(self.tableView.contentSize.height,
                (CGRectGetHeight(self.tableView.bounds) - self.tableView.contentInset.bottom));

            /* Set the new content offset Y, which will cause the bottom part to always be pinned to input bar */
            CGPoint tableOffset = self.tableView.contentOffset;
            tableOffset.y = newOffsetY;
            self.tableView.contentOffset = tableOffset;
        }
    }

    self.lastKnownKeyboardHeight = newInputBarHeight;

    if (self.isHubEnabled) {
        // Adjust the constraint used to layout the UIPageControl view. (the dots).
        [self.view setNeedsUpdateConstraints];
    }
}

#pragma mark - Message / Conversation Functions

- (void)markConversationRead
{
    [[BIUmsRequestManager sharedInstance] markConversationRead:self.conversation.conversationId
                                                    onSuccess:nil
                                                   onFailure:nil];
}

- (void)markMessageRead:(NSString *)messageId
{
    if (self.shouldMarkRead)
    {
        // This will be called for every message added by the FRC via
        // controller:didChangeObject:atIndexPath:forChangeType:newIndexPath:
        //
        // Attempt to reduce the number of messages we send the UMS by inserting a short
        // delay before processing the request.
        @synchronized(self)
        {
            [self.markReadQueue enqueue:messageId];
            [self performSelector:@selector(processMarkReadQueue) withObject:nil afterDelay:0.5f];
        }
    }
}

- (void)processMarkReadQueue
{
    NSArray *messageIds = nil;

    @synchronized(self)
    {
        if (self.markReadQueue.count > 0)
        {
            messageIds = [self.markReadQueue copy];
            self.markReadQueue = nil;
        }
    }

    if (messageIds.count > 0)
    {
        [[BIUmsRequestManager sharedInstance] markMessagesRead:messageIds
                                                   onSuccess:nil
                                                   onFailure:nil];
    }
}

- (void)scrollToMessageOnFetch
{
    if ((self.messageIds.count > 0) && (self.latestFoundMessageId.length > 0)) {
        /* Messages found during search */
        [self scrollToMessageWithId:self.latestFoundMessageId];
    }
    else {
        [self scrollToMostRecent:NO];
    }
}

- (void)fetchEvents
{
    if (self.fetchedResultsController && !self.needsToCheckForNewMessagesNextTimeShowing)
    {
        [self.tableView reloadData];
    }
    else if ([self createFetchedResultsController])
    {
        NSError *error = nil;
        [self.fetchedResultsController performFetch:&error];
        
        if (error)
        {
            BSLogError(BILogDBModule, @"Error fetching from DB: %@\n%@", error.localizedDescription, error);
        }
        else
        {
            // load the table
            [self.tableView reloadData];

            // submit analytics
            NSUInteger count = [[[self.fetchedResultsController sections] firstObject] numberOfObjects];
            if ([self.conversation isPersonConversation])
            {
                BIInternalAnalyticsEvent *event =
                    [BIInternalAnalyticsEvent
                     openPersonConversationAnalyticEvent:(BIPersonConversation *)self.conversation
                     count:@(count)];
                BISubmitInternalAnalytic(event);
            }
            else
            {
                BIInternalAnalyticsEvent *event =
                    [BIInternalAnalyticsEvent
                     openGroupConversationAnalyticEvent:(BIGroupConversation *)self.conversation
                     count:@(count)];
                BISubmitInternalAnalytic(event);
            }

            // mark read
            [self markConversationRead];
        }
    }
    else
    {
        BSLogInfo(BILogUIModule, @"DB not yet created or unable to fetch conversation messages!");
    }
}

-(BISurroundingMessages)getSurroundingMessagesForIndex:(NSIndexPath *) indexPath
{
    BISurroundingMessages messages;
    messages.previous = nil;
    messages.current = nil;
    messages.next = nil;

    // previous
    if (indexPath.row > 0)
    {
        NSIndexPath *prevPath = [NSIndexPath indexPathForRow:indexPath.row - 1 inSection:indexPath.section];
        messages.previous = [self.fetchedResultsController objectAtIndexPath:prevPath];
    }

    // get the current message
    messages.current = [self.fetchedResultsController objectAtIndexPath:indexPath];

    // next
    NSUInteger count = [[[self.fetchedResultsController sections] objectAtIndex:indexPath.section] numberOfObjects];
    if (indexPath.row + 1 < count)
    {
        NSIndexPath *nextPath = [NSIndexPath indexPathForRow:indexPath.row + 1 inSection:indexPath.section];
        messages.next = [self.fetchedResultsController objectAtIndexPath:nextPath];
    }

    return messages;
}

- (BIBalloonSequence)balloonShapeForMessageInSurroungingMessages:(BISurroundingMessages)messages
{
    if (messages.previous == nil) return BIBalloonSequenceFirst;

    BIMessage *previous = messages.previous;
    BIMessage *message = messages.current;

    // determine the balloon shape based on relation with previous and next
    if ([message.sender.personId isEqualToString:previous.sender.personId])
    {
        BIMessage *next = messages.next;
        if ([message.sender.personId isEqualToString:next.sender.personId]) {
            return BIBalloonSequenceMiddle;
        }
        else {
            return BIBalloonSequenceLast;
        }
    }
    else
    {
        return BIBalloonSequenceFirst;
    }
}

- (void)sendMessage:(NSString *)message
{
    BIMessageData *messageData = [BIMessageData new];

    // set the message body
    messageData.body = message;

    // set the sender
    messageData.sender = self.myMessagingId;

    // set the type and recipient(s)
    if ([self.conversation isPersonConversation] && (self.person.impId.length > 0))
    {
        // set the type
        messageData.type = BIChatMessage;
        messageData.receiver = self.person.impId;
    }
    else if ([self isConversationGroupAlertOutgoing])
    {
        messageData.type = BIOutgoingGroupAlertMessage;
        BIGroupConversation *group = (BIGroupConversation *)self.conversation;
        messageData.recipients = [group memberImpIds];
    }
    else
    {
        messageData.type = BIGroupAliasMessage;
        BIGroupConversation *group = (BIGroupConversation *)self.conversation;
        messageData.recipients = [group memberImpIds];
    }

    // send the message; scroll to the end of necessary
    BOOL scrollToLast = ![self lastRowIsVisible];

    BOOL success = [[BIUmsRequestManager sharedInstance]
                    sendChatMessage:messageData
                    onSuccess:^(BIRequestOperation *operation) {

                        self.inputBarViewController.messageInputBarView.messageText = nil;
                        self.inputBarViewController.enabled = YES;

                        if (scrollToLast) {
                            [self scrollToMostRecent:YES];
                        }

                    } onFailure:^(BIRequestOperation *operation) {

                        self.inputBarViewController.enabled = YES;

                    }];
    if (success)
    {
        self.inputBarViewController.enabled = NO;
    }
}

- (void)messageFailedActions:(UIGestureRecognizer *)gesture
{
    /* Hide the input bar */
    [self.inputBarViewController.view endEditing:YES];

    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:BILocalizedString(@"Unable to deliver message.")
                                                                         message:nil
                                                                  preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *tryAgain = [UIAlertAction actionWithTitle:@"Try Again"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action) {
                                                         // get the failed message
                                                         NSIndexPath *indexPath = [NSIndexPath indexPathForRow:gesture.view.tag inSection:0];
                                                         BIMessage *failedMessage = [self.fetchedResultsController objectAtIndexPath:indexPath];
                                                         // attempt to resend
                                                         [[BIUmsRequestManager sharedInstance] resendChatMessage:failedMessage.eventId
                                                                                                     onSuccess:nil
                                                                                                     onFailure:nil];

                                                         // restore the correct first responder
                                                         [self assignFirstResponder];
                                                     }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel"
                                                     style:UIAlertActionStyleCancel
                                                   handler:^(UIAlertAction *action) {
                                                       // restore the correct first responder
                                                       [self assignFirstResponder];
                                                   }];
    [actionSheet addAction:tryAgain];
    [actionSheet addAction:cancel];
    [self presentViewController:actionSheet
                       animated:YES
                     completion:nil];
}

#pragma mark - NSFetchRequestDelegate

- (BOOL)lastRowIsVisible
{
    // get the last row index
    id<NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] lastObject];
    NSInteger lastIndex = [sectionInfo numberOfObjects] - 1;
    
    NSArray *indexes = [self.tableView indexPathsForVisibleRows];
    for (NSInteger idx = indexes.count - 1; idx >= 0; --idx)
    {
        NSIndexPath *path = [indexes objectAtIndex:idx];
        if (path.row == lastIndex) {
            return YES;
        }
    }
    return NO;
}

- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller
{
    self.scrollToMostRecentAfterUpdate = [self lastRowIsVisible];
}

-(void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView reloadData];
    dispatch_main_async(^{
        if (self.scrollToMostRecentAfterUpdate) {
            [self scrollToMostRecent:NO];
        }
    });
}

- (void)controller:(NSFetchedResultsController *)controller
   didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath
     forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath
{
    if (type == NSFetchedResultsChangeInsert)
    {
        if ([anObject isKindOfClass:[BIMessage class]])
        {
            BIMessage *message = (BIMessage *)anObject;
            [self markMessageRead:message.eventId];
        }
    }
}

#pragma mark - Set Screen Title

- (void)initScreenTitle
{
    if ([self showsPresenceView])
    {
        self.navigationItem.titleView = self.presenceTitleView;
    }
    else
    {
        self.navigationItem.titleView = nil;
    }
    [self updateScreenTitle];
}

- (void)updateScreenTitle
{
    if ([self.conversation isPersonConversation])
    {
        BIPersonConversation *pc = (BIPersonConversation *)self.conversation;

        self.presenceTitleView.name     = [pc.person firstLastName];
        self.presenceTitleView.presence = [BIPresenceData presenceDataForPresence:self.person.presence];
    }
    else
    {
        BIGroupConversation *gc = (BIGroupConversation *)self.conversation;
        if ([gc groupConversationType] == BIGroupAliasConversation)
        {
            self.title = BILocalizedString(@"Group Messaging");
        }
        else if ([gc groupConversationType] == BIOutgoingGroupAlertConversation)
        {
            self.title = BILocalizedString(@"Broadcast");
        }
        else if ([gc groupConversationType] == BIMyRoomConversation)
        {
            self.presenceTitleView.name     = [gc displayFirstLastName:self.myMessagingId];
            self.presenceTitleView.presence = [BIPresenceData presenceDataForPresence:self.person.presence];
        }
        else
        {
            self.title = [gc displayFirstLastName:self.myMessagingId];
        }
    }
}

#pragma mark - BIMessageInputBarViewControllerDelegate Methods

- (void)messageInputBarViewControllerDidPressSubmit:(BIMessageInputBarViewController *)controller
                                           withText:(NSString *)messageText
{
    [self sendMessage:messageText];
}

#pragma mark - Gesture Recognizer Methods

-(NSMutableSet *)rowBeingAnimatedSet
{
    if (!_rowBeingAnimatedSet) {
        _rowBeingAnimatedSet = [[NSMutableSet alloc] initWithCapacity:20];
    }
    return _rowBeingAnimatedSet;
}

- (void)showMessageTimeAtIndexPath:(UITapGestureRecognizer *)gesture
{
    NSInteger rowIndex = gesture.view.tag;

    @synchronized (self.rowBeingAnimatedSet) {
        // ongoing animation, don't start a second one.
        if ([self.rowBeingAnimatedSet containsObject:@(rowIndex)]) return;

        [self.rowBeingAnimatedSet addObject:@(rowIndex)];
    }

    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:rowIndex inSection:0];
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    BIMessageBaseView *messageView = cell.contentView.subviews[0];

    if (messageView.timeStampInterval != nil) {
        /* Reuse the existing (precomputed) string */
        messageView.timeStamp = messageView.timeStampInterval;
    }
    else {
        BIMessage *message = [self.fetchedResultsController objectAtIndexPath:indexPath];
        messageView.timeStamp = [[message date] relativeShortDateTimeString];
    }

    /* This will assign a value to the timeStamp label text
    and set the alpha value to 0.01, just enough for beginUpdates/endUpdates
    to adjust the cell height to show the timeStamp label. */
    messageView.timeStampVisible = YES;
    /* Adjust cell height to make room for timeStamp label */
    [self.tableView beginUpdates];
    [self.tableView endUpdates];

    /* When it is the last row the time stamp is not visible.
       Need to adjust the offset of the table to make the time stamp label visible. */
    BOOL modifiedTableOffset = NO;
    NSArray *visibleIndexRows = [self.tableView indexPathsForVisibleRows];
    if ([indexPath isEqual:[visibleIndexRows lastObject]]) {
        CGPoint tableOffset = self.tableView.contentOffset;
        tableOffset.y += [messageView getTimeStampRowHeight];
        [self.tableView setContentOffset:tableOffset animated:YES];
        modifiedTableOffset = YES;
    }

    [UIView animateWithDuration:0.1f
                          delay:0.4f
                        options:UIViewAnimationOptionTransitionFlipFromTop animations:^{

                            messageView.timeStampLabel.alpha = 1.f;

                        }
                     completion:^(BOOL finished) {

                         /* Animate the fade out of the timeStamp */
                         [UIView animateWithDuration:0.2f
                                               delay:2.f
                                             options:UIViewAnimationOptionTransitionFlipFromBottom
                                          animations:^{
                                                 messageView.timeStampLabel.alpha = 0.f;
                                             }
                                          completion:^(BOOL finished) {
                                              /* Repaint the cell once the timestamp is not visible anymore,
                                               height has returned to original value */
                                              messageView.timeStampVisible = NO;
                                              if (modifiedTableOffset) {
                                                  CGPoint tableOffset = self.tableView.contentOffset;
                                                  tableOffset.y -= [messageView getTimeStampRowHeight];
                                                  [self.tableView setContentOffset:tableOffset animated:YES];
                                              }
                                              else {
                                                  [self.tableView beginUpdates];
                                                  [self.tableView endUpdates];
                                              }

                                              // Finished amination. Remove it so another animation on the same row can be done.
                                              @synchronized (self.rowBeingAnimatedSet) {
                                                  [self.rowBeingAnimatedSet removeObject:@(rowIndex)];
                                              }
                                          }];
                     }];
}

- (void)didTapCellAvatar:(UITapGestureRecognizer *)gesture
{
    if (gesture.state == UIGestureRecognizerStateEnded)
    {
        // Get the sender of the tapped message.
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:gesture.view.tag inSection:0];
        BIMessage *message = [self.fetchedResultsController objectAtIndexPath:indexPath];
        BIPerson *senderPerson = message.sender;

        BIProfileViewController *detailVC = [BIProfileViewController initWithProfileStyle:BIContactProfileDisplayStyle];
        detailVC.contact = senderPerson;
        [self.navigationController pushViewController:detailVC animated:YES];

        // restore the correct first responder
        [self assignFirstResponder];
    }
}

#pragma mark - Copy/Cut operations

- (void)didSelectCell:(UILongPressGestureRecognizer *)tap
{
    if (!self.inputBarViewController.keyboardShowing && (tap.state == UIGestureRecognizerStateBegan))
    {
        UIView* balloonView = tap.view;
        BIMessageBaseView* messageView = (BIMessageBaseView*)tap.view.superview;

        /* Setting selected to YES triggers a balloon relayout and paints it as selected */
        messageView.selected = YES;
        self.isCopyingCell = YES;
        self.copyingRowNumber = messageView.tag;
        self.copiedText = messageView.message;

        dispatch_main_async(^{
            UIMenuController *menu = [UIMenuController sharedMenuController];
            [menu setTargetRect:balloonView.frame inView:messageView];
            [menu setMenuVisible:YES animated:YES];
        });
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (self.isCopyingCell) {
        return (action == @selector(copy:));
    }
    else {
        return [super canPerformAction:action withSender:sender];
    }
}

- (void)copy:(id)sender
{
    if (self.isCopyingCell)
    {
        UIPasteboard *clipBoard = [UIPasteboard generalPasteboard];
        clipBoard.string = self.copiedText;
    }
}

- (void)menuDidHide:(NSNotification *)notification
{
    if (self.isCopyingCell)
    {
        self.isCopyingCell = NO;
        self.selectedMessageId = nil;

        NSIndexPath *selectedIndexPath = [NSIndexPath indexPathForRow:self.copyingRowNumber inSection:0];
        [self.tableView reloadRowsAtIndexPaths:@[selectedIndexPath] withRowAnimation:NO];

        self.copyingRowNumber = -1;
    }
}

- (BOOL)canAutoRotate
{
    return YES;
}

@end
