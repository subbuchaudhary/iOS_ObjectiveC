//
//  CustomerActivationModel.h
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"

@interface CustomerActivationModel : TransactionModel

@property (nonatomic, strong) NSDictionary *dataDict;

- (id)initWithData:(NSDictionary *)data;

@end
