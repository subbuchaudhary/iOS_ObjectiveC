//
//  DealsListModel.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "DealsListModel.h"
#import "DealsDetailsModel.h"

@implementation DealsListModel

- (id)initWithData:(NSDictionary *)data {
    
    NSDictionary *transDict = data[@"transaction"];
    self.status = transDict[@"status"];
    self.message = transDict[@"message"];
    self.errors = transDict[@"errors"];
    self.warnings = transDict[@"warnings"];

    NSArray *dealsArr = data[@"deals"];
    NSMutableArray *dealsMutArr = [NSMutableArray array];
    for (NSDictionary *dealsDict in dealsArr) {
        DealsDetailsModel *dealsDetailModel = [[DealsDetailsModel alloc]initWithData:dealsDict];
        [dealsMutArr addObject:dealsDetailModel];
    }
    self.dealsListArr = dealsMutArr.copy;
    
    return self;
}

@end
