//
//  YokuCommonClass.m
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "YokuCommonClass.h"

@implementation YokuCommonClass


#pragma mark for Give some space for TxtField

+(void)TextViewPadding:(UITextField*)txt{
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    paddingView.backgroundColor=[UIColor clearColor];
    txt.leftView = paddingView;
    txt.leftViewMode = UITextFieldViewModeAlways;
    
}

@end