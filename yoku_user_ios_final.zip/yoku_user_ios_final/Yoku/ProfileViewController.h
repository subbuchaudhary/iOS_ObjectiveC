//
//  ProfileViewController.h
//  Yoku
//
//  Created by Ramesh on 11/12/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileViewController : UIViewController
- (IBAction)editProfileBtnAction:(id)sender;

@end
