//
//  ResetPasswordViewController.m
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "ResetPasswordViewController.h"
#import "UITextField+ContinerImageView.h"

@interface ResetPasswordViewController ()

@property (nonatomic, weak) IBOutlet UITextField *emailTxtFld;

@end

@implementation ResetPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.emailTxtFld setLeftImageView:@"email"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
