//
//  BIMessageThreadViewController.h
//  MessageList
//
//  Created by Angel Wingartz on 2/13/15.
//  Copyright (c) 2015 BroadSoft, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "BIModel.h"

@class BIMainViewController;

@interface BIMessageThreadViewController : UIViewController <
    UITableViewDataSource,
    UITableViewDelegate,
    UITextFieldDelegate,
    UIGestureRecognizerDelegate
>

@property (weak, nonatomic) BIMainViewController *mainViewController;
@property (strong, nonatomic) NSString *name;
//@property (strong, nonatomic) BIConversation *conversation;
@property (strong, nonatomic) NSSet *messageIds;
@property (strong, nonatomic) NSString *latestFoundMessageId;

/* Flag to trigger the fetch of new events next time the view is showed.
   The flag is reset to NO, after the fetch. */
@property (assign, nonatomic) BOOL needsToCheckForNewMessagesNextTimeShowing;

/**
 Sends the text in the typing view to the current thread user
 @param the message text
 */
- (void)sendMessage:(NSString *)message;

/**
 Scrolls to the most recent message in the list.
 @param animated @c YES to animate the scroll
 */
- (void)scrollToMostRecent:(BOOL)animated;

- (void)scrollToMessageWithId:(NSString *)messageId;

- (BOOL)canAutoRotate;

float heightForStringDrawing(NSString *myString, UIFont *myFont, float myWidth);

@end
