//
//  CustomerRegistrationModel.h
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"

@interface CustomerRegistrationModel : TransactionModel

@property (nonatomic, strong) NSString *registrationId;
@property (nonatomic, strong) NSString *otpRefNo;


- (id)initWithData:(NSDictionary *)data;
@end
