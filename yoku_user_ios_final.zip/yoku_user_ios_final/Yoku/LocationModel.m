//
//  LocationModel.m
//  Yoku
//
//  Created by Ramesh on 10/30/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "LocationModel.h"

@implementation LocationModel

@end
