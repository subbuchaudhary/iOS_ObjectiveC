//
//  Constant.h
//  StripeIntegrationIniOS
//
//  Created by TheAppGuruz-iOS-103 on 16/11/15.
//  Copyright © 2015 TheAppGuruz. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

// This can be found at https://dashboard.stripe.com/account/apikeys
NSString *const kstrStripePublishableKey = @"pk_test_JB56ksyKv9aaX0GnGNAvGyfr"; // TODO: replace nil with your own value

#endif /* Constant_h */
