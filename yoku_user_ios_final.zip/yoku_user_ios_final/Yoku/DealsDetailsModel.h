//
//  DealsDetails.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DealsDetailsModel : NSObject

@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *dealDescription;
@property (nonatomic, strong) NSString *endsAt;
@property (nonatomic, strong) NSString *totalClaims;
@property (nonatomic, strong) NSString *dealId;
@property (nonatomic, strong) NSNumber *claimPerCustomer;
@property (nonatomic, strong) NSString *merchantId;
@property (nonatomic, strong) NSString *instructions;
//@property (nonatomic, strong) NSDictionary *additionalInfo;
@property (nonatomic, strong) NSString *beginsAt;
@property (nonatomic, strong) NSString *dealType;
@property (nonatomic, strong) NSNumber *activeClaims;
@property (nonatomic, strong) NSNumber *claimExpiryDuration;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *initiatedAt;
@property (nonatomic, strong) NSNumber *percentOff;
@property (nonatomic, strong) NSNumber *redeemed;
@property (nonatomic, strong) NSString *transaction;

- (id)initWithData:(NSDictionary *)data;

@end
