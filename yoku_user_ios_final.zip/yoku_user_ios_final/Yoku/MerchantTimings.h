//
//  MerchantTimings.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"
#import "MerchantBusinessTimings.h"

@interface MerchantTimings : NSObject

@property (nonatomic, strong) NSString *dayNameStr;
@property (nonatomic, strong) MerchantBusinessTimings *businessTimes;

- (id)initWithData:(NSDictionary *)data andName:(NSString *)name;

@end
