//
//  RestServiceCalss.m
//  Yoku
//
//  Created by Ramesh on 10/27/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "RestService.h"
#import "NSDictionary+URL.h"
#import "TransactionModel.h"
#import "CustomerRegistrationModel.h"
#import "CustomerActivationModel.h"
#import "CustomerLoginModel.h"
#import "CustomerDetailsModel.h"
#import "MerchantLocation.h"
#import "MerchantList.h"
#import "DealsListModel.h"
#import "UserAuthModel.h"
#import "HelperClass.h"
#import "DealClimeDetailsModel.h"
#import "CustomerProfileModel.h"


#define BASE_URL @"http://ec2-54-87-130-84.compute-1.amazonaws.com:8080/yoku/v1"

@implementation RestService

+ (void)sendAPICommand:(enum APICommandList)command methodType:(enum MethodType)Type withArgument:(NSArray *)arguments paramas:(NSData *)postData withHeaders:(NSArray *)headers isAuthRequired:(BOOL)isAuth withHandler:(CompleationHandler)handler  {
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSString *urlStr = [NSDictionary getURLString:command withArguments:arguments];
    UserAuthModel *authModel = [UserAuthModel sharedInstance];

    urlStr = [NSString stringWithFormat:@"%@%@",BASE_URL,urlStr];
    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"\""];
    urlStr = [[urlStr componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString:@""];
    NSString *escapedPath = [urlStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];

    NSURL *url = [NSURL URLWithString:escapedPath];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60];
    
    [request setHTTPMethod:[RestService getMethodType:Type]];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    if (isAuth) {
        [request setValue:authModel.authToken forHTTPHeaderField:@"auth-token"];
        [request setValue:[HelperClass getUDID] forHTTPHeaderField:@"device-hash"];
    }
    if (command == CL_CUSTOMER_ACTIVATE || command == CL_RESEND_OTP_CUSTOMER) {
        [request setValue:headers[0] forHTTPHeaderField:@"otp-ref-no"];
        if (command == CL_CUSTOMER_ACTIVATE) {
            [request setValue:headers[1] forHTTPHeaderField:@"otp-val"];
            [request setValue:[HelperClass getUDID] forHTTPHeaderField:@"deviceId"];
        }
    }
    
    if (postData) {
        [request setHTTPBody:postData];
        [request setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[postData length]] forHTTPHeaderField:@"Content-Length"];
    }
    
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (!error)
        {
            NSError *err;
            NSLog(@"responce = %@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
            NSDictionary *jsonObj = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&err];
            
            if (command == CL_CUSTOMER_LOGIN || command == CL_CUSTOMER_ACTIVATE) {
                NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                NSDictionary *resHeader = httpResponse.allHeaderFields;
                UserAuthModel *model = [UserAuthModel sharedInstance];
                model.authToken = resHeader[@"auth-token"];
                model.userHash = resHeader[@"user-hash"];
                NSLog(@"%@",model.userHash);
                NSLog(@"%@",model.authToken);
            }
            id responce = [self getParserModel:command withData:jsonObj];
            if (command == CL_CUSTOMER_REGISATER) {
                NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                NSDictionary *resHeader = httpResponse.allHeaderFields;
                CustomerRegistrationModel *model = responce;
                model.otpRefNo = resHeader[@"otp-ref-no"];
                responce = model;
            }
            handler(responce,error);
        }else{
            handler(nil,error);
        }
    }];
    [task resume];
}

+ (NSString *)getMethodType:(enum MethodType)type {
    NSString *methodType;
    switch (type) {
        case POST:
            methodType = @"POST";
            break;
        case GET:
            methodType = @"GET";
            break;
        case PUT:
            methodType = @"PUT";
            break;
        case DELETE:
            methodType = @"DELETE";
            break;
            
        default:
            break;
    }
    
    return methodType;
}

+ (id)getParserModel:(enum APICommandList)command withData:(NSDictionary *)resData{
    
    id model ;
    if (command == CL_CUSTOMER_REGISATER) {
        model =[[CustomerRegistrationModel alloc]initWithData:resData];
    }else if (command == CL_CUSTOMER_ACTIVATE) {
        model =[[CustomerActivationModel alloc]initWithData:resData];
    }else if (command == CL_CUSTOMER_LOGIN) {
        model =[[CustomerLoginModel alloc]initWithData:resData];
    }else if (command == CL_CUSTOMER_LOGOFF) {
    }else if (command == CL_FETCH_CUSTOMER_ALL_DETAILS) {
        model =[[CustomerDetailsModel alloc]initWithData:resData];
    }else if (command == CL_GET_CUSTOMER_LOCATION) {
        model =[[MerchantLocation alloc]initWithData:resData];
    }else if (command == CL_UPDATE_CUSTOMER_LOCATION) {
        model =[[TransactionModel alloc]initWithData:resData];
    }else if (command == CL_GET_NEARBY_MERCHANTS) {
        model =[[MerchantList alloc]initWithData:resData];
    }else if (command == CL_GET_NEARBY_DEALS) {
//         model =[[DealsListModel alloc]initWithData:resData];
    }else if (command == CL_SAVE_CUSTOMER_ADDRESS) {
        
    }else if (command == CL_UPDATE_CUSTOMER_ADDRESS) {
        
    }else if (command == CL_CUSTOMER_FETCH_NEARBY_MERCHANTS_LAT_LONG) {
        model =[[MerchantList alloc]initWithData:resData];
    }else if (command == CL_CUSTOMER_FETCH_NEARBY_MERCHANTS_ADDRESS) {
        model =[[MerchantList alloc]initWithData:resData];
    }else if (command == CL_CUSTOMER_CAN_CLAIM_DEALS_NOT_MORETHAN_THREE) {
        model = [[DealClimeDetailsModel alloc]initWithData:resData];
    }else if(command == CL_FETCH_CUSTOMER_PROFILE){
        model = [[CustomerProfileModel alloc]initWithData:resData];
    }

    return model;
    
//    switch (command) {
//        case CL_CUSTOMER_REGISATER:
//            CustomerRegistrationModel *model = [CustomerRegistrationModel alloc];
//            break;
//        case CL_CUSTOMER_ACTIVATE:
//            
//            break;
//        case CL_CUSTOMER_LOGIN:
//            
//            break;
//        case CL_GET_CUSTOMER_DETAILS:
//            
//            break;
//        case CL_UPDATE_CUSTOMER_DETAILS:
//            
//            break;
//        case CL_GET_CUSTOMER_LOCATION:
//            
//            break;
//        case CL_UPDATE_CUSTOMER_LOCATION:
//            
//            break;
//            
//        default:
//            break;
//    }
    
}

@end
