//
//  MyDealsTableViewCell.h
//  Yoku
//
//  Created by Ramesh on 11/11/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyDealsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *backGroundImgView;
@property (weak, nonatomic) IBOutlet UILabel *offerLbl;
@property (weak, nonatomic) IBOutlet UILabel *titleLbl;
@property (weak, nonatomic) IBOutlet UILabel *reviewsLbl;
- (IBAction)redeemBtnAction:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *locationLbl;
@property (weak, nonatomic) IBOutlet UIImageView *ratingImgView;
@property (weak, nonatomic) IBOutlet UILabel *ratingLbl;
@property (weak, nonatomic) IBOutlet UIImageView *addressImgView;

@end
