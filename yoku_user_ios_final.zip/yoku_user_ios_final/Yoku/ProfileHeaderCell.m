//
//  ProfileHeaderCell.m
//  Yoku
//
//  Created by Ramesh on 12/14/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "ProfileHeaderCell.h"

@implementation ProfileHeaderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
