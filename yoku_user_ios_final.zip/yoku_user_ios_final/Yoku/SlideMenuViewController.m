//
//  SlideMenuViewController.m
//  Yoku
//
//  Created by Ramesh on 11/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "SlideMenuViewController.h"
#import "RestService.h"
#import "ProfileHeaderCell.h"
#import "UserAuthModel.h"
#import "NSString+NullCheck.h"

#define RowCount 6

@interface SlideMenuViewController ()

@property (nonatomic, strong) NSArray *cellIdentifiersArr;

@end

@implementation SlideMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 250;
    self.cellIdentifiersArr = [NSArray arrayWithObjects:@"headerCell",@"paymentCell",@"settingCell",@"orderHistoryCell",@"conditionsCell",@"helpCell",@"logoutCell", nil];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (indexPath.row == 0) {
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"NavigateEditProfileView" object:nil];
//    }else if (indexPath.row == 1) {
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"NavigateEditProfileView" object:nil];
//    }else if (indexPath.row == 2) {
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"NavigateEditProfileView" object:nil];
//    }else if (indexPath.row == 3) {
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"NavigateEditProfileView" object:nil];
//    }else if (indexPath.row == 4) {
////        [RestService sendAPICommand:CL_CUSTOMER_LOGOFF methodType:DELETE withArgument:(NSArray *) paramas:<#(NSData *)#> isAuthRequired:NO withHandler:^(id responseObject, NSError *error) {
//        
////        }];
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"LeftMenuItemClicked:" object:@{@"indexpath":indexPath}];
//    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LeftMenuItemClicked" object:@{@"indexpath":indexPath}];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.cellIdentifiersArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 0) {
        UserAuthModel *userModel = [UserAuthModel sharedInstance];
        CustomerProfileModel *profileModel = userModel.userProfileModel;
        ProfileHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:self.cellIdentifiersArr[indexPath.row]];
//        cell.userPicImgView;
        cell.nameLbl.text = [profileModel.customerName checkNullValue];
        if ([profileModel.address isKindOfClass:[NSNull class]]) {
            cell.addressLbl.text = @"";
        }else{
            cell.addressLbl.text =  [profileModel.address checkNullValue];
        }
        cell.numOfDealsLbl.text = [NSString stringWithFormat:@"5 delas"];
        cell.ammountLbl.text = [NSString stringWithFormat:@"\u20B9 %.0f", profileModel.walletModel.walletAmount.doubleValue];
        return cell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:self.cellIdentifiersArr[indexPath.row]];
    
    return cell;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
