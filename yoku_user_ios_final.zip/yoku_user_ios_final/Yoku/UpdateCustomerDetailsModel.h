//
//  UpdateCustomerDetailsModel.h
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"

@interface UpdateCustomerDetailsModel : TransactionModel

@property (nonatomic, strong) NSDictionary  *location;

- (id)initWithData:(NSDictionary *)data;


@end
