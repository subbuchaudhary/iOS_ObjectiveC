//
//  OfferDetailsViewController.h
//  Yoku
//
//  Created by Ramesh on 11/13/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DealsDetailsViewController : UIViewController

@end
