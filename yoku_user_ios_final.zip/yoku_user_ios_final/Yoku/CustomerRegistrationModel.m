//
//  CustomerRegistrationModel.m
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "CustomerRegistrationModel.h"

@implementation CustomerRegistrationModel

- (id)initWithData:(NSDictionary *)data {
    
    if (data) {
        NSDictionary *transDict = data[@"transaction"];
        self.status = transDict[@"status"];
        self.message = transDict[@"message"];
        self.errors = transDict[@"errors"];
        self.warnings = transDict[@"warnings"];
        
//        NSDictionary *tempData = data[@"data"];
        self.registrationId = data[@"registrationId"];
    }
    
    
    return self;
}

@end
