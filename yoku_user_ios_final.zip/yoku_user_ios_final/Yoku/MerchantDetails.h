//
//  MerchantDetails.h
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TransactionModel.h"
#import "MerchantTimings.h"
#import "MerchantLocation.h"
#import "MerchantAddressDetails.h"


@interface MerchantDetails : NSObject

@property (nonatomic, strong) NSString *emailId;
@property (nonatomic, strong) NSDictionary *additionInfo;
@property (nonatomic, strong) NSString *businessType;
@property (nonatomic, strong) NSString *phoneNumber;
@property (nonatomic, strong) NSNumber *stripeAccountExists;
@property (nonatomic, strong) NSString *merchantName;
@property (nonatomic, strong) NSString *merchantPic;
@property (nonatomic, strong) MerchantAddressDetails *addressDetails;
@property (nonatomic, strong) NSArray *merchantTimings; // MerchantTimings;
@property (nonatomic, strong) NSString *wallet;
@property (nonatomic, strong) TransactionModel *transactionModel;
//@property (nonatomic, strong) MerchantLocation *merchantLocation;

- (id)initWithData:(NSDictionary *)data;

@end
