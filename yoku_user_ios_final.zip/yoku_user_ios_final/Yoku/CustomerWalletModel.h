//
//  CustomerWalletModel.h
//  Yoku
//
//  Created by Ramesh on 12/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomerWalletModel : NSObject

@property (nonatomic, strong) NSString *transaction;
@property (nonatomic, strong) NSNumber *walletAmount;

-(id)initWithData:(NSDictionary *)data;

@end
