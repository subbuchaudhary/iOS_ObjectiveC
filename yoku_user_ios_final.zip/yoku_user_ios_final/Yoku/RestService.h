//
//  RestServiceCalss.h
//  Yoku
//
//  Created by Ramesh on 10/27/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EnumList.h"


typedef void (^CompleationHandler)(id responseObject, NSError *error);

@interface RestService : NSObject


+ (void)sendAPICommand:(enum APICommandList)command methodType:(enum MethodType)Type withArgument:(NSArray *)arguments paramas:(NSData *)postData withHeaders:(NSArray *)headers isAuthRequired:(BOOL)isAuth withHandler:(CompleationHandler)handler;

@end
