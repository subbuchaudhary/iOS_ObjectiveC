//
//  MerchantTimings.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantTimings.h"
#import "MerchantBusinessTimings.h"

@implementation MerchantTimings

- (id)initWithData:(NSDictionary *)data  andName:(NSString *)name {
    
    self.dayNameStr = name;
    
    self.businessTimes = [[MerchantBusinessTimings alloc]initWithData:data];
    return self;
}

@end
