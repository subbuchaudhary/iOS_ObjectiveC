//
//  TransactionModel.m
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"

@implementation TransactionModel

- (id)initWithData:(NSDictionary *)data {
    
    self.status = data[@"status"];
    self.message = data[@"message"];
    self.errors = data[@"errors"];
    self.warnings = data[@"warnings"];
    return self;
}

@end
