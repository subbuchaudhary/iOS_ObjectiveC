//
//  FilterCollectionViewCell.h
//  Yoku
//
//  Created by Ramesh on 11/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilterCollectionViewCell : UICollectionViewCell

@property (nonatomic, weak) IBOutlet UIImageView *imgView;
@property (nonatomic, weak) IBOutlet UILabel *titleLbl;

@end
