//
//  CustomerProfileModel.h
//  Yoku
//
//  Created by Ramesh on 12/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "TransactionModel.h"
#import "CustomerWalletModel.h"

@interface CustomerProfileModel : TransactionModel

@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) NSString *customerName;
@property (nonatomic, strong) NSString *phoneNumber;
@property (nonatomic, strong) NSString *emailId;
@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) CustomerWalletModel *walletModel;
@property (nonatomic, strong) NSNumber *stripeAccountExists;

-(id)initWithData:(NSDictionary *)data;

@end
