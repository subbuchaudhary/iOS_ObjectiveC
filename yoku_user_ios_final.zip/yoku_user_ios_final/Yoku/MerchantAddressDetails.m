//
//  MerchantAddressDetails.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantAddressDetails.h"

@implementation MerchantAddressDetails

- (id)initWithData:(NSDictionary *)data {
    self.city = data[@"city"];
    self.country = data[@"country"];
    self.line1 = data[@"line1"];
    self.state = data[@"state"];
    self.landmark = data[@"landmark"];
    self.addressInFull = data[@"addressInFull"];
    self.merchantDescription = data[@"description"];
    self.merchantId = data[@"id"];
    self.line2 = data[@"line2"];
    self.location = [[MerchantLocation alloc]initWithData:data[@"location"]];
    self.title = data[@"title"];
    self.userId = data[@"userId"];
    self.userType = data[@"userType"];
    self.zipcode = data[@"zipcode"];
    
    return self;
}

@end
