//
//  CustomerProfileModel.m
//  Yoku
//
//  Created by Ramesh on 12/8/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "CustomerProfileModel.h"

@implementation CustomerProfileModel

-(id)initWithData:(NSDictionary *)data {
    
    NSDictionary *transactionDict = data[@"transaction"];
    self.status = transactionDict[@"status"];
    self.message = transactionDict[@"message"];
    self.errors = transactionDict[@"errors"];
    self.warnings = transactionDict[@"warnings"];
    
    self.userName = data[@"userName"];
    self.customerName = data[@"customerName"];
    self.phoneNumber = data[@"phoneNumber"];
    self.emailId = data[@"emailId"];
    self.address = data[@"address"];
    self.walletModel = [[CustomerWalletModel alloc]initWithData:data[@"wallet"]];
    self.stripeAccountExists = data[@"stripeAccountExists"];
    
    return self;
}

@end
