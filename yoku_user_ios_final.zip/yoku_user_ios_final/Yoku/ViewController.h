//
//  ViewController.h
//  Yoku
//
//  Created by Manoj Damineni on 22/10/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YokuCommonClass.h"

@interface ViewController : UIViewController
{
    __weak IBOutlet UIView *loginView;
    __weak IBOutlet UIButton *btnLogin;
    
    
}
@property (weak, nonatomic) IBOutlet UITextField *txtfldEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtfldPassword;


@end

