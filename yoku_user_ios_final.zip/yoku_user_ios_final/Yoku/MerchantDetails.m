//
//  MerchantDetails.m
//  Yoku
//
//  Created by Ramesh on 11/4/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "MerchantDetails.h"
#import "MerchantAddressDetails.h"
#import "MerchantTimings.h"

@implementation MerchantDetails

- (id)initWithData:(NSDictionary *)data {
    self.emailId = data[@"emailId"];
    self.additionInfo = data[@"additionalInfo"];
    self.businessType = data[@"businessType"];
    self.phoneNumber = data[@"phoneNumber"];
    self.merchantName = data[@"merchantName"];
    self.merchantPic =  data[@"merchant_pic"];
    self.stripeAccountExists = data[@"stripeAccountExists"];
    self.wallet = data[@"wallet"];
    self.transactionModel = [[TransactionModel alloc]initWithData:data[@"transaction"]];
    self.addressDetails = [[MerchantAddressDetails alloc]initWithData:data[@"address"]];
    
    NSDictionary *timingsArr = data[@"timings"];
    
    NSMutableArray *timingsMutArr = [NSMutableArray array];
    for (NSString *dayName in timingsArr.allKeys) {
        MerchantTimings *times = [[MerchantTimings alloc]initWithData:timingsArr[dayName] andName:dayName];
        [timingsMutArr addObject:times];
    }
    self.merchantTimings = [timingsMutArr copy];
//    self.merchantLocation = [[MerchantLocation alloc]initWithData:data[@"location"]];

    return self;
}

@end
