//
//  CustomerLoginModel.m
//  Yoku
//
//  Created by Ramesh on 10/28/16.
//  Copyright © 2016 Manoj Damineni. All rights reserved.
//

#import "CustomerLoginModel.h"

@implementation CustomerLoginModel

- (id)initWithData:(NSDictionary *)data {
    if (data) {
       NSDictionary *transDict = data[@"transaction"];
        self.status = transDict[@"status"];
        self.message = transDict[@"message"];
        self.errors = transDict[@"errors"];
        self.warnings = transDict[@"warnings"];
    }
    
    return self;
}


@end
